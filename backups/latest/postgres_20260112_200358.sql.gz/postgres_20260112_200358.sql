--
-- PostgreSQL database dump
--

\restrict FDVLamLPpw3tiALCk9EvVr34bQIVCXfnufdtXUCDm9tct5K4hsw5ooSWIvjllGg

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: analytics; Type: SCHEMA; Schema: -; Owner: appuser
--

CREATE SCHEMA analytics;


ALTER SCHEMA analytics OWNER TO appuser;

--
-- Name: author_clock; Type: SCHEMA; Schema: -; Owner: appuser
--

CREATE SCHEMA author_clock;


ALTER SCHEMA author_clock OWNER TO appuser;

--
-- Name: lotto; Type: SCHEMA; Schema: -; Owner: appuser
--

CREATE SCHEMA lotto;


ALTER SCHEMA lotto OWNER TO appuser;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: lotto; Owner: appuser
--

CREATE FUNCTION lotto.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION lotto.update_updated_at_column() OWNER TO appuser;

--
-- Name: cleanup_expired_sessions(); Type: FUNCTION; Schema: public; Owner: appuser
--

CREATE FUNCTION public.cleanup_expired_sessions() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM public.user_sessions
    WHERE expires_at < CURRENT_TIMESTAMP;
END;
$$;


ALTER FUNCTION public.cleanup_expired_sessions() OWNER TO appuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: daily_stats; Type: TABLE; Schema: analytics; Owner: appuser
--

CREATE TABLE analytics.daily_stats (
    id integer NOT NULL,
    project_id character varying(50) NOT NULL,
    date date NOT NULL,
    unique_visitors integer DEFAULT 0,
    total_page_views integer DEFAULT 0,
    new_users integer DEFAULT 0,
    returning_users integer DEFAULT 0,
    total_events integer DEFAULT 0,
    event_breakdown jsonb,
    total_api_calls integer DEFAULT 0,
    avg_response_time_ms numeric(10,2),
    error_count integer DEFAULT 0,
    error_rate numeric(5,2),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE analytics.daily_stats OWNER TO appuser;

--
-- Name: daily_stats_id_seq; Type: SEQUENCE; Schema: analytics; Owner: appuser
--

CREATE SEQUENCE analytics.daily_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE analytics.daily_stats_id_seq OWNER TO appuser;

--
-- Name: daily_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: analytics; Owner: appuser
--

ALTER SEQUENCE analytics.daily_stats_id_seq OWNED BY analytics.daily_stats.id;


--
-- Name: hourly_stats; Type: TABLE; Schema: analytics; Owner: appuser
--

CREATE TABLE analytics.hourly_stats (
    id integer NOT NULL,
    project_id character varying(50) NOT NULL,
    hour_timestamp timestamp without time zone NOT NULL,
    unique_visitors integer DEFAULT 0,
    page_views integer DEFAULT 0,
    api_calls integer DEFAULT 0,
    avg_response_time_ms numeric(10,2),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE analytics.hourly_stats OWNER TO appuser;

--
-- Name: hourly_stats_id_seq; Type: SEQUENCE; Schema: analytics; Owner: appuser
--

CREATE SEQUENCE analytics.hourly_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE analytics.hourly_stats_id_seq OWNER TO appuser;

--
-- Name: hourly_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: analytics; Owner: appuser
--

ALTER SEQUENCE analytics.hourly_stats_id_seq OWNED BY analytics.hourly_stats.id;


--
-- Name: project_metrics; Type: TABLE; Schema: analytics; Owner: appuser
--

CREATE TABLE analytics.project_metrics (
    project_id character varying(50) NOT NULL,
    total_users bigint DEFAULT 0,
    total_page_views bigint DEFAULT 0,
    total_events bigint DEFAULT 0,
    total_api_calls bigint DEFAULT 0,
    avg_session_duration_sec numeric(10,2),
    avg_pages_per_session numeric(10,2),
    bounce_rate numeric(5,2),
    last_activity_at timestamp without time zone,
    daily_active_users integer DEFAULT 0,
    weekly_active_users integer DEFAULT 0,
    monthly_active_users integer DEFAULT 0,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE analytics.project_metrics OWNER TO appuser;

--
-- Name: user_behavior; Type: TABLE; Schema: analytics; Owner: appuser
--

CREATE TABLE analytics.user_behavior (
    id bigint NOT NULL,
    project_id character varying(50) NOT NULL,
    session_id character varying(100) NOT NULL,
    from_page character varying(500),
    to_page character varying(500) NOT NULL,
    time_spent_sec integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    date date DEFAULT CURRENT_DATE
);


ALTER TABLE analytics.user_behavior OWNER TO appuser;

--
-- Name: user_behavior_id_seq; Type: SEQUENCE; Schema: analytics; Owner: appuser
--

CREATE SEQUENCE analytics.user_behavior_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE analytics.user_behavior_id_seq OWNER TO appuser;

--
-- Name: user_behavior_id_seq; Type: SEQUENCE OWNED BY; Schema: analytics; Owner: appuser
--

ALTER SEQUENCE analytics.user_behavior_id_seq OWNED BY analytics.user_behavior.id;


--
-- Name: anonymous_sessions; Type: TABLE; Schema: author_clock; Owner: appuser
--

CREATE TABLE author_clock.anonymous_sessions (
    id integer NOT NULL,
    session_id uuid NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    last_seen timestamp without time zone DEFAULT now()
);


ALTER TABLE author_clock.anonymous_sessions OWNER TO appuser;

--
-- Name: anonymous_sessions_id_seq; Type: SEQUENCE; Schema: author_clock; Owner: appuser
--

CREATE SEQUENCE author_clock.anonymous_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE author_clock.anonymous_sessions_id_seq OWNER TO appuser;

--
-- Name: anonymous_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: author_clock; Owner: appuser
--

ALTER SEQUENCE author_clock.anonymous_sessions_id_seq OWNED BY author_clock.anonymous_sessions.id;


--
-- Name: daily_quotes; Type: TABLE; Schema: author_clock; Owner: appuser
--

CREATE TABLE author_clock.daily_quotes (
    id integer NOT NULL,
    quote_id integer NOT NULL,
    date date NOT NULL,
    language character varying(10) DEFAULT 'ko'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE author_clock.daily_quotes OWNER TO appuser;

--
-- Name: TABLE daily_quotes; Type: COMMENT; Schema: author_clock; Owner: appuser
--

COMMENT ON TABLE author_clock.daily_quotes IS '일일 명언 기록 테이블 (날짜별로 고정된 명언 추적)';


--
-- Name: daily_quotes_id_seq; Type: SEQUENCE; Schema: author_clock; Owner: appuser
--

CREATE SEQUENCE author_clock.daily_quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE author_clock.daily_quotes_id_seq OWNER TO appuser;

--
-- Name: daily_quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: author_clock; Owner: appuser
--

ALTER SEQUENCE author_clock.daily_quotes_id_seq OWNED BY author_clock.daily_quotes.id;


--
-- Name: quotes; Type: TABLE; Schema: author_clock; Owner: appuser
--

CREATE TABLE author_clock.quotes (
    id integer NOT NULL,
    text text NOT NULL,
    author character varying(200) NOT NULL,
    source character varying(300),
    source_url text,
    language character varying(10) DEFAULT 'ko'::character varying NOT NULL,
    category character varying(50),
    is_public_domain boolean DEFAULT true,
    is_approved boolean DEFAULT true,
    submitted_by integer,
    likes_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT quotes_language_check CHECK (((language)::text = ANY ((ARRAY['ko'::character varying, 'en'::character varying, 'ja'::character varying, 'zh'::character varying, 'es'::character varying, 'fr'::character varying, 'de'::character varying])::text[]))),
    CONSTRAINT quotes_text_length CHECK ((length(text) <= 500))
);


ALTER TABLE author_clock.quotes OWNER TO appuser;

--
-- Name: TABLE quotes; Type: COMMENT; Schema: author_clock; Owner: appuser
--

COMMENT ON TABLE author_clock.quotes IS '명언 저장 테이블';


--
-- Name: COLUMN quotes.text; Type: COMMENT; Schema: author_clock; Owner: appuser
--

COMMENT ON COLUMN author_clock.quotes.text IS '명언 본문 (최대 500자)';


--
-- Name: COLUMN quotes.author; Type: COMMENT; Schema: author_clock; Owner: appuser
--

COMMENT ON COLUMN author_clock.quotes.author IS '저자명';


--
-- Name: COLUMN quotes.source; Type: COMMENT; Schema: author_clock; Owner: appuser
--

COMMENT ON COLUMN author_clock.quotes.source IS '출처 (책 제목, 작품명 등)';


--
-- Name: COLUMN quotes.language; Type: COMMENT; Schema: author_clock; Owner: appuser
--

COMMENT ON COLUMN author_clock.quotes.language IS '언어 코드 (ISO 639-1)';


--
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: author_clock; Owner: appuser
--

CREATE SEQUENCE author_clock.quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE author_clock.quotes_id_seq OWNER TO appuser;

--
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: author_clock; Owner: appuser
--

ALTER SEQUENCE author_clock.quotes_id_seq OWNED BY author_clock.quotes.id;


--
-- Name: translations; Type: TABLE; Schema: author_clock; Owner: appuser
--

CREATE TABLE author_clock.translations (
    id integer NOT NULL,
    quote_id integer NOT NULL,
    language character varying(10) NOT NULL,
    translated_text text NOT NULL,
    translated_by integer,
    is_auto_translation boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT translations_text_length CHECK ((length(translated_text) <= 500))
);


ALTER TABLE author_clock.translations OWNER TO appuser;

--
-- Name: TABLE translations; Type: COMMENT; Schema: author_clock; Owner: appuser
--

COMMENT ON TABLE author_clock.translations IS '명언 번역 테이블 (Phase 3에서 사용)';


--
-- Name: translations_id_seq; Type: SEQUENCE; Schema: author_clock; Owner: appuser
--

CREATE SEQUENCE author_clock.translations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE author_clock.translations_id_seq OWNER TO appuser;

--
-- Name: translations_id_seq; Type: SEQUENCE OWNED BY; Schema: author_clock; Owner: appuser
--

ALTER SEQUENCE author_clock.translations_id_seq OWNED BY author_clock.translations.id;


--
-- Name: user_bookmarks; Type: TABLE; Schema: author_clock; Owner: appuser
--

CREATE TABLE author_clock.user_bookmarks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    quote_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE author_clock.user_bookmarks OWNER TO appuser;

--
-- Name: user_bookmarks_id_seq; Type: SEQUENCE; Schema: author_clock; Owner: appuser
--

CREATE SEQUENCE author_clock.user_bookmarks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE author_clock.user_bookmarks_id_seq OWNER TO appuser;

--
-- Name: user_bookmarks_id_seq; Type: SEQUENCE OWNED BY; Schema: author_clock; Owner: appuser
--

ALTER SEQUENCE author_clock.user_bookmarks_id_seq OWNED BY author_clock.user_bookmarks.id;


--
-- Name: user_likes; Type: TABLE; Schema: author_clock; Owner: appuser
--

CREATE TABLE author_clock.user_likes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    quote_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE author_clock.user_likes OWNER TO appuser;

--
-- Name: TABLE user_likes; Type: COMMENT; Schema: author_clock; Owner: appuser
--

COMMENT ON TABLE author_clock.user_likes IS '사용자 좋아요 테이블 (Phase 2에서 사용)';


--
-- Name: user_likes_id_seq; Type: SEQUENCE; Schema: author_clock; Owner: appuser
--

CREATE SEQUENCE author_clock.user_likes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE author_clock.user_likes_id_seq OWNER TO appuser;

--
-- Name: user_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: author_clock; Owner: appuser
--

ALTER SEQUENCE author_clock.user_likes_id_seq OWNED BY author_clock.user_likes.id;


--
-- Name: users; Type: TABLE; Schema: author_clock; Owner: appuser
--

CREATE TABLE author_clock.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(100),
    preferred_language character varying(10) DEFAULT 'ko'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    last_login timestamp without time zone,
    is_active boolean DEFAULT true,
    CONSTRAINT users_email_format CHECK (((email)::text ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$'::text)),
    CONSTRAINT users_username_length CHECK ((length((username)::text) >= 3))
);


ALTER TABLE author_clock.users OWNER TO appuser;

--
-- Name: TABLE users; Type: COMMENT; Schema: author_clock; Owner: appuser
--

COMMENT ON TABLE author_clock.users IS '사용자 테이블 (Phase 2에서 사용)';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: author_clock; Owner: appuser
--

CREATE SEQUENCE author_clock.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE author_clock.users_id_seq OWNER TO appuser;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: author_clock; Owner: appuser
--

ALTER SEQUENCE author_clock.users_id_seq OWNED BY author_clock.users.id;


--
-- Name: draw_results; Type: TABLE; Schema: lotto; Owner: appuser
--

CREATE TABLE lotto.draw_results (
    draw_no integer NOT NULL,
    draw_date date NOT NULL,
    number1 integer NOT NULL,
    number2 integer NOT NULL,
    number3 integer NOT NULL,
    number4 integer NOT NULL,
    number5 integer NOT NULL,
    number6 integer NOT NULL,
    bonus_number integer NOT NULL,
    first_prize_winners integer,
    first_prize_amount bigint,
    total_prize_amount bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT draw_results_bonus_number_check CHECK (((bonus_number >= 1) AND (bonus_number <= 45))),
    CONSTRAINT draw_results_number1_check CHECK (((number1 >= 1) AND (number1 <= 45))),
    CONSTRAINT draw_results_number2_check CHECK (((number2 >= 1) AND (number2 <= 45))),
    CONSTRAINT draw_results_number3_check CHECK (((number3 >= 1) AND (number3 <= 45))),
    CONSTRAINT draw_results_number4_check CHECK (((number4 >= 1) AND (number4 <= 45))),
    CONSTRAINT draw_results_number5_check CHECK (((number5 >= 1) AND (number5 <= 45))),
    CONSTRAINT draw_results_number6_check CHECK (((number6 >= 1) AND (number6 <= 45)))
);


ALTER TABLE lotto.draw_results OWNER TO appuser;

--
-- Name: draws; Type: TABLE; Schema: lotto; Owner: appuser
--

CREATE TABLE lotto.draws (
    draw_no integer NOT NULL,
    draw_date date NOT NULL,
    num1 integer NOT NULL,
    num2 integer NOT NULL,
    num3 integer NOT NULL,
    num4 integer NOT NULL,
    num5 integer NOT NULL,
    num6 integer NOT NULL,
    bonus_num integer NOT NULL,
    first_win_amount bigint,
    first_win_count integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT draws_bonus_num_check CHECK (((bonus_num >= 1) AND (bonus_num <= 45))),
    CONSTRAINT draws_num1_check CHECK (((num1 >= 1) AND (num1 <= 45))),
    CONSTRAINT draws_num2_check CHECK (((num2 >= 1) AND (num2 <= 45))),
    CONSTRAINT draws_num3_check CHECK (((num3 >= 1) AND (num3 <= 45))),
    CONSTRAINT draws_num4_check CHECK (((num4 >= 1) AND (num4 <= 45))),
    CONSTRAINT draws_num5_check CHECK (((num5 >= 1) AND (num5 <= 45))),
    CONSTRAINT draws_num6_check CHECK (((num6 >= 1) AND (num6 <= 45)))
);


ALTER TABLE lotto.draws OWNER TO appuser;

--
-- Name: TABLE draws; Type: COMMENT; Schema: lotto; Owner: appuser
--

COMMENT ON TABLE lotto.draws IS '로또 당첨번호 추첨 결과';


--
-- Name: COLUMN draws.draw_no; Type: COMMENT; Schema: lotto; Owner: appuser
--

COMMENT ON COLUMN lotto.draws.draw_no IS '회차 번호 (Primary Key)';


--
-- Name: COLUMN draws.draw_date; Type: COMMENT; Schema: lotto; Owner: appuser
--

COMMENT ON COLUMN lotto.draws.draw_date IS '추첨일 (토요일)';


--
-- Name: COLUMN draws.bonus_num; Type: COMMENT; Schema: lotto; Owner: appuser
--

COMMENT ON COLUMN lotto.draws.bonus_num IS '보너스 번호';


--
-- Name: COLUMN draws.first_win_amount; Type: COMMENT; Schema: lotto; Owner: appuser
--

COMMENT ON COLUMN lotto.draws.first_win_amount IS '1등 당첨금액';


--
-- Name: COLUMN draws.first_win_count; Type: COMMENT; Schema: lotto; Owner: appuser
--

COMMENT ON COLUMN lotto.draws.first_win_count IS '1등 당첨자 수';


--
-- Name: generation_history; Type: TABLE; Schema: lotto; Owner: appuser
--

CREATE TABLE lotto.generation_history (
    id bigint NOT NULL,
    session_id character varying(100) NOT NULL,
    user_id character varying(100),
    algorithm character varying(50) NOT NULL,
    generated_numbers integer[] NOT NULL,
    analysis_data jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lotto.generation_history OWNER TO appuser;

--
-- Name: generation_history_id_seq; Type: SEQUENCE; Schema: lotto; Owner: appuser
--

CREATE SEQUENCE lotto.generation_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lotto.generation_history_id_seq OWNER TO appuser;

--
-- Name: generation_history_id_seq; Type: SEQUENCE OWNED BY; Schema: lotto; Owner: appuser
--

ALTER SEQUENCE lotto.generation_history_id_seq OWNED BY lotto.generation_history.id;


--
-- Name: statistics_cache; Type: TABLE; Schema: lotto; Owner: appuser
--

CREATE TABLE lotto.statistics_cache (
    cache_key character varying(100) NOT NULL,
    cache_data jsonb NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lotto.statistics_cache OWNER TO appuser;

--
-- Name: user_favorites; Type: TABLE; Schema: lotto; Owner: appuser
--

CREATE TABLE lotto.user_favorites (
    id bigint NOT NULL,
    user_id character varying(100) NOT NULL,
    numbers integer[] NOT NULL,
    nickname character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE lotto.user_favorites OWNER TO appuser;

--
-- Name: user_favorites_id_seq; Type: SEQUENCE; Schema: lotto; Owner: appuser
--

CREATE SEQUENCE lotto.user_favorites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE lotto.user_favorites_id_seq OWNER TO appuser;

--
-- Name: user_favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: lotto; Owner: appuser
--

ALTER SEQUENCE lotto.user_favorites_id_seq OWNED BY lotto.user_favorites.id;


--
-- Name: ai_service_status; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.ai_service_status (
    id integer NOT NULL,
    service_name character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    reason character varying(255),
    memory_usage_mb integer,
    total_memory_mb integer,
    memory_percent numeric(5,2),
    last_check timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auto_restart_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ai_service_status_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'paused'::character varying, 'stopped'::character varying])::text[])))
);


ALTER TABLE public.ai_service_status OWNER TO appuser;

--
-- Name: ai_service_status_id_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.ai_service_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ai_service_status_id_seq OWNER TO appuser;

--
-- Name: ai_service_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.ai_service_status_id_seq OWNED BY public.ai_service_status.id;


--
-- Name: analytics_events; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.analytics_events (
    id bigint NOT NULL,
    project_id character varying(50) NOT NULL,
    event_type character varying(50) NOT NULL,
    event_category character varying(50),
    event_name character varying(100) NOT NULL,
    event_value numeric(10,2),
    session_id character varying(100),
    user_id character varying(100),
    ip_address inet,
    user_agent text,
    page_url text,
    referrer text,
    device_type character varying(20),
    browser character varying(50),
    os character varying(50),
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    date date DEFAULT CURRENT_DATE NOT NULL
)
PARTITION BY RANGE (date);


ALTER TABLE public.analytics_events OWNER TO appuser;

--
-- Name: analytics_events_id_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.analytics_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.analytics_events_id_seq OWNER TO appuser;

--
-- Name: analytics_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.analytics_events_id_seq OWNED BY public.analytics_events.id;


--
-- Name: analytics_events_2025_10; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.analytics_events_2025_10 (
    id bigint DEFAULT nextval('public.analytics_events_id_seq'::regclass) NOT NULL,
    project_id character varying(50) NOT NULL,
    event_type character varying(50) NOT NULL,
    event_category character varying(50),
    event_name character varying(100) NOT NULL,
    event_value numeric(10,2),
    session_id character varying(100),
    user_id character varying(100),
    ip_address inet,
    user_agent text,
    page_url text,
    referrer text,
    device_type character varying(20),
    browser character varying(50),
    os character varying(50),
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    date date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.analytics_events_2025_10 OWNER TO appuser;

--
-- Name: analytics_events_2025_11; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.analytics_events_2025_11 (
    id bigint DEFAULT nextval('public.analytics_events_id_seq'::regclass) NOT NULL,
    project_id character varying(50) NOT NULL,
    event_type character varying(50) NOT NULL,
    event_category character varying(50),
    event_name character varying(100) NOT NULL,
    event_value numeric(10,2),
    session_id character varying(100),
    user_id character varying(100),
    ip_address inet,
    user_agent text,
    page_url text,
    referrer text,
    device_type character varying(20),
    browser character varying(50),
    os character varying(50),
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    date date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.analytics_events_2025_11 OWNER TO appuser;

--
-- Name: api_logs; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.api_logs (
    id bigint NOT NULL,
    project_id character varying(50) NOT NULL,
    method character varying(10) NOT NULL,
    endpoint character varying(500) NOT NULL,
    status_code integer NOT NULL,
    response_time_ms integer NOT NULL,
    ip_address inet,
    user_agent text,
    session_id character varying(100),
    user_id character varying(100),
    request_body jsonb,
    response_body jsonb,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    date date DEFAULT CURRENT_DATE NOT NULL
)
PARTITION BY RANGE (date);


ALTER TABLE public.api_logs OWNER TO appuser;

--
-- Name: api_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.api_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_logs_id_seq OWNER TO appuser;

--
-- Name: api_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.api_logs_id_seq OWNED BY public.api_logs.id;


--
-- Name: api_logs_2025_10; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.api_logs_2025_10 (
    id bigint DEFAULT nextval('public.api_logs_id_seq'::regclass) NOT NULL,
    project_id character varying(50) NOT NULL,
    method character varying(10) NOT NULL,
    endpoint character varying(500) NOT NULL,
    status_code integer NOT NULL,
    response_time_ms integer NOT NULL,
    ip_address inet,
    user_agent text,
    session_id character varying(100),
    user_id character varying(100),
    request_body jsonb,
    response_body jsonb,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    date date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.api_logs_2025_10 OWNER TO appuser;

--
-- Name: api_logs_2025_11; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.api_logs_2025_11 (
    id bigint DEFAULT nextval('public.api_logs_id_seq'::regclass) NOT NULL,
    project_id character varying(50) NOT NULL,
    method character varying(10) NOT NULL,
    endpoint character varying(500) NOT NULL,
    status_code integer NOT NULL,
    response_time_ms integer NOT NULL,
    ip_address inet,
    user_agent text,
    session_id character varying(100),
    user_id character varying(100),
    request_body jsonb,
    response_body jsonb,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    date date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.api_logs_2025_11 OWNER TO appuser;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.projects (
    id character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    display_name character varying(100) NOT NULL,
    emoji character varying(10),
    description text,
    category character varying(50),
    status character varying(20) DEFAULT 'active'::character varying,
    version character varying(20),
    url character varying(255),
    internal_url character varying(255),
    port integer,
    health_check_endpoint character varying(255),
    db_schema character varying(50),
    db_user character varying(50),
    tags text[],
    developer character varying(50),
    repository character varying(255),
    docs_path character varying(255),
    total_users integer DEFAULT 0,
    daily_active_users integer DEFAULT 0,
    total_requests bigint DEFAULT 0,
    avg_response_time_ms numeric(10,2),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    deployed_at timestamp without time zone,
    last_health_check timestamp without time zone,
    health_status character varying(20) DEFAULT 'unknown'::character varying,
    CONSTRAINT check_health_status CHECK (((health_status)::text = ANY ((ARRAY['healthy'::character varying, 'unhealthy'::character varying, 'unknown'::character varying])::text[]))),
    CONSTRAINT check_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'development'::character varying, 'maintenance'::character varying, 'archived'::character varying])::text[])))
);


ALTER TABLE public.projects OWNER TO appuser;

--
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.system_metrics (
    id bigint NOT NULL,
    project_id character varying(50) NOT NULL,
    metric_type character varying(50) NOT NULL,
    metric_name character varying(100) NOT NULL,
    value numeric(10,2) NOT NULL,
    unit character varying(20),
    metadata jsonb,
    collected_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    date date DEFAULT CURRENT_DATE NOT NULL
)
PARTITION BY RANGE (date);


ALTER TABLE public.system_metrics OWNER TO appuser;

--
-- Name: system_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: appuser
--

CREATE SEQUENCE public.system_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_metrics_id_seq OWNER TO appuser;

--
-- Name: system_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: appuser
--

ALTER SEQUENCE public.system_metrics_id_seq OWNED BY public.system_metrics.id;


--
-- Name: system_metrics_2025_10; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.system_metrics_2025_10 (
    id bigint DEFAULT nextval('public.system_metrics_id_seq'::regclass) NOT NULL,
    project_id character varying(50) NOT NULL,
    metric_type character varying(50) NOT NULL,
    metric_name character varying(100) NOT NULL,
    value numeric(10,2) NOT NULL,
    unit character varying(20),
    metadata jsonb,
    collected_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    date date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.system_metrics_2025_10 OWNER TO appuser;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: appuser
--

CREATE TABLE public.user_sessions (
    session_id character varying(100) NOT NULL,
    project_id character varying(50) NOT NULL,
    user_id character varying(100),
    ip_address inet,
    user_agent text,
    session_data jsonb,
    first_seen timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_seen timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    page_views integer DEFAULT 1,
    events_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp without time zone
);


ALTER TABLE public.user_sessions OWNER TO appuser;

--
-- Name: analytics_events_2025_10; Type: TABLE ATTACH; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.analytics_events ATTACH PARTITION public.analytics_events_2025_10 FOR VALUES FROM ('2025-10-01') TO ('2025-11-01');


--
-- Name: analytics_events_2025_11; Type: TABLE ATTACH; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.analytics_events ATTACH PARTITION public.analytics_events_2025_11 FOR VALUES FROM ('2025-11-01') TO ('2025-12-01');


--
-- Name: api_logs_2025_10; Type: TABLE ATTACH; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.api_logs ATTACH PARTITION public.api_logs_2025_10 FOR VALUES FROM ('2025-10-01') TO ('2025-11-01');


--
-- Name: api_logs_2025_11; Type: TABLE ATTACH; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.api_logs ATTACH PARTITION public.api_logs_2025_11 FOR VALUES FROM ('2025-11-01') TO ('2025-12-01');


--
-- Name: system_metrics_2025_10; Type: TABLE ATTACH; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.system_metrics ATTACH PARTITION public.system_metrics_2025_10 FOR VALUES FROM ('2025-10-01') TO ('2025-11-01');


--
-- Name: daily_stats id; Type: DEFAULT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.daily_stats ALTER COLUMN id SET DEFAULT nextval('analytics.daily_stats_id_seq'::regclass);


--
-- Name: hourly_stats id; Type: DEFAULT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.hourly_stats ALTER COLUMN id SET DEFAULT nextval('analytics.hourly_stats_id_seq'::regclass);


--
-- Name: user_behavior id; Type: DEFAULT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.user_behavior ALTER COLUMN id SET DEFAULT nextval('analytics.user_behavior_id_seq'::regclass);


--
-- Name: anonymous_sessions id; Type: DEFAULT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.anonymous_sessions ALTER COLUMN id SET DEFAULT nextval('author_clock.anonymous_sessions_id_seq'::regclass);


--
-- Name: daily_quotes id; Type: DEFAULT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.daily_quotes ALTER COLUMN id SET DEFAULT nextval('author_clock.daily_quotes_id_seq'::regclass);


--
-- Name: quotes id; Type: DEFAULT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.quotes ALTER COLUMN id SET DEFAULT nextval('author_clock.quotes_id_seq'::regclass);


--
-- Name: translations id; Type: DEFAULT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.translations ALTER COLUMN id SET DEFAULT nextval('author_clock.translations_id_seq'::regclass);


--
-- Name: user_bookmarks id; Type: DEFAULT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.user_bookmarks ALTER COLUMN id SET DEFAULT nextval('author_clock.user_bookmarks_id_seq'::regclass);


--
-- Name: user_likes id; Type: DEFAULT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.user_likes ALTER COLUMN id SET DEFAULT nextval('author_clock.user_likes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.users ALTER COLUMN id SET DEFAULT nextval('author_clock.users_id_seq'::regclass);


--
-- Name: generation_history id; Type: DEFAULT; Schema: lotto; Owner: appuser
--

ALTER TABLE ONLY lotto.generation_history ALTER COLUMN id SET DEFAULT nextval('lotto.generation_history_id_seq'::regclass);


--
-- Name: user_favorites id; Type: DEFAULT; Schema: lotto; Owner: appuser
--

ALTER TABLE ONLY lotto.user_favorites ALTER COLUMN id SET DEFAULT nextval('lotto.user_favorites_id_seq'::regclass);


--
-- Name: ai_service_status id; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.ai_service_status ALTER COLUMN id SET DEFAULT nextval('public.ai_service_status_id_seq'::regclass);


--
-- Name: analytics_events id; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.analytics_events ALTER COLUMN id SET DEFAULT nextval('public.analytics_events_id_seq'::regclass);


--
-- Name: api_logs id; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.api_logs ALTER COLUMN id SET DEFAULT nextval('public.api_logs_id_seq'::regclass);


--
-- Name: system_metrics id; Type: DEFAULT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.system_metrics ALTER COLUMN id SET DEFAULT nextval('public.system_metrics_id_seq'::regclass);


--
-- Data for Name: daily_stats; Type: TABLE DATA; Schema: analytics; Owner: appuser
--

COPY analytics.daily_stats (id, project_id, date, unique_visitors, total_page_views, new_users, returning_users, total_events, event_breakdown, total_api_calls, avg_response_time_ms, error_count, error_rate, created_at, updated_at) FROM stdin;
1	lotto-master	2025-10-20	0	12	0	0	26	{"test": 11, "pageview": 12, "generation": 3}	0	\N	0	0.00	2025-10-21 07:31:30.975139	2025-10-21 15:00:03.525228
2	today-fortune	2025-10-21	2	15	2	0	29	{"page_view": 15, "page_unload": 5, "tarot_drawn": 1, "fortune_generated": 7, "deployment_verification": 1}	0	\N	0	0.00	2025-10-21 07:31:40.53977	2025-10-22 15:00:03.231826
3	lotto-master	2025-10-21	1	12	1	0	54	{"pageview": 12, "generation": 42}	0	\N	0	0.00	2025-10-21 07:31:40.551221	2025-10-22 15:00:03.248686
7	today-fortune	2025-10-22	1	2	0	1	4	{"page_view": 2, "page_unload": 1, "fortune_generated": 1}	0	\N	0	0.00	2025-10-23 15:00:03.393103	2025-10-23 15:00:03.393103
8	lotto-master	2025-10-22	2	2	1	1	18	{"pageview": 2, "generation": 16}	0	\N	0	0.00	2025-10-23 15:00:03.446062	2025-10-23 15:00:03.446062
9	lotto-master	2025-10-28	1	4	0	1	10	{"pageview": 4, "generation": 6}	0	\N	0	0.00	2025-10-29 15:00:04.034446	2025-10-29 15:00:04.034446
10	lotto-master	2025-10-29	1	18	0	1	18	{"pageview": 18}	0	\N	0	0.00	2025-10-30 15:00:04.608401	2025-10-30 15:00:04.608401
11	lotto-master	2025-10-30	1	52	0	1	61	{"pageview": 52, "generation": 9}	0	\N	0	0.00	2025-10-31 15:00:03.640693	2025-10-31 15:00:03.640693
12	today-fortune	2025-11-02	1	2	1	0	2	{"page_view": 2}	0	\N	0	0.00	2025-11-03 15:00:05.149926	2025-11-03 15:00:05.149926
13	lotto-master	2025-11-02	2	25	2	0	29	{"pageview": 25, "generation": 4}	0	\N	0	0.00	2025-11-03 15:00:05.263697	2025-11-03 15:00:05.263697
14	lotto-master	2025-11-03	1	13	0	1	96	{"pageview": 13, "generation": 83}	0	\N	0	0.00	2025-11-04 15:00:03.403895	2025-11-04 15:00:03.403895
15	lotto-master	2025-11-04	1	3	0	1	3	{"pageview": 3}	0	\N	0	0.00	2025-11-05 15:00:03.781472	2025-11-05 15:00:03.781472
16	lotto-master	2025-11-05	1	2	0	1	2	{"pageview": 2}	0	\N	0	0.00	2025-11-06 15:00:03.564114	2025-11-06 15:00:03.564114
17	lotto-master	2025-11-06	1	1	0	1	115	{"pageview": 1, "generation": 114}	0	\N	0	0.00	2025-11-07 15:00:03.85946	2025-11-07 15:00:03.85946
18	lotto-master	2025-11-08	1	2	0	1	18	{"pageview": 2, "generation": 16}	0	\N	0	0.00	2025-11-09 15:00:06.504977	2025-11-09 15:00:06.504977
19	lotto-master	2025-11-09	1	6	0	1	6	{"pageview": 6}	0	\N	0	0.00	2025-11-10 15:00:05.815696	2025-11-10 15:00:05.815696
20	lotto-master	2025-11-12	1	9	1	0	12	{"pageview": 9, "generation": 3}	0	\N	0	0.00	2025-11-13 15:00:03.566517	2025-11-13 15:00:03.566517
21	today-fortune	2025-11-15	1	8	1	0	14	{"page_view": 8, "page_unload": 3, "tarot_drawn": 1, "fortune_generated": 2}	0	\N	0	0.00	2025-11-16 15:00:06.40644	2025-11-16 15:00:06.40644
22	lotto-master	2025-11-15	1	2	0	1	2	{"pageview": 2}	0	\N	0	0.00	2025-11-16 15:00:07.920112	2025-11-16 15:00:07.920112
23	lotto-master	2025-11-18	1	6	0	1	70	{"pageview": 6, "generation": 64}	0	\N	0	0.00	2025-11-19 15:00:04.175839	2025-11-19 15:00:04.175839
24	lotto-master	2025-11-23	1	11	0	1	11	{"pageview": 11}	0	\N	0	0.00	2025-11-24 15:00:04.339801	2025-11-24 15:00:04.339801
25	lotto-master	2025-11-24	1	5	0	1	25	{"pageview": 5, "generation": 20}	0	\N	0	0.00	2025-11-25 15:00:03.046806	2025-11-25 15:00:03.046806
26	lotto-master	2025-11-27	1	1	1	0	1	{"pageview": 1}	0	\N	0	0.00	2025-11-28 15:00:03.543981	2025-11-28 15:00:03.543981
\.


--
-- Data for Name: hourly_stats; Type: TABLE DATA; Schema: analytics; Owner: appuser
--

COPY analytics.hourly_stats (id, project_id, hour_timestamp, unique_visitors, page_views, api_calls, avg_response_time_ms, created_at) FROM stdin;
\.


--
-- Data for Name: project_metrics; Type: TABLE DATA; Schema: analytics; Owner: appuser
--

COPY analytics.project_metrics (project_id, total_users, total_page_views, total_events, total_api_calls, avg_session_duration_sec, avg_pages_per_session, bounce_rate, last_activity_at, daily_active_users, weekly_active_users, monthly_active_users, updated_at) FROM stdin;
\.


--
-- Data for Name: user_behavior; Type: TABLE DATA; Schema: analytics; Owner: appuser
--

COPY analytics.user_behavior (id, project_id, session_id, from_page, to_page, time_spent_sec, created_at, date) FROM stdin;
\.


--
-- Data for Name: anonymous_sessions; Type: TABLE DATA; Schema: author_clock; Owner: appuser
--

COPY author_clock.anonymous_sessions (id, session_id, user_id, created_at, last_seen) FROM stdin;
6	315e0f8f-665a-4564-8284-c80efc43f4ec	6	2026-01-09 04:07:07.069977	2026-01-09 04:07:07.069977
\.


--
-- Data for Name: daily_quotes; Type: TABLE DATA; Schema: author_clock; Owner: appuser
--

COPY author_clock.daily_quotes (id, quote_id, date, language, created_at) FROM stdin;
1	8	2025-10-31	ko	2025-10-31 05:39:01.657447
2	14	2025-11-02	ko	2025-11-02 01:08:26.833634
3	19	2025-11-03	ko	2025-11-03 00:42:16.165022
4	3	2025-11-27	ko	2025-11-27 03:07:24.100673
5	21	2026-01-09	ko	2026-01-09 04:07:07.880399
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: author_clock; Owner: appuser
--

COPY author_clock.quotes (id, text, author, source, source_url, language, category, is_public_domain, is_approved, submitted_by, likes_count, created_at, updated_at) FROM stdin;
31	While there's life, there's hope	Cicero	Tusculanae Disputationes	https://en.wikipedia.org/wiki/Tusculanae_Disputationes	en	philosophy	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
32	Knowledge is power	Francis Bacon	Meditationes Sacrae	https://en.wikipedia.org/wiki/Francis_Bacon	en	philosophy	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
33	To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment	Ralph Waldo Emerson	\N	https://en.wikipedia.org/wiki/Ralph_Waldo_Emerson	en	life	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
34	The only way to do great work is to love what you do	Steve Jobs	\N	https://en.wikipedia.org/wiki/Steve_Jobs	en	work	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
35	Life is what happens when you're busy making other plans	John Lennon	\N	https://en.wikipedia.org/wiki/John_Lennon	en	life	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
36	In the middle of difficulty lies opportunity	Albert Einstein	\N	https://en.wikipedia.org/wiki/Albert_Einstein	en	opportunity	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
37	Be the change that you wish to see in the world	Mahatma Gandhi	\N	https://en.wikipedia.org/wiki/Mahatma_Gandhi	en	change	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
38	The journey of a thousand miles begins with one step	Lao Tzu	Tao Te Ching	https://en.wikipedia.org/wiki/Tao_Te_Ching	en	wisdom	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
39	It does not matter how slowly you go as long as you do not stop	Confucius	\N	https://en.wikipedia.org/wiki/Confucius	en	perseverance	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
16	행복한 삶을 살기 위해서는 작은 것에 만족할 줄 알아야 한다	플라톤	\N	https://en.wikipedia.org/wiki/Plato	ko	philosophy	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
28	진정한 용기는 두려움을 느끼지 않는 것이 아니라 두려움을 이겨내는 것이다	넬슨 만델라	\N	https://en.wikipedia.org/wiki/Nelson_Mandela	ko	courage	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
5	평생 살 것처럼 꿈을 꾸어라. 오늘 죽을 것처럼 살아라	제임스 딘	\N	https://en.wikipedia.org/wiki/James_Dean	ko	life	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
30	위대한 일을 하려면 사랑하는 일을 해야 한다	스티브 잡스	\N	https://en.wikipedia.org/wiki/Steve_Jobs	ko	work	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
27	꿈을 계속 간직하고 있으면 반드시 실현할 때가 온다	괴테	\N	https://en.wikipedia.org/wiki/Johann_Wolfgang_von_Goethe	ko	dream	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
7	계단을 밟아야 계단 위에 올라설 수 있다	터키 속담	터키 속담	\N	ko	wisdom	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
6	절대 어제를 후회하지 마라. 인생은 오늘의 나 안에 있고 내일은 스스로 만드는 것이다	론 허버드	\N	https://en.wikipedia.org/wiki/L._Ron_Hubbard	ko	life	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
10	용기있는 자로 살아라. 운이 따라주지 않는다면 용기있는 가슴으로 불행에 맞서라	키케로	\N	https://en.wikipedia.org/wiki/Cicero	ko	philosophy	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
14	단순하게 살아라. 현대인은 쓸데없는 절차와 일 때문에 얼마나 복잡한 삶을 살아가는가?	이드리스 샤흐	\N	\N	ko	life	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
21	시작이 반이다	한국 속담	한국 속담	\N	ko	wisdom	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
2	아는 것이 힘이다	프랜시스 베이컨	명상록	https://en.wikipedia.org/wiki/Francis_Bacon	ko	philosophy	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
25	성공은 매일 반복한 작은 노력들의 합이다	로버트 콜리어	\N	\N	ko	success	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
24	좋은 책을 읽지 않는 사람은 책을 읽지 못하는 사람보다 나을 게 없다	마크 트웨인	\N	https://en.wikipedia.org/wiki/Mark_Twain	ko	learning	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
9	행복의 한 쪽 문이 닫히면 다른 쪽 문이 열린다. 그러나 우리는 닫힌 문을 오랫동안 보기 때문에 우리를 위해 열린 문을 보지 못한다	헬렌 켈러	\N	https://en.wikipedia.org/wiki/Helen_Keller	ko	life	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
19	당신이 할 수 있다고 믿든 할 수 없다고 믿든 믿는 대로 될 것이다	헨리 포드	\N	https://en.wikipedia.org/wiki/Henry_Ford	ko	motivation	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
22	말은 행동의 그림자다	데모크리토스	\N	https://en.wikipedia.org/wiki/Democritus	ko	philosophy	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
18	계속해서 앞으로 나아가는 것 말고는 성공의 비결이 없다	빌 게이츠	\N	https://en.wikipedia.org/wiki/Bill_Gates	ko	success	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
26	실패는 잊어라. 그러나 그것이 준 교훈은 절대 잊으면 안 된다	허버트 개서	\N	\N	ko	learning	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
11	중요한 것은 얼마나 오래 사느냐가 아니라 얼마나 잘 사느냐이다	세네카	\N	https://en.wikipedia.org/wiki/Seneca_the_Younger	ko	philosophy	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
13	피할 수 없으면 즐겨라	로버트 엘리엇	\N	\N	ko	life	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
1	삶이 있는 한 희망은 있다	키케로	투스쿨룸 대화	https://en.wikipedia.org/wiki/Tusculanae_Disputationes	ko	philosophy	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
17	절대 포기하지 말라. 당신이 되고 싶은 무언가가 있다면, 그에 대해 자부심을 가져라	무하마드 알리	\N	https://en.wikipedia.org/wiki/Muhammad_Ali	ko	motivation	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
3	행복은 습관이다. 그것을 몸에 지니라	허버드	\N	https://en.wikipedia.org/wiki/Elbert_Hubbard	ko	life	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
40	Everything you've ever wanted is on the other side of fear	George Addair	\N	\N	en	courage	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
41	Success is not final, failure is not fatal: it is the courage to continue that counts	Winston Churchill	\N	https://en.wikipedia.org/wiki/Winston_Churchill	en	success	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
42	Believe you can and you're halfway there	Theodore Roosevelt	\N	https://en.wikipedia.org/wiki/Theodore_Roosevelt	en	motivation	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
44	What lies behind us and what lies before us are tiny matters compared to what lies within us	Ralph Waldo Emerson	\N	https://en.wikipedia.org/wiki/Ralph_Waldo_Emerson	en	philosophy	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
45	The best time to plant a tree was 20 years ago. The second best time is now	Chinese Proverb	Chinese Proverb	\N	en	wisdom	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
46	An unexamined life is not worth living	Socrates	\N	https://en.wikipedia.org/wiki/Socrates	en	philosophy	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
47	Your time is limited, don't waste it living someone else's life	Steve Jobs	Stanford Commencement Speech	https://en.wikipedia.org/wiki/Steve_Jobs	en	life	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
48	If you judge a fish by its ability to climb a tree, it will live its whole life believing that it is stupid	Albert Einstein	\N	https://en.wikipedia.org/wiki/Albert_Einstein	en	wisdom	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
49	Tell me and I forget. Teach me and I remember. Involve me and I learn	Benjamin Franklin	\N	https://en.wikipedia.org/wiki/Benjamin_Franklin	en	learning	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
50	If winter comes, can spring be far behind?	Percy Bysshe Shelley	Ode to the West Wind	https://en.wikipedia.org/wiki/Ode_to_the_West_Wind	en	classic	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
12	신은 용기있는 자를 결코 버리지 않는다	켄러	\N	\N	ko	faith	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
29	당신의 시간은 제한되어 있다. 그러므로 다른 사람의 인생을 사느라 시간을 낭비하지 마라	스티브 잡스	스탠포드 졸업 연설	https://en.wikipedia.org/wiki/Steve_Jobs	ko	life	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
23	배움은 결코 정신을 지치게 하지 않는다	레오나르도 다 빈치	\N	https://en.wikipedia.org/wiki/Leonardo_da_Vinci	ko	learning	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
8	오늘 나를 위해 한 걸음을 걷지 않으면, 내일은 그 자리에 멈춰 서있는 자신을 보게 될 것이다	탈무드	탈무드	https://en.wikipedia.org/wiki/Talmud	ko	wisdom	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
4	고통이 남기고 간 뒤를 보라. 고난이 지나면 반드시 기쁨이 스며든다	괴테	파우스트	https://en.wikipedia.org/wiki/Goethe%27s_Faust	ko	classic	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
20	겨울이 오면 봄도 멀지 않으리	셸리	서풍에 부치는 노래	https://en.wikipedia.org/wiki/Ode_to_the_West_Wind	ko	classic	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
15	먼저 자신을 비웃어라. 다른 사람이 당신을 비웃기 전에	엘사 맥스웰	\N	\N	ko	humor	t	t	\N	0	2025-10-31 03:34:28.528641	2025-10-31 03:34:28.528641
43	The only impossible journey is the one you never begin	Tony Robbins	\N	\N	en	motivation	t	t	\N	0	2025-10-31 03:34:28.614999	2025-10-31 03:34:28.614999
\.


--
-- Data for Name: translations; Type: TABLE DATA; Schema: author_clock; Owner: appuser
--

COPY author_clock.translations (id, quote_id, language, translated_text, translated_by, is_auto_translation, created_at) FROM stdin;
\.


--
-- Data for Name: user_bookmarks; Type: TABLE DATA; Schema: author_clock; Owner: appuser
--

COPY author_clock.user_bookmarks (id, user_id, quote_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_likes; Type: TABLE DATA; Schema: author_clock; Owner: appuser
--

COPY author_clock.user_likes (id, user_id, quote_id, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: author_clock; Owner: appuser
--

COPY author_clock.users (id, username, email, password_hash, display_name, preferred_language, created_at, last_login, is_active) FROM stdin;
1	anon_bc4e007a	anon_bc4e007a@anonymous.local		Anonymous User	ko	2025-11-01 01:44:46.329673	\N	t
2	anon_550e8400	anon_550e8400@anonymous.local		Anonymous User	ko	2025-11-01 02:02:19.943698	\N	t
3	anon_7342472f	anon_7342472f@anonymous.local		Anonymous User	ko	2025-11-02 01:08:26.735683	\N	t
4	anon_a5b71b79	anon_a5b71b79@anonymous.local		Anonymous User	ko	2025-11-03 00:42:16.048113	\N	t
5	anon_505fbc93	anon_505fbc93@anonymous.local		Anonymous User	ko	2025-11-27 03:07:24.016641	\N	t
6	anon_315e0f8f	anon_315e0f8f@anonymous.local		Anonymous User	ko	2026-01-09 04:07:06.979463	\N	t
\.


--
-- Data for Name: draw_results; Type: TABLE DATA; Schema: lotto; Owner: appuser
--

COPY lotto.draw_results (draw_no, draw_date, number1, number2, number3, number4, number5, number6, bonus_number, first_prize_winners, first_prize_amount, total_prize_amount, created_at, updated_at) FROM stdin;
1	2002-12-07	10	23	29	33	37	40	16	\N	\N	\N	2025-10-29 06:53:49.824969	2025-10-29 07:45:17.154738
2	2002-12-14	9	13	21	25	32	42	2	1	2002006800	\N	2025-10-29 06:53:50.422236	2025-10-29 07:45:18.771484
3	2002-12-21	11	16	19	21	27	31	30	1	2000000000	\N	2025-10-29 06:53:50.931431	2025-10-29 07:45:19.281704
4	2002-12-28	14	27	30	31	40	42	2	\N	\N	\N	2025-10-29 06:53:51.624597	2025-10-29 07:45:20.069447
5	2003-01-04	16	24	29	40	41	42	3	\N	\N	\N	2025-10-29 06:53:52.133654	2025-10-29 07:45:20.579031
6	2003-01-11	14	15	26	27	40	42	34	1	6574451700	\N	2025-10-29 06:53:52.729317	2025-10-29 07:45:21.08929
7	2003-01-18	2	9	16	25	26	40	42	\N	\N	\N	2025-10-29 06:53:53.328091	2025-10-29 07:45:21.673637
8	2003-01-25	8	19	25	34	37	39	9	\N	\N	\N	2025-10-29 06:53:53.931953	2025-10-29 07:45:22.269575
9	2003-02-01	2	4	16	17	36	39	14	\N	\N	\N	2025-10-29 06:53:54.744919	2025-10-29 07:45:22.780762
10	2003-02-08	9	25	30	33	41	44	6	13	6430437900	\N	2025-10-29 06:53:55.339183	2025-10-29 07:45:23.291182
11	2003-02-15	1	7	36	37	41	42	14	5	4780152300	\N	2025-10-29 07:43:44.805308	2025-10-29 07:45:23.888008
12	2003-02-22	2	11	21	25	39	45	44	12	1348845700	\N	2025-10-29 07:43:45.396644	2025-10-29 07:45:24.480708
13	2003-03-01	22	23	25	37	38	42	26	\N	\N	\N	2025-10-29 07:43:45.914647	2025-10-29 07:45:24.990266
14	2003-03-08	2	6	12	31	33	40	15	4	9375048300	\N	2025-10-29 07:43:46.423303	2025-10-29 07:45:25.577963
15	2003-03-15	3	4	16	30	31	37	13	1	17014245000	\N	2025-10-29 07:43:46.93226	2025-10-29 07:45:26.086611
16	2003-03-22	6	7	24	37	38	40	33	4	4377146100	\N	2025-10-29 07:43:47.440787	2025-10-29 07:45:26.688351
17	2003-03-29	3	4	9	17	32	37	1	3	5349491200	\N	2025-10-29 07:43:47.949333	2025-10-29 07:45:27.198724
18	2003-04-05	3	12	13	19	32	35	29	\N	\N	\N	2025-10-29 07:43:48.460953	2025-10-29 07:45:27.784577
19	2003-04-12	6	30	38	39	40	43	26	1	40722959400	\N	2025-10-29 07:43:48.971113	2025-10-29 07:45:28.29377
20	2003-04-19	10	14	18	20	23	30	41	1	19352212800	\N	2025-10-29 07:43:49.48179	2025-10-29 07:45:28.887817
21	2003-04-26	6	12	17	18	31	32	21	23	797475400	\N	2025-10-29 07:45:29.59778	2025-10-29 07:45:29.59778
22	2003-05-03	4	5	6	8	17	39	25	4	4552194900	\N	2025-10-29 07:45:30.195677	2025-10-29 07:45:30.195677
23	2003-05-10	5	13	17	18	33	42	44	4	4317947700	\N	2025-10-29 07:45:30.706144	2025-10-29 07:45:30.706144
24	2003-05-17	7	8	27	29	36	43	6	\N	\N	\N	2025-10-29 07:45:31.40164	2025-10-29 07:45:31.40164
25	2003-05-24	2	4	21	26	43	44	16	2	24227745300	\N	2025-10-29 07:45:31.909893	2025-10-29 07:45:31.909893
26	2003-05-31	4	5	7	18	20	25	31	5	3495069900	\N	2025-10-29 07:45:32.418778	2025-10-29 07:45:32.418778
27	2003-06-07	1	20	26	28	37	43	27	2	9543982500	\N	2025-10-29 07:45:32.927364	2025-10-29 07:45:32.927364
28	2003-06-14	9	18	23	25	35	37	1	10	1700361100	\N	2025-10-29 07:45:33.436672	2025-10-29 07:45:33.436672
29	2003-06-21	1	5	13	34	39	40	11	5	3552594000	\N	2025-10-29 07:45:33.946076	2025-10-29 07:45:33.946076
30	2003-06-28	8	17	20	35	36	44	4	2	8728555500	\N	2025-10-29 07:45:34.45525	2025-10-29 07:45:34.45525
31	2003-07-05	7	9	18	23	28	35	32	2	8106672900	\N	2025-10-29 07:45:34.963919	2025-10-29 07:45:34.963919
32	2003-07-12	6	14	19	25	34	44	11	10	1634528300	\N	2025-10-29 07:45:35.472536	2025-10-29 07:45:35.472536
33	2003-07-19	4	7	32	33	40	41	9	1	14903517600	\N	2025-10-29 07:45:35.981884	2025-10-29 07:45:35.981884
34	2003-07-26	9	26	35	37	40	42	2	5	3056918000	\N	2025-10-29 07:45:36.495742	2025-10-29 07:45:36.495742
35	2003-08-02	2	3	11	26	37	43	39	3	5054598200	\N	2025-10-29 07:45:37.029205	2025-10-29 07:45:37.029205
36	2003-08-09	1	10	23	26	28	40	31	1	16014475800	\N	2025-10-29 07:45:37.540313	2025-10-29 07:45:37.540313
37	2003-08-16	7	27	30	33	35	37	42	3	4985999400	\N	2025-10-29 07:45:38.049843	2025-10-29 07:45:38.049843
38	2003-08-23	16	17	22	30	37	43	36	3	5374866400	\N	2025-10-29 07:45:38.558447	2025-10-29 07:45:38.558447
39	2003-08-30	6	7	13	15	21	43	8	6	2623748800	\N	2025-10-29 07:45:39.067255	2025-10-29 07:45:39.067255
40	2003-09-06	7	13	18	19	25	26	6	13	1147652400	\N	2025-10-29 07:45:39.619362	2025-10-29 07:45:39.619362
41	2003-09-13	13	20	23	35	38	43	34	\N	\N	\N	2025-10-29 07:45:40.127364	2025-10-29 07:45:40.127364
42	2003-09-20	17	18	19	21	23	32	1	6	6899280100	\N	2025-10-29 07:45:40.636281	2025-10-29 07:45:40.636281
43	2003-09-27	6	31	35	38	39	44	1	1	17749630800	\N	2025-10-29 07:45:41.145024	2025-10-29 07:45:41.145024
44	2003-10-04	3	11	21	30	38	45	39	5	3362155800	\N	2025-10-29 07:45:41.653845	2025-10-29 07:45:41.653845
45	2003-10-11	1	10	20	27	33	35	17	2	8356417800	\N	2025-10-29 07:45:42.162638	2025-10-29 07:45:42.162638
46	2003-10-18	8	13	15	23	31	38	39	3	5327758800	\N	2025-10-29 07:45:42.671679	2025-10-29 07:45:42.671679
47	2003-10-25	14	17	26	31	36	45	27	5	3250042400	\N	2025-10-29 07:45:43.180339	2025-10-29 07:45:43.180339
48	2003-11-01	6	10	18	26	37	38	3	6	2415673600	\N	2025-10-29 07:45:43.690354	2025-10-29 07:45:43.690354
49	2003-11-08	4	7	16	19	33	40	30	7	1967504600	\N	2025-10-29 07:45:44.19969	2025-10-29 07:45:44.19969
50	2003-11-15	2	10	12	15	22	44	1	3	5227061400	\N	2025-10-29 07:45:44.710601	2025-10-29 07:45:44.710601
51	2003-11-22	2	3	11	16	26	44	35	6	2421117000	\N	2025-10-29 07:45:45.219309	2025-10-29 07:45:45.219309
52	2003-11-29	2	4	15	16	20	29	1	4	3900844900	\N	2025-10-29 07:45:45.72771	2025-10-29 07:45:45.72771
53	2003-12-06	7	8	14	32	33	39	42	3	5014371000	\N	2025-10-29 07:45:46.236166	2025-10-29 07:45:46.236166
54	2003-12-13	1	8	21	27	36	39	37	3	5148626600	\N	2025-10-29 07:45:46.74785	2025-10-29 07:45:46.74785
55	2003-12-20	17	21	31	37	40	44	7	2	7088799600	\N	2025-10-29 07:45:47.256087	2025-10-29 07:45:47.256087
56	2003-12-27	10	14	30	31	33	37	19	4	3777570900	\N	2025-10-29 07:45:47.764957	2025-10-29 07:45:47.764957
57	2004-01-03	7	10	16	25	29	44	6	4	4114411900	\N	2025-10-29 07:45:48.273216	2025-10-29 07:45:48.273216
58	2004-01-10	10	24	25	33	40	44	1	4	3676429200	\N	2025-10-29 07:45:48.781231	2025-10-29 07:45:48.781231
59	2004-01-17	6	29	36	39	41	45	13	4	4127587300	\N	2025-10-29 07:45:49.289832	2025-10-29 07:45:49.289832
60	2004-01-24	2	8	25	36	39	42	11	7	2172504600	\N	2025-10-29 07:45:49.797948	2025-10-29 07:45:49.797948
61	2004-01-31	14	15	19	30	38	43	8	5	3541038800	\N	2025-10-29 07:45:50.305926	2025-10-29 07:45:50.305926
62	2004-02-07	3	8	15	27	29	35	21	1	15817286400	\N	2025-10-29 07:45:50.81801	2025-10-29 07:45:50.81801
63	2004-02-14	3	20	23	36	38	40	5	2	7922245500	\N	2025-10-29 07:45:51.326844	2025-10-29 07:45:51.326844
64	2004-02-21	14	15	18	21	26	36	39	4	3899818000	\N	2025-10-29 07:45:51.834876	2025-10-29 07:45:51.834876
65	2004-02-28	4	25	33	36	40	43	39	4	3727945800	\N	2025-10-29 07:45:52.346924	2025-10-29 07:45:52.346924
66	2004-03-06	2	3	7	17	22	24	45	4	3685138200	\N	2025-10-29 07:45:52.855041	2025-10-29 07:45:52.855041
67	2004-03-13	3	7	10	15	36	38	33	7	2114436500	\N	2025-10-29 07:45:53.363792	2025-10-29 07:45:53.363792
68	2004-03-20	10	12	15	16	26	39	38	5	2945882100	\N	2025-10-29 07:45:53.871884	2025-10-29 07:45:53.871884
69	2004-03-27	5	8	14	15	19	39	35	3	4962712200	\N	2025-10-29 07:45:54.380667	2025-10-29 07:45:54.380667
70	2004-04-03	5	19	22	25	28	43	26	3	5031277800	\N	2025-10-29 07:45:54.890068	2025-10-29 07:45:54.890068
71	2004-04-10	5	9	12	16	29	41	21	\N	\N	\N	2025-10-29 07:45:55.397941	2025-10-29 07:45:55.397941
72	2004-04-17	2	4	11	17	26	27	1	13	3260524600	\N	2025-10-29 07:45:55.906743	2025-10-29 07:45:55.906743
73	2004-04-24	3	12	18	32	40	43	38	6	2766662100	\N	2025-10-29 07:45:56.41523	2025-10-29 07:45:56.41523
74	2004-05-01	6	15	17	18	35	40	23	3	5284949800	\N	2025-10-29 07:45:56.926253	2025-10-29 07:45:56.926253
75	2004-05-08	2	5	24	32	34	44	28	4	3914616900	\N	2025-10-29 07:45:57.434914	2025-10-29 07:45:57.434914
76	2004-05-15	1	3	15	22	25	37	43	2	7451022600	\N	2025-10-29 07:45:57.942822	2025-10-29 07:45:57.942822
77	2004-05-22	2	18	29	32	43	44	37	3	5155758600	\N	2025-10-29 07:45:58.451865	2025-10-29 07:45:58.451865
78	2004-05-29	10	13	25	29	33	35	38	4	3519850000	\N	2025-10-29 07:45:58.960075	2025-10-29 07:45:58.960075
79	2004-06-05	3	12	24	27	30	32	14	4	3416443800	\N	2025-10-29 07:45:59.467812	2025-10-29 07:45:59.467812
80	2004-06-12	17	18	24	25	26	30	1	1	13809540000	\N	2025-10-29 07:45:59.976288	2025-10-29 07:45:59.976288
81	2004-06-19	5	7	11	13	20	33	6	5	2714288880	\N	2025-10-29 07:46:00.487219	2025-10-29 07:46:00.487219
82	2004-06-26	1	2	3	14	27	42	39	1	14562494400	\N	2025-10-29 07:46:00.996421	2025-10-29 07:46:00.996421
83	2004-07-03	6	10	15	17	19	34	14	2	7086948300	\N	2025-10-29 07:46:01.504114	2025-10-29 07:46:01.504114
84	2004-07-10	16	23	27	34	42	45	11	2	7669779000	\N	2025-10-29 07:46:02.012593	2025-10-29 07:46:02.012593
85	2004-07-17	6	8	13	23	31	36	21	4	3462109800	\N	2025-10-29 07:46:02.520738	2025-10-29 07:46:02.520738
86	2004-07-24	2	12	37	39	41	45	33	1	14252186400	\N	2025-10-29 07:46:03.029911	2025-10-29 07:46:03.029911
87	2004-07-31	4	12	16	23	34	43	26	11	1799358055	\N	2025-10-29 07:46:03.537366	2025-10-29 07:46:03.537366
88	2004-08-07	1	17	20	24	30	41	27	4	3069709650	\N	2025-10-29 07:46:04.046027	2025-10-29 07:46:04.046027
89	2004-08-14	4	26	28	29	33	40	37	3	4248321900	\N	2025-10-29 07:46:04.553726	2025-10-29 07:46:04.553726
90	2004-08-21	17	20	29	35	38	44	10	4	3291435300	\N	2025-10-29 07:46:05.06312	2025-10-29 07:46:05.06312
91	2004-08-28	1	21	24	26	29	42	27	4	3582902400	\N	2025-10-29 07:46:05.571185	2025-10-29 07:46:05.571185
92	2004-09-04	3	14	24	33	35	36	17	11	1233270846	\N	2025-10-29 07:46:06.078986	2025-10-29 07:46:06.078986
93	2004-09-11	6	22	24	36	38	44	19	6	2269178150	\N	2025-10-29 07:46:06.588651	2025-10-29 07:46:06.588651
94	2004-09-18	5	32	34	40	41	45	6	6	2245339950	\N	2025-10-29 07:46:07.100277	2025-10-29 07:46:07.100277
95	2004-09-25	8	17	27	31	34	43	14	8	1747741238	\N	2025-10-29 07:46:07.608058	2025-10-29 07:46:07.608058
96	2004-10-02	1	3	8	21	22	31	20	7	1847133515	\N	2025-10-29 07:46:08.117068	2025-10-29 07:46:08.117068
97	2004-10-09	6	7	14	15	20	36	3	9	1496214000	\N	2025-10-29 07:46:08.624438	2025-10-29 07:46:08.624438
98	2004-10-16	6	9	16	23	24	32	43	4	3177972300	\N	2025-10-29 07:46:09.132237	2025-10-29 07:46:09.132237
99	2004-10-23	1	3	10	27	29	37	11	6	2169219050	\N	2025-10-29 07:46:09.639881	2025-10-29 07:46:09.639881
100	2004-10-30	1	7	11	23	37	42	6	4	3315315525	\N	2025-10-29 07:46:10.148775	2025-10-29 07:46:10.148775
101	2004-11-06	1	3	17	32	35	45	8	5	2707297500	\N	2025-10-29 07:46:15.719336	2025-10-29 07:46:15.719336
102	2004-11-13	17	22	24	26	35	40	42	9	1457153067	\N	2025-10-29 07:46:16.228066	2025-10-29 07:46:16.228066
103	2004-11-20	5	14	15	27	30	45	10	8	1691589563	\N	2025-10-29 07:46:16.739883	2025-10-29 07:46:16.739883
104	2004-11-27	17	32	33	34	42	44	35	2	6610743750	\N	2025-10-29 07:46:17.249106	2025-10-29 07:46:17.249106
105	2004-12-04	8	10	20	34	41	45	28	4	3416781450	\N	2025-10-29 07:46:17.757184	2025-10-29 07:46:17.757184
106	2004-12-11	4	10	12	22	24	33	29	16	810461157	\N	2025-10-29 07:46:18.267785	2025-10-29 07:46:18.267785
107	2004-12-18	1	4	5	6	9	31	17	2	6679927800	\N	2025-10-29 07:46:18.776693	2025-10-29 07:46:18.776693
108	2004-12-25	7	18	22	23	29	44	12	7	1998900772	\N	2025-10-29 07:46:19.286457	2025-10-29 07:46:19.286457
109	2005-01-01	1	5	34	36	42	44	33	12	1246838200	\N	2025-10-29 07:46:19.794821	2025-10-29 07:46:19.794821
110	2005-01-08	7	20	22	23	29	43	1	3	4566262000	\N	2025-10-29 07:46:20.30293	2025-10-29 07:46:20.30293
111	2005-01-15	7	18	31	33	36	40	27	6	2199047450	\N	2025-10-29 07:46:20.810774	2025-10-29 07:46:20.810774
112	2005-01-22	26	29	30	33	41	42	43	9	1567271167	\N	2025-10-29 07:46:21.319685	2025-10-29 07:46:21.319685
113	2005-01-29	4	9	28	33	36	45	26	9	1561528934	\N	2025-10-29 07:46:21.829162	2025-10-29 07:46:21.829162
114	2005-02-05	11	14	19	26	28	41	2	6	2362345050	\N	2025-10-29 07:46:22.340678	2025-10-29 07:46:22.340678
115	2005-02-12	1	2	6	9	25	28	31	9	1488589567	\N	2025-10-29 07:46:22.850046	2025-10-29 07:46:22.850046
116	2005-02-19	2	4	25	31	34	37	17	7	1997747315	\N	2025-10-29 07:46:23.358204	2025-10-29 07:46:23.358204
117	2005-02-26	5	10	22	34	36	44	35	9	1558378334	\N	2025-10-29 07:46:23.86675	2025-10-29 07:46:23.86675
118	2005-03-05	3	4	10	17	19	22	38	10	1297989720	\N	2025-10-29 07:46:24.37618	2025-10-29 07:46:24.37618
119	2005-03-12	3	11	13	14	17	21	38	9	1474899400	\N	2025-10-29 07:46:24.884452	2025-10-29 07:46:24.884452
120	2005-03-19	4	6	10	11	32	37	30	3	4364530300	\N	2025-10-29 07:46:25.393092	2025-10-29 07:46:25.393092
121	2005-03-26	12	28	30	34	38	43	9	2	6839648100	\N	2025-10-29 07:46:25.901142	2025-10-29 07:46:25.901142
122	2005-04-02	1	11	16	17	36	40	8	9	1450073800	\N	2025-10-29 07:46:26.410122	2025-10-29 07:46:26.410122
123	2005-04-09	7	17	18	28	30	45	27	5	2532982680	\N	2025-10-29 07:46:26.919233	2025-10-29 07:46:26.919233
124	2005-04-16	4	16	23	25	29	42	1	9	1395936267	\N	2025-10-29 07:46:27.432805	2025-10-29 07:46:27.432805
125	2005-04-23	2	8	32	33	35	36	18	7	1754870786	\N	2025-10-29 07:46:27.940373	2025-10-29 07:46:27.940373
126	2005-04-30	7	20	22	27	40	43	1	9	1369301500	\N	2025-10-29 07:46:28.448704	2025-10-29 07:46:28.448704
127	2005-05-07	3	5	10	29	32	43	35	6	1965939150	\N	2025-10-29 07:46:28.958351	2025-10-29 07:46:28.958351
128	2005-05-14	12	30	34	36	37	45	39	6	2064043100	\N	2025-10-29 07:46:29.466458	2025-10-29 07:46:29.466458
129	2005-05-21	19	23	25	28	38	42	17	11	1093629655	\N	2025-10-29 07:46:29.974514	2025-10-29 07:46:29.974514
130	2005-05-28	7	19	24	27	42	45	31	4	3036496650	\N	2025-10-29 07:46:30.482621	2025-10-29 07:46:30.482621
131	2005-06-04	8	10	11	14	15	21	37	8	1451214488	\N	2025-10-29 07:46:30.990485	2025-10-29 07:46:30.990485
132	2005-06-11	3	17	23	34	41	45	43	4	2920473525	\N	2025-10-29 07:46:31.531728	2025-10-29 07:46:31.531728
133	2005-06-18	4	7	15	18	23	26	13	8	1450242600	\N	2025-10-29 07:46:32.040951	2025-10-29 07:46:32.040951
134	2005-06-25	3	12	20	23	31	35	43	5	2349155100	\N	2025-10-29 07:46:32.549287	2025-10-29 07:46:32.549287
135	2005-07-02	6	14	22	28	35	39	16	7	1717293515	\N	2025-10-29 07:46:33.057608	2025-10-29 07:46:33.057608
136	2005-07-09	2	16	30	36	41	42	11	6	1997694150	\N	2025-10-29 07:46:33.571668	2025-10-29 07:46:33.571668
137	2005-07-16	7	9	20	25	36	39	15	9	1270403467	\N	2025-10-29 07:46:34.081	2025-10-29 07:46:34.081
138	2005-07-23	10	11	27	28	37	39	19	5	2227152000	\N	2025-10-29 07:46:34.589818	2025-10-29 07:46:34.589818
139	2005-07-30	9	11	15	20	28	43	13	7	1650210215	\N	2025-10-29 07:46:35.098517	2025-10-29 07:46:35.098517
140	2005-08-06	3	13	17	18	19	28	8	5	2109462840	\N	2025-10-29 07:46:35.606624	2025-10-29 07:46:35.606624
141	2005-08-13	8	12	29	31	42	43	2	6	1900552400	\N	2025-10-29 07:46:36.116656	2025-10-29 07:46:36.116656
142	2005-08-20	12	16	30	34	40	44	19	11	1018265564	\N	2025-10-29 07:46:36.628347	2025-10-29 07:46:36.628347
143	2005-08-27	26	27	28	42	43	45	8	3	3954584700	\N	2025-10-29 07:46:37.143213	2025-10-29 07:46:37.143213
144	2005-09-03	4	15	17	26	36	37	43	8	1402440413	\N	2025-10-29 07:46:37.651143	2025-10-29 07:46:37.651143
145	2005-09-10	2	3	13	20	27	44	9	3	3797838200	\N	2025-10-29 07:46:38.159693	2025-10-29 07:46:38.159693
146	2005-09-17	2	19	27	35	41	42	25	2	6043415250	\N	2025-10-29 07:46:38.669622	2025-10-29 07:46:38.669622
147	2005-09-24	4	6	13	21	40	42	36	7	1700040215	\N	2025-10-29 07:46:39.178479	2025-10-29 07:46:39.178479
148	2005-10-01	21	25	33	34	35	36	17	5	2323596420	\N	2025-10-29 07:46:39.685782	2025-10-29 07:46:39.685782
149	2005-10-08	2	11	21	34	41	42	27	7	1639052143	\N	2025-10-29 07:46:40.194349	2025-10-29 07:46:40.194349
150	2005-10-15	2	18	25	28	37	39	16	4	2831645850	\N	2025-10-29 07:46:40.702422	2025-10-29 07:46:40.702422
151	2005-10-22	1	2	10	13	18	19	15	4	2716634025	\N	2025-10-29 07:46:41.209882	2025-10-29 07:46:41.209882
152	2005-10-29	1	5	13	26	29	34	43	5	2278131840	\N	2025-10-29 07:46:41.717793	2025-10-29 07:46:41.717793
153	2005-11-05	3	8	11	12	13	36	33	4	2730526125	\N	2025-10-29 07:46:42.228194	2025-10-29 07:46:42.228194
154	2005-11-12	6	19	21	35	40	45	20	4	2836628700	\N	2025-10-29 07:46:42.738018	2025-10-29 07:46:42.738018
155	2005-11-19	16	19	20	32	33	41	4	9	1193005734	\N	2025-10-29 07:46:43.259842	2025-10-29 07:46:43.259842
156	2005-11-26	5	18	28	30	42	45	2	8	1401099900	\N	2025-10-29 07:46:43.79385	2025-10-29 07:46:43.79385
157	2005-12-03	19	26	30	33	35	39	37	2	5484903750	\N	2025-10-29 07:46:44.302139	2025-10-29 07:46:44.302139
158	2005-12-10	4	9	13	18	21	34	7	10	1069544340	\N	2025-10-29 07:46:44.812262	2025-10-29 07:46:44.812262
159	2005-12-17	1	18	30	41	42	43	32	6	1755407300	\N	2025-10-29 07:46:45.321387	2025-10-29 07:46:45.321387
160	2005-12-24	3	7	8	34	39	41	1	2	5490805350	\N	2025-10-29 07:46:45.829498	2025-10-29 07:46:45.829498
161	2005-12-31	22	34	36	40	42	45	44	7	1996876272	\N	2025-10-29 07:46:46.338291	2025-10-29 07:46:46.338291
162	2006-01-07	1	5	21	25	38	41	24	5	2308265760	\N	2025-10-29 07:46:46.847582	2025-10-29 07:46:46.847582
163	2006-01-14	7	11	26	28	29	44	16	7	1629726515	\N	2025-10-29 07:46:47.357182	2025-10-29 07:46:47.357182
164	2006-01-21	6	9	10	11	39	41	27	3	4054937900	\N	2025-10-29 07:46:47.865638	2025-10-29 07:46:47.865638
165	2006-01-28	5	13	18	19	22	42	31	2	6767426700	\N	2025-10-29 07:46:48.374554	2025-10-29 07:46:48.374554
166	2006-02-04	9	12	27	36	39	45	14	11	1111299982	\N	2025-10-29 07:46:48.882555	2025-10-29 07:46:48.882555
167	2006-02-11	24	27	28	30	36	39	4	5	2491222920	\N	2025-10-29 07:46:49.391156	2025-10-29 07:46:49.391156
168	2006-02-18	3	10	31	40	42	43	30	5	2349946920	\N	2025-10-29 07:46:49.900412	2025-10-29 07:46:49.900412
169	2006-02-25	16	27	35	37	43	45	19	5	2482888380	\N	2025-10-29 07:46:50.408112	2025-10-29 07:46:50.408112
170	2006-03-04	2	11	13	15	31	42	10	6	1923108250	\N	2025-10-29 07:46:50.915512	2025-10-29 07:46:50.915512
171	2006-03-11	4	16	25	29	34	35	1	6	1961339700	\N	2025-10-29 07:46:51.423846	2025-10-29 07:46:51.423846
172	2006-03-18	4	19	21	24	26	41	35	11	1081154073	\N	2025-10-29 07:46:51.932593	2025-10-29 07:46:51.932593
173	2006-03-25	3	9	24	30	33	34	18	8	1487736788	\N	2025-10-29 07:46:52.440471	2025-10-29 07:46:52.440471
174	2006-04-01	13	14	18	22	35	39	16	7	1771103058	\N	2025-10-29 07:46:52.949777	2025-10-29 07:46:52.949777
175	2006-04-08	19	26	28	31	33	36	17	5	2371132620	\N	2025-10-29 07:46:53.459633	2025-10-29 07:46:53.459633
176	2006-04-15	4	17	30	32	33	34	15	5	2314663080	\N	2025-10-29 07:46:53.968416	2025-10-29 07:46:53.968416
177	2006-04-22	1	10	13	16	37	43	6	7	1693285500	\N	2025-10-29 07:46:54.476514	2025-10-29 07:46:54.476514
178	2006-04-29	1	5	11	12	18	23	9	5	2254621080	\N	2025-10-29 07:46:54.984005	2025-10-29 07:46:54.984005
179	2006-05-06	5	9	17	25	39	43	32	10	1081093920	\N	2025-10-29 07:46:55.492386	2025-10-29 07:46:55.492386
180	2006-05-13	2	15	20	21	29	34	22	2	5763371550	\N	2025-10-29 07:46:55.999943	2025-10-29 07:46:55.999943
181	2006-05-20	14	21	23	32	40	45	44	6	1941763300	\N	2025-10-29 07:46:56.508615	2025-10-29 07:46:56.508615
182	2006-05-27	13	15	27	29	34	40	35	3	3721439400	\N	2025-10-29 07:46:57.018602	2025-10-29 07:46:57.018602
183	2006-06-03	2	18	24	34	40	42	5	6	1777221500	\N	2025-10-29 07:46:57.526502	2025-10-29 07:46:57.526502
184	2006-06-10	1	2	6	16	20	33	41	6	1747753050	\N	2025-10-29 07:46:58.037564	2025-10-29 07:46:58.037564
185	2006-06-17	1	2	4	8	19	38	14	3	3522485800	\N	2025-10-29 07:46:58.546902	2025-10-29 07:46:58.546902
186	2006-06-24	4	10	14	19	21	45	9	9	1187882600	\N	2025-10-29 07:46:59.054645	2025-10-29 07:46:59.054645
187	2006-07-01	1	2	8	18	29	38	42	7	1544733900	\N	2025-10-29 07:46:59.56379	2025-10-29 07:46:59.56379
188	2006-07-08	19	24	27	30	31	34	36	3	3501405200	\N	2025-10-29 07:47:00.074568	2025-10-29 07:47:00.074568
189	2006-07-15	8	14	32	35	37	45	28	3	3461775100	\N	2025-10-29 07:47:00.583863	2025-10-29 07:47:00.583863
190	2006-07-22	8	14	18	30	31	44	15	6	1784159450	\N	2025-10-29 07:47:01.09168	2025-10-29 07:47:01.09168
191	2006-07-29	5	6	24	25	32	37	8	4	2577114675	\N	2025-10-29 07:47:01.600706	2025-10-29 07:47:01.600706
192	2006-08-05	4	8	11	18	37	45	33	4	2445348375	\N	2025-10-29 07:47:02.110985	2025-10-29 07:47:02.110985
193	2006-08-12	6	14	18	26	36	39	13	3	3404449700	\N	2025-10-29 07:47:02.619149	2025-10-29 07:47:02.619149
194	2006-08-19	15	20	23	26	39	44	28	4	2650567875	\N	2025-10-29 07:47:03.127905	2025-10-29 07:47:03.127905
195	2006-08-26	7	10	19	22	35	40	31	11	918992591	\N	2025-10-29 07:47:03.636183	2025-10-29 07:47:03.636183
196	2006-09-02	35	36	37	41	44	45	30	15	727876520	\N	2025-10-29 07:47:04.145035	2025-10-29 07:47:04.145035
197	2006-09-09	7	12	16	34	42	45	4	6	1803018300	\N	2025-10-29 07:47:04.653353	2025-10-29 07:47:04.653353
198	2006-09-16	12	19	20	25	41	45	2	6	1797855050	\N	2025-10-29 07:47:05.161595	2025-10-29 07:47:05.161595
199	2006-09-23	14	21	22	25	30	36	43	2	5344252200	\N	2025-10-29 07:47:05.6751	2025-10-29 07:47:05.6751
200	2006-09-30	5	6	13	14	17	20	7	8	1344616613	\N	2025-10-29 07:47:06.182851	2025-10-29 07:47:06.182851
201	2006-10-07	3	11	24	38	39	44	26	1	9719465400	\N	2025-10-29 07:47:11.728295	2025-10-29 07:47:11.728295
202	2006-10-14	12	14	27	33	39	44	17	6	1893391700	\N	2025-10-29 07:47:12.240866	2025-10-29 07:47:12.240866
203	2006-10-21	1	3	11	24	30	32	7	5	2164564740	\N	2025-10-29 07:47:12.749255	2025-10-29 07:47:12.749255
204	2006-10-28	3	12	14	35	40	45	5	8	1358347125	\N	2025-10-29 07:47:13.257424	2025-10-29 07:47:13.257424
205	2006-11-04	1	3	21	29	35	37	30	6	1835221800	\N	2025-10-29 07:47:13.765418	2025-10-29 07:47:13.765418
206	2006-11-11	1	2	3	15	20	25	43	5	2032859340	\N	2025-10-29 07:47:14.273577	2025-10-29 07:47:14.273577
207	2006-11-18	3	11	14	31	32	37	38	5	2104673760	\N	2025-10-29 07:47:14.784221	2025-10-29 07:47:14.784221
208	2006-11-25	14	25	31	34	40	44	24	6	1760767400	\N	2025-10-29 07:47:15.291886	2025-10-29 07:47:15.291886
209	2006-12-02	2	7	18	20	24	33	37	6	1660896350	\N	2025-10-29 07:47:15.800791	2025-10-29 07:47:15.800791
210	2006-12-09	10	19	22	23	25	37	39	2	5139085950	\N	2025-10-29 07:47:16.308689	2025-10-29 07:47:16.308689
211	2006-12-16	12	13	17	20	33	41	8	10	1035800250	\N	2025-10-29 07:47:16.818341	2025-10-29 07:47:16.818341
212	2006-12-23	11	12	18	21	31	38	8	4	2660747250	\N	2025-10-29 07:47:17.327898	2025-10-29 07:47:17.327898
213	2006-12-30	2	3	4	5	20	24	42	8	1376678025	\N	2025-10-29 07:47:17.837219	2025-10-29 07:47:17.837219
214	2007-01-06	5	7	20	25	28	37	32	8	1406980875	\N	2025-10-29 07:47:18.345391	2025-10-29 07:47:18.345391
215	2007-01-13	2	3	7	15	43	44	4	7	1587689615	\N	2025-10-29 07:47:18.853534	2025-10-29 07:47:18.853534
216	2007-01-20	7	16	17	33	36	40	1	13	848506108	\N	2025-10-29 07:47:19.362724	2025-10-29 07:47:19.362724
217	2007-01-27	16	20	27	33	35	39	38	7	1611246172	\N	2025-10-29 07:47:19.871327	2025-10-29 07:47:19.871327
218	2007-02-03	1	8	14	18	29	44	20	4	2779075800	\N	2025-10-29 07:47:20.381772	2025-10-29 07:47:20.381772
219	2007-02-10	4	11	20	26	35	37	16	9	1208409167	\N	2025-10-29 07:47:20.890084	2025-10-29 07:47:20.890084
220	2007-02-17	5	11	19	21	34	43	31	6	1958094950	\N	2025-10-29 07:47:21.398582	2025-10-29 07:47:21.398582
221	2007-02-24	2	20	33	35	37	40	10	6	1800104250	\N	2025-10-29 07:47:21.908185	2025-10-29 07:47:21.908185
222	2007-03-03	5	7	28	29	39	43	44	5	2275193820	\N	2025-10-29 07:47:22.416985	2025-10-29 07:47:22.416985
223	2007-03-10	1	3	18	20	26	27	38	7	1498170600	\N	2025-10-29 07:47:22.925719	2025-10-29 07:47:22.925719
224	2007-03-17	4	19	26	27	30	42	7	6	1808969950	\N	2025-10-29 07:47:23.434349	2025-10-29 07:47:23.434349
225	2007-03-24	5	11	13	19	31	36	7	6	1777201800	\N	2025-10-29 07:47:23.942605	2025-10-29 07:47:23.942605
226	2007-03-31	2	6	8	14	21	22	34	6	1744100150	\N	2025-10-29 07:47:24.452209	2025-10-29 07:47:24.452209
227	2007-04-07	4	5	15	16	22	42	2	2	5253542400	\N	2025-10-29 07:47:24.960544	2025-10-29 07:47:24.960544
228	2007-04-14	17	25	35	36	39	44	23	9	1146700334	\N	2025-10-29 07:47:25.471321	2025-10-29 07:47:25.471321
229	2007-04-21	4	5	9	11	23	38	35	7	1451441100	\N	2025-10-29 07:47:25.979409	2025-10-29 07:47:25.979409
230	2007-04-28	5	11	14	29	32	33	12	8	1292929163	\N	2025-10-29 07:47:26.491514	2025-10-29 07:47:26.491514
231	2007-05-05	5	10	19	31	44	45	27	9	1088365900	\N	2025-10-29 07:47:27.000566	2025-10-29 07:47:27.000566
232	2007-05-12	8	9	10	12	24	44	35	9	1110918400	\N	2025-10-29 07:47:27.511037	2025-10-29 07:47:27.511037
233	2007-05-19	4	6	13	17	28	40	39	10	999153750	\N	2025-10-29 07:47:28.020057	2025-10-29 07:47:28.020057
234	2007-05-26	13	21	22	24	26	37	4	4	2519743875	\N	2025-10-29 07:47:28.527891	2025-10-29 07:47:28.527891
235	2007-06-02	21	22	26	27	31	37	8	3	3433330100	\N	2025-10-29 07:47:29.034997	2025-10-29 07:47:29.034997
236	2007-06-09	1	4	8	13	37	39	7	2	5030040150	\N	2025-10-29 07:47:29.543489	2025-10-29 07:47:29.543489
237	2007-06-16	1	11	17	21	24	44	33	7	1440630729	\N	2025-10-29 07:47:30.051384	2025-10-29 07:47:30.051384
238	2007-06-23	2	4	15	28	31	34	35	9	1121660567	\N	2025-10-29 07:47:30.563526	2025-10-29 07:47:30.563526
239	2007-06-30	11	15	24	39	41	44	7	9	1134140167	\N	2025-10-29 07:47:31.071521	2025-10-29 07:47:31.071521
240	2007-07-07	6	10	16	40	41	43	21	2	5098251450	\N	2025-10-29 07:47:31.579927	2025-10-29 07:47:31.579927
241	2007-07-14	2	16	24	27	28	35	21	4	2552016300	\N	2025-10-29 07:47:32.089134	2025-10-29 07:47:32.089134
242	2007-07-21	4	19	20	21	32	34	43	8	1234542375	\N	2025-10-29 07:47:32.598335	2025-10-29 07:47:32.598335
243	2007-07-28	2	12	17	19	28	42	34	4	2408850000	\N	2025-10-29 07:47:33.1078	2025-10-29 07:47:33.1078
244	2007-08-04	13	16	25	36	37	38	19	1	9121583100	\N	2025-10-29 07:47:33.658517	2025-10-29 07:47:33.658517
245	2007-08-11	9	11	27	31	32	38	22	7	1382583129	\N	2025-10-29 07:47:34.166888	2025-10-29 07:47:34.166888
246	2007-08-18	13	18	21	23	26	39	15	5	1911774240	\N	2025-10-29 07:47:34.67727	2025-10-29 07:47:34.67727
247	2007-08-25	12	15	28	36	39	40	13	6	1669313900	\N	2025-10-29 07:47:35.18607	2025-10-29 07:47:35.18607
248	2007-09-01	3	8	17	23	38	45	13	8	1227479363	\N	2025-10-29 07:47:35.694474	2025-10-29 07:47:35.694474
249	2007-09-08	3	8	27	31	41	44	11	6	1663568700	\N	2025-10-29 07:47:36.203087	2025-10-29 07:47:36.203087
250	2007-09-15	19	23	30	37	43	45	38	5	1994726280	\N	2025-10-29 07:47:36.711576	2025-10-29 07:47:36.711576
251	2007-09-22	6	7	19	25	28	38	45	8	1282616400	\N	2025-10-29 07:47:37.222066	2025-10-29 07:47:37.222066
252	2007-09-29	14	23	26	31	39	45	28	7	1391089715	\N	2025-10-29 07:47:37.730103	2025-10-29 07:47:37.730103
253	2007-10-06	8	19	25	31	34	36	33	4	2466189525	\N	2025-10-29 07:47:38.238674	2025-10-29 07:47:38.238674
254	2007-10-13	1	5	19	20	24	30	27	1	9741015900	\N	2025-10-29 07:47:38.748111	2025-10-29 07:47:38.748111
255	2007-10-20	1	5	6	24	27	42	32	6	1598618550	\N	2025-10-29 07:47:39.256133	2025-10-29 07:47:39.256133
256	2007-10-27	4	11	14	21	23	43	32	2	4891017000	\N	2025-10-29 07:47:39.764346	2025-10-29 07:47:39.764346
257	2007-11-03	6	13	27	31	32	37	4	4	2391377025	\N	2025-10-29 07:47:40.272253	2025-10-29 07:47:40.272253
258	2007-11-10	14	27	30	31	38	40	17	4	2426434350	\N	2025-10-29 07:47:40.78016	2025-10-29 07:47:40.78016
259	2007-11-17	4	5	14	35	42	45	34	2	4838533500	\N	2025-10-29 07:47:41.290044	2025-10-29 07:47:41.290044
260	2007-11-24	7	12	15	24	37	40	43	4	2310085575	\N	2025-10-29 07:47:41.823885	2025-10-29 07:47:41.823885
261	2007-12-01	6	11	16	18	31	43	2	3	3192299100	\N	2025-10-29 07:47:42.332028	2025-10-29 07:47:42.332028
262	2007-12-08	9	12	24	25	29	31	36	2	4518741600	\N	2025-10-29 07:47:42.840495	2025-10-29 07:47:42.840495
263	2007-12-15	1	27	28	32	37	40	18	6	1551704900	\N	2025-10-29 07:47:43.3503	2025-10-29 07:47:43.3503
264	2007-12-22	9	16	27	36	41	44	5	7	1344889200	\N	2025-10-29 07:47:43.858457	2025-10-29 07:47:43.858457
265	2007-12-29	5	9	34	37	38	39	12	8	1200838575	\N	2025-10-29 07:47:44.368791	2025-10-29 07:47:44.368791
266	2008-01-05	3	4	9	11	22	42	37	3	3207211700	\N	2025-10-29 07:47:44.877116	2025-10-29 07:47:44.877116
267	2008-01-12	7	8	24	34	36	41	1	3	3257663300	\N	2025-10-29 07:47:45.385953	2025-10-29 07:47:45.385953
268	2008-01-19	3	10	19	24	32	45	12	7	1350954515	\N	2025-10-29 07:47:45.897629	2025-10-29 07:47:45.897629
269	2008-01-26	5	18	20	36	42	43	32	5	1961399940	\N	2025-10-29 07:47:46.406822	2025-10-29 07:47:46.406822
270	2008-02-02	5	9	12	20	21	26	27	5	1927830060	\N	2025-10-29 07:47:46.916286	2025-10-29 07:47:46.916286
271	2008-02-09	3	8	9	27	29	40	36	6	1565918150	\N	2025-10-29 07:47:47.424577	2025-10-29 07:47:47.424577
272	2008-02-16	7	9	12	27	39	43	28	9	1104622800	\N	2025-10-29 07:47:47.932686	2025-10-29 07:47:47.932686
273	2008-02-23	1	8	24	31	34	44	6	3	3339543100	\N	2025-10-29 07:47:48.442221	2025-10-29 07:47:48.442221
274	2008-03-01	13	14	15	26	35	39	25	4	2505085575	\N	2025-10-29 07:47:48.951311	2025-10-29 07:47:48.951311
275	2008-03-08	14	19	20	35	38	40	26	1	10044066900	\N	2025-10-29 07:47:49.459353	2025-10-29 07:47:49.459353
276	2008-03-15	4	15	21	33	39	41	25	3	3312569000	\N	2025-10-29 07:47:49.967235	2025-10-29 07:47:49.967235
277	2008-03-22	10	12	13	15	25	29	20	3	3272627800	\N	2025-10-29 07:47:50.47541	2025-10-29 07:47:50.47541
278	2008-03-29	3	11	37	39	41	43	13	3	3186530000	\N	2025-10-29 07:47:50.983582	2025-10-29 07:47:50.983582
279	2008-04-05	7	16	31	36	37	38	11	5	1914205320	\N	2025-10-29 07:47:51.493972	2025-10-29 07:47:51.493972
280	2008-04-12	10	11	23	24	36	37	35	7	1355258529	\N	2025-10-29 07:47:52.001986	2025-10-29 07:47:52.001986
281	2008-04-19	1	3	4	6	14	41	12	6	1554683200	\N	2025-10-29 07:47:52.510465	2025-10-29 07:47:52.510465
282	2008-04-26	2	5	10	18	31	32	30	7	1322052643	\N	2025-10-29 07:47:53.018412	2025-10-29 07:47:53.018412
283	2008-05-03	6	8	18	31	38	45	42	3	3137224600	\N	2025-10-29 07:47:53.526468	2025-10-29 07:47:53.526468
284	2008-05-10	2	7	15	24	30	45	28	3	3117640300	\N	2025-10-29 07:47:54.034844	2025-10-29 07:47:54.034844
285	2008-05-17	13	33	37	40	41	45	2	3	3164370100	\N	2025-10-29 07:47:54.545032	2025-10-29 07:47:54.545032
286	2008-05-24	1	15	19	40	42	44	17	3	3236566300	\N	2025-10-29 07:47:55.056416	2025-10-29 07:47:55.056416
287	2008-05-31	6	12	24	27	35	37	41	7	1328657100	\N	2025-10-29 07:47:55.564328	2025-10-29 07:47:55.564328
288	2008-06-07	1	12	17	28	35	41	10	4	2357261550	\N	2025-10-29 07:47:56.072346	2025-10-29 07:47:56.072346
289	2008-06-14	3	14	33	37	38	42	10	\N	\N	\N	2025-10-29 07:47:56.58329	2025-10-29 07:47:56.58329
290	2008-06-21	8	13	18	32	39	45	7	13	2149214424	\N	2025-10-29 07:47:57.091908	2025-10-29 07:47:57.091908
291	2008-06-28	3	7	8	18	20	42	45	7	1450585200	\N	2025-10-29 07:47:57.600833	2025-10-29 07:47:57.600833
292	2008-07-05	17	18	31	32	33	34	10	14	720373950	\N	2025-10-29 07:47:58.108894	2025-10-29 07:47:58.108894
293	2008-07-12	1	9	17	21	29	33	24	6	1656764400	\N	2025-10-29 07:47:58.616243	2025-10-29 07:47:58.616243
294	2008-07-19	6	10	17	30	37	38	40	4	2406504975	\N	2025-10-29 07:47:59.124926	2025-10-29 07:47:59.124926
295	2008-07-26	1	4	12	16	18	38	8	\N	\N	\N	2025-10-29 07:47:59.633986	2025-10-29 07:47:59.633986
296	2008-08-02	3	8	15	27	30	45	44	8	3066088275	\N	2025-10-29 07:48:00.142157	2025-10-29 07:48:00.142157
297	2008-08-09	6	11	19	20	28	32	34	2	5056668750	\N	2025-10-29 07:48:00.650347	2025-10-29 07:48:00.650347
298	2008-08-16	5	9	27	29	37	40	19	1	9909778500	\N	2025-10-29 07:48:01.158507	2025-10-29 07:48:01.158507
299	2008-08-23	1	3	20	25	36	45	24	7	1483772529	\N	2025-10-29 07:48:01.667097	2025-10-29 07:48:01.667097
300	2008-08-30	7	9	10	12	26	38	39	12	836092425	\N	2025-10-29 07:48:02.175782	2025-10-29 07:48:02.175782
301	2008-09-06	7	11	13	33	37	43	26	7	1447385015	\N	2025-10-29 07:48:07.723294	2025-10-29 07:48:07.723294
302	2008-09-13	13	19	20	32	38	42	4	2	5472167250	\N	2025-10-29 07:48:08.232835	2025-10-29 07:48:08.232835
303	2008-09-20	2	14	17	30	38	45	43	6	1672749000	\N	2025-10-29 07:48:08.741537	2025-10-29 07:48:08.741537
304	2008-09-27	4	10	16	26	33	41	38	6	1661646150	\N	2025-10-29 07:48:09.250161	2025-10-29 07:48:09.250161
305	2008-10-04	7	8	18	21	23	39	9	5	2008210140	\N	2025-10-29 07:48:09.759334	2025-10-29 07:48:09.759334
306	2008-10-11	4	18	23	30	34	41	19	5	2102669520	\N	2025-10-29 07:48:10.26754	2025-10-29 07:48:10.26754
307	2008-10-18	5	15	21	23	25	45	12	4	2587643250	\N	2025-10-29 07:48:10.778003	2025-10-29 07:48:10.778003
308	2008-10-25	14	15	17	19	37	45	40	1	10232872800	\N	2025-10-29 07:48:11.28665	2025-10-29 07:48:11.28665
309	2008-11-01	1	2	5	11	18	36	22	11	901622946	\N	2025-10-29 07:48:11.796851	2025-10-29 07:48:11.796851
310	2008-11-08	1	5	19	28	34	41	16	8	1296713325	\N	2025-10-29 07:48:12.304784	2025-10-29 07:48:12.304784
311	2008-11-15	4	12	24	27	28	32	10	8	1237691063	\N	2025-10-29 07:48:12.813259	2025-10-29 07:48:12.813259
312	2008-11-22	2	3	5	6	12	20	25	15	629017820	\N	2025-10-29 07:48:13.321231	2025-10-29 07:48:13.321231
313	2008-11-29	9	17	34	35	43	45	2	6	1715422800	\N	2025-10-29 07:48:13.82953	2025-10-29 07:48:13.82953
314	2008-12-06	15	17	19	34	38	41	2	6	1660512200	\N	2025-10-29 07:48:14.337739	2025-10-29 07:48:14.337739
315	2008-12-13	1	13	33	35	43	45	23	8	1308728625	\N	2025-10-29 07:48:14.846782	2025-10-29 07:48:14.846782
316	2008-12-20	10	11	21	27	31	39	43	6	1673586400	\N	2025-10-29 07:48:15.35453	2025-10-29 07:48:15.35453
317	2008-12-27	3	10	11	22	36	39	8	4	2576258550	\N	2025-10-29 07:48:15.863788	2025-10-29 07:48:15.863788
318	2009-01-03	2	17	19	20	34	45	21	9	1207436600	\N	2025-10-29 07:48:16.372961	2025-10-29 07:48:16.372961
319	2009-01-10	5	8	22	28	33	42	37	5	2135659380	\N	2025-10-29 07:48:16.881854	2025-10-29 07:48:16.881854
320	2009-01-17	16	19	23	25	41	45	3	2	5513067900	\N	2025-10-29 07:48:17.389833	2025-10-29 07:48:17.389833
321	2009-01-24	12	18	20	21	25	34	42	6	1959136100	\N	2025-10-29 07:48:17.897855	2025-10-29 07:48:17.897855
322	2009-01-31	9	18	29	32	38	43	20	6	1904544700	\N	2025-10-29 07:48:18.406827	2025-10-29 07:48:18.406827
323	2009-02-07	10	14	15	32	36	42	3	8	1461025388	\N	2025-10-29 07:48:18.915296	2025-10-29 07:48:18.915296
324	2009-02-14	2	4	21	25	33	36	17	6	1865130350	\N	2025-10-29 07:48:19.423636	2025-10-29 07:48:19.423636
325	2009-02-21	7	17	20	32	44	45	33	6	1806122450	\N	2025-10-29 07:48:19.934681	2025-10-29 07:48:19.934681
326	2009-02-28	16	23	25	33	36	39	40	6	1832134550	\N	2025-10-29 07:48:20.444337	2025-10-29 07:48:20.444337
327	2009-03-07	6	12	13	17	32	44	24	12	882674750	\N	2025-10-29 07:48:20.953287	2025-10-29 07:48:20.953287
328	2009-03-14	1	6	9	16	17	28	24	6	1819795900	\N	2025-10-29 07:48:21.461315	2025-10-29 07:48:21.461315
329	2009-03-21	9	17	19	30	35	42	4	6	1830391200	\N	2025-10-29 07:48:21.970893	2025-10-29 07:48:21.970893
330	2009-03-28	3	4	16	17	19	20	23	9	1162280200	\N	2025-10-29 07:48:22.483451	2025-10-29 07:48:22.483451
331	2009-04-04	4	9	14	26	31	44	39	5	2165902620	\N	2025-10-29 07:48:22.995153	2025-10-29 07:48:22.995153
332	2009-04-11	16	17	34	36	42	45	3	8	1359448388	\N	2025-10-29 07:48:23.502992	2025-10-29 07:48:23.502992
333	2009-04-18	5	14	27	30	39	43	35	7	1550987143	\N	2025-10-29 07:48:24.011363	2025-10-29 07:48:24.011363
334	2009-04-25	13	15	21	29	39	43	33	7	1523002972	\N	2025-10-29 07:48:24.519974	2025-10-29 07:48:24.519974
335	2009-05-02	5	9	16	23	26	45	21	5	2037492480	\N	2025-10-29 07:48:25.030139	2025-10-29 07:48:25.030139
336	2009-05-09	3	5	20	34	35	44	16	6	1685632650	\N	2025-10-29 07:48:25.545187	2025-10-29 07:48:25.545187
337	2009-05-16	1	5	14	18	32	37	4	8	1257500513	\N	2025-10-29 07:48:26.052878	2025-10-29 07:48:26.052878
338	2009-05-23	2	13	34	38	42	45	16	3	3383431000	\N	2025-10-29 07:48:26.561631	2025-10-29 07:48:26.561631
339	2009-05-30	6	8	14	21	30	37	45	9	1096778334	\N	2025-10-29 07:48:27.071559	2025-10-29 07:48:27.071559
340	2009-06-06	18	24	26	29	34	38	32	7	1439393186	\N	2025-10-29 07:48:27.580617	2025-10-29 07:48:27.580617
341	2009-06-13	1	8	19	34	39	43	41	7	1497207772	\N	2025-10-29 07:48:28.089713	2025-10-29 07:48:28.089713
342	2009-06-20	1	13	14	33	34	43	25	3	3454095800	\N	2025-10-29 07:48:28.600231	2025-10-29 07:48:28.600231
343	2009-06-27	1	10	17	29	31	43	15	6	1717153000	\N	2025-10-29 07:48:29.108995	2025-10-29 07:48:29.108995
344	2009-07-04	1	2	15	28	34	45	38	7	1467106543	\N	2025-10-29 07:48:29.617506	2025-10-29 07:48:29.617506
345	2009-07-11	15	20	23	29	39	42	2	2	5203577550	\N	2025-10-29 07:48:30.129269	2025-10-29 07:48:30.129269
346	2009-07-18	5	13	14	22	44	45	33	5	2017727340	\N	2025-10-29 07:48:30.637661	2025-10-29 07:48:30.637661
347	2009-07-25	3	8	13	27	32	42	10	7	1456624286	\N	2025-10-29 07:48:31.148629	2025-10-29 07:48:31.148629
348	2009-08-01	3	14	17	20	24	31	34	3	3299994000	\N	2025-10-29 07:48:31.65748	2025-10-29 07:48:31.65748
349	2009-08-08	5	13	14	20	24	25	36	3	3353209000	\N	2025-10-29 07:48:32.166624	2025-10-29 07:48:32.166624
350	2009-08-15	1	8	18	24	29	33	35	9	1101052467	\N	2025-10-29 07:48:32.675728	2025-10-29 07:48:32.675728
351	2009-08-22	5	25	27	29	34	36	33	4	2583357150	\N	2025-10-29 07:48:33.184723	2025-10-29 07:48:33.184723
352	2009-08-29	5	16	17	20	26	41	24	6	1732858250	\N	2025-10-29 07:48:33.693474	2025-10-29 07:48:33.693474
353	2009-09-05	11	16	19	22	29	36	26	2	5290838250	\N	2025-10-29 07:48:34.203238	2025-10-29 07:48:34.203238
354	2009-09-12	14	19	36	43	44	45	1	5	2124464340	\N	2025-10-29 07:48:34.71179	2025-10-29 07:48:34.71179
355	2009-09-19	5	8	29	30	35	44	38	5	2145424800	\N	2025-10-29 07:48:35.21985	2025-10-29 07:48:35.21985
356	2009-09-26	2	8	14	25	29	45	24	9	1157185267	\N	2025-10-29 07:48:35.736299	2025-10-29 07:48:35.736299
357	2009-10-03	10	14	18	21	36	37	5	2	5313394350	\N	2025-10-29 07:48:36.2507	2025-10-29 07:48:36.2507
358	2009-10-10	1	9	10	12	21	40	37	3	3472654900	\N	2025-10-29 07:48:36.759492	2025-10-29 07:48:36.759492
359	2009-10-17	1	10	19	20	24	40	23	8	1286712600	\N	2025-10-29 07:48:37.268434	2025-10-29 07:48:37.268434
360	2009-10-24	4	16	23	25	35	40	27	3	3566716200	\N	2025-10-29 07:48:37.77893	2025-10-29 07:48:37.77893
361	2009-10-31	5	10	16	24	27	35	33	7	1473115115	\N	2025-10-29 07:48:38.289005	2025-10-29 07:48:38.289005
362	2009-11-07	2	3	22	27	30	40	29	6	1729424650	\N	2025-10-29 07:48:38.797327	2025-10-29 07:48:38.797327
363	2009-11-14	11	12	14	21	32	38	6	4	2615910600	\N	2025-10-29 07:48:39.306061	2025-10-29 07:48:39.306061
364	2009-11-21	2	5	7	14	16	40	4	4	2531914800	\N	2025-10-29 07:48:39.816554	2025-10-29 07:48:39.816554
365	2009-11-28	5	15	21	25	26	30	31	1	10697716800	\N	2025-10-29 07:48:40.324652	2025-10-29 07:48:40.324652
366	2009-12-05	5	12	19	26	27	44	38	2	5351553900	\N	2025-10-29 07:48:40.833626	2025-10-29 07:48:40.833626
367	2009-12-12	3	22	25	29	32	44	19	7	1581736586	\N	2025-10-29 07:48:41.342509	2025-10-29 07:48:41.342509
368	2009-12-19	11	21	24	30	39	45	26	7	1465825115	\N	2025-10-29 07:48:41.850031	2025-10-29 07:48:41.850031
369	2009-12-26	17	20	35	36	41	43	21	6	1842177750	\N	2025-10-29 07:48:42.358805	2025-10-29 07:48:42.358805
370	2010-01-02	16	18	24	42	44	45	17	7	1678941943	\N	2025-10-29 07:48:42.867457	2025-10-29 07:48:42.867457
371	2010-01-09	7	9	15	26	27	42	18	7	1524130543	\N	2025-10-29 07:48:43.374692	2025-10-29 07:48:43.374692
372	2010-01-16	8	11	14	16	18	21	13	9	1192593200	\N	2025-10-29 07:48:43.883467	2025-10-29 07:48:43.883467
373	2010-01-23	15	26	37	42	43	45	9	4	2791801125	\N	2025-10-29 07:48:44.392756	2025-10-29 07:48:44.392756
374	2010-01-30	11	13	15	17	25	34	26	2	5528717850	\N	2025-10-29 07:48:44.901357	2025-10-29 07:48:44.901357
375	2010-02-06	4	8	19	25	27	45	7	7	1581284058	\N	2025-10-29 07:48:45.409347	2025-10-29 07:48:45.409347
376	2010-02-13	1	11	13	24	28	40	7	6	1956915800	\N	2025-10-29 07:48:45.919713	2025-10-29 07:48:45.919713
377	2010-02-20	6	22	29	37	43	45	23	3	3912085400	\N	2025-10-29 07:48:46.429466	2025-10-29 07:48:46.429466
378	2010-02-27	5	22	29	31	34	39	43	5	2317698240	\N	2025-10-29 07:48:46.937468	2025-10-29 07:48:46.937468
379	2010-03-06	6	10	22	31	35	40	19	7	1598999786	\N	2025-10-29 07:48:47.446643	2025-10-29 07:48:47.446643
380	2010-03-13	1	2	8	17	26	37	27	4	2684274825	\N	2025-10-29 07:48:47.955428	2025-10-29 07:48:47.955428
381	2010-03-20	1	5	10	12	16	20	11	19	565738895	\N	2025-10-29 07:48:48.465661	2025-10-29 07:48:48.465661
382	2010-03-27	10	15	22	24	27	42	19	6	1846674900	\N	2025-10-29 07:48:48.974682	2025-10-29 07:48:48.974682
383	2010-04-03	4	15	28	33	37	40	25	3	3596522100	\N	2025-10-29 07:48:49.484233	2025-10-29 07:48:49.484233
384	2010-04-10	11	22	24	32	36	38	7	3	3658734200	\N	2025-10-29 07:48:49.992387	2025-10-29 07:48:49.992387
385	2010-04-17	7	12	19	21	29	32	9	7	1542032700	\N	2025-10-29 07:48:50.503236	2025-10-29 07:48:50.503236
386	2010-04-24	4	7	10	19	31	40	26	10	1042953330	\N	2025-10-29 07:48:51.013406	2025-10-29 07:48:51.013406
387	2010-05-01	1	26	31	34	40	43	20	4	2675533500	\N	2025-10-29 07:48:51.522145	2025-10-29 07:48:51.522145
388	2010-05-08	1	8	9	17	29	32	45	4	2545543875	\N	2025-10-29 07:48:52.029837	2025-10-29 07:48:52.029837
389	2010-05-15	7	16	18	20	23	26	3	5	2119027020	\N	2025-10-29 07:48:52.53833	2025-10-29 07:48:52.53833
390	2010-05-22	16	17	28	37	39	40	15	1	10373997900	\N	2025-10-29 07:48:53.047609	2025-10-29 07:48:53.047609
391	2010-05-29	10	11	18	22	28	39	30	1	10508749800	\N	2025-10-29 07:48:53.556668	2025-10-29 07:48:53.556668
392	2010-06-05	1	3	7	8	24	42	43	6	1713528700	\N	2025-10-29 07:48:54.065078	2025-10-29 07:48:54.065078
393	2010-06-12	9	16	28	40	41	43	21	8	1362003975	\N	2025-10-29 07:48:54.572892	2025-10-29 07:48:54.572892
394	2010-06-19	1	13	20	22	25	28	15	1	10654349100	\N	2025-10-29 07:48:55.080763	2025-10-29 07:48:55.080763
395	2010-06-26	11	15	20	26	31	35	7	7	1534635000	\N	2025-10-29 07:48:55.5898	2025-10-29 07:48:55.5898
396	2010-07-03	18	20	31	34	40	45	30	2	5296622400	\N	2025-10-29 07:48:56.09774	2025-10-29 07:48:56.09774
397	2010-07-10	12	13	17	22	25	33	8	3	3499519700	\N	2025-10-29 07:48:56.60646	2025-10-29 07:48:56.60646
398	2010-07-17	10	15	20	23	42	44	7	4	2680625550	\N	2025-10-29 07:48:57.114836	2025-10-29 07:48:57.114836
399	2010-07-24	1	2	9	17	19	42	20	8	1276854975	\N	2025-10-29 07:48:57.636743	2025-10-29 07:48:57.636743
400	2010-07-31	9	21	27	34	41	43	2	4	2669834325	\N	2025-10-29 07:48:58.145933	2025-10-29 07:48:58.145933
401	2010-08-07	6	12	18	31	38	43	9	9	1168214792	\N	2025-10-29 07:49:03.69282	2025-10-29 07:49:03.69282
402	2010-08-14	5	9	15	19	22	36	32	4	2662206188	\N	2025-10-29 07:49:04.201613	2025-10-29 07:49:04.201613
403	2010-08-21	10	14	22	24	28	37	26	5	2122396875	\N	2025-10-29 07:49:04.709105	2025-10-29 07:49:04.709105
404	2010-08-28	5	20	21	24	33	40	36	3	3566659375	\N	2025-10-29 07:49:05.217482	2025-10-29 07:49:05.217482
405	2010-09-04	1	2	10	25	26	44	4	3	3543878000	\N	2025-10-29 07:49:05.727654	2025-10-29 07:49:05.727654
406	2010-09-11	7	12	21	24	27	36	45	5	2156142450	\N	2025-10-29 07:49:06.235766	2025-10-29 07:49:06.235766
407	2010-09-18	6	7	13	16	24	25	1	7	1649707286	\N	2025-10-29 07:49:06.744309	2025-10-29 07:49:06.744309
408	2010-09-25	9	20	21	22	30	37	16	5	2235375825	\N	2025-10-29 07:49:07.252014	2025-10-29 07:49:07.252014
409	2010-10-02	6	9	21	31	32	40	38	4	2896989750	\N	2025-10-29 07:49:07.761467	2025-10-29 07:49:07.761467
410	2010-10-09	1	3	18	32	40	41	16	9	1249335709	\N	2025-10-29 07:49:08.269876	2025-10-29 07:49:08.269876
411	2010-10-16	11	14	22	35	37	39	5	12	953227563	\N	2025-10-29 07:49:08.778046	2025-10-29 07:49:08.778046
412	2010-10-23	4	7	39	41	42	45	40	7	1656199822	\N	2025-10-29 07:49:09.285981	2025-10-29 07:49:09.285981
413	2010-10-30	2	9	15	23	34	40	3	4	2814673500	\N	2025-10-29 07:49:09.795073	2025-10-29 07:49:09.795073
414	2010-11-06	2	14	15	22	23	44	43	1	11703832500	\N	2025-10-29 07:49:10.317205	2025-10-29 07:49:10.317205
415	2010-11-13	7	17	20	26	30	40	24	8	1334182407	\N	2025-10-29 07:49:10.828917	2025-10-29 07:49:10.828917
416	2010-11-20	5	6	8	11	22	26	44	10	1072037100	\N	2025-10-29 07:49:11.337215	2025-10-29 07:49:11.337215
417	2010-11-27	4	5	14	20	22	43	44	4	2818329938	\N	2025-10-29 07:49:11.845057	2025-10-29 07:49:11.845057
418	2010-12-04	11	13	15	26	28	34	31	8	1435649766	\N	2025-10-29 07:49:12.353679	2025-10-29 07:49:12.353679
419	2010-12-11	2	11	13	14	28	30	7	3	3796490750	\N	2025-10-29 07:49:12.862976	2025-10-29 07:49:12.862976
420	2010-12-18	4	9	10	29	31	34	27	8	1424856375	\N	2025-10-29 07:49:13.370902	2025-10-29 07:49:13.370902
421	2010-12-25	6	11	26	27	28	44	30	5	2321144325	\N	2025-10-29 07:49:13.87938	2025-10-29 07:49:13.87938
422	2011-01-01	8	15	19	21	34	44	12	6	2205251375	\N	2025-10-29 07:49:14.387463	2025-10-29 07:49:14.387463
423	2011-01-08	1	17	27	28	29	40	5	3	3896153875	\N	2025-10-29 07:49:14.895561	2025-10-29 07:49:14.895561
424	2011-01-15	10	11	26	31	34	44	30	10	1109480813	\N	2025-10-29 07:49:15.403524	2025-10-29 07:49:15.403524
425	2011-01-22	8	10	14	27	33	38	3	8	1534833000	\N	2025-10-29 07:49:15.912777	2025-10-29 07:49:15.912777
426	2011-01-29	4	17	18	27	39	43	19	4	3057233625	\N	2025-10-29 07:49:16.42106	2025-10-29 07:49:16.42106
427	2011-02-05	6	7	15	24	28	30	21	1	12571445625	\N	2025-10-29 07:49:16.929626	2025-10-29 07:49:16.929626
428	2011-02-12	12	16	19	22	37	40	8	9	1437683209	\N	2025-10-29 07:49:17.440183	2025-10-29 07:49:17.440183
429	2011-02-19	3	23	28	34	39	42	16	9	1485904709	\N	2025-10-29 07:49:17.94835	2025-10-29 07:49:17.94835
430	2011-02-26	1	3	16	18	30	34	44	8	1611763219	\N	2025-10-29 07:49:18.457132	2025-10-29 07:49:18.457132
431	2011-03-05	18	22	25	31	38	45	6	10	1268434013	\N	2025-10-29 07:49:18.965224	2025-10-29 07:49:18.965224
432	2011-03-12	2	3	5	11	27	39	33	5	2299427550	\N	2025-10-29 07:49:19.473077	2025-10-29 07:49:19.473077
433	2011-03-19	19	23	29	33	35	43	27	11	1182294410	\N	2025-10-29 07:49:19.981449	2025-10-29 07:49:19.981449
434	2011-03-26	3	13	20	24	33	37	35	8	1480060266	\N	2025-10-29 07:49:20.489128	2025-10-29 07:49:20.489128
435	2011-04-02	8	16	26	30	38	45	42	10	1287550013	\N	2025-10-29 07:49:20.999976	2025-10-29 07:49:20.999976
436	2011-04-09	9	14	20	22	33	34	28	8	1512266579	\N	2025-10-29 07:49:21.507376	2025-10-29 07:49:21.507376
437	2011-04-16	11	16	29	38	41	44	21	6	2096245438	\N	2025-10-29 07:49:22.015188	2025-10-29 07:49:22.015188
438	2011-04-23	6	12	20	26	29	38	45	9	1377142167	\N	2025-10-29 07:49:22.523878	2025-10-29 07:49:22.523878
439	2011-04-30	17	20	30	31	37	40	25	6	1900077375	\N	2025-10-29 07:49:23.031892	2025-10-29 07:49:23.031892
440	2011-05-07	10	22	28	34	36	44	2	6	1995873000	\N	2025-10-29 07:49:23.540083	2025-10-29 07:49:23.540083
441	2011-05-14	1	23	28	30	34	35	9	4	3170417063	\N	2025-10-29 07:49:24.048293	2025-10-29 07:49:24.048293
442	2011-05-21	25	27	29	36	38	40	41	9	1413413042	\N	2025-10-29 07:49:24.556834	2025-10-29 07:49:24.556834
443	2011-05-28	4	6	10	19	20	44	14	9	1327597584	\N	2025-10-29 07:49:25.065366	2025-10-29 07:49:25.065366
444	2011-06-04	11	13	23	35	43	45	17	3	4154188625	\N	2025-10-29 07:49:25.572986	2025-10-29 07:49:25.572986
445	2011-06-11	13	20	21	30	39	45	32	7	1791683036	\N	2025-10-29 07:49:26.080848	2025-10-29 07:49:26.080848
446	2011-06-18	1	11	12	14	26	35	6	3	4051247625	\N	2025-10-29 07:49:26.589324	2025-10-29 07:49:26.589324
447	2011-06-25	2	7	8	9	17	33	34	4	2657941125	\N	2025-10-29 07:49:27.097113	2025-10-29 07:49:27.097113
448	2011-07-02	3	7	13	27	40	41	36	3	4026212750	\N	2025-10-29 07:49:27.604549	2025-10-29 07:49:27.604549
449	2011-07-09	3	10	20	26	35	43	36	3	4059715250	\N	2025-10-29 07:49:28.11301	2025-10-29 07:49:28.11301
450	2011-07-16	6	14	19	21	23	31	13	6	1990391625	\N	2025-10-29 07:49:28.624185	2025-10-29 07:49:28.624185
451	2011-07-23	12	15	20	24	30	38	29	13	882138952	\N	2025-10-29 07:49:29.132445	2025-10-29 07:49:29.132445
452	2011-07-30	8	10	18	30	32	34	27	9	1276902000	\N	2025-10-29 07:49:29.640118	2025-10-29 07:49:29.640118
453	2011-08-06	12	24	33	38	40	42	30	5	2262732375	\N	2025-10-29 07:49:30.177813	2025-10-29 07:49:30.177813
454	2011-08-13	13	25	27	34	38	41	10	7	1609125590	\N	2025-10-29 07:49:30.687458	2025-10-29 07:49:30.687458
455	2011-08-20	4	19	20	26	30	35	24	7	1635711483	\N	2025-10-29 07:49:31.195485	2025-10-29 07:49:31.195485
456	2011-08-27	1	7	12	18	23	27	44	7	1598505054	\N	2025-10-29 07:49:31.705975	2025-10-29 07:49:31.705975
457	2011-09-03	8	10	18	23	27	40	33	10	1159902825	\N	2025-10-29 07:49:32.214474	2025-10-29 07:49:32.214474
458	2011-09-10	4	9	10	32	36	40	18	8	1608812625	\N	2025-10-29 07:49:32.723607	2025-10-29 07:49:32.723607
459	2011-09-17	4	6	10	14	25	40	12	7	1655842233	\N	2025-10-29 07:49:33.232673	2025-10-29 07:49:33.232673
460	2011-09-24	8	11	28	30	43	45	41	4	3180895782	\N	2025-10-29 07:49:33.741116	2025-10-29 07:49:33.741116
461	2011-10-01	11	18	26	31	37	40	43	6	1948674875	\N	2025-10-29 07:49:34.248628	2025-10-29 07:49:34.248628
462	2011-10-08	3	20	24	32	37	45	4	8	1483559297	\N	2025-10-29 07:49:34.758104	2025-10-29 07:49:34.758104
463	2011-10-15	23	29	31	33	34	44	40	\N	\N	\N	2025-10-29 07:49:35.266173	2025-10-29 07:49:35.266173
464	2011-10-22	6	12	15	34	42	44	4	13	3355721106	\N	2025-10-29 07:49:35.774088	2025-10-29 07:49:35.774088
465	2011-10-29	1	8	11	13	22	38	31	7	1923662893	\N	2025-10-29 07:49:36.282312	2025-10-29 07:49:36.282312
466	2011-11-05	4	10	13	23	32	44	20	9	1530313459	\N	2025-10-29 07:49:36.790635	2025-10-29 07:49:36.790635
467	2011-11-12	2	12	14	17	24	40	39	9	1435441084	\N	2025-10-29 07:49:37.298539	2025-10-29 07:49:37.298539
468	2011-11-19	8	13	15	28	37	43	17	9	1527197167	\N	2025-10-29 07:49:37.808314	2025-10-29 07:49:37.808314
469	2011-11-26	4	21	22	34	37	38	33	4	3330131250	\N	2025-10-29 07:49:38.317461	2025-10-29 07:49:38.317461
470	2011-12-03	10	16	20	39	41	42	27	3	4333330625	\N	2025-10-29 07:49:38.826178	2025-10-29 07:49:38.826178
471	2011-12-10	6	13	29	37	39	41	43	7	1939332858	\N	2025-10-29 07:49:39.334636	2025-10-29 07:49:39.334636
472	2011-12-17	16	25	26	31	36	43	44	7	1809656090	\N	2025-10-29 07:49:39.842713	2025-10-29 07:49:39.842713
473	2011-12-24	8	13	20	22	23	36	34	4	3250418063	\N	2025-10-29 07:49:40.352375	2025-10-29 07:49:40.352375
474	2011-12-31	4	13	18	31	33	45	43	15	936690800	\N	2025-10-29 07:49:40.860475	2025-10-29 07:49:40.860475
475	2012-01-07	1	9	14	16	21	29	3	8	1693923047	\N	2025-10-29 07:49:41.371505	2025-10-29 07:49:41.371505
476	2012-01-14	9	12	13	15	37	38	27	4	3439851469	\N	2025-10-29 07:49:41.880138	2025-10-29 07:49:41.880138
477	2012-01-21	14	25	29	32	33	45	37	8	1919011829	\N	2025-10-29 07:49:42.388287	2025-10-29 07:49:42.388287
478	2012-01-28	18	29	30	37	39	43	8	14	987224759	\N	2025-10-29 07:49:42.896406	2025-10-29 07:49:42.896406
479	2012-02-04	8	23	25	27	35	44	24	6	2233046500	\N	2025-10-29 07:49:43.40411	2025-10-29 07:49:43.40411
480	2012-02-11	3	5	10	17	30	31	16	4	2996742282	\N	2025-10-29 07:49:43.911482	2025-10-29 07:49:43.911482
481	2012-02-18	3	4	23	29	40	41	20	3	4639355750	\N	2025-10-29 07:49:44.419574	2025-10-29 07:49:44.419574
482	2012-02-25	1	10	16	24	25	35	43	7	1897921179	\N	2025-10-29 07:49:44.927452	2025-10-29 07:49:44.927452
483	2012-03-03	12	15	19	22	28	34	5	5	2567196675	\N	2025-10-29 07:49:45.43593	2025-10-29 07:49:45.43593
484	2012-03-10	1	3	27	28	32	45	11	6	2305303063	\N	2025-10-29 07:49:45.944718	2025-10-29 07:49:45.944718
485	2012-03-17	17	22	26	27	36	39	20	9	1501474917	\N	2025-10-29 07:49:46.458753	2025-10-29 07:49:46.458753
486	2012-03-24	1	2	23	25	38	40	43	13	1008634125	\N	2025-10-29 07:49:46.967216	2025-10-29 07:49:46.967216
487	2012-03-31	4	8	25	27	37	41	21	8	1638830766	\N	2025-10-29 07:49:47.474862	2025-10-29 07:49:47.474862
488	2012-04-07	2	8	17	30	31	38	25	10	1330393575	\N	2025-10-29 07:49:47.983461	2025-10-29 07:49:47.983461
489	2012-04-14	2	4	8	15	20	27	11	6	2106360625	\N	2025-10-29 07:49:48.492683	2025-10-29 07:49:48.492683
490	2012-04-21	2	7	26	29	40	43	42	7	1860234161	\N	2025-10-29 07:49:49.001567	2025-10-29 07:49:49.001567
491	2012-04-28	8	17	35	36	39	42	4	4	3304634438	\N	2025-10-29 07:49:49.510953	2025-10-29 07:49:49.510953
492	2012-05-05	22	27	31	35	37	40	42	5	2493013800	\N	2025-10-29 07:49:50.022967	2025-10-29 07:49:50.022967
493	2012-05-12	20	22	26	33	36	37	25	9	1451120334	\N	2025-10-29 07:49:50.530786	2025-10-29 07:49:50.530786
494	2012-05-19	5	7	8	15	30	43	22	12	1054588407	\N	2025-10-29 07:49:51.039989	2025-10-29 07:49:51.039989
495	2012-05-26	4	13	22	27	34	44	6	6	2111645000	\N	2025-10-29 07:49:51.550297	2025-10-29 07:49:51.550297
496	2012-06-02	4	13	20	29	36	41	39	4	3285932250	\N	2025-10-29 07:49:52.058193	2025-10-29 07:49:52.058193
497	2012-06-09	19	20	23	24	43	44	13	6	2222817813	\N	2025-10-29 07:49:52.566283	2025-10-29 07:49:52.566283
498	2012-06-16	13	14	24	32	39	41	3	4	3244503094	\N	2025-10-29 07:49:53.075791	2025-10-29 07:49:53.075791
499	2012-06-23	5	20	23	27	35	40	43	3	4070480250	\N	2025-10-29 07:49:53.589367	2025-10-29 07:49:53.589367
500	2012-06-30	3	4	12	20	24	34	41	9	1351072375	\N	2025-10-29 07:49:54.097725	2025-10-29 07:49:54.097725
501	2012-07-07	1	4	10	17	31	42	2	4	3025200094	\N	2025-10-29 07:50:00.666785	2025-10-29 07:50:00.666785
502	2012-07-14	6	22	28	32	34	40	26	6	2201458125	\N	2025-10-29 07:50:01.176438	2025-10-29 07:50:01.176438
503	2012-07-21	1	5	27	30	34	36	40	7	1853634911	\N	2025-10-29 07:50:01.685863	2025-10-29 07:50:01.685863
504	2012-07-28	6	14	22	26	43	44	31	9	1443236959	\N	2025-10-29 07:50:02.194718	2025-10-29 07:50:02.194718
505	2012-08-04	7	20	22	25	38	40	44	6	1917955188	\N	2025-10-29 07:50:02.702914	2025-10-29 07:50:02.702914
506	2012-08-11	6	9	11	22	24	30	31	3	4073333875	\N	2025-10-29 07:50:03.210637	2025-10-29 07:50:03.210637
507	2012-08-18	12	13	32	33	40	41	4	9	1416438875	\N	2025-10-29 07:50:03.718668	2025-10-29 07:50:03.718668
508	2012-08-25	5	27	31	34	35	43	37	8	1599557860	\N	2025-10-29 07:50:04.227502	2025-10-29 07:50:04.227502
509	2012-09-01	12	25	29	35	42	43	24	5	2689076100	\N	2025-10-29 07:50:04.735589	2025-10-29 07:50:04.735589
510	2012-09-08	12	29	32	33	39	40	42	5	2644158150	\N	2025-10-29 07:50:05.243978	2025-10-29 07:50:05.243978
511	2012-09-15	3	7	14	23	26	42	24	6	2165579250	\N	2025-10-29 07:50:05.752892	2025-10-29 07:50:05.752892
512	2012-09-22	4	5	9	13	26	27	1	13	940094452	\N	2025-10-29 07:50:06.261949	2025-10-29 07:50:06.261949
513	2012-09-29	5	8	21	23	27	33	12	3	4589624750	\N	2025-10-29 07:50:06.769394	2025-10-29 07:50:06.769394
514	2012-10-06	1	15	20	26	35	42	9	3	4451055500	\N	2025-10-29 07:50:07.277325	2025-10-29 07:50:07.277325
515	2012-10-13	2	11	12	15	23	37	8	1	13200466875	\N	2025-10-29 07:50:07.788032	2025-10-29 07:50:07.788032
516	2012-10-20	2	8	23	41	43	44	30	11	1294190182	\N	2025-10-29 07:50:08.296091	2025-10-29 07:50:08.296091
517	2012-10-27	1	9	12	28	36	41	10	5	2659057725	\N	2025-10-29 07:50:08.804341	2025-10-29 07:50:08.804341
518	2012-11-03	14	23	30	32	34	38	6	6	2263804125	\N	2025-10-29 07:50:09.313033	2025-10-29 07:50:09.313033
519	2012-11-10	6	8	13	16	30	43	3	7	1950601393	\N	2025-10-29 07:50:09.821968	2025-10-29 07:50:09.821968
520	2012-11-17	4	22	27	28	38	40	1	6	2167205438	\N	2025-10-29 07:50:10.330235	2025-10-29 07:50:10.330235
521	2012-11-24	3	7	18	29	32	36	19	8	1693420922	\N	2025-10-29 07:50:10.837846	2025-10-29 07:50:10.837846
522	2012-12-01	4	5	13	14	37	41	11	6	2281623000	\N	2025-10-29 07:50:11.348574	2025-10-29 07:50:11.348574
523	2012-12-08	1	4	37	38	40	45	7	7	1780355840	\N	2025-10-29 07:50:11.855797	2025-10-29 07:50:11.855797
524	2012-12-15	10	11	29	38	41	45	21	4	3491695594	\N	2025-10-29 07:50:12.364438	2025-10-29 07:50:12.364438
525	2012-12-22	11	23	26	29	39	44	22	9	1501132375	\N	2025-10-29 07:50:12.872541	2025-10-29 07:50:12.872541
526	2012-12-29	7	14	17	20	35	39	31	9	1491031959	\N	2025-10-29 07:50:13.380183	2025-10-29 07:50:13.380183
527	2013-01-05	1	12	22	32	33	42	38	13	1032386366	\N	2025-10-29 07:50:13.888832	2025-10-29 07:50:13.888832
528	2013-01-12	5	17	25	31	39	40	10	11	1197889125	\N	2025-10-29 07:50:14.39799	2025-10-29 07:50:14.39799
529	2013-01-19	18	20	24	27	31	42	39	8	1749114797	\N	2025-10-29 07:50:14.906259	2025-10-29 07:50:14.906259
530	2013-01-26	16	23	27	29	33	41	22	11	1231656239	\N	2025-10-29 07:50:15.413896	2025-10-29 07:50:15.413896
531	2013-02-02	1	5	9	21	27	35	45	9	1521519750	\N	2025-10-29 07:50:15.923102	2025-10-29 07:50:15.923102
532	2013-02-09	16	17	23	24	29	44	3	7	2216896286	\N	2025-10-29 07:50:16.431049	2025-10-29 07:50:16.431049
533	2013-02-16	9	14	15	17	31	33	23	8	1785671579	\N	2025-10-29 07:50:16.939217	2025-10-29 07:50:16.939217
534	2013-02-23	10	24	26	29	37	38	32	1	14215763250	\N	2025-10-29 07:50:17.447772	2025-10-29 07:50:17.447772
535	2013-03-02	11	12	14	15	18	39	34	3	4935603000	\N	2025-10-29 07:50:17.958474	2025-10-29 07:50:17.958474
536	2013-03-09	7	8	18	32	37	43	12	11	1308523603	\N	2025-10-29 07:50:18.46635	2025-10-29 07:50:18.46635
537	2013-03-16	12	23	26	30	36	43	11	7	2104038911	\N	2025-10-29 07:50:18.975175	2025-10-29 07:50:18.975175
538	2013-03-23	6	10	18	31	32	34	11	3	4688021625	\N	2025-10-29 07:50:19.482585	2025-10-29 07:50:19.482585
539	2013-03-30	3	19	22	31	42	43	26	9	1621036667	\N	2025-10-29 07:50:19.991897	2025-10-29 07:50:19.991897
540	2013-04-06	3	12	13	15	34	36	14	7	1989365250	\N	2025-10-29 07:50:20.500164	2025-10-29 07:50:20.500164
541	2013-04-13	8	13	26	28	32	34	43	11	1269327171	\N	2025-10-29 07:50:21.009099	2025-10-29 07:50:21.009099
542	2013-04-20	5	6	19	26	41	45	34	6	2335152563	\N	2025-10-29 07:50:21.516687	2025-10-29 07:50:21.516687
543	2013-04-27	13	18	26	31	34	44	12	12	1112934844	\N	2025-10-29 07:50:22.024478	2025-10-29 07:50:22.024478
544	2013-05-04	5	17	21	25	36	44	10	13	1046388433	\N	2025-10-29 07:50:22.534082	2025-10-29 07:50:22.534082
545	2013-05-11	4	24	25	27	34	35	2	11	1198994353	\N	2025-10-29 07:50:23.04302	2025-10-29 07:50:23.04302
546	2013-05-18	8	17	20	27	37	43	6	30	405939950	\N	2025-10-29 07:50:23.550653	2025-10-29 07:50:23.550653
547	2013-05-25	6	7	15	22	34	39	28	5	2838444450	\N	2025-10-29 07:50:24.058695	2025-10-29 07:50:24.058695
548	2013-06-01	1	12	13	21	32	45	14	8	1736871891	\N	2025-10-29 07:50:24.56786	2025-10-29 07:50:24.56786
549	2013-06-08	29	31	35	38	40	44	17	8	1760805047	\N	2025-10-29 07:50:25.076522	2025-10-29 07:50:25.076522
550	2013-06-15	1	7	14	20	34	37	41	11	1118679205	\N	2025-10-29 07:50:25.583732	2025-10-29 07:50:25.583732
551	2013-06-22	3	6	20	24	27	44	25	1	13526973750	\N	2025-10-29 07:50:26.091546	2025-10-29 07:50:26.091546
552	2013-06-29	1	10	20	32	35	40	43	10	1330824225	\N	2025-10-29 07:50:26.600488	2025-10-29 07:50:26.600488
553	2013-07-06	2	7	17	28	29	39	37	6	2249631438	\N	2025-10-29 07:50:27.108359	2025-10-29 07:50:27.108359
554	2013-07-13	13	14	17	32	41	42	6	2	6813893625	\N	2025-10-29 07:50:27.616268	2025-10-29 07:50:27.616268
555	2013-07-20	11	17	21	24	26	36	12	8	1711027360	\N	2025-10-29 07:50:28.126562	2025-10-29 07:50:28.126562
556	2013-07-27	12	20	23	28	30	44	43	7	2005209161	\N	2025-10-29 07:50:28.63446	2025-10-29 07:50:28.63446
557	2013-08-03	4	20	26	28	35	40	31	7	1888069286	\N	2025-10-29 07:50:29.143903	2025-10-29 07:50:29.143903
558	2013-08-10	12	15	19	26	40	43	29	10	1315913663	\N	2025-10-29 07:50:29.652083	2025-10-29 07:50:29.652083
559	2013-08-17	11	12	25	32	44	45	23	7	1926145608	\N	2025-10-29 07:50:30.160597	2025-10-29 07:50:30.160597
560	2013-08-24	1	4	20	23	29	45	28	7	1976697215	\N	2025-10-29 07:50:30.668135	2025-10-29 07:50:30.668135
561	2013-08-31	5	7	18	37	42	45	20	5	2753712225	\N	2025-10-29 07:50:31.176296	2025-10-29 07:50:31.176296
562	2013-09-07	4	11	13	17	20	31	33	11	1166694614	\N	2025-10-29 07:50:31.685636	2025-10-29 07:50:31.685636
563	2013-09-14	5	10	16	17	31	32	21	7	1932735643	\N	2025-10-29 07:50:32.195015	2025-10-29 07:50:32.195015
564	2013-09-21	14	19	25	26	27	34	2	7	1934801143	\N	2025-10-29 07:50:32.702915	2025-10-29 07:50:32.702915
565	2013-09-28	4	10	18	27	40	45	38	8	1742064469	\N	2025-10-29 07:50:33.212811	2025-10-29 07:50:33.212811
566	2013-10-05	4	5	6	25	26	43	41	4	3508951032	\N	2025-10-29 07:50:33.721345	2025-10-29 07:50:33.721345
567	2013-10-12	1	10	15	16	32	41	28	6	2318659438	\N	2025-10-29 07:50:34.229931	2025-10-29 07:50:34.229931
568	2013-10-19	1	3	17	20	31	44	40	10	1305167550	\N	2025-10-29 07:50:34.738256	2025-10-29 07:50:34.738256
569	2013-10-26	3	6	13	23	24	35	1	4	3467925188	\N	2025-10-29 07:50:35.246146	2025-10-29 07:50:35.246146
570	2013-11-02	1	12	26	27	29	33	42	9	1527791625	\N	2025-10-29 07:50:35.754214	2025-10-29 07:50:35.754214
571	2013-11-09	11	18	21	26	38	43	29	7	1966538465	\N	2025-10-29 07:50:36.261879	2025-10-29 07:50:36.261879
572	2013-11-16	3	13	18	33	37	45	1	8	1668216188	\N	2025-10-29 07:50:36.770647	2025-10-29 07:50:36.770647
573	2013-11-23	2	4	20	34	35	43	14	8	1645691766	\N	2025-10-29 07:50:37.280212	2025-10-29 07:50:37.280212
574	2013-11-30	14	15	16	19	25	43	2	2	6965184938	\N	2025-10-29 07:50:37.788497	2025-10-29 07:50:37.788497
575	2013-12-07	2	8	20	30	33	34	6	8	1699267875	\N	2025-10-29 07:50:38.297265	2025-10-29 07:50:38.297265
576	2013-12-14	10	11	15	25	35	41	13	3	4321966000	\N	2025-10-29 07:50:38.805312	2025-10-29 07:50:38.805312
577	2013-12-21	16	17	22	31	34	37	33	3	4484438375	\N	2025-10-29 07:50:39.313305	2025-10-29 07:50:39.313305
578	2013-12-28	5	12	14	32	34	42	16	5	2796466575	\N	2025-10-29 07:50:39.821056	2025-10-29 07:50:39.821056
579	2014-01-04	5	7	20	22	37	42	39	11	1396068444	\N	2025-10-29 07:50:40.328981	2025-10-29 07:50:40.328981
580	2014-01-11	5	7	9	11	32	35	33	7	2028610500	\N	2025-10-29 07:50:40.836868	2025-10-29 07:50:40.836868
581	2014-01-18	3	5	14	20	42	44	33	8	1844554547	\N	2025-10-29 07:50:41.345134	2025-10-29 07:50:41.345134
582	2014-01-25	2	12	14	33	40	41	25	4	3560558719	\N	2025-10-29 07:50:41.852924	2025-10-29 07:50:41.852924
583	2014-02-01	8	17	27	33	40	44	24	11	1341848353	\N	2025-10-29 07:50:42.360901	2025-10-29 07:50:42.360901
584	2014-02-08	7	18	30	39	40	41	36	3	5033183250	\N	2025-10-29 07:50:42.868999	2025-10-29 07:50:42.868999
585	2014-02-15	6	7	10	16	38	41	4	9	1620546334	\N	2025-10-29 07:50:43.376857	2025-10-29 07:50:43.376857
586	2014-02-22	2	7	12	15	21	34	5	8	1778354344	\N	2025-10-29 07:50:43.885531	2025-10-29 07:50:43.885531
587	2014-03-01	14	21	29	31	32	37	17	3	4974577375	\N	2025-10-29 07:50:44.394475	2025-10-29 07:50:44.394475
588	2014-03-08	2	8	15	22	25	41	30	5	2889342075	\N	2025-10-29 07:50:44.902656	2025-10-29 07:50:44.902656
589	2014-03-15	6	8	28	33	38	39	22	7	2136877983	\N	2025-10-29 07:50:45.411658	2025-10-29 07:50:45.411658
590	2014-03-22	20	30	36	38	41	45	23	7	2185183983	\N	2025-10-29 07:50:45.920294	2025-10-29 07:50:45.920294
591	2014-03-29	8	13	14	30	38	39	5	5	2964676200	\N	2025-10-29 07:50:46.42858	2025-10-29 07:50:46.42858
592	2014-04-05	2	5	6	13	28	44	43	6	2356381688	\N	2025-10-29 07:50:46.936902	2025-10-29 07:50:46.936902
593	2014-04-12	9	10	13	24	33	38	28	9	1532833500	\N	2025-10-29 07:50:47.445317	2025-10-29 07:50:47.445317
594	2014-04-19	2	8	13	25	28	37	3	11	1255592796	\N	2025-10-29 07:50:47.952845	2025-10-29 07:50:47.952845
595	2014-04-26	8	24	28	35	38	40	5	8	1744525219	\N	2025-10-29 07:50:48.461687	2025-10-29 07:50:48.461687
596	2014-05-03	3	4	12	14	25	43	17	10	1328267663	\N	2025-10-29 07:50:48.970928	2025-10-29 07:50:48.970928
597	2014-05-10	8	10	23	24	35	43	37	13	1057920606	\N	2025-10-29 07:50:49.478353	2025-10-29 07:50:49.478353
598	2014-05-17	4	12	24	33	38	45	22	16	833998594	\N	2025-10-29 07:50:49.988887	2025-10-29 07:50:49.988887
599	2014-05-24	5	12	17	29	34	35	27	8	1710918329	\N	2025-10-29 07:50:50.497126	2025-10-29 07:50:50.497126
600	2014-05-31	5	11	14	27	29	36	44	15	901798725	\N	2025-10-29 07:50:51.005246	2025-10-29 07:50:51.005246
601	2014-06-07	2	16	19	31	34	35	37	9	1524565209	\N	2025-10-29 07:50:57.562401	2025-10-29 07:50:57.562401
602	2014-06-14	13	14	22	27	30	38	2	8	1689530860	\N	2025-10-29 07:50:58.070907	2025-10-29 07:50:58.070907
603	2014-06-21	2	19	25	26	27	43	28	4	3452136563	\N	2025-10-29 07:50:58.579179	2025-10-29 07:50:58.579179
604	2014-06-28	2	6	18	21	33	34	30	11	1229141557	\N	2025-10-29 07:50:59.087348	2025-10-29 07:50:59.087348
605	2014-07-05	1	2	7	9	10	38	42	9	1394232250	\N	2025-10-29 07:50:59.620581	2025-10-29 07:50:59.620581
606	2014-07-12	1	5	6	14	20	39	22	10	1311566850	\N	2025-10-29 07:51:00.129613	2025-10-29 07:51:00.129613
607	2014-07-19	8	14	23	36	38	39	13	4	3494480907	\N	2025-10-29 07:51:00.637122	2025-10-29 07:51:00.637122
608	2014-07-26	4	8	18	19	39	44	41	7	1943530018	\N	2025-10-29 07:51:01.144991	2025-10-29 07:51:01.144991
609	2014-08-02	4	8	27	34	39	40	13	2	6339311438	\N	2025-10-29 07:51:01.653247	2025-10-29 07:51:01.653247
610	2014-08-09	14	18	20	23	28	36	33	4	3516018375	\N	2025-10-29 07:51:02.161412	2025-10-29 07:51:02.161412
611	2014-08-16	2	22	27	33	36	37	14	4	3502706157	\N	2025-10-29 07:51:02.668955	2025-10-29 07:51:02.668955
612	2014-08-23	6	9	18	19	25	33	40	11	1181705250	\N	2025-10-29 07:51:03.176728	2025-10-29 07:51:03.176728
613	2014-08-30	7	8	11	16	41	44	35	9	1549831209	\N	2025-10-29 07:51:03.686098	2025-10-29 07:51:03.686098
614	2014-09-06	8	21	25	39	40	44	18	6	2540975438	\N	2025-10-29 07:51:04.194337	2025-10-29 07:51:04.194337
615	2014-09-13	10	17	18	19	23	27	35	9	1535062417	\N	2025-10-29 07:51:04.716481	2025-10-29 07:51:04.716481
616	2014-09-20	5	13	18	23	40	45	3	9	1611811250	\N	2025-10-29 07:51:05.22472	2025-10-29 07:51:05.22472
617	2014-09-27	4	5	11	12	24	27	28	8	1629701860	\N	2025-10-29 07:51:05.734915	2025-10-29 07:51:05.734915
618	2014-10-04	8	16	25	30	42	43	15	5	2881326225	\N	2025-10-29 07:51:06.24547	2025-10-29 07:51:06.24547
619	2014-10-11	6	8	13	30	35	40	21	3	4612479375	\N	2025-10-29 07:51:06.753705	2025-10-29 07:51:06.753705
620	2014-10-18	2	16	17	32	39	45	40	7	2028283233	\N	2025-10-29 07:51:07.26265	2025-10-29 07:51:07.26265
621	2014-10-25	1	2	6	16	19	42	9	6	2359723500	\N	2025-10-29 07:51:07.771672	2025-10-29 07:51:07.771672
622	2014-11-01	9	15	16	21	28	34	24	9	1630598292	\N	2025-10-29 07:51:08.28013	2025-10-29 07:51:08.28013
623	2014-11-08	7	13	30	39	41	45	25	8	1813702594	\N	2025-10-29 07:51:08.788165	2025-10-29 07:51:08.788165
624	2014-11-15	1	7	19	26	27	35	16	5	2763729450	\N	2025-10-29 07:51:09.295801	2025-10-29 07:51:09.295801
625	2014-11-22	3	6	7	20	21	39	13	5	2765184675	\N	2025-10-29 07:51:09.804767	2025-10-29 07:51:09.804767
626	2014-11-29	13	14	26	33	40	43	15	8	1717871110	\N	2025-10-29 07:51:10.314982	2025-10-29 07:51:10.314982
627	2014-12-06	2	9	22	25	31	45	12	10	1352230650	\N	2025-10-29 07:51:10.824389	2025-10-29 07:51:10.824389
628	2014-12-13	1	7	12	15	23	42	11	9	1499942875	\N	2025-10-29 07:51:11.332716	2025-10-29 07:51:11.332716
629	2014-12-20	19	28	31	38	43	44	1	5	2919433575	\N	2025-10-29 07:51:11.843274	2025-10-29 07:51:11.843274
630	2014-12-27	8	17	21	24	27	31	15	3	4836305500	\N	2025-10-29 07:51:12.350719	2025-10-29 07:51:12.350719
631	2015-01-03	1	2	4	23	31	34	8	4	3919853532	\N	2025-10-29 07:51:12.858773	2025-10-29 07:51:12.858773
632	2015-01-10	15	18	21	32	35	44	6	11	1432587716	\N	2025-10-29 07:51:13.368996	2025-10-29 07:51:13.368996
633	2015-01-17	9	12	19	20	39	41	13	12	1217257094	\N	2025-10-29 07:51:13.877454	2025-10-29 07:51:13.877454
634	2015-01-24	4	10	11	12	20	27	38	13	1077935106	\N	2025-10-29 07:51:14.3858	2025-10-29 07:51:14.3858
635	2015-01-31	11	13	25	26	29	33	32	8	1855587235	\N	2025-10-29 07:51:14.893871	2025-10-29 07:51:14.893871
636	2015-02-07	6	7	15	16	20	31	26	8	1832362219	\N	2025-10-29 07:51:15.40134	2025-10-29 07:51:15.40134
637	2015-02-14	3	16	22	37	38	44	23	4	3899241094	\N	2025-10-29 07:51:15.909212	2025-10-29 07:51:15.909212
638	2015-02-21	7	18	22	24	31	34	6	7	2229403179	\N	2025-10-29 07:51:16.417549	2025-10-29 07:51:16.417549
639	2015-02-28	6	15	22	23	25	32	40	4	4061185219	\N	2025-10-29 07:51:16.927323	2025-10-29 07:51:16.927323
640	2015-03-07	14	15	18	21	26	35	23	9	1728768834	\N	2025-10-29 07:51:17.435	2025-10-29 07:51:17.435
641	2015-03-14	11	18	21	36	37	43	12	8	1990074563	\N	2025-10-29 07:51:17.943263	2025-10-29 07:51:17.943263
642	2015-03-21	8	17	18	24	39	45	32	12	1251460438	\N	2025-10-29 07:51:18.452097	2025-10-29 07:51:18.452097
643	2015-03-28	15	24	31	32	33	40	13	6	2535763625	\N	2025-10-29 07:51:18.960261	2025-10-29 07:51:18.960261
644	2015-04-04	5	13	17	23	28	36	8	8	1831451204	\N	2025-10-29 07:51:19.467794	2025-10-29 07:51:19.467794
645	2015-04-11	1	4	16	26	40	41	31	4	3696297750	\N	2025-10-29 07:51:19.976578	2025-10-29 07:51:19.976578
646	2015-04-18	2	9	24	41	43	45	30	7	2215498393	\N	2025-10-29 07:51:20.485371	2025-10-29 07:51:20.485371
647	2015-04-25	5	16	21	23	24	30	29	7	2189725608	\N	2025-10-29 07:51:20.993141	2025-10-29 07:51:20.993141
648	2015-05-02	13	19	28	37	38	43	4	7	2120987947	\N	2025-10-29 07:51:21.500888	2025-10-29 07:51:21.500888
649	2015-05-09	3	21	22	33	41	42	20	5	2948042100	\N	2025-10-29 07:51:22.009792	2025-10-29 07:51:22.009792
650	2015-05-16	3	4	7	11	31	41	35	5	2849298900	\N	2025-10-29 07:51:22.51888	2025-10-29 07:51:22.51888
651	2015-05-23	11	12	16	26	29	44	18	8	1855306454	\N	2025-10-29 07:51:23.026788	2025-10-29 07:51:23.026788
652	2015-05-30	3	13	15	40	41	44	20	5	3003483525	\N	2025-10-29 07:51:23.534054	2025-10-29 07:51:23.534054
653	2015-06-06	5	6	26	27	38	39	1	14	980958670	\N	2025-10-29 07:51:24.042039	2025-10-29 07:51:24.042039
654	2015-06-13	16	21	26	31	36	43	6	8	1879301391	\N	2025-10-29 07:51:24.552312	2025-10-29 07:51:24.552312
655	2015-06-20	7	37	38	39	40	44	18	9	1661439625	\N	2025-10-29 07:51:25.060009	2025-10-29 07:51:25.060009
656	2015-06-27	3	7	14	16	31	40	39	2	7330002750	\N	2025-10-29 07:51:25.567905	2025-10-29 07:51:25.567905
657	2015-07-04	10	14	19	39	40	43	23	9	1694762792	\N	2025-10-29 07:51:26.076028	2025-10-29 07:51:26.076028
658	2015-07-11	8	19	25	28	32	36	37	9	1634031375	\N	2025-10-29 07:51:26.583904	2025-10-29 07:51:26.583904
659	2015-07-18	7	18	19	27	29	42	45	11	1336604216	\N	2025-10-29 07:51:27.09209	2025-10-29 07:51:27.09209
660	2015-07-25	4	9	23	33	39	44	14	10	1421272575	\N	2025-10-29 07:51:27.59965	2025-10-29 07:51:27.59965
661	2015-08-01	2	3	12	20	27	38	40	8	1713025547	\N	2025-10-29 07:51:28.10819	2025-10-29 07:51:28.10819
662	2015-08-08	5	6	9	11	15	37	26	8	1689733688	\N	2025-10-29 07:51:28.619008	2025-10-29 07:51:28.619008
663	2015-08-15	3	5	8	19	38	42	20	7	2080244143	\N	2025-10-29 07:51:29.129061	2025-10-29 07:51:29.129061
664	2015-08-22	10	20	33	36	41	44	5	10	1536801338	\N	2025-10-29 07:51:29.636961	2025-10-29 07:51:29.636961
665	2015-08-29	5	6	11	17	38	44	13	4	3643230375	\N	2025-10-29 07:51:30.148431	2025-10-29 07:51:30.148431
666	2015-09-05	2	4	6	11	17	28	16	6	2396901063	\N	2025-10-29 07:51:30.654431	2025-10-29 07:51:30.654431
667	2015-09-12	15	17	25	37	42	43	13	7	2228764393	\N	2025-10-29 07:51:31.161865	2025-10-29 07:51:31.161865
668	2015-09-19	12	14	15	24	27	32	3	5	2991158625	\N	2025-10-29 07:51:31.668851	2025-10-29 07:51:31.668851
669	2015-09-26	7	8	20	29	33	38	9	6	2708173188	\N	2025-10-29 07:51:32.177103	2025-10-29 07:51:32.177103
670	2015-10-03	11	18	26	27	40	41	25	12	1191725219	\N	2025-10-29 07:51:32.685245	2025-10-29 07:51:32.685245
671	2015-10-10	7	9	10	13	31	35	24	4	3722322844	\N	2025-10-29 07:51:33.192934	2025-10-29 07:51:33.192934
672	2015-10-17	8	21	28	31	36	45	43	9	1754745000	\N	2025-10-29 07:51:33.700929	2025-10-29 07:51:33.700929
673	2015-10-24	7	10	17	29	33	44	5	10	1491453300	\N	2025-10-29 07:51:34.208824	2025-10-29 07:51:34.208824
674	2015-10-31	9	10	14	25	27	31	11	8	1770565500	\N	2025-10-29 07:51:34.717683	2025-10-29 07:51:34.717683
675	2015-11-07	1	8	11	15	18	45	7	4	3514549032	\N	2025-10-29 07:51:35.225473	2025-10-29 07:51:35.225473
676	2015-11-14	1	8	17	34	39	45	27	8	1879726500	\N	2025-10-29 07:51:35.733801	2025-10-29 07:51:35.733801
677	2015-11-21	12	15	24	36	41	44	42	8	1921114407	\N	2025-10-29 07:51:36.241546	2025-10-29 07:51:36.241546
678	2015-11-28	4	5	6	12	25	37	45	6	2288490188	\N	2025-10-29 07:51:36.748995	2025-10-29 07:51:36.748995
679	2015-12-05	3	5	7	14	26	34	35	5	2863005600	\N	2025-10-29 07:51:37.257272	2025-10-29 07:51:37.257272
680	2015-12-12	4	10	19	29	32	42	30	14	1110570563	\N	2025-10-29 07:51:37.765214	2025-10-29 07:51:37.765214
681	2015-12-19	21	24	27	29	43	44	7	6	2696328938	\N	2025-10-29 07:51:38.275723	2025-10-29 07:51:38.275723
682	2015-12-26	17	23	27	35	38	43	2	4	4063713563	\N	2025-10-29 07:51:38.785329	2025-10-29 07:51:38.785329
683	2016-01-02	6	13	20	27	28	40	15	16	1010930883	\N	2025-10-29 07:51:39.293538	2025-10-29 07:51:39.293538
684	2016-01-09	1	11	15	17	25	39	40	9	1688815709	\N	2025-10-29 07:51:39.802518	2025-10-29 07:51:39.802518
685	2016-01-16	6	7	12	28	38	40	18	11	1494367671	\N	2025-10-29 07:51:40.311655	2025-10-29 07:51:40.311655
686	2016-01-23	7	12	15	24	25	43	13	8	1937531719	\N	2025-10-29 07:51:40.82018	2025-10-29 07:51:40.82018
687	2016-01-30	1	8	10	13	28	42	45	6	2720029313	\N	2025-10-29 07:51:41.329113	2025-10-29 07:51:41.329113
688	2016-02-06	5	15	22	23	34	35	2	9	1967536750	\N	2025-10-29 07:51:41.836883	2025-10-29 07:51:41.836883
689	2016-02-13	7	17	19	30	36	38	34	7	2321775911	\N	2025-10-29 07:51:42.347495	2025-10-29 07:51:42.347495
690	2016-02-20	24	25	33	34	38	39	43	15	1126507625	\N	2025-10-29 07:51:42.859984	2025-10-29 07:51:42.859984
691	2016-02-27	15	27	33	35	43	45	16	6	2839296750	\N	2025-10-29 07:51:43.372352	2025-10-29 07:51:43.372352
692	2016-03-05	3	11	14	15	32	36	44	7	2301273697	\N	2025-10-29 07:51:43.881403	2025-10-29 07:51:43.881403
693	2016-03-12	1	6	11	28	34	42	30	10	1642763813	\N	2025-10-29 07:51:44.388744	2025-10-29 07:51:44.388744
694	2016-03-19	7	15	20	25	33	43	12	10	1555036388	\N	2025-10-29 07:51:44.89824	2025-10-29 07:51:44.89824
695	2016-03-26	4	18	26	33	34	38	14	11	1450214830	\N	2025-10-29 07:51:45.411334	2025-10-29 07:51:45.411334
696	2016-04-02	1	7	16	18	34	38	21	10	1632054413	\N	2025-10-29 07:51:45.919119	2025-10-29 07:51:45.919119
697	2016-04-09	2	5	8	11	33	39	31	10	1531443038	\N	2025-10-29 07:51:46.42758	2025-10-29 07:51:46.42758
698	2016-04-16	3	11	13	21	33	37	18	8	1921084125	\N	2025-10-29 07:51:46.941683	2025-10-29 07:51:46.941683
699	2016-04-23	4	5	8	16	21	29	3	8	1995411375	\N	2025-10-29 07:51:47.45027	2025-10-29 07:51:47.45027
700	2016-04-30	11	23	28	29	30	44	13	8	2082099188	\N	2025-10-29 07:51:47.957876	2025-10-29 07:51:47.957876
701	2016-05-07	3	10	14	16	36	38	35	10	1583183175	\N	2025-10-29 07:51:54.518539	2025-10-29 07:51:54.518539
702	2016-05-14	3	13	16	24	26	29	9	11	1465091387	\N	2025-10-29 07:51:55.026198	2025-10-29 07:51:55.026198
703	2016-05-21	10	28	31	33	41	44	21	5	3235784100	\N	2025-10-29 07:51:55.550102	2025-10-29 07:51:55.550102
704	2016-05-28	1	4	8	23	33	42	45	4	3865190344	\N	2025-10-29 07:51:56.061692	2025-10-29 07:51:56.061692
705	2016-06-04	1	6	17	22	28	45	23	4	3987206532	\N	2025-10-29 07:51:56.571123	2025-10-29 07:51:56.571123
706	2016-06-11	3	4	6	10	28	30	37	4	3831746063	\N	2025-10-29 07:51:57.079398	2025-10-29 07:51:57.079398
707	2016-06-18	2	12	19	24	39	44	35	12	1322167313	\N	2025-10-29 07:51:57.588098	2025-10-29 07:51:57.588098
708	2016-06-25	2	10	16	19	34	45	1	4	4099552219	\N	2025-10-29 07:51:58.096955	2025-10-29 07:51:58.096955
709	2016-07-02	10	18	30	36	39	44	32	14	1165271625	\N	2025-10-29 07:51:58.605364	2025-10-29 07:51:58.605364
710	2016-07-09	3	4	9	24	25	33	10	5	2895441150	\N	2025-10-29 07:51:59.115357	2025-10-29 07:51:59.115357
711	2016-07-16	11	15	24	35	37	45	42	7	2277413358	\N	2025-10-29 07:51:59.623251	2025-10-29 07:51:59.623251
712	2016-07-23	17	20	30	31	33	45	19	4	4034485125	\N	2025-10-29 07:52:00.130399	2025-10-29 07:52:00.130399
713	2016-07-30	2	5	15	18	19	23	44	9	1714720917	\N	2025-10-29 07:52:00.638666	2025-10-29 07:52:00.638666
714	2016-08-06	1	7	22	33	37	40	20	7	2085131733	\N	2025-10-29 07:52:01.147849	2025-10-29 07:52:01.147849
715	2016-08-13	2	7	27	33	41	44	10	6	2605510438	\N	2025-10-29 07:52:01.656557	2025-10-29 07:52:01.656557
716	2016-08-20	2	6	13	16	29	30	21	12	1358752157	\N	2025-10-29 07:52:02.163658	2025-10-29 07:52:02.163658
717	2016-08-27	2	11	19	25	28	32	44	6	2702433688	\N	2025-10-29 07:52:02.671897	2025-10-29 07:52:02.671897
718	2016-09-03	4	11	20	23	32	39	40	17	926166464	\N	2025-10-29 07:52:03.179303	2025-10-29 07:52:03.179303
719	2016-09-10	4	8	13	19	20	43	26	9	1879581334	\N	2025-10-29 07:52:03.68757	2025-10-29 07:52:03.68757
720	2016-09-17	1	12	29	34	36	37	41	14	1233770358	\N	2025-10-29 07:52:04.197274	2025-10-29 07:52:04.197274
721	2016-09-24	1	28	35	41	43	44	31	8	2273767360	\N	2025-10-29 07:52:04.70889	2025-10-29 07:52:04.70889
722	2016-10-01	12	14	21	30	39	43	45	4	4365422719	\N	2025-10-29 07:52:05.216748	2025-10-29 07:52:05.216748
723	2016-10-08	20	30	33	35	36	44	22	8	2114365360	\N	2025-10-29 07:52:05.725516	2025-10-29 07:52:05.725516
724	2016-10-15	2	8	33	35	37	41	14	12	1427789813	\N	2025-10-29 07:52:06.234473	2025-10-29 07:52:06.234473
725	2016-10-22	6	7	19	21	41	43	38	11	1579217250	\N	2025-10-29 07:52:06.742039	2025-10-29 07:52:06.742039
726	2016-10-29	1	11	21	23	34	44	24	14	1166872634	\N	2025-10-29 07:52:07.25053	2025-10-29 07:52:07.25053
727	2016-11-05	7	8	10	19	21	31	20	14	1115107742	\N	2025-10-29 07:52:07.759302	2025-10-29 07:52:07.759302
728	2016-11-12	3	6	10	30	34	37	36	5	3243464400	\N	2025-10-29 07:52:08.267622	2025-10-29 07:52:08.267622
729	2016-11-19	11	17	21	26	36	45	16	4	4198250719	\N	2025-10-29 07:52:08.779933	2025-10-29 07:52:08.779933
730	2016-11-26	4	10	14	15	18	22	39	8	2017382110	\N	2025-10-29 07:52:09.287667	2025-10-29 07:52:09.287667
731	2016-12-03	2	7	13	25	42	45	39	7	2340471054	\N	2025-10-29 07:52:09.796466	2025-10-29 07:52:09.796466
732	2016-12-10	2	4	5	17	27	32	43	7	2203270608	\N	2025-10-29 07:52:10.30806	2025-10-29 07:52:10.30806
733	2016-12-17	11	24	32	33	35	40	13	4	4016725125	\N	2025-10-29 07:52:10.81673	2025-10-29 07:52:10.81673
734	2016-12-24	6	16	37	38	41	45	18	9	1949395500	\N	2025-10-29 07:52:11.324571	2025-10-29 07:52:11.324571
735	2016-12-31	5	10	13	27	37	41	4	10	1847231588	\N	2025-10-29 07:52:11.832682	2025-10-29 07:52:11.832682
736	2017-01-07	2	11	17	18	21	27	6	5	3397362225	\N	2025-10-29 07:52:12.341327	2025-10-29 07:52:12.341327
737	2017-01-14	13	15	18	24	27	41	11	4	4283061000	\N	2025-10-29 07:52:12.850018	2025-10-29 07:52:12.850018
738	2017-01-21	23	27	28	38	42	43	36	11	1634191091	\N	2025-10-29 07:52:13.359483	2025-10-29 07:52:13.359483
739	2017-01-28	7	22	29	33	34	35	30	4	4744122282	\N	2025-10-29 07:52:13.86752	2025-10-29 07:52:13.86752
740	2017-02-04	4	8	9	16	17	19	31	18	936929792	\N	2025-10-29 07:52:14.376577	2025-10-29 07:52:14.376577
741	2017-02-11	5	21	27	34	44	45	16	6	3043595938	\N	2025-10-29 07:52:14.886569	2025-10-29 07:52:14.886569
742	2017-02-18	8	10	13	36	37	40	6	16	1111814813	\N	2025-10-29 07:52:15.394024	2025-10-29 07:52:15.394024
743	2017-02-25	15	19	21	34	41	44	10	7	2608641000	\N	2025-10-29 07:52:15.9027	2025-10-29 07:52:15.9027
744	2017-03-04	10	15	18	21	34	41	43	15	1155411575	\N	2025-10-29 07:52:16.410997	2025-10-29 07:52:16.410997
745	2017-03-11	1	2	3	9	12	23	10	20	746822982	\N	2025-10-29 07:52:16.919447	2025-10-29 07:52:16.919447
746	2017-03-18	3	12	33	36	42	45	25	9	2038623709	\N	2025-10-29 07:52:17.428228	2025-10-29 07:52:17.428228
747	2017-03-25	7	9	12	14	23	28	17	9	1903214584	\N	2025-10-29 07:52:17.936325	2025-10-29 07:52:17.936325
748	2017-04-01	3	10	13	22	31	32	29	9	1928246542	\N	2025-10-29 07:52:18.445347	2025-10-29 07:52:18.445347
749	2017-04-08	12	14	24	26	34	45	41	13	1350104395	\N	2025-10-29 07:52:18.953884	2025-10-29 07:52:18.953884
750	2017-04-15	1	2	15	19	24	36	12	7	2522104286	\N	2025-10-29 07:52:19.463258	2025-10-29 07:52:19.463258
751	2017-04-22	3	4	16	20	28	44	17	8	2097968110	\N	2025-10-29 07:52:19.973847	2025-10-29 07:52:19.973847
752	2017-04-29	4	16	20	33	40	43	7	9	1870358834	\N	2025-10-29 07:52:20.483164	2025-10-29 07:52:20.483164
753	2017-05-06	2	17	19	24	37	41	3	6	2711105063	\N	2025-10-29 07:52:20.991249	2025-10-29 07:52:20.991249
754	2017-05-13	2	8	17	24	29	31	32	5	3427542000	\N	2025-10-29 07:52:21.498872	2025-10-29 07:52:21.498872
755	2017-05-20	13	14	26	28	30	36	37	8	2214427266	\N	2025-10-29 07:52:22.00636	2025-10-29 07:52:22.00636
756	2017-05-27	10	14	16	18	27	28	4	5	3414434700	\N	2025-10-29 07:52:22.514034	2025-10-29 07:52:22.514034
757	2017-06-03	6	7	11	17	33	44	1	21	739839858	\N	2025-10-29 07:52:23.022561	2025-10-29 07:52:23.022561
758	2017-06-10	5	9	12	30	39	43	24	8	2078969954	\N	2025-10-29 07:52:23.531222	2025-10-29 07:52:23.531222
759	2017-06-17	9	33	36	40	42	43	32	6	3032670500	\N	2025-10-29 07:52:24.039635	2025-10-29 07:52:24.039635
760	2017-06-24	10	22	27	31	42	43	12	8	2253299391	\N	2025-10-29 07:52:24.548529	2025-10-29 07:52:24.548529
761	2017-07-01	4	7	11	24	42	45	30	7	2392730518	\N	2025-10-29 07:52:25.056416	2025-10-29 07:52:25.056416
762	2017-07-08	1	3	12	21	26	41	16	10	1631432063	\N	2025-10-29 07:52:25.564647	2025-10-29 07:52:25.564647
763	2017-07-15	3	8	16	32	34	43	10	8	2138130000	\N	2025-10-29 07:52:26.072678	2025-10-29 07:52:26.072678
764	2017-07-22	7	22	24	31	34	36	15	7	2459975465	\N	2025-10-29 07:52:26.581995	2025-10-29 07:52:26.581995
765	2017-07-29	1	3	8	12	42	43	33	15	1109214250	\N	2025-10-29 07:52:27.090442	2025-10-29 07:52:27.090442
766	2017-08-05	9	30	34	35	39	41	21	8	2173637297	\N	2025-10-29 07:52:27.598877	2025-10-29 07:52:27.598877
767	2017-08-12	5	15	20	31	34	42	22	15	1163768725	\N	2025-10-29 07:52:28.108537	2025-10-29 07:52:28.108537
768	2017-08-19	7	27	29	30	38	44	4	13	1363572260	\N	2025-10-29 07:52:28.616076	2025-10-29 07:52:28.616076
769	2017-08-26	5	7	11	16	41	45	4	9	1930760042	\N	2025-10-29 07:52:29.123864	2025-10-29 07:52:29.123864
770	2017-09-02	1	9	12	23	39	43	34	8	2163099329	\N	2025-10-29 07:52:29.633101	2025-10-29 07:52:29.633101
771	2017-09-09	6	10	17	18	21	29	30	4	4362644907	\N	2025-10-29 07:52:30.145253	2025-10-29 07:52:30.145253
772	2017-09-16	5	6	11	14	21	41	32	10	1769608838	\N	2025-10-29 07:52:30.653114	2025-10-29 07:52:30.653114
773	2017-09-23	8	12	19	21	31	35	44	11	1609403080	\N	2025-10-29 07:52:31.161164	2025-10-29 07:52:31.161164
774	2017-09-30	12	15	18	28	34	42	9	11	1709721512	\N	2025-10-29 07:52:31.6709	2025-10-29 07:52:31.6709
775	2017-10-07	11	12	29	33	38	42	17	5	3470437650	\N	2025-10-29 07:52:32.181518	2025-10-29 07:52:32.181518
776	2017-10-14	8	9	18	21	28	40	20	7	2557579393	\N	2025-10-29 07:52:32.689017	2025-10-29 07:52:32.689017
777	2017-10-21	6	12	17	21	34	37	18	21	833468036	\N	2025-10-29 07:52:33.196927	2025-10-29 07:52:33.196927
778	2017-10-28	6	21	35	36	37	41	11	3	6264069500	\N	2025-10-29 07:52:33.705023	2025-10-29 07:52:33.705023
779	2017-11-04	6	12	19	24	34	41	4	11	1527709296	\N	2025-10-29 07:52:34.213059	2025-10-29 07:52:34.213059
780	2017-11-11	15	17	19	21	27	45	16	11	1667520137	\N	2025-10-29 07:52:34.721083	2025-10-29 07:52:34.721083
781	2017-11-18	11	16	18	19	24	39	43	9	1882891542	\N	2025-10-29 07:52:35.230034	2025-10-29 07:52:35.230034
782	2017-11-25	6	18	31	34	38	45	20	9	1946487625	\N	2025-10-29 07:52:35.737821	2025-10-29 07:52:35.737821
783	2017-12-02	14	15	16	17	38	45	36	4	4603964625	\N	2025-10-29 07:52:36.245538	2025-10-29 07:52:36.245538
784	2017-12-09	3	10	23	24	31	39	22	9	1908678000	\N	2025-10-29 07:52:36.753645	2025-10-29 07:52:36.753645
785	2017-12-16	4	6	15	25	26	33	40	6	2886622688	\N	2025-10-29 07:52:37.263078	2025-10-29 07:52:37.263078
786	2017-12-23	12	15	16	20	24	30	38	4	4551365250	\N	2025-10-29 07:52:37.771692	2025-10-29 07:52:37.771692
787	2017-12-30	5	6	13	16	27	28	9	6	3092108313	\N	2025-10-29 07:52:38.280945	2025-10-29 07:52:38.280945
788	2018-01-06	2	10	11	19	35	39	29	13	1401475154	\N	2025-10-29 07:52:38.789052	2025-10-29 07:52:38.789052
789	2018-01-13	2	6	7	12	19	45	38	15	1140976825	\N	2025-10-29 07:52:39.297052	2025-10-29 07:52:39.297052
790	2018-01-20	3	8	19	27	30	41	12	16	1160516274	\N	2025-10-29 07:52:39.805561	2025-10-29 07:52:39.805561
791	2018-01-27	2	10	12	31	33	42	32	14	1253081893	\N	2025-10-29 07:52:40.313208	2025-10-29 07:52:40.313208
792	2018-02-03	2	7	19	25	29	36	16	7	2655736768	\N	2025-10-29 07:52:40.821169	2025-10-29 07:52:40.821169
793	2018-02-10	10	15	21	35	38	43	31	5	3750146775	\N	2025-10-29 07:52:41.330948	2025-10-29 07:52:41.330948
794	2018-02-17	6	7	18	19	30	38	13	7	2650940304	\N	2025-10-29 07:52:41.840922	2025-10-29 07:52:41.840922
795	2018-02-24	3	10	13	26	34	38	36	11	1714977000	\N	2025-10-29 07:52:42.348618	2025-10-29 07:52:42.348618
796	2018-03-03	1	21	26	36	40	41	5	7	2763490340	\N	2025-10-29 07:52:42.856204	2025-10-29 07:52:42.856204
797	2018-03-10	5	22	31	32	39	45	36	8	2397028125	\N	2025-10-29 07:52:43.364966	2025-10-29 07:52:43.364966
798	2018-03-17	2	10	14	22	32	36	41	7	2710791911	\N	2025-10-29 07:52:43.872449	2025-10-29 07:52:43.872449
799	2018-03-24	12	17	23	34	42	45	33	10	1826427225	\N	2025-10-29 07:52:44.38126	2025-10-29 07:52:44.38126
800	2018-03-31	1	4	10	12	28	45	26	11	1632246205	\N	2025-10-29 07:52:44.889226	2025-10-29 07:52:44.889226
801	2018-04-07	17	25	28	37	43	44	2	8	2256786657	\N	2025-10-29 07:52:50.433444	2025-10-29 07:52:50.433444
802	2018-04-14	10	11	12	18	24	42	27	16	1082947993	\N	2025-10-29 07:52:50.940956	2025-10-29 07:52:50.940956
803	2018-04-21	5	9	14	26	30	43	2	5	3663810225	\N	2025-10-29 07:52:51.449277	2025-10-29 07:52:51.449277
804	2018-04-28	1	10	13	26	32	36	9	11	1631996523	\N	2025-10-29 07:52:51.956796	2025-10-29 07:52:51.956796
805	2018-05-05	3	12	13	18	31	32	42	4	4266061969	\N	2025-10-29 07:52:52.465982	2025-10-29 07:52:52.465982
806	2018-05-12	14	20	23	31	37	38	27	7	2640760875	\N	2025-10-29 07:52:52.973565	2025-10-29 07:52:52.973565
807	2018-05-19	6	10	18	25	34	35	33	7	2437662322	\N	2025-10-29 07:52:53.482305	2025-10-29 07:52:53.482305
808	2018-05-26	15	21	31	32	41	43	24	6	3087620500	\N	2025-10-29 07:52:53.988986	2025-10-29 07:52:53.988986
809	2018-06-02	6	11	15	17	23	40	39	6	2921372750	\N	2025-10-29 07:52:54.497575	2025-10-29 07:52:54.497575
810	2018-06-09	5	10	13	21	39	43	11	8	2231598047	\N	2025-10-29 07:52:55.006955	2025-10-29 07:52:55.006955
811	2018-06-16	8	11	19	21	36	45	25	7	2524148197	\N	2025-10-29 07:52:55.514899	2025-10-29 07:52:55.514899
812	2018-06-23	1	3	12	14	16	43	10	6	2947954750	\N	2025-10-29 07:52:56.026798	2025-10-29 07:52:56.026798
813	2018-06-30	11	30	34	35	42	44	27	4	4591763157	\N	2025-10-29 07:52:56.53687	2025-10-29 07:52:56.53687
814	2018-07-07	2	21	28	38	42	45	30	6	3067192063	\N	2025-10-29 07:52:57.045903	2025-10-29 07:52:57.045903
815	2018-07-14	17	21	25	26	27	36	4	7	2579855358	\N	2025-10-29 07:52:57.554307	2025-10-29 07:52:57.554307
816	2018-07-21	12	18	19	29	31	39	7	8	2128107938	\N	2025-10-29 07:52:58.062806	2025-10-29 07:52:58.062806
817	2018-07-28	3	9	12	13	25	43	34	9	1868477334	\N	2025-10-29 07:52:58.571524	2025-10-29 07:52:58.571524
818	2018-08-04	14	15	25	28	29	30	3	13	1380804318	\N	2025-10-29 07:52:59.079633	2025-10-29 07:52:59.079633
819	2018-08-11	16	25	33	38	40	45	15	7	2594534840	\N	2025-10-29 07:52:59.588984	2025-10-29 07:52:59.588984
820	2018-08-18	10	21	22	30	35	42	6	4	4627313532	\N	2025-10-29 07:53:00.096391	2025-10-29 07:53:00.096391
821	2018-08-25	1	12	13	24	29	44	16	14	1316155956	\N	2025-10-29 07:53:00.604909	2025-10-29 07:53:00.604909
822	2018-09-01	9	18	20	24	27	36	12	3	5930898625	\N	2025-10-29 07:53:01.112594	2025-10-29 07:53:01.112594
823	2018-09-08	12	18	24	26	39	40	15	9	2009843917	\N	2025-10-29 07:53:01.620149	2025-10-29 07:53:01.620149
824	2018-09-15	7	9	24	29	34	38	26	15	1256646550	\N	2025-10-29 07:53:02.127498	2025-10-29 07:53:02.127498
825	2018-09-22	8	15	21	31	33	38	42	12	1658710563	\N	2025-10-29 07:53:02.636247	2025-10-29 07:53:02.636247
826	2018-09-29	13	16	24	25	33	36	42	9	2075192084	\N	2025-10-29 07:53:03.144148	2025-10-29 07:53:03.144148
827	2018-10-06	5	11	12	29	33	44	14	15	1206500375	\N	2025-10-29 07:53:03.651385	2025-10-29 07:53:03.651385
828	2018-10-13	4	7	13	29	31	39	18	13	1455185972	\N	2025-10-29 07:53:04.159921	2025-10-29 07:53:04.159921
829	2018-10-20	4	5	31	35	43	45	29	8	2444650641	\N	2025-10-29 07:53:04.6684	2025-10-29 07:53:04.6684
830	2018-10-27	5	6	16	18	37	38	17	9	2060528750	\N	2025-10-29 07:53:05.176394	2025-10-29 07:53:05.176394
831	2018-11-03	3	10	16	19	31	39	9	16	1110702258	\N	2025-10-29 07:53:05.683487	2025-10-29 07:53:05.683487
832	2018-11-10	13	14	19	26	40	43	30	9	2088204584	\N	2025-10-29 07:53:06.189968	2025-10-29 07:53:06.189968
833	2018-11-17	12	18	30	39	41	42	19	8	2356317282	\N	2025-10-29 07:53:06.702149	2025-10-29 07:53:06.702149
834	2018-11-24	6	8	18	35	42	43	3	11	1690693671	\N	2025-10-29 07:53:07.20983	2025-10-29 07:53:07.20983
835	2018-12-01	9	10	13	28	38	45	35	15	1233681125	\N	2025-10-29 07:53:07.717967	2025-10-29 07:53:07.717967
836	2018-12-08	1	9	11	14	26	28	19	14	1257843670	\N	2025-10-29 07:53:08.225463	2025-10-29 07:53:08.225463
837	2018-12-15	2	25	28	30	33	45	6	6	3144449125	\N	2025-10-29 07:53:08.73477	2025-10-29 07:53:08.73477
838	2018-12-22	9	14	17	33	36	38	20	5	3813733050	\N	2025-10-29 07:53:09.24477	2025-10-29 07:53:09.24477
839	2018-12-29	3	9	11	12	13	19	35	13	1359454904	\N	2025-10-29 07:53:09.753588	2025-10-29 07:53:09.753588
840	2019-01-05	2	4	11	28	29	43	27	10	2042961788	\N	2025-10-29 07:53:10.26148	2025-10-29 07:53:10.26148
841	2019-01-12	5	11	14	30	33	38	24	17	1116095714	\N	2025-10-29 07:53:10.768838	2025-10-29 07:53:10.768838
842	2019-01-19	14	26	32	36	39	42	38	10	2035475025	\N	2025-10-29 07:53:11.277667	2025-10-29 07:53:11.277667
843	2019-01-26	19	21	30	33	34	42	4	5	4012970100	\N	2025-10-29 07:53:11.786734	2025-10-29 07:53:11.786734
844	2019-02-02	7	8	13	15	33	45	18	18	1162963542	\N	2025-10-29 07:53:12.294722	2025-10-29 07:53:12.294722
845	2019-02-09	1	16	29	33	40	45	6	11	1891217182	\N	2025-10-29 07:53:12.80386	2025-10-29 07:53:12.80386
846	2019-02-16	5	18	30	41	43	45	13	13	1596884395	\N	2025-10-29 07:53:13.312232	2025-10-29 07:53:13.312232
847	2019-02-23	12	16	26	28	30	42	22	8	2520846657	\N	2025-10-29 07:53:13.819568	2025-10-29 07:53:13.819568
848	2019-03-02	1	2	16	22	38	39	34	7	3011580858	\N	2025-10-29 07:53:14.326853	2025-10-29 07:53:14.326853
849	2019-03-09	5	13	17	29	34	39	3	17	1158252883	\N	2025-10-29 07:53:14.834591	2025-10-29 07:53:14.834591
850	2019-03-16	16	20	24	28	36	39	5	6	3377587875	\N	2025-10-29 07:53:15.342484	2025-10-29 07:53:15.342484
851	2019-03-23	14	18	22	26	31	44	40	8	2483692313	\N	2025-10-29 07:53:15.850204	2025-10-29 07:53:15.850204
852	2019-03-30	11	17	28	30	33	35	9	4	4801543407	\N	2025-10-29 07:53:16.360272	2025-10-29 07:53:16.360272
853	2019-04-06	2	8	23	26	27	44	13	7	2885006786	\N	2025-10-29 07:53:16.86923	2025-10-29 07:53:16.86923
854	2019-04-13	20	25	31	32	36	43	3	6	3421706750	\N	2025-10-29 07:53:17.377856	2025-10-29 07:53:17.377856
855	2019-04-20	8	15	17	19	43	44	7	9	2269510500	\N	2025-10-29 07:53:17.886062	2025-10-29 07:53:17.886062
856	2019-04-27	10	24	40	41	43	44	17	5	3977927550	\N	2025-10-29 07:53:18.395047	2025-10-29 07:53:18.395047
857	2019-05-04	6	10	16	28	34	38	43	15	1284915425	\N	2025-10-29 07:53:18.903186	2025-10-29 07:53:18.903186
858	2019-05-11	9	13	32	38	39	43	23	9	2202347459	\N	2025-10-29 07:53:19.41474	2025-10-29 07:53:19.41474
859	2019-05-18	8	22	35	38	39	41	24	11	1853927489	\N	2025-10-29 07:53:19.924298	2025-10-29 07:53:19.924298
860	2019-05-25	4	8	18	25	27	32	42	10	1879899825	\N	2025-10-29 07:53:20.431927	2025-10-29 07:53:20.431927
861	2019-06-01	11	17	19	21	22	25	24	4	4872108844	\N	2025-10-29 07:53:20.939838	2025-10-29 07:53:20.939838
862	2019-06-08	10	34	38	40	42	43	32	9	2190922709	\N	2025-10-29 07:53:21.44823	2025-10-29 07:53:21.44823
863	2019-06-15	16	21	28	35	39	43	12	7	2853357322	\N	2025-10-29 07:53:21.955883	2025-10-29 07:53:21.955883
864	2019-06-22	3	7	10	13	25	36	32	11	1716553637	\N	2025-10-29 07:53:22.464414	2025-10-29 07:53:22.464414
865	2019-06-29	3	15	22	32	33	45	2	13	1551729145	\N	2025-10-29 07:53:22.972366	2025-10-29 07:53:22.972366
866	2019-07-06	9	15	29	34	37	39	12	9	2240409000	\N	2025-10-29 07:53:23.479459	2025-10-29 07:53:23.479459
867	2019-07-13	14	17	19	22	24	40	41	5	3933755250	\N	2025-10-29 07:53:23.987004	2025-10-29 07:53:23.987004
868	2019-07-20	12	17	28	41	43	44	25	6	3233804250	\N	2025-10-29 07:53:24.494867	2025-10-29 07:53:24.494867
869	2019-07-27	2	6	20	27	37	39	4	10	1922582588	\N	2025-10-29 07:53:25.003932	2025-10-29 07:53:25.003932
870	2019-08-03	21	25	30	32	40	42	31	10	1928842988	\N	2025-10-29 07:53:25.512636	2025-10-29 07:53:25.512636
871	2019-08-10	2	6	12	26	30	34	38	7	2718071358	\N	2025-10-29 07:53:26.021312	2025-10-29 07:53:26.021312
872	2019-08-17	2	4	30	32	33	43	29	16	1262705579	\N	2025-10-29 07:53:26.528991	2025-10-29 07:53:26.528991
873	2019-08-24	3	5	12	13	33	39	38	10	1874553225	\N	2025-10-29 07:53:27.037319	2025-10-29 07:53:27.037319
874	2019-08-31	1	15	19	23	28	42	32	18	1117123917	\N	2025-10-29 07:53:27.545033	2025-10-29 07:53:27.545033
875	2019-09-07	19	22	30	34	39	44	36	14	1415946724	\N	2025-10-29 07:53:28.054215	2025-10-29 07:53:28.054215
876	2019-09-14	5	16	21	26	34	42	24	19	1090657856	\N	2025-10-29 07:53:28.561521	2025-10-29 07:53:28.561521
877	2019-09-21	5	17	18	22	23	43	12	12	1716607188	\N	2025-10-29 07:53:29.069767	2025-10-29 07:53:29.069767
878	2019-09-28	2	6	11	16	25	31	3	6	3207993500	\N	2025-10-29 07:53:29.578719	2025-10-29 07:53:29.578719
879	2019-10-05	1	4	10	14	15	35	20	6	3206361313	\N	2025-10-29 07:53:30.088279	2025-10-29 07:53:30.088279
880	2019-10-12	7	17	19	23	24	45	38	7	2837810465	\N	2025-10-29 07:53:30.595996	2025-10-29 07:53:30.595996
881	2019-10-19	4	18	20	26	27	32	9	8	2503212282	\N	2025-10-29 07:53:31.103876	2025-10-29 07:53:31.103876
882	2019-10-26	18	34	39	43	44	45	23	5	4127270400	\N	2025-10-29 07:53:31.612186	2025-10-29 07:53:31.612186
883	2019-11-02	9	18	32	33	37	44	22	15	1360519525	\N	2025-10-29 07:53:32.120178	2025-10-29 07:53:32.120178
884	2019-11-09	4	14	23	28	37	45	17	12	1799077282	\N	2025-10-29 07:53:32.62786	2025-10-29 07:53:32.62786
885	2019-11-16	1	3	24	27	39	45	31	13	1543832568	\N	2025-10-29 07:53:33.136044	2025-10-29 07:53:33.136044
886	2019-11-23	19	23	28	37	42	45	2	7	2974643786	\N	2025-10-29 07:53:33.643408	2025-10-29 07:53:33.643408
887	2019-11-30	8	14	17	27	36	45	10	8	2535268688	\N	2025-10-29 07:53:34.150969	2025-10-29 07:53:34.150969
888	2019-12-07	3	7	12	31	34	38	32	8	2370359204	\N	2025-10-29 07:53:34.659521	2025-10-29 07:53:34.659521
889	2019-12-14	3	13	29	38	39	42	26	10	2108986950	\N	2025-10-29 07:53:35.172918	2025-10-29 07:53:35.172918
890	2019-12-21	1	4	14	18	29	37	6	9	2335486167	\N	2025-10-29 07:53:35.680478	2025-10-29 07:53:35.680478
891	2019-12-28	9	13	28	31	39	41	19	7	3082673947	\N	2025-10-29 07:53:36.187823	2025-10-29 07:53:36.187823
892	2020-01-04	4	9	17	18	26	42	36	17	1282017464	\N	2025-10-29 07:53:36.694724	2025-10-29 07:53:36.694724
893	2020-01-11	1	15	17	23	25	41	10	9	2377433625	\N	2025-10-29 07:53:37.203185	2025-10-29 07:53:37.203185
894	2020-01-18	19	32	37	40	41	43	45	9	2377935959	\N	2025-10-29 07:53:37.710904	2025-10-29 07:53:37.710904
895	2020-01-25	16	26	31	38	39	41	23	12	1928079219	\N	2025-10-29 07:53:38.220931	2025-10-29 07:53:38.220931
896	2020-02-01	5	12	25	26	38	45	23	7	3053222036	\N	2025-10-29 07:53:38.728409	2025-10-29 07:53:38.728409
897	2020-02-08	6	7	12	22	26	36	29	13	1619922520	\N	2025-10-29 07:53:39.238194	2025-10-29 07:53:39.238194
898	2020-02-15	18	21	28	35	37	42	17	8	2639313235	\N	2025-10-29 07:53:39.745368	2025-10-29 07:53:39.745368
899	2020-02-22	8	19	20	21	33	39	37	6	3359356063	\N	2025-10-29 07:53:40.254287	2025-10-29 07:53:40.254287
900	2020-02-29	7	13	16	18	35	38	14	6	3349851375	\N	2025-10-29 07:53:40.761919	2025-10-29 07:53:40.761919
901	2020-03-07	5	18	20	23	30	34	21	9	2267974667	\N	2025-10-29 07:53:46.30581	2025-10-29 07:53:46.30581
902	2020-03-14	7	19	23	24	36	39	30	13	1619317529	\N	2025-10-29 07:53:46.814522	2025-10-29 07:53:46.814522
903	2020-03-21	2	15	16	21	22	28	45	13	1684582212	\N	2025-10-29 07:53:47.323021	2025-10-29 07:53:47.323021
904	2020-03-28	2	6	8	26	43	45	11	8	2718077813	\N	2025-10-29 07:53:47.830519	2025-10-29 07:53:47.830519
905	2020-04-04	3	4	16	27	38	40	20	7	3017862536	\N	2025-10-29 07:53:48.337604	2025-10-29 07:53:48.337604
906	2020-04-11	2	5	14	28	31	32	20	9	2472607250	\N	2025-10-29 07:53:48.846489	2025-10-29 07:53:48.846489
907	2020-04-18	21	27	29	38	40	44	37	7	3165059036	\N	2025-10-29 07:53:49.355235	2025-10-29 07:53:49.355235
908	2020-04-25	3	16	21	22	23	44	30	8	2834856141	\N	2025-10-29 07:53:49.862269	2025-10-29 07:53:49.862269
909	2020-05-02	7	24	29	30	34	35	33	11	2021062875	\N	2025-10-29 07:53:50.369786	2025-10-29 07:53:50.369786
910	2020-05-09	1	11	17	27	35	39	31	21	941316375	\N	2025-10-29 07:53:50.878014	2025-10-29 07:53:50.878014
911	2020-05-16	4	5	12	14	32	42	35	10	2113538625	\N	2025-10-29 07:53:51.385152	2025-10-29 07:53:51.385152
912	2020-05-23	5	8	18	21	22	38	10	14	1493500581	\N	2025-10-29 07:53:51.892375	2025-10-29 07:53:51.892375
913	2020-05-30	6	14	16	21	27	37	40	16	1338755602	\N	2025-10-29 07:53:52.40035	2025-10-29 07:53:52.40035
914	2020-06-06	16	19	24	33	42	44	27	11	1950005557	\N	2025-10-29 07:53:52.907657	2025-10-29 07:53:52.907657
915	2020-06-13	2	6	11	13	22	37	14	6	3518640500	\N	2025-10-29 07:53:53.418182	2025-10-29 07:53:53.418182
916	2020-06-20	6	21	22	32	35	36	17	11	2025384341	\N	2025-10-29 07:53:53.925941	2025-10-29 07:53:53.925941
917	2020-06-27	1	3	23	24	27	43	34	10	2144799638	\N	2025-10-29 07:53:54.434138	2025-10-29 07:53:54.434138
918	2020-07-04	7	11	12	31	33	38	5	18	1117622646	\N	2025-10-29 07:53:54.941074	2025-10-29 07:53:54.941074
919	2020-07-11	9	14	17	18	42	44	35	5	4305150450	\N	2025-10-29 07:53:55.448573	2025-10-29 07:53:55.448573
920	2020-07-18	2	3	26	33	34	43	29	7	3120260197	\N	2025-10-29 07:53:55.957478	2025-10-29 07:53:55.957478
921	2020-07-25	5	7	12	22	28	41	1	17	1232573405	\N	2025-10-29 07:53:56.464844	2025-10-29 07:53:56.464844
922	2020-08-01	2	6	13	17	27	43	36	6	3417904500	\N	2025-10-29 07:53:56.972437	2025-10-29 07:53:56.972437
923	2020-08-08	3	17	18	23	36	41	26	8	2667554625	\N	2025-10-29 07:53:57.479448	2025-10-29 07:53:57.479448
924	2020-08-15	3	11	34	42	43	44	13	9	2382430667	\N	2025-10-29 07:53:57.993924	2025-10-29 07:53:57.993924
925	2020-08-22	13	24	32	34	39	42	4	12	1771080532	\N	2025-10-29 07:53:58.502018	2025-10-29 07:53:58.502018
926	2020-08-29	10	16	18	20	25	31	6	10	2032490663	\N	2025-10-29 07:53:59.010481	2025-10-29 07:53:59.010481
927	2020-09-05	4	15	22	38	41	43	26	6	3714203875	\N	2025-10-29 07:53:59.519105	2025-10-29 07:53:59.519105
928	2020-09-12	3	4	10	20	28	44	30	7	3134591358	\N	2025-10-29 07:54:00.033307	2025-10-29 07:54:00.033307
929	2020-09-19	7	9	12	15	19	23	4	16	1308035157	\N	2025-10-29 07:54:00.540575	2025-10-29 07:54:00.540575
930	2020-09-26	8	21	25	38	39	44	28	8	2832418829	\N	2025-10-29 07:54:01.049103	2025-10-29 07:54:01.049103
931	2020-10-03	14	15	23	25	35	43	32	8	2957108063	\N	2025-10-29 07:54:01.5566	2025-10-29 07:54:01.5566
932	2020-10-10	1	6	15	36	37	38	5	7	3390022983	\N	2025-10-29 07:54:02.065139	2025-10-29 07:54:02.065139
933	2020-10-17	23	27	29	31	36	45	37	8	2927797079	\N	2025-10-29 07:54:02.573032	2025-10-29 07:54:02.573032
934	2020-10-24	1	3	30	33	36	39	12	4	5765772844	\N	2025-10-29 07:54:03.081853	2025-10-29 07:54:03.081853
935	2020-10-31	4	10	20	32	38	44	18	13	1711055424	\N	2025-10-29 07:54:03.589919	2025-10-29 07:54:03.589919
936	2020-11-07	7	11	13	17	18	29	43	14	1492069179	\N	2025-10-29 07:54:04.098161	2025-10-29 07:54:04.098161
937	2020-11-14	2	10	13	22	29	40	26	11	2058420819	\N	2025-10-29 07:54:04.605568	2025-10-29 07:54:04.605568
938	2020-11-21	4	8	10	16	31	36	9	10	2249466563	\N	2025-10-29 07:54:05.115206	2025-10-29 07:54:05.115206
939	2020-11-28	4	11	28	39	42	45	6	13	1708363039	\N	2025-10-29 07:54:05.623017	2025-10-29 07:54:05.623017
940	2020-12-05	3	15	20	22	24	41	11	8	2846071079	\N	2025-10-29 07:54:06.13132	2025-10-29 07:54:06.13132
941	2020-12-12	12	14	25	27	39	40	35	16	1347297422	\N	2025-10-29 07:54:06.644105	2025-10-29 07:54:06.644105
942	2020-12-19	10	12	18	35	42	43	39	6	3761680313	\N	2025-10-29 07:54:07.151733	2025-10-29 07:54:07.151733
943	2020-12-26	1	8	13	36	44	45	39	7	3435045108	\N	2025-10-29 07:54:07.659698	2025-10-29 07:54:07.659698
944	2021-01-02	2	13	16	19	32	33	42	13	1961836356	\N	2025-10-29 07:54:08.167885	2025-10-29 07:54:08.167885
945	2021-01-09	9	10	15	30	33	37	26	13	1765554491	\N	2025-10-29 07:54:08.676478	2025-10-29 07:54:08.676478
946	2021-01-16	9	18	19	30	34	40	20	11	2157656182	\N	2025-10-29 07:54:09.184407	2025-10-29 07:54:09.184407
947	2021-01-23	3	8	17	20	27	35	26	18	1275855750	\N	2025-10-29 07:54:09.69193	2025-10-29 07:54:09.69193
948	2021-01-30	13	18	30	31	38	41	5	11	2188548716	\N	2025-10-29 07:54:10.199905	2025-10-29 07:54:10.199905
949	2021-02-06	14	21	35	36	40	44	30	10	2458569713	\N	2025-10-29 07:54:10.707117	2025-10-29 07:54:10.707117
950	2021-02-13	3	4	15	22	28	40	10	8	3281920500	\N	2025-10-29 07:54:11.215008	2025-10-29 07:54:11.215008
951	2021-02-20	2	12	30	31	39	43	38	14	1747552661	\N	2025-10-29 07:54:11.722863	2025-10-29 07:54:11.722863
952	2021-02-27	4	12	22	24	33	41	38	9	2713699834	\N	2025-10-29 07:54:12.232332	2025-10-29 07:54:12.232332
953	2021-03-06	7	9	22	27	37	42	34	14	1640636009	\N	2025-10-29 07:54:12.738843	2025-10-29 07:54:12.738843
954	2021-03-13	1	9	26	28	30	41	32	10	2478795900	\N	2025-10-29 07:54:13.246914	2025-10-29 07:54:13.246914
955	2021-03-20	4	9	23	26	29	33	8	12	2023170188	\N	2025-10-29 07:54:13.755273	2025-10-29 07:54:13.755273
956	2021-03-27	10	11	20	21	25	41	40	11	2022982671	\N	2025-10-29 07:54:14.263216	2025-10-29 07:54:14.263216
957	2021-04-03	4	15	24	35	36	40	1	11	2126634137	\N	2025-10-29 07:54:14.770469	2025-10-29 07:54:14.770469
958	2021-04-10	2	9	10	16	35	37	1	15	1596119675	\N	2025-10-29 07:54:15.278827	2025-10-29 07:54:15.278827
959	2021-04-17	1	14	15	24	40	41	35	8	3015312891	\N	2025-10-29 07:54:15.787458	2025-10-29 07:54:15.787458
960	2021-04-24	2	18	24	30	32	45	14	10	2401133213	\N	2025-10-29 07:54:16.294741	2025-10-29 07:54:16.294741
961	2021-05-01	11	20	29	31	33	42	43	9	2575231209	\N	2025-10-29 07:54:16.80307	2025-10-29 07:54:16.80307
962	2021-05-08	1	18	28	31	34	43	40	12	1940906094	\N	2025-10-29 07:54:17.31123	2025-10-29 07:54:17.31123
963	2021-05-15	6	12	19	23	34	42	35	15	1476478125	\N	2025-10-29 07:54:17.818905	2025-10-29 07:54:17.818905
964	2021-05-22	6	21	36	38	39	43	30	10	2345861063	\N	2025-10-29 07:54:18.327213	2025-10-29 07:54:18.327213
965	2021-05-29	2	13	25	28	29	36	34	7	3403348929	\N	2025-10-29 07:54:18.834781	2025-10-29 07:54:18.834781
966	2021-06-05	1	21	25	29	34	37	36	10	2411303513	\N	2025-10-29 07:54:19.34305	2025-10-29 07:54:19.34305
967	2021-06-12	1	6	13	37	38	40	9	4	5809776094	\N	2025-10-29 07:54:19.850876	2025-10-29 07:54:19.850876
968	2021-06-19	2	5	12	14	24	39	33	13	1667729683	\N	2025-10-29 07:54:20.358371	2025-10-29 07:54:20.358371
969	2021-06-26	3	9	10	29	40	45	7	20	1149427894	\N	2025-10-29 07:54:20.867248	2025-10-29 07:54:20.867248
970	2021-07-03	9	11	16	21	28	36	5	14	1611544045	\N	2025-10-29 07:54:21.375546	2025-10-29 07:54:21.375546
971	2021-07-10	2	6	17	18	21	26	7	6	3725880250	\N	2025-10-29 07:54:21.883439	2025-10-29 07:54:21.883439
972	2021-07-17	3	6	17	23	37	39	26	20	1124886244	\N	2025-10-29 07:54:22.391254	2025-10-29 07:54:22.391254
973	2021-07-24	22	26	31	37	41	42	24	8	2912742750	\N	2025-10-29 07:54:22.898732	2025-10-29 07:54:22.898732
974	2021-07-31	1	2	11	16	39	44	32	17	1317034523	\N	2025-10-29 07:54:23.407406	2025-10-29 07:54:23.407406
975	2021-08-07	7	8	9	17	22	24	5	9	2440410375	\N	2025-10-29 07:54:23.917218	2025-10-29 07:54:23.917218
976	2021-08-14	4	12	14	25	35	37	2	7	3243867215	\N	2025-10-29 07:54:24.424635	2025-10-29 07:54:24.424635
977	2021-08-21	2	9	10	14	22	44	16	14	1669905911	\N	2025-10-29 07:54:24.934165	2025-10-29 07:54:24.934165
978	2021-08-28	1	7	15	32	34	42	8	10	2373391388	\N	2025-10-29 07:54:25.44167	2025-10-29 07:54:25.44167
979	2021-09-04	7	11	16	21	27	33	24	14	1606400518	\N	2025-10-29 07:54:25.948978	2025-10-29 07:54:25.948978
980	2021-09-11	3	13	16	23	24	35	14	7	3409443215	\N	2025-10-29 07:54:26.456209	2025-10-29 07:54:26.456209
981	2021-09-18	27	36	37	41	43	45	32	13	1992863193	\N	2025-10-29 07:54:26.967133	2025-10-29 07:54:26.967133
982	2021-09-25	5	7	13	20	21	44	33	8	3023630672	\N	2025-10-29 07:54:27.474843	2025-10-29 07:54:27.474843
983	2021-10-02	13	23	26	31	35	43	15	10	2503422225	\N	2025-10-29 07:54:27.982288	2025-10-29 07:54:27.982288
984	2021-10-09	3	10	23	35	36	37	18	7	3453006268	\N	2025-10-29 07:54:28.491199	2025-10-29 07:54:28.491199
985	2021-10-16	17	21	23	30	34	44	19	10	2434752975	\N	2025-10-29 07:54:28.999014	2025-10-29 07:54:28.999014
986	2021-10-23	7	10	16	28	41	42	40	10	2375275125	\N	2025-10-29 07:54:29.506413	2025-10-29 07:54:29.506413
987	2021-10-30	2	4	15	23	29	38	7	10	2378711625	\N	2025-10-29 07:54:30.014502	2025-10-29 07:54:30.014502
988	2021-11-06	2	13	20	30	31	41	27	9	2678489375	\N	2025-10-29 07:54:30.522509	2025-10-29 07:54:30.522509
989	2021-11-13	17	18	21	27	29	33	26	4	5826768563	\N	2025-10-29 07:54:31.029831	2025-10-29 07:54:31.029831
990	2021-11-20	2	4	25	26	36	37	28	14	1740095277	\N	2025-10-29 07:54:31.538144	2025-10-29 07:54:31.538144
991	2021-11-27	13	18	25	31	33	44	38	8	2904166032	\N	2025-10-29 07:54:32.046117	2025-10-29 07:54:32.046117
992	2021-12-04	12	20	26	33	44	45	24	12	1986955563	\N	2025-10-29 07:54:32.553478	2025-10-29 07:54:32.553478
993	2021-12-11	6	14	16	18	24	42	44	6	3991197063	\N	2025-10-29 07:54:33.062176	2025-10-29 07:54:33.062176
994	2021-12-18	1	3	8	24	27	35	28	12	1861582063	\N	2025-10-29 07:54:33.569819	2025-10-29 07:54:33.569819
995	2021-12-25	1	4	13	29	38	39	7	7	3447271875	\N	2025-10-29 07:54:34.078487	2025-10-29 07:54:34.078487
996	2022-01-01	6	11	15	24	32	39	28	18	1491185771	\N	2025-10-29 07:54:34.586208	2025-10-29 07:54:34.586208
997	2022-01-08	4	7	14	16	24	44	20	19	1253749560	\N	2025-10-29 07:54:35.094103	2025-10-29 07:54:35.094103
998	2022-01-15	13	17	18	20	42	45	41	12	2076499657	\N	2025-10-29 07:54:35.601702	2025-10-29 07:54:35.601702
999	2022-01-22	1	3	9	14	18	28	34	16	1513274790	\N	2025-10-29 07:54:36.109342	2025-10-29 07:54:36.109342
1000	2022-01-29	2	8	19	22	32	42	39	22	1246819620	\N	2025-10-29 07:54:36.616721	2025-10-29 07:54:36.616721
1001	2022-02-05	6	10	12	14	20	42	15	12	2077279594	\N	2025-10-29 07:54:42.161095	2025-10-29 07:54:42.161095
1002	2022-02-12	17	25	33	35	38	45	15	8	3088449563	\N	2025-10-29 07:54:42.670944	2025-10-29 07:54:42.670944
1003	2022-02-19	1	4	29	39	43	45	31	14	1811116822	\N	2025-10-29 07:54:43.1792	2025-10-29 07:54:43.1792
1004	2022-02-26	7	15	30	37	39	44	18	10	2576251913	\N	2025-10-29 07:54:43.686422	2025-10-29 07:54:43.686422
1005	2022-03-05	8	13	18	24	27	29	17	12	2061199344	\N	2025-10-29 07:54:44.194015	2025-10-29 07:54:44.194015
1006	2022-03-12	8	11	15	16	17	37	36	9	2855602125	\N	2025-10-29 07:54:44.701255	2025-10-29 07:54:44.701255
1007	2022-03-19	8	11	16	19	21	25	40	9	2718786375	\N	2025-10-29 07:54:45.208986	2025-10-29 07:54:45.208986
1008	2022-03-26	9	11	30	31	41	44	33	11	2267377910	\N	2025-10-29 07:54:45.716434	2025-10-29 07:54:45.716434
1009	2022-04-02	15	23	29	34	40	44	20	15	1702462825	\N	2025-10-29 07:54:46.224405	2025-10-29 07:54:46.224405
1010	2022-04-09	9	12	15	25	34	36	3	8	3119380079	\N	2025-10-29 07:54:46.732463	2025-10-29 07:54:46.732463
1011	2022-04-16	1	9	12	26	35	38	42	11	2220348512	\N	2025-10-29 07:54:47.239282	2025-10-29 07:54:47.239282
1012	2022-04-23	5	11	18	20	35	45	3	13	1861944318	\N	2025-10-29 07:54:47.74635	2025-10-29 07:54:47.74635
1013	2022-04-30	21	22	26	34	36	41	32	5	5047570725	\N	2025-10-29 07:54:48.257124	2025-10-29 07:54:48.257124
1014	2022-05-07	3	11	14	18	26	27	21	10	2410449338	\N	2025-10-29 07:54:48.764355	2025-10-29 07:54:48.764355
1015	2022-05-14	14	23	31	33	37	40	44	8	3051105610	\N	2025-10-29 07:54:49.272024	2025-10-29 07:54:49.272024
1016	2022-05-21	15	26	28	34	41	42	44	11	2260660671	\N	2025-10-29 07:54:49.779794	2025-10-29 07:54:49.779794
1017	2022-05-28	12	18	22	23	30	34	32	7	3517684822	\N	2025-10-29 07:54:50.288387	2025-10-29 07:54:50.288387
1018	2022-06-04	3	19	21	25	37	45	35	2	12361744688	\N	2025-10-29 07:54:50.795874	2025-10-29 07:54:50.795874
1019	2022-06-11	1	4	13	17	34	39	6	50	438565140	\N	2025-10-29 07:54:51.311203	2025-10-29 07:54:51.311203
1020	2022-06-18	12	27	29	38	41	45	6	13	1966431520	\N	2025-10-29 07:54:51.819103	2025-10-29 07:54:51.819103
1021	2022-06-25	12	15	17	24	29	45	16	12	2108962250	\N	2025-10-29 07:54:52.326683	2025-10-29 07:54:52.326683
1022	2022-07-02	5	6	11	29	42	45	28	5	4866468075	\N	2025-10-29 07:54:52.834451	2025-10-29 07:54:52.834451
1023	2022-07-09	10	14	16	18	29	35	25	9	2745677875	\N	2025-10-29 07:54:53.341665	2025-10-29 07:54:53.341665
1024	2022-07-16	9	18	20	22	38	44	10	8	3020323500	\N	2025-10-29 07:54:53.850158	2025-10-29 07:54:53.850158
1025	2022-07-23	8	9	20	25	29	33	7	4	6118853344	\N	2025-10-29 07:54:54.35708	2025-10-29 07:54:54.35708
1026	2022-07-30	5	12	13	31	32	41	34	15	1619118475	\N	2025-10-29 07:54:54.864294	2025-10-29 07:54:54.864294
1027	2022-08-06	14	16	27	35	39	45	5	10	2460504338	\N	2025-10-29 07:54:55.3725	2025-10-29 07:54:55.3725
1028	2022-08-13	5	7	12	13	18	35	23	20	1181235132	\N	2025-10-29 07:54:55.879666	2025-10-29 07:54:55.879666
1029	2022-08-20	12	30	32	37	39	41	24	10	2527848450	\N	2025-10-29 07:54:56.387144	2025-10-29 07:54:56.387144
1030	2022-08-27	2	5	11	17	24	29	9	19	1276406507	\N	2025-10-29 07:54:56.893942	2025-10-29 07:54:56.893942
1031	2022-09-03	6	7	22	32	35	36	19	8	3213957563	\N	2025-10-29 07:54:57.401977	2025-10-29 07:54:57.401977
1032	2022-09-10	1	6	12	19	36	42	28	10	2675257538	\N	2025-10-29 07:54:57.910583	2025-10-29 07:54:57.910583
1033	2022-09-17	3	11	15	20	35	44	10	13	1913414943	\N	2025-10-29 07:54:58.420557	2025-10-29 07:54:58.420557
1034	2022-09-24	26	31	32	33	38	40	11	9	2868856209	\N	2025-10-29 07:54:58.927663	2025-10-29 07:54:58.927663
1035	2022-10-01	9	14	34	35	41	42	2	8	3231193735	\N	2025-10-29 07:54:59.435509	2025-10-29 07:54:59.435509
1036	2022-10-08	2	5	22	32	34	45	39	9	2837323167	\N	2025-10-29 07:54:59.943601	2025-10-29 07:54:59.943601
1037	2022-10-15	2	14	15	22	27	33	31	15	1708576825	\N	2025-10-29 07:55:00.451292	2025-10-29 07:55:00.451292
1038	2022-10-22	7	16	24	27	37	44	2	15	1627457225	\N	2025-10-29 07:55:00.958833	2025-10-29 07:55:00.958833
1039	2022-10-29	2	3	6	19	36	39	26	16	1585019672	\N	2025-10-29 07:55:01.466573	2025-10-29 07:55:01.466573
1040	2022-11-05	8	16	26	29	31	36	11	7	3660482625	\N	2025-10-29 07:55:01.982663	2025-10-29 07:55:01.982663
1041	2022-11-12	6	7	9	11	17	18	45	25	935091165	\N	2025-10-29 07:55:02.489408	2025-10-29 07:55:02.489408
1042	2022-11-19	5	14	15	23	34	43	4	20	1240663669	\N	2025-10-29 07:55:02.996576	2025-10-29 07:55:02.996576
1043	2022-11-26	3	5	12	22	26	31	19	17	1468646956	\N	2025-10-29 07:55:03.504184	2025-10-29 07:55:03.504184
1044	2022-12-03	12	17	20	26	28	36	4	8	3136941235	\N	2025-10-29 07:55:04.012323	2025-10-29 07:55:04.012323
1045	2022-12-10	6	14	15	19	21	41	37	13	1990060443	\N	2025-10-29 07:55:04.519782	2025-10-29 07:55:04.519782
1046	2022-12-17	7	16	25	29	35	36	28	12	2011415719	\N	2025-10-29 07:55:05.026853	2025-10-29 07:55:05.026853
1047	2022-12-24	2	20	33	40	42	44	32	9	2748797875	\N	2025-10-29 07:55:05.534036	2025-10-29 07:55:05.534036
1048	2022-12-31	6	12	17	21	32	39	30	17	1612494508	\N	2025-10-29 07:55:06.041624	2025-10-29 07:55:06.041624
1049	2023-01-07	3	5	13	20	21	37	17	15	1727810100	\N	2025-10-29 07:55:06.550287	2025-10-29 07:55:06.550287
1050	2023-01-14	6	12	31	35	38	43	17	17	1535083280	\N	2025-10-29 07:55:07.057337	2025-10-29 07:55:07.057337
1051	2023-01-21	21	26	30	32	33	35	44	18	1669558480	\N	2025-10-29 07:55:07.565116	2025-10-29 07:55:07.565116
1052	2023-01-28	5	17	26	27	35	38	1	11	2341682762	\N	2025-10-29 07:55:08.072419	2025-10-29 07:55:08.072419
1053	2023-02-04	22	26	29	30	34	45	15	7	4090367411	\N	2025-10-29 07:55:08.580712	2025-10-29 07:55:08.580712
1054	2023-02-11	14	19	27	28	30	45	33	9	3147925709	\N	2025-10-29 07:55:09.08931	2025-10-29 07:55:09.08931
1055	2023-02-18	4	7	12	14	22	33	31	11	2362815205	\N	2025-10-29 07:55:09.597316	2025-10-29 07:55:09.597316
1056	2023-02-25	13	20	24	32	36	45	29	14	1969662456	\N	2025-10-29 07:55:10.104736	2025-10-29 07:55:10.104736
1057	2023-03-04	8	13	19	27	40	45	12	17	1616069714	\N	2025-10-29 07:55:10.61404	2025-10-29 07:55:10.61404
1058	2023-03-11	11	23	25	30	32	40	42	13	2058020250	\N	2025-10-29 07:55:11.12117	2025-10-29 07:55:11.12117
1059	2023-03-18	7	10	22	25	34	40	27	13	2033168481	\N	2025-10-29 07:55:11.628585	2025-10-29 07:55:11.628585
1060	2023-03-25	3	10	24	33	38	45	36	28	898238907	\N	2025-10-29 07:55:12.137035	2025-10-29 07:55:12.137035
1061	2023-04-01	4	24	27	35	37	45	15	11	2422768773	\N	2025-10-29 07:55:12.645236	2025-10-29 07:55:12.645236
1062	2023-04-08	20	31	32	40	41	45	12	7	3801933804	\N	2025-10-29 07:55:13.155893	2025-10-29 07:55:13.155893
1063	2023-04-15	3	6	22	23	24	38	30	7	3770311875	\N	2025-10-29 07:55:13.663053	2025-10-29 07:55:13.663053
1064	2023-04-22	3	6	9	18	22	35	14	19	1348168106	\N	2025-10-29 07:55:14.170689	2025-10-29 07:55:14.170689
1065	2023-04-29	3	18	19	23	32	45	24	14	1852593938	\N	2025-10-29 07:55:14.680383	2025-10-29 07:55:14.680383
1066	2023-05-06	6	11	16	19	21	32	45	15	1670947250	\N	2025-10-29 07:55:15.188215	2025-10-29 07:55:15.188215
1067	2023-05-13	7	10	19	23	28	33	18	13	1981114010	\N	2025-10-29 07:55:15.695844	2025-10-29 07:55:15.695844
1068	2023-05-20	4	7	19	26	33	35	3	19	1363929514	\N	2025-10-29 07:55:16.203863	2025-10-29 07:55:16.203863
1069	2023-05-27	1	10	18	22	28	31	44	14	1863217554	\N	2025-10-29 07:55:16.712776	2025-10-29 07:55:16.712776
1070	2023-06-03	3	6	14	22	30	41	36	14	1859116929	\N	2025-10-29 07:55:17.220433	2025-10-29 07:55:17.220433
1071	2023-06-10	1	2	11	21	30	35	39	5	5183979750	\N	2025-10-29 07:55:17.728265	2025-10-29 07:55:17.728265
1072	2023-06-17	16	18	20	23	32	43	27	12	2175006375	\N	2025-10-29 07:55:18.236345	2025-10-29 07:55:18.236345
1073	2023-06-24	6	18	28	30	32	38	15	11	2345227603	\N	2025-10-29 07:55:18.744079	2025-10-29 07:55:18.744079
1074	2023-07-01	1	6	20	27	28	41	15	12	2134763657	\N	2025-10-29 07:55:19.25131	2025-10-29 07:55:19.25131
1075	2023-07-08	1	23	24	35	44	45	10	9	2896337167	\N	2025-10-29 07:55:19.758623	2025-10-29 07:55:19.758623
1076	2023-07-15	3	7	9	33	36	37	10	9	2672689750	\N	2025-10-29 07:55:20.268661	2025-10-29 07:55:20.268661
1077	2023-07-22	4	8	17	30	40	43	34	7	3570901018	\N	2025-10-29 07:55:20.78619	2025-10-29 07:55:20.78619
1078	2023-07-29	6	10	11	14	36	38	43	12	2141604938	\N	2025-10-29 07:55:21.294384	2025-10-29 07:55:21.294384
1079	2023-08-05	4	8	18	24	37	45	6	9	2712329417	\N	2025-10-29 07:55:21.801358	2025-10-29 07:55:21.801358
1080	2023-08-12	13	16	23	31	36	44	38	7	3639444429	\N	2025-10-29 07:55:22.309235	2025-10-29 07:55:22.309235
1081	2023-08-19	1	9	16	23	24	38	17	11	2343892944	\N	2025-10-29 07:55:22.817717	2025-10-29 07:55:22.817717
1082	2023-08-26	21	26	27	32	34	42	31	7	3720489643	\N	2025-10-29 07:55:23.325933	2025-10-29 07:55:23.325933
1083	2023-09-02	3	7	14	15	22	38	17	15	1713084525	\N	2025-10-29 07:55:23.833854	2025-10-29 07:55:23.833854
1084	2023-09-09	8	12	13	29	33	42	5	15	1738764600	\N	2025-10-29 07:55:24.341892	2025-10-29 07:55:24.341892
1085	2023-09-16	4	7	17	18	38	44	36	23	1073277473	\N	2025-10-29 07:55:24.848914	2025-10-29 07:55:24.848914
1086	2023-09-23	11	16	25	27	35	36	37	17	1515913809	\N	2025-10-29 07:55:25.356928	2025-10-29 07:55:25.356928
1087	2023-09-30	13	14	18	21	34	44	16	16	1732253602	\N	2025-10-29 07:55:25.866512	2025-10-29 07:55:25.866512
1088	2023-10-07	11	21	22	30	39	44	31	11	2434697898	\N	2025-10-29 07:55:26.373539	2025-10-29 07:55:26.373539
1089	2023-10-14	4	18	31	37	42	43	40	9	2978522167	\N	2025-10-29 07:55:26.883238	2025-10-29 07:55:26.883238
1090	2023-10-21	12	19	21	29	40	45	1	11	2386494614	\N	2025-10-29 07:55:27.390853	2025-10-29 07:55:27.390853
1091	2023-10-28	6	20	23	24	28	30	44	9	2898470459	\N	2025-10-29 07:55:27.898246	2025-10-29 07:55:27.898246
1092	2023-11-04	7	18	19	26	33	45	37	16	1583289844	\N	2025-10-29 07:55:28.405812	2025-10-29 07:55:28.405812
1093	2023-11-11	10	17	22	30	35	43	44	13	1967040750	\N	2025-10-29 07:55:28.913704	2025-10-29 07:55:28.913704
1094	2023-11-18	6	7	15	22	26	40	41	12	2112854469	\N	2025-10-29 07:55:29.421058	2025-10-29 07:55:29.421058
1095	2023-11-25	8	14	28	29	34	40	12	10	2617825575	\N	2025-10-29 07:55:29.928242	2025-10-29 07:55:29.928242
1096	2023-12-02	1	12	16	19	23	43	34	10	2539391175	\N	2025-10-29 07:55:30.439374	2025-10-29 07:55:30.439374
1097	2023-12-09	14	33	34	35	37	40	4	7	3864293090	\N	2025-10-29 07:55:30.947019	2025-10-29 07:55:30.947019
1098	2023-12-16	12	16	21	24	41	43	15	13	1930461895	\N	2025-10-29 07:55:31.456044	2025-10-29 07:55:31.456044
1099	2023-12-23	3	20	28	38	40	43	4	9	2959934125	\N	2025-10-29 07:55:31.96305	2025-10-29 07:55:31.96305
1100	2023-12-30	17	26	29	30	31	43	12	13	2207575472	\N	2025-10-29 07:55:32.472332	2025-10-29 07:55:32.472332
1101	2024-01-06	6	7	13	28	36	42	41	13	2100529500	\N	2025-10-29 07:55:38.049612	2025-10-29 07:55:38.049612
1102	2024-01-13	13	14	22	26	37	38	20	20	1383591413	\N	2025-10-29 07:55:38.558849	2025-10-29 07:55:38.558849
1103	2024-01-20	10	12	29	31	40	44	2	17	1574419633	\N	2025-10-29 07:55:39.06651	2025-10-29 07:55:39.06651
1104	2024-01-27	1	7	21	30	35	38	2	15	1817193100	\N	2025-10-29 07:55:39.574922	2025-10-29 07:55:39.574922
1105	2024-02-03	6	16	34	37	39	40	11	15	1834853800	\N	2025-10-29 07:55:40.082442	2025-10-29 07:55:40.082442
1106	2024-02-10	1	3	4	29	42	45	36	11	2790462819	\N	2025-10-29 07:55:40.589523	2025-10-29 07:55:40.589523
1107	2024-02-17	6	14	30	31	40	41	29	14	2025625233	\N	2025-10-29 07:55:41.098125	2025-10-29 07:55:41.098125
1108	2024-02-24	7	19	26	37	39	44	27	14	1957990849	\N	2025-10-29 07:55:41.607326	2025-10-29 07:55:41.607326
1109	2024-03-02	10	12	13	19	33	40	2	17	1584352875	\N	2025-10-29 07:55:42.11666	2025-10-29 07:55:42.11666
1110	2024-03-09	3	7	11	20	22	41	24	16	1647392719	\N	2025-10-29 07:55:42.625426	2025-10-29 07:55:42.625426
1111	2024-03-16	3	13	30	33	43	45	4	16	1714662540	\N	2025-10-29 07:55:43.133782	2025-10-29 07:55:43.133782
1112	2024-03-23	16	20	26	36	42	44	24	10	2804455650	\N	2025-10-29 07:55:43.641887	2025-10-29 07:55:43.641887
1113	2024-03-30	11	13	20	21	32	44	8	14	1987426822	\N	2025-10-29 07:55:44.150872	2025-10-29 07:55:44.150872
1114	2024-04-06	10	16	19	32	33	38	3	17	1583813824	\N	2025-10-29 07:55:44.658883	2025-10-29 07:55:44.658883
1115	2024-04-13	7	12	23	32	34	36	8	12	2257278282	\N	2025-10-29 07:55:45.167636	2025-10-29 07:55:45.167636
1116	2024-04-20	15	16	17	25	30	31	32	10	2695000238	\N	2025-10-29 07:55:45.67768	2025-10-29 07:55:45.67768
1117	2024-04-27	3	4	9	30	33	36	7	9	3028385542	\N	2025-10-29 07:55:46.184818	2025-10-29 07:55:46.184818
1118	2024-05-04	11	13	14	15	16	45	3	19	1477445132	\N	2025-10-29 07:55:46.693253	2025-10-29 07:55:46.693253
1119	2024-05-11	1	9	12	13	20	45	3	19	1396028764	\N	2025-10-29 07:55:47.201605	2025-10-29 07:55:47.201605
1120	2024-05-18	2	19	26	31	38	41	34	11	2522163375	\N	2025-10-29 07:55:47.710285	2025-10-29 07:55:47.710285
1121	2024-05-25	6	24	31	32	38	44	8	11	2524513262	\N	2025-10-29 07:55:48.217971	2025-10-29 07:55:48.217971
1122	2024-06-01	3	6	21	30	34	35	22	11	2556266046	\N	2025-10-29 07:55:48.726479	2025-10-29 07:55:48.726479
1123	2024-06-08	13	19	21	24	34	35	26	16	1731310711	\N	2025-10-29 07:55:49.234091	2025-10-29 07:55:49.234091
1124	2024-06-15	3	8	17	30	33	34	28	10	2623327913	\N	2025-10-29 07:55:49.742028	2025-10-29 07:55:49.742028
1125	2024-06-22	6	14	25	33	40	44	30	12	2195289188	\N	2025-10-29 07:55:50.249294	2025-10-29 07:55:50.249294
1126	2024-06-29	4	5	9	11	37	40	7	11	2386382421	\N	2025-10-29 07:55:50.756497	2025-10-29 07:55:50.756497
1127	2024-07-06	10	15	24	30	31	37	32	12	2267891969	\N	2025-10-29 07:55:51.264855	2025-10-29 07:55:51.264855
1128	2024-07-13	1	5	8	16	28	33	45	63	419925560	\N	2025-10-29 07:55:51.773616	2025-10-29 07:55:51.773616
1129	2024-07-20	5	10	11	17	28	34	22	11	2369567660	\N	2025-10-29 07:55:52.281803	2025-10-29 07:55:52.281803
1130	2024-07-27	15	19	21	25	27	28	40	12	2263301219	\N	2025-10-29 07:55:52.788613	2025-10-29 07:55:52.788613
1131	2024-08-03	1	2	6	14	27	38	33	17	1542367898	\N	2025-10-29 07:55:53.296389	2025-10-29 07:55:53.296389
1132	2024-08-10	6	7	19	28	34	41	5	11	2404951807	\N	2025-10-29 07:55:53.804244	2025-10-29 07:55:53.804244
1133	2024-08-17	13	14	20	28	29	34	23	13	2105079491	\N	2025-10-29 07:55:54.311713	2025-10-29 07:55:54.311713
1134	2024-08-24	3	7	9	13	19	24	23	14	1755689384	\N	2025-10-29 07:55:54.820104	2025-10-29 07:55:54.820104
1135	2024-08-31	1	6	13	19	21	33	4	9	2953726125	\N	2025-10-29 07:55:55.327927	2025-10-29 07:55:55.327927
1136	2024-09-07	21	33	35	38	42	44	1	12	2314468157	\N	2025-10-29 07:55:55.837591	2025-10-29 07:55:55.837591
1137	2024-09-14	4	9	12	15	33	45	26	14	2023447688	\N	2025-10-29 07:55:56.346103	2025-10-29 07:55:56.346103
1138	2024-09-21	14	16	19	20	29	34	35	14	1902656786	\N	2025-10-29 07:55:56.85386	2025-10-29 07:55:56.85386
1139	2024-09-28	5	12	15	30	37	40	18	13	2167490972	\N	2025-10-29 07:55:57.361447	2025-10-29 07:55:57.361447
1140	2024-10-05	7	10	22	29	31	38	15	12	2279823938	\N	2025-10-29 07:55:57.870195	2025-10-29 07:55:57.870195
1141	2024-10-12	7	11	12	21	26	35	20	11	2457758285	\N	2025-10-29 07:55:58.377756	2025-10-29 07:55:58.377756
1142	2024-10-19	2	8	28	30	37	41	22	9	3117517709	\N	2025-10-29 07:55:58.884755	2025-10-29 07:55:58.884755
1143	2024-10-26	10	16	17	27	28	36	6	11	2545657023	\N	2025-10-29 07:55:59.393999	2025-10-29 07:55:59.393999
1144	2024-11-02	3	4	12	15	26	34	6	18	1489347375	\N	2025-10-29 07:55:59.900948	2025-10-29 07:55:59.900948
1145	2024-11-09	2	11	31	33	37	44	32	9	3051630084	\N	2025-10-29 07:56:00.408502	2025-10-29 07:56:00.408502
1146	2024-11-16	6	11	17	19	40	43	28	11	2526476353	\N	2025-10-29 07:56:00.918232	2025-10-29 07:56:00.918232
1147	2024-11-23	7	11	24	26	27	37	32	8	3323422079	\N	2025-10-29 07:56:01.42595	2025-10-29 07:56:01.42595
1148	2024-11-30	3	6	13	15	16	22	32	13	2073332308	\N	2025-10-29 07:56:01.933587	2025-10-29 07:56:01.933587
1149	2024-12-07	8	15	19	21	32	36	38	17	1613380765	\N	2025-10-29 07:56:02.440519	2025-10-29 07:56:02.440519
1150	2024-12-14	8	9	18	35	39	45	25	17	1570620309	\N	2025-10-29 07:56:02.947817	2025-10-29 07:56:02.947817
1151	2024-12-21	2	3	9	15	27	29	8	17	1620503030	\N	2025-10-29 08:01:09.860338	2025-10-29 08:01:09.860338
1152	2024-12-28	30	31	32	35	36	37	5	35	874349668	\N	2025-10-29 08:01:10.461941	2025-10-29 08:01:10.461941
1153	2025-01-04	1	9	10	13	35	44	5	15	2027312925	\N	2025-10-29 08:01:10.970751	2025-10-29 08:01:10.970751
1154	2025-01-11	4	8	22	26	32	38	27	15	1854965425	\N	2025-10-29 08:01:11.478987	2025-10-29 08:01:11.478987
1155	2025-01-18	10	16	19	27	37	38	13	7	4066375179	\N	2025-10-29 08:01:11.986568	2025-10-29 08:01:11.986568
1156	2025-01-25	30	31	34	39	41	45	7	21	1505207090	\N	2025-10-29 08:01:12.496032	2025-10-29 08:01:12.496032
1157	2025-02-01	5	7	12	20	25	26	28	12	2257842157	\N	2025-10-29 08:01:13.379153	2025-10-29 08:01:13.379153
1158	2025-02-08	21	25	27	32	37	38	20	21	1394358197	\N	2025-10-29 08:01:13.975584	2025-10-29 08:01:13.975584
1159	2025-02-15	3	9	27	28	38	39	7	23	1284854250	\N	2025-10-29 08:01:14.571922	2025-10-29 08:01:14.571922
1160	2025-02-22	7	13	18	36	39	45	19	12	2509359875	\N	2025-10-29 08:01:15.081323	2025-10-29 08:01:15.081323
1161	2025-03-01	2	12	20	24	34	42	37	16	1792657969	\N	2025-10-29 08:01:15.590819	2025-10-29 08:01:15.590819
1162	2025-03-08	20	21	22	25	28	29	6	36	823931021	\N	2025-10-29 08:01:16.177143	2025-10-29 08:01:16.177143
1163	2025-03-15	2	13	15	16	33	43	4	15	1936891150	\N	2025-10-29 08:01:16.686486	2025-10-29 08:01:16.686486
1164	2025-03-22	17	18	23	25	38	39	22	13	2193092164	\N	2025-10-29 08:01:17.286534	2025-10-29 08:01:17.286534
1165	2025-03-29	6	7	27	29	38	45	17	13	2192485270	\N	2025-10-29 08:01:17.881933	2025-10-29 08:01:17.881933
1166	2025-04-05	14	23	25	27	29	42	16	14	2072319938	\N	2025-10-29 08:01:18.389697	2025-10-29 08:01:18.389697
1167	2025-04-12	8	23	31	35	39	40	24	10	2884087913	\N	2025-10-29 08:01:18.986101	2025-10-29 08:01:18.986101
1168	2025-04-19	9	21	24	30	33	37	29	13	2136635914	\N	2025-10-29 08:01:19.495737	2025-10-29 08:01:19.495737
1169	2025-04-26	5	12	24	26	39	42	20	10	2852735813	\N	2025-10-29 08:01:20.087955	2025-10-29 08:01:20.087955
1170	2025-05-03	3	13	28	34	38	42	25	20	1386550969	\N	2025-10-29 08:01:20.692606	2025-10-29 08:01:20.692606
1171	2025-05-10	3	6	7	11	12	17	19	21	1128345286	\N	2025-10-29 08:01:21.200227	2025-10-29 08:01:21.200227
1172	2025-05-17	7	9	24	40	42	44	45	13	2203004452	\N	2025-10-29 08:01:21.792609	2025-10-29 08:01:21.792609
1173	2025-05-24	1	5	18	20	30	35	3	24	1179946063	\N	2025-10-29 08:01:22.300753	2025-10-29 08:01:22.300753
1174	2025-05-31	8	11	14	17	36	39	22	15	1910619425	\N	2025-10-29 08:01:22.80863	2025-10-29 08:01:22.80863
1175	2025-06-07	3	4	6	8	32	42	31	20	1384026094	\N	2025-10-29 08:01:23.402489	2025-10-29 08:01:23.402489
1176	2025-06-14	7	9	11	21	30	35	29	13	2052166154	\N	2025-10-29 08:01:23.997762	2025-10-29 08:01:23.997762
1177	2025-06-21	3	7	15	16	19	43	21	6	4576672000	\N	2025-10-29 08:01:24.505234	2025-10-29 08:01:24.505234
1178	2025-06-28	5	6	11	27	43	44	17	12	2391608407	\N	2025-10-29 08:01:25.100382	2025-10-29 08:01:25.100382
1179	2025-07-05	3	16	18	24	40	44	21	13	2162821097	\N	2025-10-29 08:01:25.809008	2025-10-29 08:01:25.809008
1180	2025-07-12	6	12	18	37	40	41	3	11	2535566421	\N	2025-10-29 08:01:26.413123	2025-10-29 08:01:26.413123
1181	2025-07-19	8	10	14	20	33	41	28	17	1593643500	\N	2025-10-29 08:01:27.010227	2025-10-29 08:01:27.010227
1182	2025-07-26	1	13	21	25	28	31	22	13	2124785424	\N	2025-10-29 08:01:27.518705	2025-10-29 08:01:27.518705
1183	2025-08-02	4	15	17	23	27	36	31	13	2073966000	\N	2025-10-29 08:01:28.107672	2025-10-29 08:01:28.107672
1184	2025-08-09	14	16	23	25	31	37	42	15	1910655600	\N	2025-10-29 08:01:28.710127	2025-10-29 08:01:28.710127
1185	2025-08-16	6	17	22	28	29	32	38	12	2388695125	\N	2025-10-29 08:01:29.218748	2025-10-29 08:01:29.218748
1186	2025-08-23	2	8	13	16	23	28	35	14	1985676911	\N	2025-10-29 08:01:29.725956	2025-10-29 08:01:29.725956
1187	2025-08-30	5	13	26	29	37	40	42	11	2619380012	\N	2025-10-29 08:01:30.233491	2025-10-29 08:01:30.233491
1188	2025-09-06	3	4	12	19	22	27	9	24	1074625172	\N	2025-10-29 08:01:30.826205	2025-10-29 08:01:30.826205
1189	2025-09-13	9	19	29	35	37	38	31	13	2263651299	\N	2025-10-29 08:01:31.423387	2025-10-29 08:01:31.423387
1190	2025-09-20	7	9	19	23	26	45	33	6	4622793813	\N	2025-10-29 08:01:31.931827	2025-10-29 08:01:31.931827
1191	2025-09-27	1	4	11	12	20	41	2	18	1536334355	\N	2025-10-29 08:01:32.523356	2025-10-29 08:01:32.523356
1192	2025-10-04	10	16	23	36	39	40	11	29	1079546587	\N	2025-10-29 08:01:33.123962	2025-10-29 08:01:33.123962
1193	2025-10-11	6	9	16	19	24	28	17	16	1717013508	\N	2025-10-29 08:01:33.634467	2025-10-29 08:01:33.634467
1194	2025-10-18	3	13	15	24	33	37	2	28	985155349	\N	2025-10-29 08:01:34.141628	2025-10-29 08:01:34.141628
1195	2025-10-25	3	15	27	33	34	36	37	10	2939186738	\N	2025-10-29 08:01:34.650679	2025-10-29 08:01:34.650679
1196	2025-11-01	8	12	15	29	40	45	14	15	2001627550	\N	2025-11-01 15:00:11.442546	2025-11-01 15:00:11.442546
\.


--
-- Data for Name: draws; Type: TABLE DATA; Schema: lotto; Owner: appuser
--

COPY lotto.draws (draw_no, draw_date, num1, num2, num3, num4, num5, num6, bonus_num, first_win_amount, first_win_count, created_at, updated_at) FROM stdin;
1	2002-12-07	10	23	29	33	37	40	16	\N	\N	2025-10-29 06:53:49.824969	2025-10-29 07:45:17.154738
2	2002-12-14	9	13	21	25	32	42	2	2002006800	1	2025-10-29 06:53:50.422236	2025-10-29 07:45:18.771484
3	2002-12-21	11	16	19	21	27	31	30	2000000000	1	2025-10-29 06:53:50.931431	2025-10-29 07:45:19.281704
4	2002-12-28	14	27	30	31	40	42	2	\N	\N	2025-10-29 06:53:51.624597	2025-10-29 07:45:20.069447
5	2003-01-04	16	24	29	40	41	42	3	\N	\N	2025-10-29 06:53:52.133654	2025-10-29 07:45:20.579031
6	2003-01-11	14	15	26	27	40	42	34	6574451700	1	2025-10-29 06:53:52.729317	2025-10-29 07:45:21.08929
7	2003-01-18	2	9	16	25	26	40	42	\N	\N	2025-10-29 06:53:53.328091	2025-10-29 07:45:21.673637
8	2003-01-25	8	19	25	34	37	39	9	\N	\N	2025-10-29 06:53:53.931953	2025-10-29 07:45:22.269575
9	2003-02-01	2	4	16	17	36	39	14	\N	\N	2025-10-29 06:53:54.744919	2025-10-29 07:45:22.780762
10	2003-02-08	9	25	30	33	41	44	6	6430437900	13	2025-10-29 06:53:55.339183	2025-10-29 07:45:23.291182
11	2003-02-15	1	7	36	37	41	42	14	4780152300	5	2025-10-29 07:43:44.805308	2025-10-29 07:45:23.888008
12	2003-02-22	2	11	21	25	39	45	44	1348845700	12	2025-10-29 07:43:45.396644	2025-10-29 07:45:24.480708
13	2003-03-01	22	23	25	37	38	42	26	\N	\N	2025-10-29 07:43:45.914647	2025-10-29 07:45:24.990266
14	2003-03-08	2	6	12	31	33	40	15	9375048300	4	2025-10-29 07:43:46.423303	2025-10-29 07:45:25.577963
15	2003-03-15	3	4	16	30	31	37	13	17014245000	1	2025-10-29 07:43:46.93226	2025-10-29 07:45:26.086611
16	2003-03-22	6	7	24	37	38	40	33	4377146100	4	2025-10-29 07:43:47.440787	2025-10-29 07:45:26.688351
17	2003-03-29	3	4	9	17	32	37	1	5349491200	3	2025-10-29 07:43:47.949333	2025-10-29 07:45:27.198724
18	2003-04-05	3	12	13	19	32	35	29	\N	\N	2025-10-29 07:43:48.460953	2025-10-29 07:45:27.784577
19	2003-04-12	6	30	38	39	40	43	26	40722959400	1	2025-10-29 07:43:48.971113	2025-10-29 07:45:28.29377
20	2003-04-19	10	14	18	20	23	30	41	19352212800	1	2025-10-29 07:43:49.48179	2025-10-29 07:45:28.887817
21	2003-04-26	6	12	17	18	31	32	21	797475400	23	2025-10-29 07:45:29.59778	2025-10-29 07:45:29.59778
22	2003-05-03	4	5	6	8	17	39	25	4552194900	4	2025-10-29 07:45:30.195677	2025-10-29 07:45:30.195677
23	2003-05-10	5	13	17	18	33	42	44	4317947700	4	2025-10-29 07:45:30.706144	2025-10-29 07:45:30.706144
24	2003-05-17	7	8	27	29	36	43	6	\N	\N	2025-10-29 07:45:31.40164	2025-10-29 07:45:31.40164
25	2003-05-24	2	4	21	26	43	44	16	24227745300	2	2025-10-29 07:45:31.909893	2025-10-29 07:45:31.909893
26	2003-05-31	4	5	7	18	20	25	31	3495069900	5	2025-10-29 07:45:32.418778	2025-10-29 07:45:32.418778
27	2003-06-07	1	20	26	28	37	43	27	9543982500	2	2025-10-29 07:45:32.927364	2025-10-29 07:45:32.927364
28	2003-06-14	9	18	23	25	35	37	1	1700361100	10	2025-10-29 07:45:33.436672	2025-10-29 07:45:33.436672
29	2003-06-21	1	5	13	34	39	40	11	3552594000	5	2025-10-29 07:45:33.946076	2025-10-29 07:45:33.946076
30	2003-06-28	8	17	20	35	36	44	4	8728555500	2	2025-10-29 07:45:34.45525	2025-10-29 07:45:34.45525
31	2003-07-05	7	9	18	23	28	35	32	8106672900	2	2025-10-29 07:45:34.963919	2025-10-29 07:45:34.963919
32	2003-07-12	6	14	19	25	34	44	11	1634528300	10	2025-10-29 07:45:35.472536	2025-10-29 07:45:35.472536
33	2003-07-19	4	7	32	33	40	41	9	14903517600	1	2025-10-29 07:45:35.981884	2025-10-29 07:45:35.981884
34	2003-07-26	9	26	35	37	40	42	2	3056918000	5	2025-10-29 07:45:36.495742	2025-10-29 07:45:36.495742
35	2003-08-02	2	3	11	26	37	43	39	5054598200	3	2025-10-29 07:45:37.029205	2025-10-29 07:45:37.029205
36	2003-08-09	1	10	23	26	28	40	31	16014475800	1	2025-10-29 07:45:37.540313	2025-10-29 07:45:37.540313
37	2003-08-16	7	27	30	33	35	37	42	4985999400	3	2025-10-29 07:45:38.049843	2025-10-29 07:45:38.049843
38	2003-08-23	16	17	22	30	37	43	36	5374866400	3	2025-10-29 07:45:38.558447	2025-10-29 07:45:38.558447
39	2003-08-30	6	7	13	15	21	43	8	2623748800	6	2025-10-29 07:45:39.067255	2025-10-29 07:45:39.067255
40	2003-09-06	7	13	18	19	25	26	6	1147652400	13	2025-10-29 07:45:39.619362	2025-10-29 07:45:39.619362
41	2003-09-13	13	20	23	35	38	43	34	\N	\N	2025-10-29 07:45:40.127364	2025-10-29 07:45:40.127364
42	2003-09-20	17	18	19	21	23	32	1	6899280100	6	2025-10-29 07:45:40.636281	2025-10-29 07:45:40.636281
43	2003-09-27	6	31	35	38	39	44	1	17749630800	1	2025-10-29 07:45:41.145024	2025-10-29 07:45:41.145024
44	2003-10-04	3	11	21	30	38	45	39	3362155800	5	2025-10-29 07:45:41.653845	2025-10-29 07:45:41.653845
45	2003-10-11	1	10	20	27	33	35	17	8356417800	2	2025-10-29 07:45:42.162638	2025-10-29 07:45:42.162638
46	2003-10-18	8	13	15	23	31	38	39	5327758800	3	2025-10-29 07:45:42.671679	2025-10-29 07:45:42.671679
47	2003-10-25	14	17	26	31	36	45	27	3250042400	5	2025-10-29 07:45:43.180339	2025-10-29 07:45:43.180339
48	2003-11-01	6	10	18	26	37	38	3	2415673600	6	2025-10-29 07:45:43.690354	2025-10-29 07:45:43.690354
49	2003-11-08	4	7	16	19	33	40	30	1967504600	7	2025-10-29 07:45:44.19969	2025-10-29 07:45:44.19969
50	2003-11-15	2	10	12	15	22	44	1	5227061400	3	2025-10-29 07:45:44.710601	2025-10-29 07:45:44.710601
51	2003-11-22	2	3	11	16	26	44	35	2421117000	6	2025-10-29 07:45:45.219309	2025-10-29 07:45:45.219309
52	2003-11-29	2	4	15	16	20	29	1	3900844900	4	2025-10-29 07:45:45.72771	2025-10-29 07:45:45.72771
53	2003-12-06	7	8	14	32	33	39	42	5014371000	3	2025-10-29 07:45:46.236166	2025-10-29 07:45:46.236166
54	2003-12-13	1	8	21	27	36	39	37	5148626600	3	2025-10-29 07:45:46.74785	2025-10-29 07:45:46.74785
55	2003-12-20	17	21	31	37	40	44	7	7088799600	2	2025-10-29 07:45:47.256087	2025-10-29 07:45:47.256087
56	2003-12-27	10	14	30	31	33	37	19	3777570900	4	2025-10-29 07:45:47.764957	2025-10-29 07:45:47.764957
57	2004-01-03	7	10	16	25	29	44	6	4114411900	4	2025-10-29 07:45:48.273216	2025-10-29 07:45:48.273216
58	2004-01-10	10	24	25	33	40	44	1	3676429200	4	2025-10-29 07:45:48.781231	2025-10-29 07:45:48.781231
59	2004-01-17	6	29	36	39	41	45	13	4127587300	4	2025-10-29 07:45:49.289832	2025-10-29 07:45:49.289832
60	2004-01-24	2	8	25	36	39	42	11	2172504600	7	2025-10-29 07:45:49.797948	2025-10-29 07:45:49.797948
61	2004-01-31	14	15	19	30	38	43	8	3541038800	5	2025-10-29 07:45:50.305926	2025-10-29 07:45:50.305926
62	2004-02-07	3	8	15	27	29	35	21	15817286400	1	2025-10-29 07:45:50.81801	2025-10-29 07:45:50.81801
63	2004-02-14	3	20	23	36	38	40	5	7922245500	2	2025-10-29 07:45:51.326844	2025-10-29 07:45:51.326844
64	2004-02-21	14	15	18	21	26	36	39	3899818000	4	2025-10-29 07:45:51.834876	2025-10-29 07:45:51.834876
65	2004-02-28	4	25	33	36	40	43	39	3727945800	4	2025-10-29 07:45:52.346924	2025-10-29 07:45:52.346924
66	2004-03-06	2	3	7	17	22	24	45	3685138200	4	2025-10-29 07:45:52.855041	2025-10-29 07:45:52.855041
67	2004-03-13	3	7	10	15	36	38	33	2114436500	7	2025-10-29 07:45:53.363792	2025-10-29 07:45:53.363792
68	2004-03-20	10	12	15	16	26	39	38	2945882100	5	2025-10-29 07:45:53.871884	2025-10-29 07:45:53.871884
69	2004-03-27	5	8	14	15	19	39	35	4962712200	3	2025-10-29 07:45:54.380667	2025-10-29 07:45:54.380667
70	2004-04-03	5	19	22	25	28	43	26	5031277800	3	2025-10-29 07:45:54.890068	2025-10-29 07:45:54.890068
71	2004-04-10	5	9	12	16	29	41	21	\N	\N	2025-10-29 07:45:55.397941	2025-10-29 07:45:55.397941
72	2004-04-17	2	4	11	17	26	27	1	3260524600	13	2025-10-29 07:45:55.906743	2025-10-29 07:45:55.906743
73	2004-04-24	3	12	18	32	40	43	38	2766662100	6	2025-10-29 07:45:56.41523	2025-10-29 07:45:56.41523
74	2004-05-01	6	15	17	18	35	40	23	5284949800	3	2025-10-29 07:45:56.926253	2025-10-29 07:45:56.926253
75	2004-05-08	2	5	24	32	34	44	28	3914616900	4	2025-10-29 07:45:57.434914	2025-10-29 07:45:57.434914
76	2004-05-15	1	3	15	22	25	37	43	7451022600	2	2025-10-29 07:45:57.942822	2025-10-29 07:45:57.942822
77	2004-05-22	2	18	29	32	43	44	37	5155758600	3	2025-10-29 07:45:58.451865	2025-10-29 07:45:58.451865
78	2004-05-29	10	13	25	29	33	35	38	3519850000	4	2025-10-29 07:45:58.960075	2025-10-29 07:45:58.960075
79	2004-06-05	3	12	24	27	30	32	14	3416443800	4	2025-10-29 07:45:59.467812	2025-10-29 07:45:59.467812
80	2004-06-12	17	18	24	25	26	30	1	13809540000	1	2025-10-29 07:45:59.976288	2025-10-29 07:45:59.976288
81	2004-06-19	5	7	11	13	20	33	6	2714288880	5	2025-10-29 07:46:00.487219	2025-10-29 07:46:00.487219
82	2004-06-26	1	2	3	14	27	42	39	14562494400	1	2025-10-29 07:46:00.996421	2025-10-29 07:46:00.996421
83	2004-07-03	6	10	15	17	19	34	14	7086948300	2	2025-10-29 07:46:01.504114	2025-10-29 07:46:01.504114
84	2004-07-10	16	23	27	34	42	45	11	7669779000	2	2025-10-29 07:46:02.012593	2025-10-29 07:46:02.012593
85	2004-07-17	6	8	13	23	31	36	21	3462109800	4	2025-10-29 07:46:02.520738	2025-10-29 07:46:02.520738
86	2004-07-24	2	12	37	39	41	45	33	14252186400	1	2025-10-29 07:46:03.029911	2025-10-29 07:46:03.029911
87	2004-07-31	4	12	16	23	34	43	26	1799358055	11	2025-10-29 07:46:03.537366	2025-10-29 07:46:03.537366
88	2004-08-07	1	17	20	24	30	41	27	3069709650	4	2025-10-29 07:46:04.046027	2025-10-29 07:46:04.046027
89	2004-08-14	4	26	28	29	33	40	37	4248321900	3	2025-10-29 07:46:04.553726	2025-10-29 07:46:04.553726
90	2004-08-21	17	20	29	35	38	44	10	3291435300	4	2025-10-29 07:46:05.06312	2025-10-29 07:46:05.06312
91	2004-08-28	1	21	24	26	29	42	27	3582902400	4	2025-10-29 07:46:05.571185	2025-10-29 07:46:05.571185
92	2004-09-04	3	14	24	33	35	36	17	1233270846	11	2025-10-29 07:46:06.078986	2025-10-29 07:46:06.078986
93	2004-09-11	6	22	24	36	38	44	19	2269178150	6	2025-10-29 07:46:06.588651	2025-10-29 07:46:06.588651
94	2004-09-18	5	32	34	40	41	45	6	2245339950	6	2025-10-29 07:46:07.100277	2025-10-29 07:46:07.100277
95	2004-09-25	8	17	27	31	34	43	14	1747741238	8	2025-10-29 07:46:07.608058	2025-10-29 07:46:07.608058
96	2004-10-02	1	3	8	21	22	31	20	1847133515	7	2025-10-29 07:46:08.117068	2025-10-29 07:46:08.117068
97	2004-10-09	6	7	14	15	20	36	3	1496214000	9	2025-10-29 07:46:08.624438	2025-10-29 07:46:08.624438
98	2004-10-16	6	9	16	23	24	32	43	3177972300	4	2025-10-29 07:46:09.132237	2025-10-29 07:46:09.132237
99	2004-10-23	1	3	10	27	29	37	11	2169219050	6	2025-10-29 07:46:09.639881	2025-10-29 07:46:09.639881
100	2004-10-30	1	7	11	23	37	42	6	3315315525	4	2025-10-29 07:46:10.148775	2025-10-29 07:46:10.148775
101	2004-11-06	1	3	17	32	35	45	8	2707297500	5	2025-10-29 07:46:15.719336	2025-10-29 07:46:15.719336
102	2004-11-13	17	22	24	26	35	40	42	1457153067	9	2025-10-29 07:46:16.228066	2025-10-29 07:46:16.228066
103	2004-11-20	5	14	15	27	30	45	10	1691589563	8	2025-10-29 07:46:16.739883	2025-10-29 07:46:16.739883
104	2004-11-27	17	32	33	34	42	44	35	6610743750	2	2025-10-29 07:46:17.249106	2025-10-29 07:46:17.249106
105	2004-12-04	8	10	20	34	41	45	28	3416781450	4	2025-10-29 07:46:17.757184	2025-10-29 07:46:17.757184
106	2004-12-11	4	10	12	22	24	33	29	810461157	16	2025-10-29 07:46:18.267785	2025-10-29 07:46:18.267785
107	2004-12-18	1	4	5	6	9	31	17	6679927800	2	2025-10-29 07:46:18.776693	2025-10-29 07:46:18.776693
108	2004-12-25	7	18	22	23	29	44	12	1998900772	7	2025-10-29 07:46:19.286457	2025-10-29 07:46:19.286457
109	2005-01-01	1	5	34	36	42	44	33	1246838200	12	2025-10-29 07:46:19.794821	2025-10-29 07:46:19.794821
110	2005-01-08	7	20	22	23	29	43	1	4566262000	3	2025-10-29 07:46:20.30293	2025-10-29 07:46:20.30293
111	2005-01-15	7	18	31	33	36	40	27	2199047450	6	2025-10-29 07:46:20.810774	2025-10-29 07:46:20.810774
112	2005-01-22	26	29	30	33	41	42	43	1567271167	9	2025-10-29 07:46:21.319685	2025-10-29 07:46:21.319685
113	2005-01-29	4	9	28	33	36	45	26	1561528934	9	2025-10-29 07:46:21.829162	2025-10-29 07:46:21.829162
114	2005-02-05	11	14	19	26	28	41	2	2362345050	6	2025-10-29 07:46:22.340678	2025-10-29 07:46:22.340678
115	2005-02-12	1	2	6	9	25	28	31	1488589567	9	2025-10-29 07:46:22.850046	2025-10-29 07:46:22.850046
116	2005-02-19	2	4	25	31	34	37	17	1997747315	7	2025-10-29 07:46:23.358204	2025-10-29 07:46:23.358204
117	2005-02-26	5	10	22	34	36	44	35	1558378334	9	2025-10-29 07:46:23.86675	2025-10-29 07:46:23.86675
118	2005-03-05	3	4	10	17	19	22	38	1297989720	10	2025-10-29 07:46:24.37618	2025-10-29 07:46:24.37618
119	2005-03-12	3	11	13	14	17	21	38	1474899400	9	2025-10-29 07:46:24.884452	2025-10-29 07:46:24.884452
120	2005-03-19	4	6	10	11	32	37	30	4364530300	3	2025-10-29 07:46:25.393092	2025-10-29 07:46:25.393092
121	2005-03-26	12	28	30	34	38	43	9	6839648100	2	2025-10-29 07:46:25.901142	2025-10-29 07:46:25.901142
122	2005-04-02	1	11	16	17	36	40	8	1450073800	9	2025-10-29 07:46:26.410122	2025-10-29 07:46:26.410122
123	2005-04-09	7	17	18	28	30	45	27	2532982680	5	2025-10-29 07:46:26.919233	2025-10-29 07:46:26.919233
124	2005-04-16	4	16	23	25	29	42	1	1395936267	9	2025-10-29 07:46:27.432805	2025-10-29 07:46:27.432805
125	2005-04-23	2	8	32	33	35	36	18	1754870786	7	2025-10-29 07:46:27.940373	2025-10-29 07:46:27.940373
126	2005-04-30	7	20	22	27	40	43	1	1369301500	9	2025-10-29 07:46:28.448704	2025-10-29 07:46:28.448704
127	2005-05-07	3	5	10	29	32	43	35	1965939150	6	2025-10-29 07:46:28.958351	2025-10-29 07:46:28.958351
128	2005-05-14	12	30	34	36	37	45	39	2064043100	6	2025-10-29 07:46:29.466458	2025-10-29 07:46:29.466458
129	2005-05-21	19	23	25	28	38	42	17	1093629655	11	2025-10-29 07:46:29.974514	2025-10-29 07:46:29.974514
130	2005-05-28	7	19	24	27	42	45	31	3036496650	4	2025-10-29 07:46:30.482621	2025-10-29 07:46:30.482621
131	2005-06-04	8	10	11	14	15	21	37	1451214488	8	2025-10-29 07:46:30.990485	2025-10-29 07:46:30.990485
132	2005-06-11	3	17	23	34	41	45	43	2920473525	4	2025-10-29 07:46:31.531728	2025-10-29 07:46:31.531728
133	2005-06-18	4	7	15	18	23	26	13	1450242600	8	2025-10-29 07:46:32.040951	2025-10-29 07:46:32.040951
134	2005-06-25	3	12	20	23	31	35	43	2349155100	5	2025-10-29 07:46:32.549287	2025-10-29 07:46:32.549287
135	2005-07-02	6	14	22	28	35	39	16	1717293515	7	2025-10-29 07:46:33.057608	2025-10-29 07:46:33.057608
136	2005-07-09	2	16	30	36	41	42	11	1997694150	6	2025-10-29 07:46:33.571668	2025-10-29 07:46:33.571668
137	2005-07-16	7	9	20	25	36	39	15	1270403467	9	2025-10-29 07:46:34.081	2025-10-29 07:46:34.081
138	2005-07-23	10	11	27	28	37	39	19	2227152000	5	2025-10-29 07:46:34.589818	2025-10-29 07:46:34.589818
139	2005-07-30	9	11	15	20	28	43	13	1650210215	7	2025-10-29 07:46:35.098517	2025-10-29 07:46:35.098517
140	2005-08-06	3	13	17	18	19	28	8	2109462840	5	2025-10-29 07:46:35.606624	2025-10-29 07:46:35.606624
141	2005-08-13	8	12	29	31	42	43	2	1900552400	6	2025-10-29 07:46:36.116656	2025-10-29 07:46:36.116656
142	2005-08-20	12	16	30	34	40	44	19	1018265564	11	2025-10-29 07:46:36.628347	2025-10-29 07:46:36.628347
143	2005-08-27	26	27	28	42	43	45	8	3954584700	3	2025-10-29 07:46:37.143213	2025-10-29 07:46:37.143213
144	2005-09-03	4	15	17	26	36	37	43	1402440413	8	2025-10-29 07:46:37.651143	2025-10-29 07:46:37.651143
145	2005-09-10	2	3	13	20	27	44	9	3797838200	3	2025-10-29 07:46:38.159693	2025-10-29 07:46:38.159693
146	2005-09-17	2	19	27	35	41	42	25	6043415250	2	2025-10-29 07:46:38.669622	2025-10-29 07:46:38.669622
147	2005-09-24	4	6	13	21	40	42	36	1700040215	7	2025-10-29 07:46:39.178479	2025-10-29 07:46:39.178479
148	2005-10-01	21	25	33	34	35	36	17	2323596420	5	2025-10-29 07:46:39.685782	2025-10-29 07:46:39.685782
149	2005-10-08	2	11	21	34	41	42	27	1639052143	7	2025-10-29 07:46:40.194349	2025-10-29 07:46:40.194349
150	2005-10-15	2	18	25	28	37	39	16	2831645850	4	2025-10-29 07:46:40.702422	2025-10-29 07:46:40.702422
151	2005-10-22	1	2	10	13	18	19	15	2716634025	4	2025-10-29 07:46:41.209882	2025-10-29 07:46:41.209882
152	2005-10-29	1	5	13	26	29	34	43	2278131840	5	2025-10-29 07:46:41.717793	2025-10-29 07:46:41.717793
153	2005-11-05	3	8	11	12	13	36	33	2730526125	4	2025-10-29 07:46:42.228194	2025-10-29 07:46:42.228194
154	2005-11-12	6	19	21	35	40	45	20	2836628700	4	2025-10-29 07:46:42.738018	2025-10-29 07:46:42.738018
155	2005-11-19	16	19	20	32	33	41	4	1193005734	9	2025-10-29 07:46:43.259842	2025-10-29 07:46:43.259842
156	2005-11-26	5	18	28	30	42	45	2	1401099900	8	2025-10-29 07:46:43.79385	2025-10-29 07:46:43.79385
157	2005-12-03	19	26	30	33	35	39	37	5484903750	2	2025-10-29 07:46:44.302139	2025-10-29 07:46:44.302139
158	2005-12-10	4	9	13	18	21	34	7	1069544340	10	2025-10-29 07:46:44.812262	2025-10-29 07:46:44.812262
159	2005-12-17	1	18	30	41	42	43	32	1755407300	6	2025-10-29 07:46:45.321387	2025-10-29 07:46:45.321387
160	2005-12-24	3	7	8	34	39	41	1	5490805350	2	2025-10-29 07:46:45.829498	2025-10-29 07:46:45.829498
161	2005-12-31	22	34	36	40	42	45	44	1996876272	7	2025-10-29 07:46:46.338291	2025-10-29 07:46:46.338291
162	2006-01-07	1	5	21	25	38	41	24	2308265760	5	2025-10-29 07:46:46.847582	2025-10-29 07:46:46.847582
163	2006-01-14	7	11	26	28	29	44	16	1629726515	7	2025-10-29 07:46:47.357182	2025-10-29 07:46:47.357182
164	2006-01-21	6	9	10	11	39	41	27	4054937900	3	2025-10-29 07:46:47.865638	2025-10-29 07:46:47.865638
165	2006-01-28	5	13	18	19	22	42	31	6767426700	2	2025-10-29 07:46:48.374554	2025-10-29 07:46:48.374554
166	2006-02-04	9	12	27	36	39	45	14	1111299982	11	2025-10-29 07:46:48.882555	2025-10-29 07:46:48.882555
167	2006-02-11	24	27	28	30	36	39	4	2491222920	5	2025-10-29 07:46:49.391156	2025-10-29 07:46:49.391156
168	2006-02-18	3	10	31	40	42	43	30	2349946920	5	2025-10-29 07:46:49.900412	2025-10-29 07:46:49.900412
169	2006-02-25	16	27	35	37	43	45	19	2482888380	5	2025-10-29 07:46:50.408112	2025-10-29 07:46:50.408112
170	2006-03-04	2	11	13	15	31	42	10	1923108250	6	2025-10-29 07:46:50.915512	2025-10-29 07:46:50.915512
171	2006-03-11	4	16	25	29	34	35	1	1961339700	6	2025-10-29 07:46:51.423846	2025-10-29 07:46:51.423846
172	2006-03-18	4	19	21	24	26	41	35	1081154073	11	2025-10-29 07:46:51.932593	2025-10-29 07:46:51.932593
173	2006-03-25	3	9	24	30	33	34	18	1487736788	8	2025-10-29 07:46:52.440471	2025-10-29 07:46:52.440471
174	2006-04-01	13	14	18	22	35	39	16	1771103058	7	2025-10-29 07:46:52.949777	2025-10-29 07:46:52.949777
175	2006-04-08	19	26	28	31	33	36	17	2371132620	5	2025-10-29 07:46:53.459633	2025-10-29 07:46:53.459633
176	2006-04-15	4	17	30	32	33	34	15	2314663080	5	2025-10-29 07:46:53.968416	2025-10-29 07:46:53.968416
177	2006-04-22	1	10	13	16	37	43	6	1693285500	7	2025-10-29 07:46:54.476514	2025-10-29 07:46:54.476514
178	2006-04-29	1	5	11	12	18	23	9	2254621080	5	2025-10-29 07:46:54.984005	2025-10-29 07:46:54.984005
179	2006-05-06	5	9	17	25	39	43	32	1081093920	10	2025-10-29 07:46:55.492386	2025-10-29 07:46:55.492386
180	2006-05-13	2	15	20	21	29	34	22	5763371550	2	2025-10-29 07:46:55.999943	2025-10-29 07:46:55.999943
181	2006-05-20	14	21	23	32	40	45	44	1941763300	6	2025-10-29 07:46:56.508615	2025-10-29 07:46:56.508615
182	2006-05-27	13	15	27	29	34	40	35	3721439400	3	2025-10-29 07:46:57.018602	2025-10-29 07:46:57.018602
183	2006-06-03	2	18	24	34	40	42	5	1777221500	6	2025-10-29 07:46:57.526502	2025-10-29 07:46:57.526502
184	2006-06-10	1	2	6	16	20	33	41	1747753050	6	2025-10-29 07:46:58.037564	2025-10-29 07:46:58.037564
185	2006-06-17	1	2	4	8	19	38	14	3522485800	3	2025-10-29 07:46:58.546902	2025-10-29 07:46:58.546902
186	2006-06-24	4	10	14	19	21	45	9	1187882600	9	2025-10-29 07:46:59.054645	2025-10-29 07:46:59.054645
187	2006-07-01	1	2	8	18	29	38	42	1544733900	7	2025-10-29 07:46:59.56379	2025-10-29 07:46:59.56379
188	2006-07-08	19	24	27	30	31	34	36	3501405200	3	2025-10-29 07:47:00.074568	2025-10-29 07:47:00.074568
189	2006-07-15	8	14	32	35	37	45	28	3461775100	3	2025-10-29 07:47:00.583863	2025-10-29 07:47:00.583863
190	2006-07-22	8	14	18	30	31	44	15	1784159450	6	2025-10-29 07:47:01.09168	2025-10-29 07:47:01.09168
191	2006-07-29	5	6	24	25	32	37	8	2577114675	4	2025-10-29 07:47:01.600706	2025-10-29 07:47:01.600706
192	2006-08-05	4	8	11	18	37	45	33	2445348375	4	2025-10-29 07:47:02.110985	2025-10-29 07:47:02.110985
193	2006-08-12	6	14	18	26	36	39	13	3404449700	3	2025-10-29 07:47:02.619149	2025-10-29 07:47:02.619149
194	2006-08-19	15	20	23	26	39	44	28	2650567875	4	2025-10-29 07:47:03.127905	2025-10-29 07:47:03.127905
195	2006-08-26	7	10	19	22	35	40	31	918992591	11	2025-10-29 07:47:03.636183	2025-10-29 07:47:03.636183
196	2006-09-02	35	36	37	41	44	45	30	727876520	15	2025-10-29 07:47:04.145035	2025-10-29 07:47:04.145035
197	2006-09-09	7	12	16	34	42	45	4	1803018300	6	2025-10-29 07:47:04.653353	2025-10-29 07:47:04.653353
198	2006-09-16	12	19	20	25	41	45	2	1797855050	6	2025-10-29 07:47:05.161595	2025-10-29 07:47:05.161595
199	2006-09-23	14	21	22	25	30	36	43	5344252200	2	2025-10-29 07:47:05.6751	2025-10-29 07:47:05.6751
200	2006-09-30	5	6	13	14	17	20	7	1344616613	8	2025-10-29 07:47:06.182851	2025-10-29 07:47:06.182851
201	2006-10-07	3	11	24	38	39	44	26	9719465400	1	2025-10-29 07:47:11.728295	2025-10-29 07:47:11.728295
202	2006-10-14	12	14	27	33	39	44	17	1893391700	6	2025-10-29 07:47:12.240866	2025-10-29 07:47:12.240866
203	2006-10-21	1	3	11	24	30	32	7	2164564740	5	2025-10-29 07:47:12.749255	2025-10-29 07:47:12.749255
204	2006-10-28	3	12	14	35	40	45	5	1358347125	8	2025-10-29 07:47:13.257424	2025-10-29 07:47:13.257424
205	2006-11-04	1	3	21	29	35	37	30	1835221800	6	2025-10-29 07:47:13.765418	2025-10-29 07:47:13.765418
206	2006-11-11	1	2	3	15	20	25	43	2032859340	5	2025-10-29 07:47:14.273577	2025-10-29 07:47:14.273577
207	2006-11-18	3	11	14	31	32	37	38	2104673760	5	2025-10-29 07:47:14.784221	2025-10-29 07:47:14.784221
208	2006-11-25	14	25	31	34	40	44	24	1760767400	6	2025-10-29 07:47:15.291886	2025-10-29 07:47:15.291886
209	2006-12-02	2	7	18	20	24	33	37	1660896350	6	2025-10-29 07:47:15.800791	2025-10-29 07:47:15.800791
210	2006-12-09	10	19	22	23	25	37	39	5139085950	2	2025-10-29 07:47:16.308689	2025-10-29 07:47:16.308689
211	2006-12-16	12	13	17	20	33	41	8	1035800250	10	2025-10-29 07:47:16.818341	2025-10-29 07:47:16.818341
212	2006-12-23	11	12	18	21	31	38	8	2660747250	4	2025-10-29 07:47:17.327898	2025-10-29 07:47:17.327898
213	2006-12-30	2	3	4	5	20	24	42	1376678025	8	2025-10-29 07:47:17.837219	2025-10-29 07:47:17.837219
214	2007-01-06	5	7	20	25	28	37	32	1406980875	8	2025-10-29 07:47:18.345391	2025-10-29 07:47:18.345391
215	2007-01-13	2	3	7	15	43	44	4	1587689615	7	2025-10-29 07:47:18.853534	2025-10-29 07:47:18.853534
216	2007-01-20	7	16	17	33	36	40	1	848506108	13	2025-10-29 07:47:19.362724	2025-10-29 07:47:19.362724
217	2007-01-27	16	20	27	33	35	39	38	1611246172	7	2025-10-29 07:47:19.871327	2025-10-29 07:47:19.871327
218	2007-02-03	1	8	14	18	29	44	20	2779075800	4	2025-10-29 07:47:20.381772	2025-10-29 07:47:20.381772
219	2007-02-10	4	11	20	26	35	37	16	1208409167	9	2025-10-29 07:47:20.890084	2025-10-29 07:47:20.890084
220	2007-02-17	5	11	19	21	34	43	31	1958094950	6	2025-10-29 07:47:21.398582	2025-10-29 07:47:21.398582
221	2007-02-24	2	20	33	35	37	40	10	1800104250	6	2025-10-29 07:47:21.908185	2025-10-29 07:47:21.908185
222	2007-03-03	5	7	28	29	39	43	44	2275193820	5	2025-10-29 07:47:22.416985	2025-10-29 07:47:22.416985
223	2007-03-10	1	3	18	20	26	27	38	1498170600	7	2025-10-29 07:47:22.925719	2025-10-29 07:47:22.925719
224	2007-03-17	4	19	26	27	30	42	7	1808969950	6	2025-10-29 07:47:23.434349	2025-10-29 07:47:23.434349
225	2007-03-24	5	11	13	19	31	36	7	1777201800	6	2025-10-29 07:47:23.942605	2025-10-29 07:47:23.942605
226	2007-03-31	2	6	8	14	21	22	34	1744100150	6	2025-10-29 07:47:24.452209	2025-10-29 07:47:24.452209
227	2007-04-07	4	5	15	16	22	42	2	5253542400	2	2025-10-29 07:47:24.960544	2025-10-29 07:47:24.960544
228	2007-04-14	17	25	35	36	39	44	23	1146700334	9	2025-10-29 07:47:25.471321	2025-10-29 07:47:25.471321
229	2007-04-21	4	5	9	11	23	38	35	1451441100	7	2025-10-29 07:47:25.979409	2025-10-29 07:47:25.979409
230	2007-04-28	5	11	14	29	32	33	12	1292929163	8	2025-10-29 07:47:26.491514	2025-10-29 07:47:26.491514
231	2007-05-05	5	10	19	31	44	45	27	1088365900	9	2025-10-29 07:47:27.000566	2025-10-29 07:47:27.000566
232	2007-05-12	8	9	10	12	24	44	35	1110918400	9	2025-10-29 07:47:27.511037	2025-10-29 07:47:27.511037
233	2007-05-19	4	6	13	17	28	40	39	999153750	10	2025-10-29 07:47:28.020057	2025-10-29 07:47:28.020057
234	2007-05-26	13	21	22	24	26	37	4	2519743875	4	2025-10-29 07:47:28.527891	2025-10-29 07:47:28.527891
235	2007-06-02	21	22	26	27	31	37	8	3433330100	3	2025-10-29 07:47:29.034997	2025-10-29 07:47:29.034997
236	2007-06-09	1	4	8	13	37	39	7	5030040150	2	2025-10-29 07:47:29.543489	2025-10-29 07:47:29.543489
237	2007-06-16	1	11	17	21	24	44	33	1440630729	7	2025-10-29 07:47:30.051384	2025-10-29 07:47:30.051384
238	2007-06-23	2	4	15	28	31	34	35	1121660567	9	2025-10-29 07:47:30.563526	2025-10-29 07:47:30.563526
239	2007-06-30	11	15	24	39	41	44	7	1134140167	9	2025-10-29 07:47:31.071521	2025-10-29 07:47:31.071521
240	2007-07-07	6	10	16	40	41	43	21	5098251450	2	2025-10-29 07:47:31.579927	2025-10-29 07:47:31.579927
241	2007-07-14	2	16	24	27	28	35	21	2552016300	4	2025-10-29 07:47:32.089134	2025-10-29 07:47:32.089134
242	2007-07-21	4	19	20	21	32	34	43	1234542375	8	2025-10-29 07:47:32.598335	2025-10-29 07:47:32.598335
243	2007-07-28	2	12	17	19	28	42	34	2408850000	4	2025-10-29 07:47:33.1078	2025-10-29 07:47:33.1078
244	2007-08-04	13	16	25	36	37	38	19	9121583100	1	2025-10-29 07:47:33.658517	2025-10-29 07:47:33.658517
245	2007-08-11	9	11	27	31	32	38	22	1382583129	7	2025-10-29 07:47:34.166888	2025-10-29 07:47:34.166888
246	2007-08-18	13	18	21	23	26	39	15	1911774240	5	2025-10-29 07:47:34.67727	2025-10-29 07:47:34.67727
247	2007-08-25	12	15	28	36	39	40	13	1669313900	6	2025-10-29 07:47:35.18607	2025-10-29 07:47:35.18607
248	2007-09-01	3	8	17	23	38	45	13	1227479363	8	2025-10-29 07:47:35.694474	2025-10-29 07:47:35.694474
249	2007-09-08	3	8	27	31	41	44	11	1663568700	6	2025-10-29 07:47:36.203087	2025-10-29 07:47:36.203087
250	2007-09-15	19	23	30	37	43	45	38	1994726280	5	2025-10-29 07:47:36.711576	2025-10-29 07:47:36.711576
251	2007-09-22	6	7	19	25	28	38	45	1282616400	8	2025-10-29 07:47:37.222066	2025-10-29 07:47:37.222066
252	2007-09-29	14	23	26	31	39	45	28	1391089715	7	2025-10-29 07:47:37.730103	2025-10-29 07:47:37.730103
253	2007-10-06	8	19	25	31	34	36	33	2466189525	4	2025-10-29 07:47:38.238674	2025-10-29 07:47:38.238674
254	2007-10-13	1	5	19	20	24	30	27	9741015900	1	2025-10-29 07:47:38.748111	2025-10-29 07:47:38.748111
255	2007-10-20	1	5	6	24	27	42	32	1598618550	6	2025-10-29 07:47:39.256133	2025-10-29 07:47:39.256133
256	2007-10-27	4	11	14	21	23	43	32	4891017000	2	2025-10-29 07:47:39.764346	2025-10-29 07:47:39.764346
257	2007-11-03	6	13	27	31	32	37	4	2391377025	4	2025-10-29 07:47:40.272253	2025-10-29 07:47:40.272253
258	2007-11-10	14	27	30	31	38	40	17	2426434350	4	2025-10-29 07:47:40.78016	2025-10-29 07:47:40.78016
259	2007-11-17	4	5	14	35	42	45	34	4838533500	2	2025-10-29 07:47:41.290044	2025-10-29 07:47:41.290044
260	2007-11-24	7	12	15	24	37	40	43	2310085575	4	2025-10-29 07:47:41.823885	2025-10-29 07:47:41.823885
261	2007-12-01	6	11	16	18	31	43	2	3192299100	3	2025-10-29 07:47:42.332028	2025-10-29 07:47:42.332028
262	2007-12-08	9	12	24	25	29	31	36	4518741600	2	2025-10-29 07:47:42.840495	2025-10-29 07:47:42.840495
263	2007-12-15	1	27	28	32	37	40	18	1551704900	6	2025-10-29 07:47:43.3503	2025-10-29 07:47:43.3503
264	2007-12-22	9	16	27	36	41	44	5	1344889200	7	2025-10-29 07:47:43.858457	2025-10-29 07:47:43.858457
265	2007-12-29	5	9	34	37	38	39	12	1200838575	8	2025-10-29 07:47:44.368791	2025-10-29 07:47:44.368791
266	2008-01-05	3	4	9	11	22	42	37	3207211700	3	2025-10-29 07:47:44.877116	2025-10-29 07:47:44.877116
267	2008-01-12	7	8	24	34	36	41	1	3257663300	3	2025-10-29 07:47:45.385953	2025-10-29 07:47:45.385953
268	2008-01-19	3	10	19	24	32	45	12	1350954515	7	2025-10-29 07:47:45.897629	2025-10-29 07:47:45.897629
269	2008-01-26	5	18	20	36	42	43	32	1961399940	5	2025-10-29 07:47:46.406822	2025-10-29 07:47:46.406822
270	2008-02-02	5	9	12	20	21	26	27	1927830060	5	2025-10-29 07:47:46.916286	2025-10-29 07:47:46.916286
271	2008-02-09	3	8	9	27	29	40	36	1565918150	6	2025-10-29 07:47:47.424577	2025-10-29 07:47:47.424577
272	2008-02-16	7	9	12	27	39	43	28	1104622800	9	2025-10-29 07:47:47.932686	2025-10-29 07:47:47.932686
273	2008-02-23	1	8	24	31	34	44	6	3339543100	3	2025-10-29 07:47:48.442221	2025-10-29 07:47:48.442221
274	2008-03-01	13	14	15	26	35	39	25	2505085575	4	2025-10-29 07:47:48.951311	2025-10-29 07:47:48.951311
275	2008-03-08	14	19	20	35	38	40	26	10044066900	1	2025-10-29 07:47:49.459353	2025-10-29 07:47:49.459353
276	2008-03-15	4	15	21	33	39	41	25	3312569000	3	2025-10-29 07:47:49.967235	2025-10-29 07:47:49.967235
277	2008-03-22	10	12	13	15	25	29	20	3272627800	3	2025-10-29 07:47:50.47541	2025-10-29 07:47:50.47541
278	2008-03-29	3	11	37	39	41	43	13	3186530000	3	2025-10-29 07:47:50.983582	2025-10-29 07:47:50.983582
279	2008-04-05	7	16	31	36	37	38	11	1914205320	5	2025-10-29 07:47:51.493972	2025-10-29 07:47:51.493972
280	2008-04-12	10	11	23	24	36	37	35	1355258529	7	2025-10-29 07:47:52.001986	2025-10-29 07:47:52.001986
281	2008-04-19	1	3	4	6	14	41	12	1554683200	6	2025-10-29 07:47:52.510465	2025-10-29 07:47:52.510465
282	2008-04-26	2	5	10	18	31	32	30	1322052643	7	2025-10-29 07:47:53.018412	2025-10-29 07:47:53.018412
283	2008-05-03	6	8	18	31	38	45	42	3137224600	3	2025-10-29 07:47:53.526468	2025-10-29 07:47:53.526468
284	2008-05-10	2	7	15	24	30	45	28	3117640300	3	2025-10-29 07:47:54.034844	2025-10-29 07:47:54.034844
285	2008-05-17	13	33	37	40	41	45	2	3164370100	3	2025-10-29 07:47:54.545032	2025-10-29 07:47:54.545032
286	2008-05-24	1	15	19	40	42	44	17	3236566300	3	2025-10-29 07:47:55.056416	2025-10-29 07:47:55.056416
287	2008-05-31	6	12	24	27	35	37	41	1328657100	7	2025-10-29 07:47:55.564328	2025-10-29 07:47:55.564328
288	2008-06-07	1	12	17	28	35	41	10	2357261550	4	2025-10-29 07:47:56.072346	2025-10-29 07:47:56.072346
289	2008-06-14	3	14	33	37	38	42	10	\N	\N	2025-10-29 07:47:56.58329	2025-10-29 07:47:56.58329
290	2008-06-21	8	13	18	32	39	45	7	2149214424	13	2025-10-29 07:47:57.091908	2025-10-29 07:47:57.091908
291	2008-06-28	3	7	8	18	20	42	45	1450585200	7	2025-10-29 07:47:57.600833	2025-10-29 07:47:57.600833
292	2008-07-05	17	18	31	32	33	34	10	720373950	14	2025-10-29 07:47:58.108894	2025-10-29 07:47:58.108894
293	2008-07-12	1	9	17	21	29	33	24	1656764400	6	2025-10-29 07:47:58.616243	2025-10-29 07:47:58.616243
294	2008-07-19	6	10	17	30	37	38	40	2406504975	4	2025-10-29 07:47:59.124926	2025-10-29 07:47:59.124926
295	2008-07-26	1	4	12	16	18	38	8	\N	\N	2025-10-29 07:47:59.633986	2025-10-29 07:47:59.633986
296	2008-08-02	3	8	15	27	30	45	44	3066088275	8	2025-10-29 07:48:00.142157	2025-10-29 07:48:00.142157
297	2008-08-09	6	11	19	20	28	32	34	5056668750	2	2025-10-29 07:48:00.650347	2025-10-29 07:48:00.650347
298	2008-08-16	5	9	27	29	37	40	19	9909778500	1	2025-10-29 07:48:01.158507	2025-10-29 07:48:01.158507
299	2008-08-23	1	3	20	25	36	45	24	1483772529	7	2025-10-29 07:48:01.667097	2025-10-29 07:48:01.667097
300	2008-08-30	7	9	10	12	26	38	39	836092425	12	2025-10-29 07:48:02.175782	2025-10-29 07:48:02.175782
301	2008-09-06	7	11	13	33	37	43	26	1447385015	7	2025-10-29 07:48:07.723294	2025-10-29 07:48:07.723294
302	2008-09-13	13	19	20	32	38	42	4	5472167250	2	2025-10-29 07:48:08.232835	2025-10-29 07:48:08.232835
303	2008-09-20	2	14	17	30	38	45	43	1672749000	6	2025-10-29 07:48:08.741537	2025-10-29 07:48:08.741537
304	2008-09-27	4	10	16	26	33	41	38	1661646150	6	2025-10-29 07:48:09.250161	2025-10-29 07:48:09.250161
305	2008-10-04	7	8	18	21	23	39	9	2008210140	5	2025-10-29 07:48:09.759334	2025-10-29 07:48:09.759334
306	2008-10-11	4	18	23	30	34	41	19	2102669520	5	2025-10-29 07:48:10.26754	2025-10-29 07:48:10.26754
307	2008-10-18	5	15	21	23	25	45	12	2587643250	4	2025-10-29 07:48:10.778003	2025-10-29 07:48:10.778003
308	2008-10-25	14	15	17	19	37	45	40	10232872800	1	2025-10-29 07:48:11.28665	2025-10-29 07:48:11.28665
309	2008-11-01	1	2	5	11	18	36	22	901622946	11	2025-10-29 07:48:11.796851	2025-10-29 07:48:11.796851
310	2008-11-08	1	5	19	28	34	41	16	1296713325	8	2025-10-29 07:48:12.304784	2025-10-29 07:48:12.304784
311	2008-11-15	4	12	24	27	28	32	10	1237691063	8	2025-10-29 07:48:12.813259	2025-10-29 07:48:12.813259
312	2008-11-22	2	3	5	6	12	20	25	629017820	15	2025-10-29 07:48:13.321231	2025-10-29 07:48:13.321231
313	2008-11-29	9	17	34	35	43	45	2	1715422800	6	2025-10-29 07:48:13.82953	2025-10-29 07:48:13.82953
314	2008-12-06	15	17	19	34	38	41	2	1660512200	6	2025-10-29 07:48:14.337739	2025-10-29 07:48:14.337739
315	2008-12-13	1	13	33	35	43	45	23	1308728625	8	2025-10-29 07:48:14.846782	2025-10-29 07:48:14.846782
316	2008-12-20	10	11	21	27	31	39	43	1673586400	6	2025-10-29 07:48:15.35453	2025-10-29 07:48:15.35453
317	2008-12-27	3	10	11	22	36	39	8	2576258550	4	2025-10-29 07:48:15.863788	2025-10-29 07:48:15.863788
318	2009-01-03	2	17	19	20	34	45	21	1207436600	9	2025-10-29 07:48:16.372961	2025-10-29 07:48:16.372961
319	2009-01-10	5	8	22	28	33	42	37	2135659380	5	2025-10-29 07:48:16.881854	2025-10-29 07:48:16.881854
320	2009-01-17	16	19	23	25	41	45	3	5513067900	2	2025-10-29 07:48:17.389833	2025-10-29 07:48:17.389833
321	2009-01-24	12	18	20	21	25	34	42	1959136100	6	2025-10-29 07:48:17.897855	2025-10-29 07:48:17.897855
322	2009-01-31	9	18	29	32	38	43	20	1904544700	6	2025-10-29 07:48:18.406827	2025-10-29 07:48:18.406827
323	2009-02-07	10	14	15	32	36	42	3	1461025388	8	2025-10-29 07:48:18.915296	2025-10-29 07:48:18.915296
324	2009-02-14	2	4	21	25	33	36	17	1865130350	6	2025-10-29 07:48:19.423636	2025-10-29 07:48:19.423636
325	2009-02-21	7	17	20	32	44	45	33	1806122450	6	2025-10-29 07:48:19.934681	2025-10-29 07:48:19.934681
326	2009-02-28	16	23	25	33	36	39	40	1832134550	6	2025-10-29 07:48:20.444337	2025-10-29 07:48:20.444337
327	2009-03-07	6	12	13	17	32	44	24	882674750	12	2025-10-29 07:48:20.953287	2025-10-29 07:48:20.953287
328	2009-03-14	1	6	9	16	17	28	24	1819795900	6	2025-10-29 07:48:21.461315	2025-10-29 07:48:21.461315
329	2009-03-21	9	17	19	30	35	42	4	1830391200	6	2025-10-29 07:48:21.970893	2025-10-29 07:48:21.970893
330	2009-03-28	3	4	16	17	19	20	23	1162280200	9	2025-10-29 07:48:22.483451	2025-10-29 07:48:22.483451
331	2009-04-04	4	9	14	26	31	44	39	2165902620	5	2025-10-29 07:48:22.995153	2025-10-29 07:48:22.995153
332	2009-04-11	16	17	34	36	42	45	3	1359448388	8	2025-10-29 07:48:23.502992	2025-10-29 07:48:23.502992
333	2009-04-18	5	14	27	30	39	43	35	1550987143	7	2025-10-29 07:48:24.011363	2025-10-29 07:48:24.011363
334	2009-04-25	13	15	21	29	39	43	33	1523002972	7	2025-10-29 07:48:24.519974	2025-10-29 07:48:24.519974
335	2009-05-02	5	9	16	23	26	45	21	2037492480	5	2025-10-29 07:48:25.030139	2025-10-29 07:48:25.030139
336	2009-05-09	3	5	20	34	35	44	16	1685632650	6	2025-10-29 07:48:25.545187	2025-10-29 07:48:25.545187
337	2009-05-16	1	5	14	18	32	37	4	1257500513	8	2025-10-29 07:48:26.052878	2025-10-29 07:48:26.052878
338	2009-05-23	2	13	34	38	42	45	16	3383431000	3	2025-10-29 07:48:26.561631	2025-10-29 07:48:26.561631
339	2009-05-30	6	8	14	21	30	37	45	1096778334	9	2025-10-29 07:48:27.071559	2025-10-29 07:48:27.071559
340	2009-06-06	18	24	26	29	34	38	32	1439393186	7	2025-10-29 07:48:27.580617	2025-10-29 07:48:27.580617
341	2009-06-13	1	8	19	34	39	43	41	1497207772	7	2025-10-29 07:48:28.089713	2025-10-29 07:48:28.089713
342	2009-06-20	1	13	14	33	34	43	25	3454095800	3	2025-10-29 07:48:28.600231	2025-10-29 07:48:28.600231
343	2009-06-27	1	10	17	29	31	43	15	1717153000	6	2025-10-29 07:48:29.108995	2025-10-29 07:48:29.108995
344	2009-07-04	1	2	15	28	34	45	38	1467106543	7	2025-10-29 07:48:29.617506	2025-10-29 07:48:29.617506
345	2009-07-11	15	20	23	29	39	42	2	5203577550	2	2025-10-29 07:48:30.129269	2025-10-29 07:48:30.129269
346	2009-07-18	5	13	14	22	44	45	33	2017727340	5	2025-10-29 07:48:30.637661	2025-10-29 07:48:30.637661
347	2009-07-25	3	8	13	27	32	42	10	1456624286	7	2025-10-29 07:48:31.148629	2025-10-29 07:48:31.148629
348	2009-08-01	3	14	17	20	24	31	34	3299994000	3	2025-10-29 07:48:31.65748	2025-10-29 07:48:31.65748
349	2009-08-08	5	13	14	20	24	25	36	3353209000	3	2025-10-29 07:48:32.166624	2025-10-29 07:48:32.166624
350	2009-08-15	1	8	18	24	29	33	35	1101052467	9	2025-10-29 07:48:32.675728	2025-10-29 07:48:32.675728
351	2009-08-22	5	25	27	29	34	36	33	2583357150	4	2025-10-29 07:48:33.184723	2025-10-29 07:48:33.184723
352	2009-08-29	5	16	17	20	26	41	24	1732858250	6	2025-10-29 07:48:33.693474	2025-10-29 07:48:33.693474
353	2009-09-05	11	16	19	22	29	36	26	5290838250	2	2025-10-29 07:48:34.203238	2025-10-29 07:48:34.203238
354	2009-09-12	14	19	36	43	44	45	1	2124464340	5	2025-10-29 07:48:34.71179	2025-10-29 07:48:34.71179
355	2009-09-19	5	8	29	30	35	44	38	2145424800	5	2025-10-29 07:48:35.21985	2025-10-29 07:48:35.21985
356	2009-09-26	2	8	14	25	29	45	24	1157185267	9	2025-10-29 07:48:35.736299	2025-10-29 07:48:35.736299
357	2009-10-03	10	14	18	21	36	37	5	5313394350	2	2025-10-29 07:48:36.2507	2025-10-29 07:48:36.2507
358	2009-10-10	1	9	10	12	21	40	37	3472654900	3	2025-10-29 07:48:36.759492	2025-10-29 07:48:36.759492
359	2009-10-17	1	10	19	20	24	40	23	1286712600	8	2025-10-29 07:48:37.268434	2025-10-29 07:48:37.268434
360	2009-10-24	4	16	23	25	35	40	27	3566716200	3	2025-10-29 07:48:37.77893	2025-10-29 07:48:37.77893
361	2009-10-31	5	10	16	24	27	35	33	1473115115	7	2025-10-29 07:48:38.289005	2025-10-29 07:48:38.289005
362	2009-11-07	2	3	22	27	30	40	29	1729424650	6	2025-10-29 07:48:38.797327	2025-10-29 07:48:38.797327
363	2009-11-14	11	12	14	21	32	38	6	2615910600	4	2025-10-29 07:48:39.306061	2025-10-29 07:48:39.306061
364	2009-11-21	2	5	7	14	16	40	4	2531914800	4	2025-10-29 07:48:39.816554	2025-10-29 07:48:39.816554
365	2009-11-28	5	15	21	25	26	30	31	10697716800	1	2025-10-29 07:48:40.324652	2025-10-29 07:48:40.324652
366	2009-12-05	5	12	19	26	27	44	38	5351553900	2	2025-10-29 07:48:40.833626	2025-10-29 07:48:40.833626
367	2009-12-12	3	22	25	29	32	44	19	1581736586	7	2025-10-29 07:48:41.342509	2025-10-29 07:48:41.342509
368	2009-12-19	11	21	24	30	39	45	26	1465825115	7	2025-10-29 07:48:41.850031	2025-10-29 07:48:41.850031
369	2009-12-26	17	20	35	36	41	43	21	1842177750	6	2025-10-29 07:48:42.358805	2025-10-29 07:48:42.358805
370	2010-01-02	16	18	24	42	44	45	17	1678941943	7	2025-10-29 07:48:42.867457	2025-10-29 07:48:42.867457
371	2010-01-09	7	9	15	26	27	42	18	1524130543	7	2025-10-29 07:48:43.374692	2025-10-29 07:48:43.374692
372	2010-01-16	8	11	14	16	18	21	13	1192593200	9	2025-10-29 07:48:43.883467	2025-10-29 07:48:43.883467
373	2010-01-23	15	26	37	42	43	45	9	2791801125	4	2025-10-29 07:48:44.392756	2025-10-29 07:48:44.392756
374	2010-01-30	11	13	15	17	25	34	26	5528717850	2	2025-10-29 07:48:44.901357	2025-10-29 07:48:44.901357
375	2010-02-06	4	8	19	25	27	45	7	1581284058	7	2025-10-29 07:48:45.409347	2025-10-29 07:48:45.409347
376	2010-02-13	1	11	13	24	28	40	7	1956915800	6	2025-10-29 07:48:45.919713	2025-10-29 07:48:45.919713
377	2010-02-20	6	22	29	37	43	45	23	3912085400	3	2025-10-29 07:48:46.429466	2025-10-29 07:48:46.429466
378	2010-02-27	5	22	29	31	34	39	43	2317698240	5	2025-10-29 07:48:46.937468	2025-10-29 07:48:46.937468
379	2010-03-06	6	10	22	31	35	40	19	1598999786	7	2025-10-29 07:48:47.446643	2025-10-29 07:48:47.446643
380	2010-03-13	1	2	8	17	26	37	27	2684274825	4	2025-10-29 07:48:47.955428	2025-10-29 07:48:47.955428
381	2010-03-20	1	5	10	12	16	20	11	565738895	19	2025-10-29 07:48:48.465661	2025-10-29 07:48:48.465661
382	2010-03-27	10	15	22	24	27	42	19	1846674900	6	2025-10-29 07:48:48.974682	2025-10-29 07:48:48.974682
383	2010-04-03	4	15	28	33	37	40	25	3596522100	3	2025-10-29 07:48:49.484233	2025-10-29 07:48:49.484233
384	2010-04-10	11	22	24	32	36	38	7	3658734200	3	2025-10-29 07:48:49.992387	2025-10-29 07:48:49.992387
385	2010-04-17	7	12	19	21	29	32	9	1542032700	7	2025-10-29 07:48:50.503236	2025-10-29 07:48:50.503236
386	2010-04-24	4	7	10	19	31	40	26	1042953330	10	2025-10-29 07:48:51.013406	2025-10-29 07:48:51.013406
387	2010-05-01	1	26	31	34	40	43	20	2675533500	4	2025-10-29 07:48:51.522145	2025-10-29 07:48:51.522145
388	2010-05-08	1	8	9	17	29	32	45	2545543875	4	2025-10-29 07:48:52.029837	2025-10-29 07:48:52.029837
389	2010-05-15	7	16	18	20	23	26	3	2119027020	5	2025-10-29 07:48:52.53833	2025-10-29 07:48:52.53833
390	2010-05-22	16	17	28	37	39	40	15	10373997900	1	2025-10-29 07:48:53.047609	2025-10-29 07:48:53.047609
391	2010-05-29	10	11	18	22	28	39	30	10508749800	1	2025-10-29 07:48:53.556668	2025-10-29 07:48:53.556668
392	2010-06-05	1	3	7	8	24	42	43	1713528700	6	2025-10-29 07:48:54.065078	2025-10-29 07:48:54.065078
393	2010-06-12	9	16	28	40	41	43	21	1362003975	8	2025-10-29 07:48:54.572892	2025-10-29 07:48:54.572892
394	2010-06-19	1	13	20	22	25	28	15	10654349100	1	2025-10-29 07:48:55.080763	2025-10-29 07:48:55.080763
395	2010-06-26	11	15	20	26	31	35	7	1534635000	7	2025-10-29 07:48:55.5898	2025-10-29 07:48:55.5898
396	2010-07-03	18	20	31	34	40	45	30	5296622400	2	2025-10-29 07:48:56.09774	2025-10-29 07:48:56.09774
397	2010-07-10	12	13	17	22	25	33	8	3499519700	3	2025-10-29 07:48:56.60646	2025-10-29 07:48:56.60646
398	2010-07-17	10	15	20	23	42	44	7	2680625550	4	2025-10-29 07:48:57.114836	2025-10-29 07:48:57.114836
399	2010-07-24	1	2	9	17	19	42	20	1276854975	8	2025-10-29 07:48:57.636743	2025-10-29 07:48:57.636743
400	2010-07-31	9	21	27	34	41	43	2	2669834325	4	2025-10-29 07:48:58.145933	2025-10-29 07:48:58.145933
401	2010-08-07	6	12	18	31	38	43	9	1168214792	9	2025-10-29 07:49:03.69282	2025-10-29 07:49:03.69282
402	2010-08-14	5	9	15	19	22	36	32	2662206188	4	2025-10-29 07:49:04.201613	2025-10-29 07:49:04.201613
403	2010-08-21	10	14	22	24	28	37	26	2122396875	5	2025-10-29 07:49:04.709105	2025-10-29 07:49:04.709105
404	2010-08-28	5	20	21	24	33	40	36	3566659375	3	2025-10-29 07:49:05.217482	2025-10-29 07:49:05.217482
405	2010-09-04	1	2	10	25	26	44	4	3543878000	3	2025-10-29 07:49:05.727654	2025-10-29 07:49:05.727654
406	2010-09-11	7	12	21	24	27	36	45	2156142450	5	2025-10-29 07:49:06.235766	2025-10-29 07:49:06.235766
407	2010-09-18	6	7	13	16	24	25	1	1649707286	7	2025-10-29 07:49:06.744309	2025-10-29 07:49:06.744309
408	2010-09-25	9	20	21	22	30	37	16	2235375825	5	2025-10-29 07:49:07.252014	2025-10-29 07:49:07.252014
409	2010-10-02	6	9	21	31	32	40	38	2896989750	4	2025-10-29 07:49:07.761467	2025-10-29 07:49:07.761467
410	2010-10-09	1	3	18	32	40	41	16	1249335709	9	2025-10-29 07:49:08.269876	2025-10-29 07:49:08.269876
411	2010-10-16	11	14	22	35	37	39	5	953227563	12	2025-10-29 07:49:08.778046	2025-10-29 07:49:08.778046
412	2010-10-23	4	7	39	41	42	45	40	1656199822	7	2025-10-29 07:49:09.285981	2025-10-29 07:49:09.285981
413	2010-10-30	2	9	15	23	34	40	3	2814673500	4	2025-10-29 07:49:09.795073	2025-10-29 07:49:09.795073
414	2010-11-06	2	14	15	22	23	44	43	11703832500	1	2025-10-29 07:49:10.317205	2025-10-29 07:49:10.317205
415	2010-11-13	7	17	20	26	30	40	24	1334182407	8	2025-10-29 07:49:10.828917	2025-10-29 07:49:10.828917
416	2010-11-20	5	6	8	11	22	26	44	1072037100	10	2025-10-29 07:49:11.337215	2025-10-29 07:49:11.337215
417	2010-11-27	4	5	14	20	22	43	44	2818329938	4	2025-10-29 07:49:11.845057	2025-10-29 07:49:11.845057
418	2010-12-04	11	13	15	26	28	34	31	1435649766	8	2025-10-29 07:49:12.353679	2025-10-29 07:49:12.353679
419	2010-12-11	2	11	13	14	28	30	7	3796490750	3	2025-10-29 07:49:12.862976	2025-10-29 07:49:12.862976
420	2010-12-18	4	9	10	29	31	34	27	1424856375	8	2025-10-29 07:49:13.370902	2025-10-29 07:49:13.370902
421	2010-12-25	6	11	26	27	28	44	30	2321144325	5	2025-10-29 07:49:13.87938	2025-10-29 07:49:13.87938
422	2011-01-01	8	15	19	21	34	44	12	2205251375	6	2025-10-29 07:49:14.387463	2025-10-29 07:49:14.387463
423	2011-01-08	1	17	27	28	29	40	5	3896153875	3	2025-10-29 07:49:14.895561	2025-10-29 07:49:14.895561
424	2011-01-15	10	11	26	31	34	44	30	1109480813	10	2025-10-29 07:49:15.403524	2025-10-29 07:49:15.403524
425	2011-01-22	8	10	14	27	33	38	3	1534833000	8	2025-10-29 07:49:15.912777	2025-10-29 07:49:15.912777
426	2011-01-29	4	17	18	27	39	43	19	3057233625	4	2025-10-29 07:49:16.42106	2025-10-29 07:49:16.42106
427	2011-02-05	6	7	15	24	28	30	21	12571445625	1	2025-10-29 07:49:16.929626	2025-10-29 07:49:16.929626
428	2011-02-12	12	16	19	22	37	40	8	1437683209	9	2025-10-29 07:49:17.440183	2025-10-29 07:49:17.440183
429	2011-02-19	3	23	28	34	39	42	16	1485904709	9	2025-10-29 07:49:17.94835	2025-10-29 07:49:17.94835
430	2011-02-26	1	3	16	18	30	34	44	1611763219	8	2025-10-29 07:49:18.457132	2025-10-29 07:49:18.457132
431	2011-03-05	18	22	25	31	38	45	6	1268434013	10	2025-10-29 07:49:18.965224	2025-10-29 07:49:18.965224
432	2011-03-12	2	3	5	11	27	39	33	2299427550	5	2025-10-29 07:49:19.473077	2025-10-29 07:49:19.473077
433	2011-03-19	19	23	29	33	35	43	27	1182294410	11	2025-10-29 07:49:19.981449	2025-10-29 07:49:19.981449
434	2011-03-26	3	13	20	24	33	37	35	1480060266	8	2025-10-29 07:49:20.489128	2025-10-29 07:49:20.489128
435	2011-04-02	8	16	26	30	38	45	42	1287550013	10	2025-10-29 07:49:20.999976	2025-10-29 07:49:20.999976
436	2011-04-09	9	14	20	22	33	34	28	1512266579	8	2025-10-29 07:49:21.507376	2025-10-29 07:49:21.507376
437	2011-04-16	11	16	29	38	41	44	21	2096245438	6	2025-10-29 07:49:22.015188	2025-10-29 07:49:22.015188
438	2011-04-23	6	12	20	26	29	38	45	1377142167	9	2025-10-29 07:49:22.523878	2025-10-29 07:49:22.523878
439	2011-04-30	17	20	30	31	37	40	25	1900077375	6	2025-10-29 07:49:23.031892	2025-10-29 07:49:23.031892
440	2011-05-07	10	22	28	34	36	44	2	1995873000	6	2025-10-29 07:49:23.540083	2025-10-29 07:49:23.540083
441	2011-05-14	1	23	28	30	34	35	9	3170417063	4	2025-10-29 07:49:24.048293	2025-10-29 07:49:24.048293
442	2011-05-21	25	27	29	36	38	40	41	1413413042	9	2025-10-29 07:49:24.556834	2025-10-29 07:49:24.556834
443	2011-05-28	4	6	10	19	20	44	14	1327597584	9	2025-10-29 07:49:25.065366	2025-10-29 07:49:25.065366
444	2011-06-04	11	13	23	35	43	45	17	4154188625	3	2025-10-29 07:49:25.572986	2025-10-29 07:49:25.572986
445	2011-06-11	13	20	21	30	39	45	32	1791683036	7	2025-10-29 07:49:26.080848	2025-10-29 07:49:26.080848
446	2011-06-18	1	11	12	14	26	35	6	4051247625	3	2025-10-29 07:49:26.589324	2025-10-29 07:49:26.589324
447	2011-06-25	2	7	8	9	17	33	34	2657941125	4	2025-10-29 07:49:27.097113	2025-10-29 07:49:27.097113
448	2011-07-02	3	7	13	27	40	41	36	4026212750	3	2025-10-29 07:49:27.604549	2025-10-29 07:49:27.604549
449	2011-07-09	3	10	20	26	35	43	36	4059715250	3	2025-10-29 07:49:28.11301	2025-10-29 07:49:28.11301
450	2011-07-16	6	14	19	21	23	31	13	1990391625	6	2025-10-29 07:49:28.624185	2025-10-29 07:49:28.624185
451	2011-07-23	12	15	20	24	30	38	29	882138952	13	2025-10-29 07:49:29.132445	2025-10-29 07:49:29.132445
452	2011-07-30	8	10	18	30	32	34	27	1276902000	9	2025-10-29 07:49:29.640118	2025-10-29 07:49:29.640118
453	2011-08-06	12	24	33	38	40	42	30	2262732375	5	2025-10-29 07:49:30.177813	2025-10-29 07:49:30.177813
454	2011-08-13	13	25	27	34	38	41	10	1609125590	7	2025-10-29 07:49:30.687458	2025-10-29 07:49:30.687458
455	2011-08-20	4	19	20	26	30	35	24	1635711483	7	2025-10-29 07:49:31.195485	2025-10-29 07:49:31.195485
456	2011-08-27	1	7	12	18	23	27	44	1598505054	7	2025-10-29 07:49:31.705975	2025-10-29 07:49:31.705975
457	2011-09-03	8	10	18	23	27	40	33	1159902825	10	2025-10-29 07:49:32.214474	2025-10-29 07:49:32.214474
458	2011-09-10	4	9	10	32	36	40	18	1608812625	8	2025-10-29 07:49:32.723607	2025-10-29 07:49:32.723607
459	2011-09-17	4	6	10	14	25	40	12	1655842233	7	2025-10-29 07:49:33.232673	2025-10-29 07:49:33.232673
460	2011-09-24	8	11	28	30	43	45	41	3180895782	4	2025-10-29 07:49:33.741116	2025-10-29 07:49:33.741116
461	2011-10-01	11	18	26	31	37	40	43	1948674875	6	2025-10-29 07:49:34.248628	2025-10-29 07:49:34.248628
462	2011-10-08	3	20	24	32	37	45	4	1483559297	8	2025-10-29 07:49:34.758104	2025-10-29 07:49:34.758104
463	2011-10-15	23	29	31	33	34	44	40	\N	\N	2025-10-29 07:49:35.266173	2025-10-29 07:49:35.266173
464	2011-10-22	6	12	15	34	42	44	4	3355721106	13	2025-10-29 07:49:35.774088	2025-10-29 07:49:35.774088
465	2011-10-29	1	8	11	13	22	38	31	1923662893	7	2025-10-29 07:49:36.282312	2025-10-29 07:49:36.282312
466	2011-11-05	4	10	13	23	32	44	20	1530313459	9	2025-10-29 07:49:36.790635	2025-10-29 07:49:36.790635
467	2011-11-12	2	12	14	17	24	40	39	1435441084	9	2025-10-29 07:49:37.298539	2025-10-29 07:49:37.298539
468	2011-11-19	8	13	15	28	37	43	17	1527197167	9	2025-10-29 07:49:37.808314	2025-10-29 07:49:37.808314
469	2011-11-26	4	21	22	34	37	38	33	3330131250	4	2025-10-29 07:49:38.317461	2025-10-29 07:49:38.317461
470	2011-12-03	10	16	20	39	41	42	27	4333330625	3	2025-10-29 07:49:38.826178	2025-10-29 07:49:38.826178
471	2011-12-10	6	13	29	37	39	41	43	1939332858	7	2025-10-29 07:49:39.334636	2025-10-29 07:49:39.334636
472	2011-12-17	16	25	26	31	36	43	44	1809656090	7	2025-10-29 07:49:39.842713	2025-10-29 07:49:39.842713
473	2011-12-24	8	13	20	22	23	36	34	3250418063	4	2025-10-29 07:49:40.352375	2025-10-29 07:49:40.352375
474	2011-12-31	4	13	18	31	33	45	43	936690800	15	2025-10-29 07:49:40.860475	2025-10-29 07:49:40.860475
475	2012-01-07	1	9	14	16	21	29	3	1693923047	8	2025-10-29 07:49:41.371505	2025-10-29 07:49:41.371505
476	2012-01-14	9	12	13	15	37	38	27	3439851469	4	2025-10-29 07:49:41.880138	2025-10-29 07:49:41.880138
477	2012-01-21	14	25	29	32	33	45	37	1919011829	8	2025-10-29 07:49:42.388287	2025-10-29 07:49:42.388287
478	2012-01-28	18	29	30	37	39	43	8	987224759	14	2025-10-29 07:49:42.896406	2025-10-29 07:49:42.896406
479	2012-02-04	8	23	25	27	35	44	24	2233046500	6	2025-10-29 07:49:43.40411	2025-10-29 07:49:43.40411
480	2012-02-11	3	5	10	17	30	31	16	2996742282	4	2025-10-29 07:49:43.911482	2025-10-29 07:49:43.911482
481	2012-02-18	3	4	23	29	40	41	20	4639355750	3	2025-10-29 07:49:44.419574	2025-10-29 07:49:44.419574
482	2012-02-25	1	10	16	24	25	35	43	1897921179	7	2025-10-29 07:49:44.927452	2025-10-29 07:49:44.927452
483	2012-03-03	12	15	19	22	28	34	5	2567196675	5	2025-10-29 07:49:45.43593	2025-10-29 07:49:45.43593
484	2012-03-10	1	3	27	28	32	45	11	2305303063	6	2025-10-29 07:49:45.944718	2025-10-29 07:49:45.944718
485	2012-03-17	17	22	26	27	36	39	20	1501474917	9	2025-10-29 07:49:46.458753	2025-10-29 07:49:46.458753
486	2012-03-24	1	2	23	25	38	40	43	1008634125	13	2025-10-29 07:49:46.967216	2025-10-29 07:49:46.967216
487	2012-03-31	4	8	25	27	37	41	21	1638830766	8	2025-10-29 07:49:47.474862	2025-10-29 07:49:47.474862
488	2012-04-07	2	8	17	30	31	38	25	1330393575	10	2025-10-29 07:49:47.983461	2025-10-29 07:49:47.983461
489	2012-04-14	2	4	8	15	20	27	11	2106360625	6	2025-10-29 07:49:48.492683	2025-10-29 07:49:48.492683
490	2012-04-21	2	7	26	29	40	43	42	1860234161	7	2025-10-29 07:49:49.001567	2025-10-29 07:49:49.001567
491	2012-04-28	8	17	35	36	39	42	4	3304634438	4	2025-10-29 07:49:49.510953	2025-10-29 07:49:49.510953
492	2012-05-05	22	27	31	35	37	40	42	2493013800	5	2025-10-29 07:49:50.022967	2025-10-29 07:49:50.022967
493	2012-05-12	20	22	26	33	36	37	25	1451120334	9	2025-10-29 07:49:50.530786	2025-10-29 07:49:50.530786
494	2012-05-19	5	7	8	15	30	43	22	1054588407	12	2025-10-29 07:49:51.039989	2025-10-29 07:49:51.039989
495	2012-05-26	4	13	22	27	34	44	6	2111645000	6	2025-10-29 07:49:51.550297	2025-10-29 07:49:51.550297
496	2012-06-02	4	13	20	29	36	41	39	3285932250	4	2025-10-29 07:49:52.058193	2025-10-29 07:49:52.058193
497	2012-06-09	19	20	23	24	43	44	13	2222817813	6	2025-10-29 07:49:52.566283	2025-10-29 07:49:52.566283
498	2012-06-16	13	14	24	32	39	41	3	3244503094	4	2025-10-29 07:49:53.075791	2025-10-29 07:49:53.075791
499	2012-06-23	5	20	23	27	35	40	43	4070480250	3	2025-10-29 07:49:53.589367	2025-10-29 07:49:53.589367
500	2012-06-30	3	4	12	20	24	34	41	1351072375	9	2025-10-29 07:49:54.097725	2025-10-29 07:49:54.097725
501	2012-07-07	1	4	10	17	31	42	2	3025200094	4	2025-10-29 07:50:00.666785	2025-10-29 07:50:00.666785
502	2012-07-14	6	22	28	32	34	40	26	2201458125	6	2025-10-29 07:50:01.176438	2025-10-29 07:50:01.176438
503	2012-07-21	1	5	27	30	34	36	40	1853634911	7	2025-10-29 07:50:01.685863	2025-10-29 07:50:01.685863
504	2012-07-28	6	14	22	26	43	44	31	1443236959	9	2025-10-29 07:50:02.194718	2025-10-29 07:50:02.194718
505	2012-08-04	7	20	22	25	38	40	44	1917955188	6	2025-10-29 07:50:02.702914	2025-10-29 07:50:02.702914
506	2012-08-11	6	9	11	22	24	30	31	4073333875	3	2025-10-29 07:50:03.210637	2025-10-29 07:50:03.210637
507	2012-08-18	12	13	32	33	40	41	4	1416438875	9	2025-10-29 07:50:03.718668	2025-10-29 07:50:03.718668
508	2012-08-25	5	27	31	34	35	43	37	1599557860	8	2025-10-29 07:50:04.227502	2025-10-29 07:50:04.227502
509	2012-09-01	12	25	29	35	42	43	24	2689076100	5	2025-10-29 07:50:04.735589	2025-10-29 07:50:04.735589
510	2012-09-08	12	29	32	33	39	40	42	2644158150	5	2025-10-29 07:50:05.243978	2025-10-29 07:50:05.243978
511	2012-09-15	3	7	14	23	26	42	24	2165579250	6	2025-10-29 07:50:05.752892	2025-10-29 07:50:05.752892
512	2012-09-22	4	5	9	13	26	27	1	940094452	13	2025-10-29 07:50:06.261949	2025-10-29 07:50:06.261949
513	2012-09-29	5	8	21	23	27	33	12	4589624750	3	2025-10-29 07:50:06.769394	2025-10-29 07:50:06.769394
514	2012-10-06	1	15	20	26	35	42	9	4451055500	3	2025-10-29 07:50:07.277325	2025-10-29 07:50:07.277325
515	2012-10-13	2	11	12	15	23	37	8	13200466875	1	2025-10-29 07:50:07.788032	2025-10-29 07:50:07.788032
516	2012-10-20	2	8	23	41	43	44	30	1294190182	11	2025-10-29 07:50:08.296091	2025-10-29 07:50:08.296091
517	2012-10-27	1	9	12	28	36	41	10	2659057725	5	2025-10-29 07:50:08.804341	2025-10-29 07:50:08.804341
518	2012-11-03	14	23	30	32	34	38	6	2263804125	6	2025-10-29 07:50:09.313033	2025-10-29 07:50:09.313033
519	2012-11-10	6	8	13	16	30	43	3	1950601393	7	2025-10-29 07:50:09.821968	2025-10-29 07:50:09.821968
520	2012-11-17	4	22	27	28	38	40	1	2167205438	6	2025-10-29 07:50:10.330235	2025-10-29 07:50:10.330235
521	2012-11-24	3	7	18	29	32	36	19	1693420922	8	2025-10-29 07:50:10.837846	2025-10-29 07:50:10.837846
522	2012-12-01	4	5	13	14	37	41	11	2281623000	6	2025-10-29 07:50:11.348574	2025-10-29 07:50:11.348574
523	2012-12-08	1	4	37	38	40	45	7	1780355840	7	2025-10-29 07:50:11.855797	2025-10-29 07:50:11.855797
524	2012-12-15	10	11	29	38	41	45	21	3491695594	4	2025-10-29 07:50:12.364438	2025-10-29 07:50:12.364438
525	2012-12-22	11	23	26	29	39	44	22	1501132375	9	2025-10-29 07:50:12.872541	2025-10-29 07:50:12.872541
526	2012-12-29	7	14	17	20	35	39	31	1491031959	9	2025-10-29 07:50:13.380183	2025-10-29 07:50:13.380183
527	2013-01-05	1	12	22	32	33	42	38	1032386366	13	2025-10-29 07:50:13.888832	2025-10-29 07:50:13.888832
528	2013-01-12	5	17	25	31	39	40	10	1197889125	11	2025-10-29 07:50:14.39799	2025-10-29 07:50:14.39799
529	2013-01-19	18	20	24	27	31	42	39	1749114797	8	2025-10-29 07:50:14.906259	2025-10-29 07:50:14.906259
530	2013-01-26	16	23	27	29	33	41	22	1231656239	11	2025-10-29 07:50:15.413896	2025-10-29 07:50:15.413896
531	2013-02-02	1	5	9	21	27	35	45	1521519750	9	2025-10-29 07:50:15.923102	2025-10-29 07:50:15.923102
532	2013-02-09	16	17	23	24	29	44	3	2216896286	7	2025-10-29 07:50:16.431049	2025-10-29 07:50:16.431049
533	2013-02-16	9	14	15	17	31	33	23	1785671579	8	2025-10-29 07:50:16.939217	2025-10-29 07:50:16.939217
534	2013-02-23	10	24	26	29	37	38	32	14215763250	1	2025-10-29 07:50:17.447772	2025-10-29 07:50:17.447772
535	2013-03-02	11	12	14	15	18	39	34	4935603000	3	2025-10-29 07:50:17.958474	2025-10-29 07:50:17.958474
536	2013-03-09	7	8	18	32	37	43	12	1308523603	11	2025-10-29 07:50:18.46635	2025-10-29 07:50:18.46635
537	2013-03-16	12	23	26	30	36	43	11	2104038911	7	2025-10-29 07:50:18.975175	2025-10-29 07:50:18.975175
538	2013-03-23	6	10	18	31	32	34	11	4688021625	3	2025-10-29 07:50:19.482585	2025-10-29 07:50:19.482585
539	2013-03-30	3	19	22	31	42	43	26	1621036667	9	2025-10-29 07:50:19.991897	2025-10-29 07:50:19.991897
540	2013-04-06	3	12	13	15	34	36	14	1989365250	7	2025-10-29 07:50:20.500164	2025-10-29 07:50:20.500164
541	2013-04-13	8	13	26	28	32	34	43	1269327171	11	2025-10-29 07:50:21.009099	2025-10-29 07:50:21.009099
542	2013-04-20	5	6	19	26	41	45	34	2335152563	6	2025-10-29 07:50:21.516687	2025-10-29 07:50:21.516687
543	2013-04-27	13	18	26	31	34	44	12	1112934844	12	2025-10-29 07:50:22.024478	2025-10-29 07:50:22.024478
544	2013-05-04	5	17	21	25	36	44	10	1046388433	13	2025-10-29 07:50:22.534082	2025-10-29 07:50:22.534082
545	2013-05-11	4	24	25	27	34	35	2	1198994353	11	2025-10-29 07:50:23.04302	2025-10-29 07:50:23.04302
546	2013-05-18	8	17	20	27	37	43	6	405939950	30	2025-10-29 07:50:23.550653	2025-10-29 07:50:23.550653
547	2013-05-25	6	7	15	22	34	39	28	2838444450	5	2025-10-29 07:50:24.058695	2025-10-29 07:50:24.058695
548	2013-06-01	1	12	13	21	32	45	14	1736871891	8	2025-10-29 07:50:24.56786	2025-10-29 07:50:24.56786
549	2013-06-08	29	31	35	38	40	44	17	1760805047	8	2025-10-29 07:50:25.076522	2025-10-29 07:50:25.076522
550	2013-06-15	1	7	14	20	34	37	41	1118679205	11	2025-10-29 07:50:25.583732	2025-10-29 07:50:25.583732
551	2013-06-22	3	6	20	24	27	44	25	13526973750	1	2025-10-29 07:50:26.091546	2025-10-29 07:50:26.091546
552	2013-06-29	1	10	20	32	35	40	43	1330824225	10	2025-10-29 07:50:26.600488	2025-10-29 07:50:26.600488
553	2013-07-06	2	7	17	28	29	39	37	2249631438	6	2025-10-29 07:50:27.108359	2025-10-29 07:50:27.108359
554	2013-07-13	13	14	17	32	41	42	6	6813893625	2	2025-10-29 07:50:27.616268	2025-10-29 07:50:27.616268
555	2013-07-20	11	17	21	24	26	36	12	1711027360	8	2025-10-29 07:50:28.126562	2025-10-29 07:50:28.126562
556	2013-07-27	12	20	23	28	30	44	43	2005209161	7	2025-10-29 07:50:28.63446	2025-10-29 07:50:28.63446
557	2013-08-03	4	20	26	28	35	40	31	1888069286	7	2025-10-29 07:50:29.143903	2025-10-29 07:50:29.143903
558	2013-08-10	12	15	19	26	40	43	29	1315913663	10	2025-10-29 07:50:29.652083	2025-10-29 07:50:29.652083
559	2013-08-17	11	12	25	32	44	45	23	1926145608	7	2025-10-29 07:50:30.160597	2025-10-29 07:50:30.160597
560	2013-08-24	1	4	20	23	29	45	28	1976697215	7	2025-10-29 07:50:30.668135	2025-10-29 07:50:30.668135
561	2013-08-31	5	7	18	37	42	45	20	2753712225	5	2025-10-29 07:50:31.176296	2025-10-29 07:50:31.176296
562	2013-09-07	4	11	13	17	20	31	33	1166694614	11	2025-10-29 07:50:31.685636	2025-10-29 07:50:31.685636
563	2013-09-14	5	10	16	17	31	32	21	1932735643	7	2025-10-29 07:50:32.195015	2025-10-29 07:50:32.195015
564	2013-09-21	14	19	25	26	27	34	2	1934801143	7	2025-10-29 07:50:32.702915	2025-10-29 07:50:32.702915
565	2013-09-28	4	10	18	27	40	45	38	1742064469	8	2025-10-29 07:50:33.212811	2025-10-29 07:50:33.212811
566	2013-10-05	4	5	6	25	26	43	41	3508951032	4	2025-10-29 07:50:33.721345	2025-10-29 07:50:33.721345
567	2013-10-12	1	10	15	16	32	41	28	2318659438	6	2025-10-29 07:50:34.229931	2025-10-29 07:50:34.229931
568	2013-10-19	1	3	17	20	31	44	40	1305167550	10	2025-10-29 07:50:34.738256	2025-10-29 07:50:34.738256
569	2013-10-26	3	6	13	23	24	35	1	3467925188	4	2025-10-29 07:50:35.246146	2025-10-29 07:50:35.246146
570	2013-11-02	1	12	26	27	29	33	42	1527791625	9	2025-10-29 07:50:35.754214	2025-10-29 07:50:35.754214
571	2013-11-09	11	18	21	26	38	43	29	1966538465	7	2025-10-29 07:50:36.261879	2025-10-29 07:50:36.261879
572	2013-11-16	3	13	18	33	37	45	1	1668216188	8	2025-10-29 07:50:36.770647	2025-10-29 07:50:36.770647
573	2013-11-23	2	4	20	34	35	43	14	1645691766	8	2025-10-29 07:50:37.280212	2025-10-29 07:50:37.280212
574	2013-11-30	14	15	16	19	25	43	2	6965184938	2	2025-10-29 07:50:37.788497	2025-10-29 07:50:37.788497
575	2013-12-07	2	8	20	30	33	34	6	1699267875	8	2025-10-29 07:50:38.297265	2025-10-29 07:50:38.297265
576	2013-12-14	10	11	15	25	35	41	13	4321966000	3	2025-10-29 07:50:38.805312	2025-10-29 07:50:38.805312
577	2013-12-21	16	17	22	31	34	37	33	4484438375	3	2025-10-29 07:50:39.313305	2025-10-29 07:50:39.313305
578	2013-12-28	5	12	14	32	34	42	16	2796466575	5	2025-10-29 07:50:39.821056	2025-10-29 07:50:39.821056
579	2014-01-04	5	7	20	22	37	42	39	1396068444	11	2025-10-29 07:50:40.328981	2025-10-29 07:50:40.328981
580	2014-01-11	5	7	9	11	32	35	33	2028610500	7	2025-10-29 07:50:40.836868	2025-10-29 07:50:40.836868
581	2014-01-18	3	5	14	20	42	44	33	1844554547	8	2025-10-29 07:50:41.345134	2025-10-29 07:50:41.345134
582	2014-01-25	2	12	14	33	40	41	25	3560558719	4	2025-10-29 07:50:41.852924	2025-10-29 07:50:41.852924
583	2014-02-01	8	17	27	33	40	44	24	1341848353	11	2025-10-29 07:50:42.360901	2025-10-29 07:50:42.360901
584	2014-02-08	7	18	30	39	40	41	36	5033183250	3	2025-10-29 07:50:42.868999	2025-10-29 07:50:42.868999
585	2014-02-15	6	7	10	16	38	41	4	1620546334	9	2025-10-29 07:50:43.376857	2025-10-29 07:50:43.376857
586	2014-02-22	2	7	12	15	21	34	5	1778354344	8	2025-10-29 07:50:43.885531	2025-10-29 07:50:43.885531
587	2014-03-01	14	21	29	31	32	37	17	4974577375	3	2025-10-29 07:50:44.394475	2025-10-29 07:50:44.394475
588	2014-03-08	2	8	15	22	25	41	30	2889342075	5	2025-10-29 07:50:44.902656	2025-10-29 07:50:44.902656
589	2014-03-15	6	8	28	33	38	39	22	2136877983	7	2025-10-29 07:50:45.411658	2025-10-29 07:50:45.411658
590	2014-03-22	20	30	36	38	41	45	23	2185183983	7	2025-10-29 07:50:45.920294	2025-10-29 07:50:45.920294
591	2014-03-29	8	13	14	30	38	39	5	2964676200	5	2025-10-29 07:50:46.42858	2025-10-29 07:50:46.42858
592	2014-04-05	2	5	6	13	28	44	43	2356381688	6	2025-10-29 07:50:46.936902	2025-10-29 07:50:46.936902
593	2014-04-12	9	10	13	24	33	38	28	1532833500	9	2025-10-29 07:50:47.445317	2025-10-29 07:50:47.445317
594	2014-04-19	2	8	13	25	28	37	3	1255592796	11	2025-10-29 07:50:47.952845	2025-10-29 07:50:47.952845
595	2014-04-26	8	24	28	35	38	40	5	1744525219	8	2025-10-29 07:50:48.461687	2025-10-29 07:50:48.461687
596	2014-05-03	3	4	12	14	25	43	17	1328267663	10	2025-10-29 07:50:48.970928	2025-10-29 07:50:48.970928
597	2014-05-10	8	10	23	24	35	43	37	1057920606	13	2025-10-29 07:50:49.478353	2025-10-29 07:50:49.478353
598	2014-05-17	4	12	24	33	38	45	22	833998594	16	2025-10-29 07:50:49.988887	2025-10-29 07:50:49.988887
599	2014-05-24	5	12	17	29	34	35	27	1710918329	8	2025-10-29 07:50:50.497126	2025-10-29 07:50:50.497126
600	2014-05-31	5	11	14	27	29	36	44	901798725	15	2025-10-29 07:50:51.005246	2025-10-29 07:50:51.005246
601	2014-06-07	2	16	19	31	34	35	37	1524565209	9	2025-10-29 07:50:57.562401	2025-10-29 07:50:57.562401
602	2014-06-14	13	14	22	27	30	38	2	1689530860	8	2025-10-29 07:50:58.070907	2025-10-29 07:50:58.070907
603	2014-06-21	2	19	25	26	27	43	28	3452136563	4	2025-10-29 07:50:58.579179	2025-10-29 07:50:58.579179
604	2014-06-28	2	6	18	21	33	34	30	1229141557	11	2025-10-29 07:50:59.087348	2025-10-29 07:50:59.087348
605	2014-07-05	1	2	7	9	10	38	42	1394232250	9	2025-10-29 07:50:59.620581	2025-10-29 07:50:59.620581
606	2014-07-12	1	5	6	14	20	39	22	1311566850	10	2025-10-29 07:51:00.129613	2025-10-29 07:51:00.129613
607	2014-07-19	8	14	23	36	38	39	13	3494480907	4	2025-10-29 07:51:00.637122	2025-10-29 07:51:00.637122
608	2014-07-26	4	8	18	19	39	44	41	1943530018	7	2025-10-29 07:51:01.144991	2025-10-29 07:51:01.144991
609	2014-08-02	4	8	27	34	39	40	13	6339311438	2	2025-10-29 07:51:01.653247	2025-10-29 07:51:01.653247
610	2014-08-09	14	18	20	23	28	36	33	3516018375	4	2025-10-29 07:51:02.161412	2025-10-29 07:51:02.161412
611	2014-08-16	2	22	27	33	36	37	14	3502706157	4	2025-10-29 07:51:02.668955	2025-10-29 07:51:02.668955
612	2014-08-23	6	9	18	19	25	33	40	1181705250	11	2025-10-29 07:51:03.176728	2025-10-29 07:51:03.176728
613	2014-08-30	7	8	11	16	41	44	35	1549831209	9	2025-10-29 07:51:03.686098	2025-10-29 07:51:03.686098
614	2014-09-06	8	21	25	39	40	44	18	2540975438	6	2025-10-29 07:51:04.194337	2025-10-29 07:51:04.194337
615	2014-09-13	10	17	18	19	23	27	35	1535062417	9	2025-10-29 07:51:04.716481	2025-10-29 07:51:04.716481
616	2014-09-20	5	13	18	23	40	45	3	1611811250	9	2025-10-29 07:51:05.22472	2025-10-29 07:51:05.22472
617	2014-09-27	4	5	11	12	24	27	28	1629701860	8	2025-10-29 07:51:05.734915	2025-10-29 07:51:05.734915
618	2014-10-04	8	16	25	30	42	43	15	2881326225	5	2025-10-29 07:51:06.24547	2025-10-29 07:51:06.24547
619	2014-10-11	6	8	13	30	35	40	21	4612479375	3	2025-10-29 07:51:06.753705	2025-10-29 07:51:06.753705
620	2014-10-18	2	16	17	32	39	45	40	2028283233	7	2025-10-29 07:51:07.26265	2025-10-29 07:51:07.26265
621	2014-10-25	1	2	6	16	19	42	9	2359723500	6	2025-10-29 07:51:07.771672	2025-10-29 07:51:07.771672
622	2014-11-01	9	15	16	21	28	34	24	1630598292	9	2025-10-29 07:51:08.28013	2025-10-29 07:51:08.28013
623	2014-11-08	7	13	30	39	41	45	25	1813702594	8	2025-10-29 07:51:08.788165	2025-10-29 07:51:08.788165
624	2014-11-15	1	7	19	26	27	35	16	2763729450	5	2025-10-29 07:51:09.295801	2025-10-29 07:51:09.295801
625	2014-11-22	3	6	7	20	21	39	13	2765184675	5	2025-10-29 07:51:09.804767	2025-10-29 07:51:09.804767
626	2014-11-29	13	14	26	33	40	43	15	1717871110	8	2025-10-29 07:51:10.314982	2025-10-29 07:51:10.314982
627	2014-12-06	2	9	22	25	31	45	12	1352230650	10	2025-10-29 07:51:10.824389	2025-10-29 07:51:10.824389
628	2014-12-13	1	7	12	15	23	42	11	1499942875	9	2025-10-29 07:51:11.332716	2025-10-29 07:51:11.332716
629	2014-12-20	19	28	31	38	43	44	1	2919433575	5	2025-10-29 07:51:11.843274	2025-10-29 07:51:11.843274
630	2014-12-27	8	17	21	24	27	31	15	4836305500	3	2025-10-29 07:51:12.350719	2025-10-29 07:51:12.350719
631	2015-01-03	1	2	4	23	31	34	8	3919853532	4	2025-10-29 07:51:12.858773	2025-10-29 07:51:12.858773
632	2015-01-10	15	18	21	32	35	44	6	1432587716	11	2025-10-29 07:51:13.368996	2025-10-29 07:51:13.368996
633	2015-01-17	9	12	19	20	39	41	13	1217257094	12	2025-10-29 07:51:13.877454	2025-10-29 07:51:13.877454
634	2015-01-24	4	10	11	12	20	27	38	1077935106	13	2025-10-29 07:51:14.3858	2025-10-29 07:51:14.3858
635	2015-01-31	11	13	25	26	29	33	32	1855587235	8	2025-10-29 07:51:14.893871	2025-10-29 07:51:14.893871
636	2015-02-07	6	7	15	16	20	31	26	1832362219	8	2025-10-29 07:51:15.40134	2025-10-29 07:51:15.40134
637	2015-02-14	3	16	22	37	38	44	23	3899241094	4	2025-10-29 07:51:15.909212	2025-10-29 07:51:15.909212
638	2015-02-21	7	18	22	24	31	34	6	2229403179	7	2025-10-29 07:51:16.417549	2025-10-29 07:51:16.417549
639	2015-02-28	6	15	22	23	25	32	40	4061185219	4	2025-10-29 07:51:16.927323	2025-10-29 07:51:16.927323
640	2015-03-07	14	15	18	21	26	35	23	1728768834	9	2025-10-29 07:51:17.435	2025-10-29 07:51:17.435
641	2015-03-14	11	18	21	36	37	43	12	1990074563	8	2025-10-29 07:51:17.943263	2025-10-29 07:51:17.943263
642	2015-03-21	8	17	18	24	39	45	32	1251460438	12	2025-10-29 07:51:18.452097	2025-10-29 07:51:18.452097
643	2015-03-28	15	24	31	32	33	40	13	2535763625	6	2025-10-29 07:51:18.960261	2025-10-29 07:51:18.960261
644	2015-04-04	5	13	17	23	28	36	8	1831451204	8	2025-10-29 07:51:19.467794	2025-10-29 07:51:19.467794
645	2015-04-11	1	4	16	26	40	41	31	3696297750	4	2025-10-29 07:51:19.976578	2025-10-29 07:51:19.976578
646	2015-04-18	2	9	24	41	43	45	30	2215498393	7	2025-10-29 07:51:20.485371	2025-10-29 07:51:20.485371
647	2015-04-25	5	16	21	23	24	30	29	2189725608	7	2025-10-29 07:51:20.993141	2025-10-29 07:51:20.993141
648	2015-05-02	13	19	28	37	38	43	4	2120987947	7	2025-10-29 07:51:21.500888	2025-10-29 07:51:21.500888
649	2015-05-09	3	21	22	33	41	42	20	2948042100	5	2025-10-29 07:51:22.009792	2025-10-29 07:51:22.009792
650	2015-05-16	3	4	7	11	31	41	35	2849298900	5	2025-10-29 07:51:22.51888	2025-10-29 07:51:22.51888
651	2015-05-23	11	12	16	26	29	44	18	1855306454	8	2025-10-29 07:51:23.026788	2025-10-29 07:51:23.026788
652	2015-05-30	3	13	15	40	41	44	20	3003483525	5	2025-10-29 07:51:23.534054	2025-10-29 07:51:23.534054
653	2015-06-06	5	6	26	27	38	39	1	980958670	14	2025-10-29 07:51:24.042039	2025-10-29 07:51:24.042039
654	2015-06-13	16	21	26	31	36	43	6	1879301391	8	2025-10-29 07:51:24.552312	2025-10-29 07:51:24.552312
655	2015-06-20	7	37	38	39	40	44	18	1661439625	9	2025-10-29 07:51:25.060009	2025-10-29 07:51:25.060009
656	2015-06-27	3	7	14	16	31	40	39	7330002750	2	2025-10-29 07:51:25.567905	2025-10-29 07:51:25.567905
657	2015-07-04	10	14	19	39	40	43	23	1694762792	9	2025-10-29 07:51:26.076028	2025-10-29 07:51:26.076028
658	2015-07-11	8	19	25	28	32	36	37	1634031375	9	2025-10-29 07:51:26.583904	2025-10-29 07:51:26.583904
659	2015-07-18	7	18	19	27	29	42	45	1336604216	11	2025-10-29 07:51:27.09209	2025-10-29 07:51:27.09209
660	2015-07-25	4	9	23	33	39	44	14	1421272575	10	2025-10-29 07:51:27.59965	2025-10-29 07:51:27.59965
661	2015-08-01	2	3	12	20	27	38	40	1713025547	8	2025-10-29 07:51:28.10819	2025-10-29 07:51:28.10819
662	2015-08-08	5	6	9	11	15	37	26	1689733688	8	2025-10-29 07:51:28.619008	2025-10-29 07:51:28.619008
663	2015-08-15	3	5	8	19	38	42	20	2080244143	7	2025-10-29 07:51:29.129061	2025-10-29 07:51:29.129061
664	2015-08-22	10	20	33	36	41	44	5	1536801338	10	2025-10-29 07:51:29.636961	2025-10-29 07:51:29.636961
665	2015-08-29	5	6	11	17	38	44	13	3643230375	4	2025-10-29 07:51:30.148431	2025-10-29 07:51:30.148431
666	2015-09-05	2	4	6	11	17	28	16	2396901063	6	2025-10-29 07:51:30.654431	2025-10-29 07:51:30.654431
667	2015-09-12	15	17	25	37	42	43	13	2228764393	7	2025-10-29 07:51:31.161865	2025-10-29 07:51:31.161865
668	2015-09-19	12	14	15	24	27	32	3	2991158625	5	2025-10-29 07:51:31.668851	2025-10-29 07:51:31.668851
669	2015-09-26	7	8	20	29	33	38	9	2708173188	6	2025-10-29 07:51:32.177103	2025-10-29 07:51:32.177103
670	2015-10-03	11	18	26	27	40	41	25	1191725219	12	2025-10-29 07:51:32.685245	2025-10-29 07:51:32.685245
671	2015-10-10	7	9	10	13	31	35	24	3722322844	4	2025-10-29 07:51:33.192934	2025-10-29 07:51:33.192934
672	2015-10-17	8	21	28	31	36	45	43	1754745000	9	2025-10-29 07:51:33.700929	2025-10-29 07:51:33.700929
673	2015-10-24	7	10	17	29	33	44	5	1491453300	10	2025-10-29 07:51:34.208824	2025-10-29 07:51:34.208824
674	2015-10-31	9	10	14	25	27	31	11	1770565500	8	2025-10-29 07:51:34.717683	2025-10-29 07:51:34.717683
675	2015-11-07	1	8	11	15	18	45	7	3514549032	4	2025-10-29 07:51:35.225473	2025-10-29 07:51:35.225473
676	2015-11-14	1	8	17	34	39	45	27	1879726500	8	2025-10-29 07:51:35.733801	2025-10-29 07:51:35.733801
677	2015-11-21	12	15	24	36	41	44	42	1921114407	8	2025-10-29 07:51:36.241546	2025-10-29 07:51:36.241546
678	2015-11-28	4	5	6	12	25	37	45	2288490188	6	2025-10-29 07:51:36.748995	2025-10-29 07:51:36.748995
679	2015-12-05	3	5	7	14	26	34	35	2863005600	5	2025-10-29 07:51:37.257272	2025-10-29 07:51:37.257272
680	2015-12-12	4	10	19	29	32	42	30	1110570563	14	2025-10-29 07:51:37.765214	2025-10-29 07:51:37.765214
681	2015-12-19	21	24	27	29	43	44	7	2696328938	6	2025-10-29 07:51:38.275723	2025-10-29 07:51:38.275723
682	2015-12-26	17	23	27	35	38	43	2	4063713563	4	2025-10-29 07:51:38.785329	2025-10-29 07:51:38.785329
683	2016-01-02	6	13	20	27	28	40	15	1010930883	16	2025-10-29 07:51:39.293538	2025-10-29 07:51:39.293538
684	2016-01-09	1	11	15	17	25	39	40	1688815709	9	2025-10-29 07:51:39.802518	2025-10-29 07:51:39.802518
685	2016-01-16	6	7	12	28	38	40	18	1494367671	11	2025-10-29 07:51:40.311655	2025-10-29 07:51:40.311655
686	2016-01-23	7	12	15	24	25	43	13	1937531719	8	2025-10-29 07:51:40.82018	2025-10-29 07:51:40.82018
687	2016-01-30	1	8	10	13	28	42	45	2720029313	6	2025-10-29 07:51:41.329113	2025-10-29 07:51:41.329113
688	2016-02-06	5	15	22	23	34	35	2	1967536750	9	2025-10-29 07:51:41.836883	2025-10-29 07:51:41.836883
689	2016-02-13	7	17	19	30	36	38	34	2321775911	7	2025-10-29 07:51:42.347495	2025-10-29 07:51:42.347495
690	2016-02-20	24	25	33	34	38	39	43	1126507625	15	2025-10-29 07:51:42.859984	2025-10-29 07:51:42.859984
691	2016-02-27	15	27	33	35	43	45	16	2839296750	6	2025-10-29 07:51:43.372352	2025-10-29 07:51:43.372352
692	2016-03-05	3	11	14	15	32	36	44	2301273697	7	2025-10-29 07:51:43.881403	2025-10-29 07:51:43.881403
693	2016-03-12	1	6	11	28	34	42	30	1642763813	10	2025-10-29 07:51:44.388744	2025-10-29 07:51:44.388744
694	2016-03-19	7	15	20	25	33	43	12	1555036388	10	2025-10-29 07:51:44.89824	2025-10-29 07:51:44.89824
695	2016-03-26	4	18	26	33	34	38	14	1450214830	11	2025-10-29 07:51:45.411334	2025-10-29 07:51:45.411334
696	2016-04-02	1	7	16	18	34	38	21	1632054413	10	2025-10-29 07:51:45.919119	2025-10-29 07:51:45.919119
697	2016-04-09	2	5	8	11	33	39	31	1531443038	10	2025-10-29 07:51:46.42758	2025-10-29 07:51:46.42758
698	2016-04-16	3	11	13	21	33	37	18	1921084125	8	2025-10-29 07:51:46.941683	2025-10-29 07:51:46.941683
699	2016-04-23	4	5	8	16	21	29	3	1995411375	8	2025-10-29 07:51:47.45027	2025-10-29 07:51:47.45027
700	2016-04-30	11	23	28	29	30	44	13	2082099188	8	2025-10-29 07:51:47.957876	2025-10-29 07:51:47.957876
701	2016-05-07	3	10	14	16	36	38	35	1583183175	10	2025-10-29 07:51:54.518539	2025-10-29 07:51:54.518539
702	2016-05-14	3	13	16	24	26	29	9	1465091387	11	2025-10-29 07:51:55.026198	2025-10-29 07:51:55.026198
703	2016-05-21	10	28	31	33	41	44	21	3235784100	5	2025-10-29 07:51:55.550102	2025-10-29 07:51:55.550102
704	2016-05-28	1	4	8	23	33	42	45	3865190344	4	2025-10-29 07:51:56.061692	2025-10-29 07:51:56.061692
705	2016-06-04	1	6	17	22	28	45	23	3987206532	4	2025-10-29 07:51:56.571123	2025-10-29 07:51:56.571123
706	2016-06-11	3	4	6	10	28	30	37	3831746063	4	2025-10-29 07:51:57.079398	2025-10-29 07:51:57.079398
707	2016-06-18	2	12	19	24	39	44	35	1322167313	12	2025-10-29 07:51:57.588098	2025-10-29 07:51:57.588098
708	2016-06-25	2	10	16	19	34	45	1	4099552219	4	2025-10-29 07:51:58.096955	2025-10-29 07:51:58.096955
709	2016-07-02	10	18	30	36	39	44	32	1165271625	14	2025-10-29 07:51:58.605364	2025-10-29 07:51:58.605364
710	2016-07-09	3	4	9	24	25	33	10	2895441150	5	2025-10-29 07:51:59.115357	2025-10-29 07:51:59.115357
711	2016-07-16	11	15	24	35	37	45	42	2277413358	7	2025-10-29 07:51:59.623251	2025-10-29 07:51:59.623251
712	2016-07-23	17	20	30	31	33	45	19	4034485125	4	2025-10-29 07:52:00.130399	2025-10-29 07:52:00.130399
713	2016-07-30	2	5	15	18	19	23	44	1714720917	9	2025-10-29 07:52:00.638666	2025-10-29 07:52:00.638666
714	2016-08-06	1	7	22	33	37	40	20	2085131733	7	2025-10-29 07:52:01.147849	2025-10-29 07:52:01.147849
715	2016-08-13	2	7	27	33	41	44	10	2605510438	6	2025-10-29 07:52:01.656557	2025-10-29 07:52:01.656557
716	2016-08-20	2	6	13	16	29	30	21	1358752157	12	2025-10-29 07:52:02.163658	2025-10-29 07:52:02.163658
717	2016-08-27	2	11	19	25	28	32	44	2702433688	6	2025-10-29 07:52:02.671897	2025-10-29 07:52:02.671897
718	2016-09-03	4	11	20	23	32	39	40	926166464	17	2025-10-29 07:52:03.179303	2025-10-29 07:52:03.179303
719	2016-09-10	4	8	13	19	20	43	26	1879581334	9	2025-10-29 07:52:03.68757	2025-10-29 07:52:03.68757
720	2016-09-17	1	12	29	34	36	37	41	1233770358	14	2025-10-29 07:52:04.197274	2025-10-29 07:52:04.197274
721	2016-09-24	1	28	35	41	43	44	31	2273767360	8	2025-10-29 07:52:04.70889	2025-10-29 07:52:04.70889
722	2016-10-01	12	14	21	30	39	43	45	4365422719	4	2025-10-29 07:52:05.216748	2025-10-29 07:52:05.216748
723	2016-10-08	20	30	33	35	36	44	22	2114365360	8	2025-10-29 07:52:05.725516	2025-10-29 07:52:05.725516
724	2016-10-15	2	8	33	35	37	41	14	1427789813	12	2025-10-29 07:52:06.234473	2025-10-29 07:52:06.234473
725	2016-10-22	6	7	19	21	41	43	38	1579217250	11	2025-10-29 07:52:06.742039	2025-10-29 07:52:06.742039
726	2016-10-29	1	11	21	23	34	44	24	1166872634	14	2025-10-29 07:52:07.25053	2025-10-29 07:52:07.25053
727	2016-11-05	7	8	10	19	21	31	20	1115107742	14	2025-10-29 07:52:07.759302	2025-10-29 07:52:07.759302
728	2016-11-12	3	6	10	30	34	37	36	3243464400	5	2025-10-29 07:52:08.267622	2025-10-29 07:52:08.267622
729	2016-11-19	11	17	21	26	36	45	16	4198250719	4	2025-10-29 07:52:08.779933	2025-10-29 07:52:08.779933
730	2016-11-26	4	10	14	15	18	22	39	2017382110	8	2025-10-29 07:52:09.287667	2025-10-29 07:52:09.287667
731	2016-12-03	2	7	13	25	42	45	39	2340471054	7	2025-10-29 07:52:09.796466	2025-10-29 07:52:09.796466
732	2016-12-10	2	4	5	17	27	32	43	2203270608	7	2025-10-29 07:52:10.30806	2025-10-29 07:52:10.30806
733	2016-12-17	11	24	32	33	35	40	13	4016725125	4	2025-10-29 07:52:10.81673	2025-10-29 07:52:10.81673
734	2016-12-24	6	16	37	38	41	45	18	1949395500	9	2025-10-29 07:52:11.324571	2025-10-29 07:52:11.324571
735	2016-12-31	5	10	13	27	37	41	4	1847231588	10	2025-10-29 07:52:11.832682	2025-10-29 07:52:11.832682
736	2017-01-07	2	11	17	18	21	27	6	3397362225	5	2025-10-29 07:52:12.341327	2025-10-29 07:52:12.341327
737	2017-01-14	13	15	18	24	27	41	11	4283061000	4	2025-10-29 07:52:12.850018	2025-10-29 07:52:12.850018
738	2017-01-21	23	27	28	38	42	43	36	1634191091	11	2025-10-29 07:52:13.359483	2025-10-29 07:52:13.359483
739	2017-01-28	7	22	29	33	34	35	30	4744122282	4	2025-10-29 07:52:13.86752	2025-10-29 07:52:13.86752
740	2017-02-04	4	8	9	16	17	19	31	936929792	18	2025-10-29 07:52:14.376577	2025-10-29 07:52:14.376577
741	2017-02-11	5	21	27	34	44	45	16	3043595938	6	2025-10-29 07:52:14.886569	2025-10-29 07:52:14.886569
742	2017-02-18	8	10	13	36	37	40	6	1111814813	16	2025-10-29 07:52:15.394024	2025-10-29 07:52:15.394024
743	2017-02-25	15	19	21	34	41	44	10	2608641000	7	2025-10-29 07:52:15.9027	2025-10-29 07:52:15.9027
744	2017-03-04	10	15	18	21	34	41	43	1155411575	15	2025-10-29 07:52:16.410997	2025-10-29 07:52:16.410997
745	2017-03-11	1	2	3	9	12	23	10	746822982	20	2025-10-29 07:52:16.919447	2025-10-29 07:52:16.919447
746	2017-03-18	3	12	33	36	42	45	25	2038623709	9	2025-10-29 07:52:17.428228	2025-10-29 07:52:17.428228
747	2017-03-25	7	9	12	14	23	28	17	1903214584	9	2025-10-29 07:52:17.936325	2025-10-29 07:52:17.936325
748	2017-04-01	3	10	13	22	31	32	29	1928246542	9	2025-10-29 07:52:18.445347	2025-10-29 07:52:18.445347
749	2017-04-08	12	14	24	26	34	45	41	1350104395	13	2025-10-29 07:52:18.953884	2025-10-29 07:52:18.953884
750	2017-04-15	1	2	15	19	24	36	12	2522104286	7	2025-10-29 07:52:19.463258	2025-10-29 07:52:19.463258
751	2017-04-22	3	4	16	20	28	44	17	2097968110	8	2025-10-29 07:52:19.973847	2025-10-29 07:52:19.973847
752	2017-04-29	4	16	20	33	40	43	7	1870358834	9	2025-10-29 07:52:20.483164	2025-10-29 07:52:20.483164
753	2017-05-06	2	17	19	24	37	41	3	2711105063	6	2025-10-29 07:52:20.991249	2025-10-29 07:52:20.991249
754	2017-05-13	2	8	17	24	29	31	32	3427542000	5	2025-10-29 07:52:21.498872	2025-10-29 07:52:21.498872
755	2017-05-20	13	14	26	28	30	36	37	2214427266	8	2025-10-29 07:52:22.00636	2025-10-29 07:52:22.00636
756	2017-05-27	10	14	16	18	27	28	4	3414434700	5	2025-10-29 07:52:22.514034	2025-10-29 07:52:22.514034
757	2017-06-03	6	7	11	17	33	44	1	739839858	21	2025-10-29 07:52:23.022561	2025-10-29 07:52:23.022561
758	2017-06-10	5	9	12	30	39	43	24	2078969954	8	2025-10-29 07:52:23.531222	2025-10-29 07:52:23.531222
759	2017-06-17	9	33	36	40	42	43	32	3032670500	6	2025-10-29 07:52:24.039635	2025-10-29 07:52:24.039635
760	2017-06-24	10	22	27	31	42	43	12	2253299391	8	2025-10-29 07:52:24.548529	2025-10-29 07:52:24.548529
761	2017-07-01	4	7	11	24	42	45	30	2392730518	7	2025-10-29 07:52:25.056416	2025-10-29 07:52:25.056416
762	2017-07-08	1	3	12	21	26	41	16	1631432063	10	2025-10-29 07:52:25.564647	2025-10-29 07:52:25.564647
763	2017-07-15	3	8	16	32	34	43	10	2138130000	8	2025-10-29 07:52:26.072678	2025-10-29 07:52:26.072678
764	2017-07-22	7	22	24	31	34	36	15	2459975465	7	2025-10-29 07:52:26.581995	2025-10-29 07:52:26.581995
765	2017-07-29	1	3	8	12	42	43	33	1109214250	15	2025-10-29 07:52:27.090442	2025-10-29 07:52:27.090442
766	2017-08-05	9	30	34	35	39	41	21	2173637297	8	2025-10-29 07:52:27.598877	2025-10-29 07:52:27.598877
767	2017-08-12	5	15	20	31	34	42	22	1163768725	15	2025-10-29 07:52:28.108537	2025-10-29 07:52:28.108537
768	2017-08-19	7	27	29	30	38	44	4	1363572260	13	2025-10-29 07:52:28.616076	2025-10-29 07:52:28.616076
769	2017-08-26	5	7	11	16	41	45	4	1930760042	9	2025-10-29 07:52:29.123864	2025-10-29 07:52:29.123864
770	2017-09-02	1	9	12	23	39	43	34	2163099329	8	2025-10-29 07:52:29.633101	2025-10-29 07:52:29.633101
771	2017-09-09	6	10	17	18	21	29	30	4362644907	4	2025-10-29 07:52:30.145253	2025-10-29 07:52:30.145253
772	2017-09-16	5	6	11	14	21	41	32	1769608838	10	2025-10-29 07:52:30.653114	2025-10-29 07:52:30.653114
773	2017-09-23	8	12	19	21	31	35	44	1609403080	11	2025-10-29 07:52:31.161164	2025-10-29 07:52:31.161164
774	2017-09-30	12	15	18	28	34	42	9	1709721512	11	2025-10-29 07:52:31.6709	2025-10-29 07:52:31.6709
775	2017-10-07	11	12	29	33	38	42	17	3470437650	5	2025-10-29 07:52:32.181518	2025-10-29 07:52:32.181518
776	2017-10-14	8	9	18	21	28	40	20	2557579393	7	2025-10-29 07:52:32.689017	2025-10-29 07:52:32.689017
777	2017-10-21	6	12	17	21	34	37	18	833468036	21	2025-10-29 07:52:33.196927	2025-10-29 07:52:33.196927
778	2017-10-28	6	21	35	36	37	41	11	6264069500	3	2025-10-29 07:52:33.705023	2025-10-29 07:52:33.705023
779	2017-11-04	6	12	19	24	34	41	4	1527709296	11	2025-10-29 07:52:34.213059	2025-10-29 07:52:34.213059
780	2017-11-11	15	17	19	21	27	45	16	1667520137	11	2025-10-29 07:52:34.721083	2025-10-29 07:52:34.721083
781	2017-11-18	11	16	18	19	24	39	43	1882891542	9	2025-10-29 07:52:35.230034	2025-10-29 07:52:35.230034
782	2017-11-25	6	18	31	34	38	45	20	1946487625	9	2025-10-29 07:52:35.737821	2025-10-29 07:52:35.737821
783	2017-12-02	14	15	16	17	38	45	36	4603964625	4	2025-10-29 07:52:36.245538	2025-10-29 07:52:36.245538
784	2017-12-09	3	10	23	24	31	39	22	1908678000	9	2025-10-29 07:52:36.753645	2025-10-29 07:52:36.753645
785	2017-12-16	4	6	15	25	26	33	40	2886622688	6	2025-10-29 07:52:37.263078	2025-10-29 07:52:37.263078
786	2017-12-23	12	15	16	20	24	30	38	4551365250	4	2025-10-29 07:52:37.771692	2025-10-29 07:52:37.771692
787	2017-12-30	5	6	13	16	27	28	9	3092108313	6	2025-10-29 07:52:38.280945	2025-10-29 07:52:38.280945
788	2018-01-06	2	10	11	19	35	39	29	1401475154	13	2025-10-29 07:52:38.789052	2025-10-29 07:52:38.789052
789	2018-01-13	2	6	7	12	19	45	38	1140976825	15	2025-10-29 07:52:39.297052	2025-10-29 07:52:39.297052
790	2018-01-20	3	8	19	27	30	41	12	1160516274	16	2025-10-29 07:52:39.805561	2025-10-29 07:52:39.805561
791	2018-01-27	2	10	12	31	33	42	32	1253081893	14	2025-10-29 07:52:40.313208	2025-10-29 07:52:40.313208
792	2018-02-03	2	7	19	25	29	36	16	2655736768	7	2025-10-29 07:52:40.821169	2025-10-29 07:52:40.821169
793	2018-02-10	10	15	21	35	38	43	31	3750146775	5	2025-10-29 07:52:41.330948	2025-10-29 07:52:41.330948
794	2018-02-17	6	7	18	19	30	38	13	2650940304	7	2025-10-29 07:52:41.840922	2025-10-29 07:52:41.840922
795	2018-02-24	3	10	13	26	34	38	36	1714977000	11	2025-10-29 07:52:42.348618	2025-10-29 07:52:42.348618
796	2018-03-03	1	21	26	36	40	41	5	2763490340	7	2025-10-29 07:52:42.856204	2025-10-29 07:52:42.856204
797	2018-03-10	5	22	31	32	39	45	36	2397028125	8	2025-10-29 07:52:43.364966	2025-10-29 07:52:43.364966
798	2018-03-17	2	10	14	22	32	36	41	2710791911	7	2025-10-29 07:52:43.872449	2025-10-29 07:52:43.872449
799	2018-03-24	12	17	23	34	42	45	33	1826427225	10	2025-10-29 07:52:44.38126	2025-10-29 07:52:44.38126
800	2018-03-31	1	4	10	12	28	45	26	1632246205	11	2025-10-29 07:52:44.889226	2025-10-29 07:52:44.889226
801	2018-04-07	17	25	28	37	43	44	2	2256786657	8	2025-10-29 07:52:50.433444	2025-10-29 07:52:50.433444
802	2018-04-14	10	11	12	18	24	42	27	1082947993	16	2025-10-29 07:52:50.940956	2025-10-29 07:52:50.940956
803	2018-04-21	5	9	14	26	30	43	2	3663810225	5	2025-10-29 07:52:51.449277	2025-10-29 07:52:51.449277
804	2018-04-28	1	10	13	26	32	36	9	1631996523	11	2025-10-29 07:52:51.956796	2025-10-29 07:52:51.956796
805	2018-05-05	3	12	13	18	31	32	42	4266061969	4	2025-10-29 07:52:52.465982	2025-10-29 07:52:52.465982
806	2018-05-12	14	20	23	31	37	38	27	2640760875	7	2025-10-29 07:52:52.973565	2025-10-29 07:52:52.973565
807	2018-05-19	6	10	18	25	34	35	33	2437662322	7	2025-10-29 07:52:53.482305	2025-10-29 07:52:53.482305
808	2018-05-26	15	21	31	32	41	43	24	3087620500	6	2025-10-29 07:52:53.988986	2025-10-29 07:52:53.988986
809	2018-06-02	6	11	15	17	23	40	39	2921372750	6	2025-10-29 07:52:54.497575	2025-10-29 07:52:54.497575
810	2018-06-09	5	10	13	21	39	43	11	2231598047	8	2025-10-29 07:52:55.006955	2025-10-29 07:52:55.006955
811	2018-06-16	8	11	19	21	36	45	25	2524148197	7	2025-10-29 07:52:55.514899	2025-10-29 07:52:55.514899
812	2018-06-23	1	3	12	14	16	43	10	2947954750	6	2025-10-29 07:52:56.026798	2025-10-29 07:52:56.026798
813	2018-06-30	11	30	34	35	42	44	27	4591763157	4	2025-10-29 07:52:56.53687	2025-10-29 07:52:56.53687
814	2018-07-07	2	21	28	38	42	45	30	3067192063	6	2025-10-29 07:52:57.045903	2025-10-29 07:52:57.045903
815	2018-07-14	17	21	25	26	27	36	4	2579855358	7	2025-10-29 07:52:57.554307	2025-10-29 07:52:57.554307
816	2018-07-21	12	18	19	29	31	39	7	2128107938	8	2025-10-29 07:52:58.062806	2025-10-29 07:52:58.062806
817	2018-07-28	3	9	12	13	25	43	34	1868477334	9	2025-10-29 07:52:58.571524	2025-10-29 07:52:58.571524
818	2018-08-04	14	15	25	28	29	30	3	1380804318	13	2025-10-29 07:52:59.079633	2025-10-29 07:52:59.079633
819	2018-08-11	16	25	33	38	40	45	15	2594534840	7	2025-10-29 07:52:59.588984	2025-10-29 07:52:59.588984
820	2018-08-18	10	21	22	30	35	42	6	4627313532	4	2025-10-29 07:53:00.096391	2025-10-29 07:53:00.096391
821	2018-08-25	1	12	13	24	29	44	16	1316155956	14	2025-10-29 07:53:00.604909	2025-10-29 07:53:00.604909
822	2018-09-01	9	18	20	24	27	36	12	5930898625	3	2025-10-29 07:53:01.112594	2025-10-29 07:53:01.112594
823	2018-09-08	12	18	24	26	39	40	15	2009843917	9	2025-10-29 07:53:01.620149	2025-10-29 07:53:01.620149
824	2018-09-15	7	9	24	29	34	38	26	1256646550	15	2025-10-29 07:53:02.127498	2025-10-29 07:53:02.127498
825	2018-09-22	8	15	21	31	33	38	42	1658710563	12	2025-10-29 07:53:02.636247	2025-10-29 07:53:02.636247
826	2018-09-29	13	16	24	25	33	36	42	2075192084	9	2025-10-29 07:53:03.144148	2025-10-29 07:53:03.144148
827	2018-10-06	5	11	12	29	33	44	14	1206500375	15	2025-10-29 07:53:03.651385	2025-10-29 07:53:03.651385
828	2018-10-13	4	7	13	29	31	39	18	1455185972	13	2025-10-29 07:53:04.159921	2025-10-29 07:53:04.159921
829	2018-10-20	4	5	31	35	43	45	29	2444650641	8	2025-10-29 07:53:04.6684	2025-10-29 07:53:04.6684
830	2018-10-27	5	6	16	18	37	38	17	2060528750	9	2025-10-29 07:53:05.176394	2025-10-29 07:53:05.176394
831	2018-11-03	3	10	16	19	31	39	9	1110702258	16	2025-10-29 07:53:05.683487	2025-10-29 07:53:05.683487
832	2018-11-10	13	14	19	26	40	43	30	2088204584	9	2025-10-29 07:53:06.189968	2025-10-29 07:53:06.189968
833	2018-11-17	12	18	30	39	41	42	19	2356317282	8	2025-10-29 07:53:06.702149	2025-10-29 07:53:06.702149
834	2018-11-24	6	8	18	35	42	43	3	1690693671	11	2025-10-29 07:53:07.20983	2025-10-29 07:53:07.20983
835	2018-12-01	9	10	13	28	38	45	35	1233681125	15	2025-10-29 07:53:07.717967	2025-10-29 07:53:07.717967
836	2018-12-08	1	9	11	14	26	28	19	1257843670	14	2025-10-29 07:53:08.225463	2025-10-29 07:53:08.225463
837	2018-12-15	2	25	28	30	33	45	6	3144449125	6	2025-10-29 07:53:08.73477	2025-10-29 07:53:08.73477
838	2018-12-22	9	14	17	33	36	38	20	3813733050	5	2025-10-29 07:53:09.24477	2025-10-29 07:53:09.24477
839	2018-12-29	3	9	11	12	13	19	35	1359454904	13	2025-10-29 07:53:09.753588	2025-10-29 07:53:09.753588
840	2019-01-05	2	4	11	28	29	43	27	2042961788	10	2025-10-29 07:53:10.26148	2025-10-29 07:53:10.26148
841	2019-01-12	5	11	14	30	33	38	24	1116095714	17	2025-10-29 07:53:10.768838	2025-10-29 07:53:10.768838
842	2019-01-19	14	26	32	36	39	42	38	2035475025	10	2025-10-29 07:53:11.277667	2025-10-29 07:53:11.277667
843	2019-01-26	19	21	30	33	34	42	4	4012970100	5	2025-10-29 07:53:11.786734	2025-10-29 07:53:11.786734
844	2019-02-02	7	8	13	15	33	45	18	1162963542	18	2025-10-29 07:53:12.294722	2025-10-29 07:53:12.294722
845	2019-02-09	1	16	29	33	40	45	6	1891217182	11	2025-10-29 07:53:12.80386	2025-10-29 07:53:12.80386
846	2019-02-16	5	18	30	41	43	45	13	1596884395	13	2025-10-29 07:53:13.312232	2025-10-29 07:53:13.312232
847	2019-02-23	12	16	26	28	30	42	22	2520846657	8	2025-10-29 07:53:13.819568	2025-10-29 07:53:13.819568
848	2019-03-02	1	2	16	22	38	39	34	3011580858	7	2025-10-29 07:53:14.326853	2025-10-29 07:53:14.326853
849	2019-03-09	5	13	17	29	34	39	3	1158252883	17	2025-10-29 07:53:14.834591	2025-10-29 07:53:14.834591
850	2019-03-16	16	20	24	28	36	39	5	3377587875	6	2025-10-29 07:53:15.342484	2025-10-29 07:53:15.342484
851	2019-03-23	14	18	22	26	31	44	40	2483692313	8	2025-10-29 07:53:15.850204	2025-10-29 07:53:15.850204
852	2019-03-30	11	17	28	30	33	35	9	4801543407	4	2025-10-29 07:53:16.360272	2025-10-29 07:53:16.360272
853	2019-04-06	2	8	23	26	27	44	13	2885006786	7	2025-10-29 07:53:16.86923	2025-10-29 07:53:16.86923
854	2019-04-13	20	25	31	32	36	43	3	3421706750	6	2025-10-29 07:53:17.377856	2025-10-29 07:53:17.377856
855	2019-04-20	8	15	17	19	43	44	7	2269510500	9	2025-10-29 07:53:17.886062	2025-10-29 07:53:17.886062
856	2019-04-27	10	24	40	41	43	44	17	3977927550	5	2025-10-29 07:53:18.395047	2025-10-29 07:53:18.395047
857	2019-05-04	6	10	16	28	34	38	43	1284915425	15	2025-10-29 07:53:18.903186	2025-10-29 07:53:18.903186
858	2019-05-11	9	13	32	38	39	43	23	2202347459	9	2025-10-29 07:53:19.41474	2025-10-29 07:53:19.41474
859	2019-05-18	8	22	35	38	39	41	24	1853927489	11	2025-10-29 07:53:19.924298	2025-10-29 07:53:19.924298
860	2019-05-25	4	8	18	25	27	32	42	1879899825	10	2025-10-29 07:53:20.431927	2025-10-29 07:53:20.431927
861	2019-06-01	11	17	19	21	22	25	24	4872108844	4	2025-10-29 07:53:20.939838	2025-10-29 07:53:20.939838
862	2019-06-08	10	34	38	40	42	43	32	2190922709	9	2025-10-29 07:53:21.44823	2025-10-29 07:53:21.44823
863	2019-06-15	16	21	28	35	39	43	12	2853357322	7	2025-10-29 07:53:21.955883	2025-10-29 07:53:21.955883
864	2019-06-22	3	7	10	13	25	36	32	1716553637	11	2025-10-29 07:53:22.464414	2025-10-29 07:53:22.464414
865	2019-06-29	3	15	22	32	33	45	2	1551729145	13	2025-10-29 07:53:22.972366	2025-10-29 07:53:22.972366
866	2019-07-06	9	15	29	34	37	39	12	2240409000	9	2025-10-29 07:53:23.479459	2025-10-29 07:53:23.479459
867	2019-07-13	14	17	19	22	24	40	41	3933755250	5	2025-10-29 07:53:23.987004	2025-10-29 07:53:23.987004
868	2019-07-20	12	17	28	41	43	44	25	3233804250	6	2025-10-29 07:53:24.494867	2025-10-29 07:53:24.494867
869	2019-07-27	2	6	20	27	37	39	4	1922582588	10	2025-10-29 07:53:25.003932	2025-10-29 07:53:25.003932
870	2019-08-03	21	25	30	32	40	42	31	1928842988	10	2025-10-29 07:53:25.512636	2025-10-29 07:53:25.512636
871	2019-08-10	2	6	12	26	30	34	38	2718071358	7	2025-10-29 07:53:26.021312	2025-10-29 07:53:26.021312
872	2019-08-17	2	4	30	32	33	43	29	1262705579	16	2025-10-29 07:53:26.528991	2025-10-29 07:53:26.528991
873	2019-08-24	3	5	12	13	33	39	38	1874553225	10	2025-10-29 07:53:27.037319	2025-10-29 07:53:27.037319
874	2019-08-31	1	15	19	23	28	42	32	1117123917	18	2025-10-29 07:53:27.545033	2025-10-29 07:53:27.545033
875	2019-09-07	19	22	30	34	39	44	36	1415946724	14	2025-10-29 07:53:28.054215	2025-10-29 07:53:28.054215
876	2019-09-14	5	16	21	26	34	42	24	1090657856	19	2025-10-29 07:53:28.561521	2025-10-29 07:53:28.561521
877	2019-09-21	5	17	18	22	23	43	12	1716607188	12	2025-10-29 07:53:29.069767	2025-10-29 07:53:29.069767
878	2019-09-28	2	6	11	16	25	31	3	3207993500	6	2025-10-29 07:53:29.578719	2025-10-29 07:53:29.578719
879	2019-10-05	1	4	10	14	15	35	20	3206361313	6	2025-10-29 07:53:30.088279	2025-10-29 07:53:30.088279
880	2019-10-12	7	17	19	23	24	45	38	2837810465	7	2025-10-29 07:53:30.595996	2025-10-29 07:53:30.595996
881	2019-10-19	4	18	20	26	27	32	9	2503212282	8	2025-10-29 07:53:31.103876	2025-10-29 07:53:31.103876
882	2019-10-26	18	34	39	43	44	45	23	4127270400	5	2025-10-29 07:53:31.612186	2025-10-29 07:53:31.612186
883	2019-11-02	9	18	32	33	37	44	22	1360519525	15	2025-10-29 07:53:32.120178	2025-10-29 07:53:32.120178
884	2019-11-09	4	14	23	28	37	45	17	1799077282	12	2025-10-29 07:53:32.62786	2025-10-29 07:53:32.62786
885	2019-11-16	1	3	24	27	39	45	31	1543832568	13	2025-10-29 07:53:33.136044	2025-10-29 07:53:33.136044
886	2019-11-23	19	23	28	37	42	45	2	2974643786	7	2025-10-29 07:53:33.643408	2025-10-29 07:53:33.643408
887	2019-11-30	8	14	17	27	36	45	10	2535268688	8	2025-10-29 07:53:34.150969	2025-10-29 07:53:34.150969
888	2019-12-07	3	7	12	31	34	38	32	2370359204	8	2025-10-29 07:53:34.659521	2025-10-29 07:53:34.659521
889	2019-12-14	3	13	29	38	39	42	26	2108986950	10	2025-10-29 07:53:35.172918	2025-10-29 07:53:35.172918
890	2019-12-21	1	4	14	18	29	37	6	2335486167	9	2025-10-29 07:53:35.680478	2025-10-29 07:53:35.680478
891	2019-12-28	9	13	28	31	39	41	19	3082673947	7	2025-10-29 07:53:36.187823	2025-10-29 07:53:36.187823
892	2020-01-04	4	9	17	18	26	42	36	1282017464	17	2025-10-29 07:53:36.694724	2025-10-29 07:53:36.694724
893	2020-01-11	1	15	17	23	25	41	10	2377433625	9	2025-10-29 07:53:37.203185	2025-10-29 07:53:37.203185
894	2020-01-18	19	32	37	40	41	43	45	2377935959	9	2025-10-29 07:53:37.710904	2025-10-29 07:53:37.710904
895	2020-01-25	16	26	31	38	39	41	23	1928079219	12	2025-10-29 07:53:38.220931	2025-10-29 07:53:38.220931
896	2020-02-01	5	12	25	26	38	45	23	3053222036	7	2025-10-29 07:53:38.728409	2025-10-29 07:53:38.728409
897	2020-02-08	6	7	12	22	26	36	29	1619922520	13	2025-10-29 07:53:39.238194	2025-10-29 07:53:39.238194
898	2020-02-15	18	21	28	35	37	42	17	2639313235	8	2025-10-29 07:53:39.745368	2025-10-29 07:53:39.745368
899	2020-02-22	8	19	20	21	33	39	37	3359356063	6	2025-10-29 07:53:40.254287	2025-10-29 07:53:40.254287
900	2020-02-29	7	13	16	18	35	38	14	3349851375	6	2025-10-29 07:53:40.761919	2025-10-29 07:53:40.761919
901	2020-03-07	5	18	20	23	30	34	21	2267974667	9	2025-10-29 07:53:46.30581	2025-10-29 07:53:46.30581
902	2020-03-14	7	19	23	24	36	39	30	1619317529	13	2025-10-29 07:53:46.814522	2025-10-29 07:53:46.814522
903	2020-03-21	2	15	16	21	22	28	45	1684582212	13	2025-10-29 07:53:47.323021	2025-10-29 07:53:47.323021
904	2020-03-28	2	6	8	26	43	45	11	2718077813	8	2025-10-29 07:53:47.830519	2025-10-29 07:53:47.830519
905	2020-04-04	3	4	16	27	38	40	20	3017862536	7	2025-10-29 07:53:48.337604	2025-10-29 07:53:48.337604
906	2020-04-11	2	5	14	28	31	32	20	2472607250	9	2025-10-29 07:53:48.846489	2025-10-29 07:53:48.846489
907	2020-04-18	21	27	29	38	40	44	37	3165059036	7	2025-10-29 07:53:49.355235	2025-10-29 07:53:49.355235
908	2020-04-25	3	16	21	22	23	44	30	2834856141	8	2025-10-29 07:53:49.862269	2025-10-29 07:53:49.862269
909	2020-05-02	7	24	29	30	34	35	33	2021062875	11	2025-10-29 07:53:50.369786	2025-10-29 07:53:50.369786
910	2020-05-09	1	11	17	27	35	39	31	941316375	21	2025-10-29 07:53:50.878014	2025-10-29 07:53:50.878014
911	2020-05-16	4	5	12	14	32	42	35	2113538625	10	2025-10-29 07:53:51.385152	2025-10-29 07:53:51.385152
912	2020-05-23	5	8	18	21	22	38	10	1493500581	14	2025-10-29 07:53:51.892375	2025-10-29 07:53:51.892375
913	2020-05-30	6	14	16	21	27	37	40	1338755602	16	2025-10-29 07:53:52.40035	2025-10-29 07:53:52.40035
914	2020-06-06	16	19	24	33	42	44	27	1950005557	11	2025-10-29 07:53:52.907657	2025-10-29 07:53:52.907657
915	2020-06-13	2	6	11	13	22	37	14	3518640500	6	2025-10-29 07:53:53.418182	2025-10-29 07:53:53.418182
916	2020-06-20	6	21	22	32	35	36	17	2025384341	11	2025-10-29 07:53:53.925941	2025-10-29 07:53:53.925941
917	2020-06-27	1	3	23	24	27	43	34	2144799638	10	2025-10-29 07:53:54.434138	2025-10-29 07:53:54.434138
918	2020-07-04	7	11	12	31	33	38	5	1117622646	18	2025-10-29 07:53:54.941074	2025-10-29 07:53:54.941074
919	2020-07-11	9	14	17	18	42	44	35	4305150450	5	2025-10-29 07:53:55.448573	2025-10-29 07:53:55.448573
920	2020-07-18	2	3	26	33	34	43	29	3120260197	7	2025-10-29 07:53:55.957478	2025-10-29 07:53:55.957478
921	2020-07-25	5	7	12	22	28	41	1	1232573405	17	2025-10-29 07:53:56.464844	2025-10-29 07:53:56.464844
922	2020-08-01	2	6	13	17	27	43	36	3417904500	6	2025-10-29 07:53:56.972437	2025-10-29 07:53:56.972437
923	2020-08-08	3	17	18	23	36	41	26	2667554625	8	2025-10-29 07:53:57.479448	2025-10-29 07:53:57.479448
924	2020-08-15	3	11	34	42	43	44	13	2382430667	9	2025-10-29 07:53:57.993924	2025-10-29 07:53:57.993924
925	2020-08-22	13	24	32	34	39	42	4	1771080532	12	2025-10-29 07:53:58.502018	2025-10-29 07:53:58.502018
926	2020-08-29	10	16	18	20	25	31	6	2032490663	10	2025-10-29 07:53:59.010481	2025-10-29 07:53:59.010481
927	2020-09-05	4	15	22	38	41	43	26	3714203875	6	2025-10-29 07:53:59.519105	2025-10-29 07:53:59.519105
928	2020-09-12	3	4	10	20	28	44	30	3134591358	7	2025-10-29 07:54:00.033307	2025-10-29 07:54:00.033307
929	2020-09-19	7	9	12	15	19	23	4	1308035157	16	2025-10-29 07:54:00.540575	2025-10-29 07:54:00.540575
930	2020-09-26	8	21	25	38	39	44	28	2832418829	8	2025-10-29 07:54:01.049103	2025-10-29 07:54:01.049103
931	2020-10-03	14	15	23	25	35	43	32	2957108063	8	2025-10-29 07:54:01.5566	2025-10-29 07:54:01.5566
932	2020-10-10	1	6	15	36	37	38	5	3390022983	7	2025-10-29 07:54:02.065139	2025-10-29 07:54:02.065139
933	2020-10-17	23	27	29	31	36	45	37	2927797079	8	2025-10-29 07:54:02.573032	2025-10-29 07:54:02.573032
934	2020-10-24	1	3	30	33	36	39	12	5765772844	4	2025-10-29 07:54:03.081853	2025-10-29 07:54:03.081853
935	2020-10-31	4	10	20	32	38	44	18	1711055424	13	2025-10-29 07:54:03.589919	2025-10-29 07:54:03.589919
936	2020-11-07	7	11	13	17	18	29	43	1492069179	14	2025-10-29 07:54:04.098161	2025-10-29 07:54:04.098161
937	2020-11-14	2	10	13	22	29	40	26	2058420819	11	2025-10-29 07:54:04.605568	2025-10-29 07:54:04.605568
938	2020-11-21	4	8	10	16	31	36	9	2249466563	10	2025-10-29 07:54:05.115206	2025-10-29 07:54:05.115206
939	2020-11-28	4	11	28	39	42	45	6	1708363039	13	2025-10-29 07:54:05.623017	2025-10-29 07:54:05.623017
940	2020-12-05	3	15	20	22	24	41	11	2846071079	8	2025-10-29 07:54:06.13132	2025-10-29 07:54:06.13132
941	2020-12-12	12	14	25	27	39	40	35	1347297422	16	2025-10-29 07:54:06.644105	2025-10-29 07:54:06.644105
942	2020-12-19	10	12	18	35	42	43	39	3761680313	6	2025-10-29 07:54:07.151733	2025-10-29 07:54:07.151733
943	2020-12-26	1	8	13	36	44	45	39	3435045108	7	2025-10-29 07:54:07.659698	2025-10-29 07:54:07.659698
944	2021-01-02	2	13	16	19	32	33	42	1961836356	13	2025-10-29 07:54:08.167885	2025-10-29 07:54:08.167885
945	2021-01-09	9	10	15	30	33	37	26	1765554491	13	2025-10-29 07:54:08.676478	2025-10-29 07:54:08.676478
946	2021-01-16	9	18	19	30	34	40	20	2157656182	11	2025-10-29 07:54:09.184407	2025-10-29 07:54:09.184407
947	2021-01-23	3	8	17	20	27	35	26	1275855750	18	2025-10-29 07:54:09.69193	2025-10-29 07:54:09.69193
948	2021-01-30	13	18	30	31	38	41	5	2188548716	11	2025-10-29 07:54:10.199905	2025-10-29 07:54:10.199905
949	2021-02-06	14	21	35	36	40	44	30	2458569713	10	2025-10-29 07:54:10.707117	2025-10-29 07:54:10.707117
950	2021-02-13	3	4	15	22	28	40	10	3281920500	8	2025-10-29 07:54:11.215008	2025-10-29 07:54:11.215008
951	2021-02-20	2	12	30	31	39	43	38	1747552661	14	2025-10-29 07:54:11.722863	2025-10-29 07:54:11.722863
952	2021-02-27	4	12	22	24	33	41	38	2713699834	9	2025-10-29 07:54:12.232332	2025-10-29 07:54:12.232332
953	2021-03-06	7	9	22	27	37	42	34	1640636009	14	2025-10-29 07:54:12.738843	2025-10-29 07:54:12.738843
954	2021-03-13	1	9	26	28	30	41	32	2478795900	10	2025-10-29 07:54:13.246914	2025-10-29 07:54:13.246914
955	2021-03-20	4	9	23	26	29	33	8	2023170188	12	2025-10-29 07:54:13.755273	2025-10-29 07:54:13.755273
956	2021-03-27	10	11	20	21	25	41	40	2022982671	11	2025-10-29 07:54:14.263216	2025-10-29 07:54:14.263216
957	2021-04-03	4	15	24	35	36	40	1	2126634137	11	2025-10-29 07:54:14.770469	2025-10-29 07:54:14.770469
958	2021-04-10	2	9	10	16	35	37	1	1596119675	15	2025-10-29 07:54:15.278827	2025-10-29 07:54:15.278827
959	2021-04-17	1	14	15	24	40	41	35	3015312891	8	2025-10-29 07:54:15.787458	2025-10-29 07:54:15.787458
960	2021-04-24	2	18	24	30	32	45	14	2401133213	10	2025-10-29 07:54:16.294741	2025-10-29 07:54:16.294741
961	2021-05-01	11	20	29	31	33	42	43	2575231209	9	2025-10-29 07:54:16.80307	2025-10-29 07:54:16.80307
962	2021-05-08	1	18	28	31	34	43	40	1940906094	12	2025-10-29 07:54:17.31123	2025-10-29 07:54:17.31123
963	2021-05-15	6	12	19	23	34	42	35	1476478125	15	2025-10-29 07:54:17.818905	2025-10-29 07:54:17.818905
964	2021-05-22	6	21	36	38	39	43	30	2345861063	10	2025-10-29 07:54:18.327213	2025-10-29 07:54:18.327213
965	2021-05-29	2	13	25	28	29	36	34	3403348929	7	2025-10-29 07:54:18.834781	2025-10-29 07:54:18.834781
966	2021-06-05	1	21	25	29	34	37	36	2411303513	10	2025-10-29 07:54:19.34305	2025-10-29 07:54:19.34305
967	2021-06-12	1	6	13	37	38	40	9	5809776094	4	2025-10-29 07:54:19.850876	2025-10-29 07:54:19.850876
968	2021-06-19	2	5	12	14	24	39	33	1667729683	13	2025-10-29 07:54:20.358371	2025-10-29 07:54:20.358371
969	2021-06-26	3	9	10	29	40	45	7	1149427894	20	2025-10-29 07:54:20.867248	2025-10-29 07:54:20.867248
970	2021-07-03	9	11	16	21	28	36	5	1611544045	14	2025-10-29 07:54:21.375546	2025-10-29 07:54:21.375546
971	2021-07-10	2	6	17	18	21	26	7	3725880250	6	2025-10-29 07:54:21.883439	2025-10-29 07:54:21.883439
972	2021-07-17	3	6	17	23	37	39	26	1124886244	20	2025-10-29 07:54:22.391254	2025-10-29 07:54:22.391254
973	2021-07-24	22	26	31	37	41	42	24	2912742750	8	2025-10-29 07:54:22.898732	2025-10-29 07:54:22.898732
974	2021-07-31	1	2	11	16	39	44	32	1317034523	17	2025-10-29 07:54:23.407406	2025-10-29 07:54:23.407406
975	2021-08-07	7	8	9	17	22	24	5	2440410375	9	2025-10-29 07:54:23.917218	2025-10-29 07:54:23.917218
976	2021-08-14	4	12	14	25	35	37	2	3243867215	7	2025-10-29 07:54:24.424635	2025-10-29 07:54:24.424635
977	2021-08-21	2	9	10	14	22	44	16	1669905911	14	2025-10-29 07:54:24.934165	2025-10-29 07:54:24.934165
978	2021-08-28	1	7	15	32	34	42	8	2373391388	10	2025-10-29 07:54:25.44167	2025-10-29 07:54:25.44167
979	2021-09-04	7	11	16	21	27	33	24	1606400518	14	2025-10-29 07:54:25.948978	2025-10-29 07:54:25.948978
980	2021-09-11	3	13	16	23	24	35	14	3409443215	7	2025-10-29 07:54:26.456209	2025-10-29 07:54:26.456209
981	2021-09-18	27	36	37	41	43	45	32	1992863193	13	2025-10-29 07:54:26.967133	2025-10-29 07:54:26.967133
982	2021-09-25	5	7	13	20	21	44	33	3023630672	8	2025-10-29 07:54:27.474843	2025-10-29 07:54:27.474843
983	2021-10-02	13	23	26	31	35	43	15	2503422225	10	2025-10-29 07:54:27.982288	2025-10-29 07:54:27.982288
984	2021-10-09	3	10	23	35	36	37	18	3453006268	7	2025-10-29 07:54:28.491199	2025-10-29 07:54:28.491199
985	2021-10-16	17	21	23	30	34	44	19	2434752975	10	2025-10-29 07:54:28.999014	2025-10-29 07:54:28.999014
986	2021-10-23	7	10	16	28	41	42	40	2375275125	10	2025-10-29 07:54:29.506413	2025-10-29 07:54:29.506413
987	2021-10-30	2	4	15	23	29	38	7	2378711625	10	2025-10-29 07:54:30.014502	2025-10-29 07:54:30.014502
988	2021-11-06	2	13	20	30	31	41	27	2678489375	9	2025-10-29 07:54:30.522509	2025-10-29 07:54:30.522509
989	2021-11-13	17	18	21	27	29	33	26	5826768563	4	2025-10-29 07:54:31.029831	2025-10-29 07:54:31.029831
990	2021-11-20	2	4	25	26	36	37	28	1740095277	14	2025-10-29 07:54:31.538144	2025-10-29 07:54:31.538144
991	2021-11-27	13	18	25	31	33	44	38	2904166032	8	2025-10-29 07:54:32.046117	2025-10-29 07:54:32.046117
992	2021-12-04	12	20	26	33	44	45	24	1986955563	12	2025-10-29 07:54:32.553478	2025-10-29 07:54:32.553478
993	2021-12-11	6	14	16	18	24	42	44	3991197063	6	2025-10-29 07:54:33.062176	2025-10-29 07:54:33.062176
994	2021-12-18	1	3	8	24	27	35	28	1861582063	12	2025-10-29 07:54:33.569819	2025-10-29 07:54:33.569819
995	2021-12-25	1	4	13	29	38	39	7	3447271875	7	2025-10-29 07:54:34.078487	2025-10-29 07:54:34.078487
996	2022-01-01	6	11	15	24	32	39	28	1491185771	18	2025-10-29 07:54:34.586208	2025-10-29 07:54:34.586208
997	2022-01-08	4	7	14	16	24	44	20	1253749560	19	2025-10-29 07:54:35.094103	2025-10-29 07:54:35.094103
998	2022-01-15	13	17	18	20	42	45	41	2076499657	12	2025-10-29 07:54:35.601702	2025-10-29 07:54:35.601702
999	2022-01-22	1	3	9	14	18	28	34	1513274790	16	2025-10-29 07:54:36.109342	2025-10-29 07:54:36.109342
1000	2022-01-29	2	8	19	22	32	42	39	1246819620	22	2025-10-29 07:54:36.616721	2025-10-29 07:54:36.616721
1001	2022-02-05	6	10	12	14	20	42	15	2077279594	12	2025-10-29 07:54:42.161095	2025-10-29 07:54:42.161095
1002	2022-02-12	17	25	33	35	38	45	15	3088449563	8	2025-10-29 07:54:42.670944	2025-10-29 07:54:42.670944
1003	2022-02-19	1	4	29	39	43	45	31	1811116822	14	2025-10-29 07:54:43.1792	2025-10-29 07:54:43.1792
1004	2022-02-26	7	15	30	37	39	44	18	2576251913	10	2025-10-29 07:54:43.686422	2025-10-29 07:54:43.686422
1005	2022-03-05	8	13	18	24	27	29	17	2061199344	12	2025-10-29 07:54:44.194015	2025-10-29 07:54:44.194015
1006	2022-03-12	8	11	15	16	17	37	36	2855602125	9	2025-10-29 07:54:44.701255	2025-10-29 07:54:44.701255
1007	2022-03-19	8	11	16	19	21	25	40	2718786375	9	2025-10-29 07:54:45.208986	2025-10-29 07:54:45.208986
1008	2022-03-26	9	11	30	31	41	44	33	2267377910	11	2025-10-29 07:54:45.716434	2025-10-29 07:54:45.716434
1009	2022-04-02	15	23	29	34	40	44	20	1702462825	15	2025-10-29 07:54:46.224405	2025-10-29 07:54:46.224405
1010	2022-04-09	9	12	15	25	34	36	3	3119380079	8	2025-10-29 07:54:46.732463	2025-10-29 07:54:46.732463
1011	2022-04-16	1	9	12	26	35	38	42	2220348512	11	2025-10-29 07:54:47.239282	2025-10-29 07:54:47.239282
1012	2022-04-23	5	11	18	20	35	45	3	1861944318	13	2025-10-29 07:54:47.74635	2025-10-29 07:54:47.74635
1013	2022-04-30	21	22	26	34	36	41	32	5047570725	5	2025-10-29 07:54:48.257124	2025-10-29 07:54:48.257124
1014	2022-05-07	3	11	14	18	26	27	21	2410449338	10	2025-10-29 07:54:48.764355	2025-10-29 07:54:48.764355
1015	2022-05-14	14	23	31	33	37	40	44	3051105610	8	2025-10-29 07:54:49.272024	2025-10-29 07:54:49.272024
1016	2022-05-21	15	26	28	34	41	42	44	2260660671	11	2025-10-29 07:54:49.779794	2025-10-29 07:54:49.779794
1017	2022-05-28	12	18	22	23	30	34	32	3517684822	7	2025-10-29 07:54:50.288387	2025-10-29 07:54:50.288387
1018	2022-06-04	3	19	21	25	37	45	35	12361744688	2	2025-10-29 07:54:50.795874	2025-10-29 07:54:50.795874
1019	2022-06-11	1	4	13	17	34	39	6	438565140	50	2025-10-29 07:54:51.311203	2025-10-29 07:54:51.311203
1020	2022-06-18	12	27	29	38	41	45	6	1966431520	13	2025-10-29 07:54:51.819103	2025-10-29 07:54:51.819103
1021	2022-06-25	12	15	17	24	29	45	16	2108962250	12	2025-10-29 07:54:52.326683	2025-10-29 07:54:52.326683
1022	2022-07-02	5	6	11	29	42	45	28	4866468075	5	2025-10-29 07:54:52.834451	2025-10-29 07:54:52.834451
1023	2022-07-09	10	14	16	18	29	35	25	2745677875	9	2025-10-29 07:54:53.341665	2025-10-29 07:54:53.341665
1024	2022-07-16	9	18	20	22	38	44	10	3020323500	8	2025-10-29 07:54:53.850158	2025-10-29 07:54:53.850158
1025	2022-07-23	8	9	20	25	29	33	7	6118853344	4	2025-10-29 07:54:54.35708	2025-10-29 07:54:54.35708
1026	2022-07-30	5	12	13	31	32	41	34	1619118475	15	2025-10-29 07:54:54.864294	2025-10-29 07:54:54.864294
1027	2022-08-06	14	16	27	35	39	45	5	2460504338	10	2025-10-29 07:54:55.3725	2025-10-29 07:54:55.3725
1028	2022-08-13	5	7	12	13	18	35	23	1181235132	20	2025-10-29 07:54:55.879666	2025-10-29 07:54:55.879666
1029	2022-08-20	12	30	32	37	39	41	24	2527848450	10	2025-10-29 07:54:56.387144	2025-10-29 07:54:56.387144
1030	2022-08-27	2	5	11	17	24	29	9	1276406507	19	2025-10-29 07:54:56.893942	2025-10-29 07:54:56.893942
1031	2022-09-03	6	7	22	32	35	36	19	3213957563	8	2025-10-29 07:54:57.401977	2025-10-29 07:54:57.401977
1032	2022-09-10	1	6	12	19	36	42	28	2675257538	10	2025-10-29 07:54:57.910583	2025-10-29 07:54:57.910583
1033	2022-09-17	3	11	15	20	35	44	10	1913414943	13	2025-10-29 07:54:58.420557	2025-10-29 07:54:58.420557
1034	2022-09-24	26	31	32	33	38	40	11	2868856209	9	2025-10-29 07:54:58.927663	2025-10-29 07:54:58.927663
1035	2022-10-01	9	14	34	35	41	42	2	3231193735	8	2025-10-29 07:54:59.435509	2025-10-29 07:54:59.435509
1036	2022-10-08	2	5	22	32	34	45	39	2837323167	9	2025-10-29 07:54:59.943601	2025-10-29 07:54:59.943601
1037	2022-10-15	2	14	15	22	27	33	31	1708576825	15	2025-10-29 07:55:00.451292	2025-10-29 07:55:00.451292
1038	2022-10-22	7	16	24	27	37	44	2	1627457225	15	2025-10-29 07:55:00.958833	2025-10-29 07:55:00.958833
1039	2022-10-29	2	3	6	19	36	39	26	1585019672	16	2025-10-29 07:55:01.466573	2025-10-29 07:55:01.466573
1040	2022-11-05	8	16	26	29	31	36	11	3660482625	7	2025-10-29 07:55:01.982663	2025-10-29 07:55:01.982663
1041	2022-11-12	6	7	9	11	17	18	45	935091165	25	2025-10-29 07:55:02.489408	2025-10-29 07:55:02.489408
1042	2022-11-19	5	14	15	23	34	43	4	1240663669	20	2025-10-29 07:55:02.996576	2025-10-29 07:55:02.996576
1043	2022-11-26	3	5	12	22	26	31	19	1468646956	17	2025-10-29 07:55:03.504184	2025-10-29 07:55:03.504184
1044	2022-12-03	12	17	20	26	28	36	4	3136941235	8	2025-10-29 07:55:04.012323	2025-10-29 07:55:04.012323
1045	2022-12-10	6	14	15	19	21	41	37	1990060443	13	2025-10-29 07:55:04.519782	2025-10-29 07:55:04.519782
1046	2022-12-17	7	16	25	29	35	36	28	2011415719	12	2025-10-29 07:55:05.026853	2025-10-29 07:55:05.026853
1047	2022-12-24	2	20	33	40	42	44	32	2748797875	9	2025-10-29 07:55:05.534036	2025-10-29 07:55:05.534036
1048	2022-12-31	6	12	17	21	32	39	30	1612494508	17	2025-10-29 07:55:06.041624	2025-10-29 07:55:06.041624
1049	2023-01-07	3	5	13	20	21	37	17	1727810100	15	2025-10-29 07:55:06.550287	2025-10-29 07:55:06.550287
1050	2023-01-14	6	12	31	35	38	43	17	1535083280	17	2025-10-29 07:55:07.057337	2025-10-29 07:55:07.057337
1051	2023-01-21	21	26	30	32	33	35	44	1669558480	18	2025-10-29 07:55:07.565116	2025-10-29 07:55:07.565116
1052	2023-01-28	5	17	26	27	35	38	1	2341682762	11	2025-10-29 07:55:08.072419	2025-10-29 07:55:08.072419
1053	2023-02-04	22	26	29	30	34	45	15	4090367411	7	2025-10-29 07:55:08.580712	2025-10-29 07:55:08.580712
1054	2023-02-11	14	19	27	28	30	45	33	3147925709	9	2025-10-29 07:55:09.08931	2025-10-29 07:55:09.08931
1055	2023-02-18	4	7	12	14	22	33	31	2362815205	11	2025-10-29 07:55:09.597316	2025-10-29 07:55:09.597316
1056	2023-02-25	13	20	24	32	36	45	29	1969662456	14	2025-10-29 07:55:10.104736	2025-10-29 07:55:10.104736
1057	2023-03-04	8	13	19	27	40	45	12	1616069714	17	2025-10-29 07:55:10.61404	2025-10-29 07:55:10.61404
1058	2023-03-11	11	23	25	30	32	40	42	2058020250	13	2025-10-29 07:55:11.12117	2025-10-29 07:55:11.12117
1059	2023-03-18	7	10	22	25	34	40	27	2033168481	13	2025-10-29 07:55:11.628585	2025-10-29 07:55:11.628585
1060	2023-03-25	3	10	24	33	38	45	36	898238907	28	2025-10-29 07:55:12.137035	2025-10-29 07:55:12.137035
1061	2023-04-01	4	24	27	35	37	45	15	2422768773	11	2025-10-29 07:55:12.645236	2025-10-29 07:55:12.645236
1062	2023-04-08	20	31	32	40	41	45	12	3801933804	7	2025-10-29 07:55:13.155893	2025-10-29 07:55:13.155893
1063	2023-04-15	3	6	22	23	24	38	30	3770311875	7	2025-10-29 07:55:13.663053	2025-10-29 07:55:13.663053
1064	2023-04-22	3	6	9	18	22	35	14	1348168106	19	2025-10-29 07:55:14.170689	2025-10-29 07:55:14.170689
1065	2023-04-29	3	18	19	23	32	45	24	1852593938	14	2025-10-29 07:55:14.680383	2025-10-29 07:55:14.680383
1066	2023-05-06	6	11	16	19	21	32	45	1670947250	15	2025-10-29 07:55:15.188215	2025-10-29 07:55:15.188215
1067	2023-05-13	7	10	19	23	28	33	18	1981114010	13	2025-10-29 07:55:15.695844	2025-10-29 07:55:15.695844
1068	2023-05-20	4	7	19	26	33	35	3	1363929514	19	2025-10-29 07:55:16.203863	2025-10-29 07:55:16.203863
1069	2023-05-27	1	10	18	22	28	31	44	1863217554	14	2025-10-29 07:55:16.712776	2025-10-29 07:55:16.712776
1070	2023-06-03	3	6	14	22	30	41	36	1859116929	14	2025-10-29 07:55:17.220433	2025-10-29 07:55:17.220433
1071	2023-06-10	1	2	11	21	30	35	39	5183979750	5	2025-10-29 07:55:17.728265	2025-10-29 07:55:17.728265
1072	2023-06-17	16	18	20	23	32	43	27	2175006375	12	2025-10-29 07:55:18.236345	2025-10-29 07:55:18.236345
1073	2023-06-24	6	18	28	30	32	38	15	2345227603	11	2025-10-29 07:55:18.744079	2025-10-29 07:55:18.744079
1074	2023-07-01	1	6	20	27	28	41	15	2134763657	12	2025-10-29 07:55:19.25131	2025-10-29 07:55:19.25131
1075	2023-07-08	1	23	24	35	44	45	10	2896337167	9	2025-10-29 07:55:19.758623	2025-10-29 07:55:19.758623
1076	2023-07-15	3	7	9	33	36	37	10	2672689750	9	2025-10-29 07:55:20.268661	2025-10-29 07:55:20.268661
1077	2023-07-22	4	8	17	30	40	43	34	3570901018	7	2025-10-29 07:55:20.78619	2025-10-29 07:55:20.78619
1078	2023-07-29	6	10	11	14	36	38	43	2141604938	12	2025-10-29 07:55:21.294384	2025-10-29 07:55:21.294384
1079	2023-08-05	4	8	18	24	37	45	6	2712329417	9	2025-10-29 07:55:21.801358	2025-10-29 07:55:21.801358
1080	2023-08-12	13	16	23	31	36	44	38	3639444429	7	2025-10-29 07:55:22.309235	2025-10-29 07:55:22.309235
1081	2023-08-19	1	9	16	23	24	38	17	2343892944	11	2025-10-29 07:55:22.817717	2025-10-29 07:55:22.817717
1082	2023-08-26	21	26	27	32	34	42	31	3720489643	7	2025-10-29 07:55:23.325933	2025-10-29 07:55:23.325933
1083	2023-09-02	3	7	14	15	22	38	17	1713084525	15	2025-10-29 07:55:23.833854	2025-10-29 07:55:23.833854
1084	2023-09-09	8	12	13	29	33	42	5	1738764600	15	2025-10-29 07:55:24.341892	2025-10-29 07:55:24.341892
1085	2023-09-16	4	7	17	18	38	44	36	1073277473	23	2025-10-29 07:55:24.848914	2025-10-29 07:55:24.848914
1086	2023-09-23	11	16	25	27	35	36	37	1515913809	17	2025-10-29 07:55:25.356928	2025-10-29 07:55:25.356928
1087	2023-09-30	13	14	18	21	34	44	16	1732253602	16	2025-10-29 07:55:25.866512	2025-10-29 07:55:25.866512
1088	2023-10-07	11	21	22	30	39	44	31	2434697898	11	2025-10-29 07:55:26.373539	2025-10-29 07:55:26.373539
1089	2023-10-14	4	18	31	37	42	43	40	2978522167	9	2025-10-29 07:55:26.883238	2025-10-29 07:55:26.883238
1090	2023-10-21	12	19	21	29	40	45	1	2386494614	11	2025-10-29 07:55:27.390853	2025-10-29 07:55:27.390853
1091	2023-10-28	6	20	23	24	28	30	44	2898470459	9	2025-10-29 07:55:27.898246	2025-10-29 07:55:27.898246
1092	2023-11-04	7	18	19	26	33	45	37	1583289844	16	2025-10-29 07:55:28.405812	2025-10-29 07:55:28.405812
1093	2023-11-11	10	17	22	30	35	43	44	1967040750	13	2025-10-29 07:55:28.913704	2025-10-29 07:55:28.913704
1094	2023-11-18	6	7	15	22	26	40	41	2112854469	12	2025-10-29 07:55:29.421058	2025-10-29 07:55:29.421058
1095	2023-11-25	8	14	28	29	34	40	12	2617825575	10	2025-10-29 07:55:29.928242	2025-10-29 07:55:29.928242
1096	2023-12-02	1	12	16	19	23	43	34	2539391175	10	2025-10-29 07:55:30.439374	2025-10-29 07:55:30.439374
1097	2023-12-09	14	33	34	35	37	40	4	3864293090	7	2025-10-29 07:55:30.947019	2025-10-29 07:55:30.947019
1098	2023-12-16	12	16	21	24	41	43	15	1930461895	13	2025-10-29 07:55:31.456044	2025-10-29 07:55:31.456044
1099	2023-12-23	3	20	28	38	40	43	4	2959934125	9	2025-10-29 07:55:31.96305	2025-10-29 07:55:31.96305
1100	2023-12-30	17	26	29	30	31	43	12	2207575472	13	2025-10-29 07:55:32.472332	2025-10-29 07:55:32.472332
1101	2024-01-06	6	7	13	28	36	42	41	2100529500	13	2025-10-29 07:55:38.049612	2025-10-29 07:55:38.049612
1102	2024-01-13	13	14	22	26	37	38	20	1383591413	20	2025-10-29 07:55:38.558849	2025-10-29 07:55:38.558849
1103	2024-01-20	10	12	29	31	40	44	2	1574419633	17	2025-10-29 07:55:39.06651	2025-10-29 07:55:39.06651
1104	2024-01-27	1	7	21	30	35	38	2	1817193100	15	2025-10-29 07:55:39.574922	2025-10-29 07:55:39.574922
1105	2024-02-03	6	16	34	37	39	40	11	1834853800	15	2025-10-29 07:55:40.082442	2025-10-29 07:55:40.082442
1106	2024-02-10	1	3	4	29	42	45	36	2790462819	11	2025-10-29 07:55:40.589523	2025-10-29 07:55:40.589523
1107	2024-02-17	6	14	30	31	40	41	29	2025625233	14	2025-10-29 07:55:41.098125	2025-10-29 07:55:41.098125
1108	2024-02-24	7	19	26	37	39	44	27	1957990849	14	2025-10-29 07:55:41.607326	2025-10-29 07:55:41.607326
1109	2024-03-02	10	12	13	19	33	40	2	1584352875	17	2025-10-29 07:55:42.11666	2025-10-29 07:55:42.11666
1110	2024-03-09	3	7	11	20	22	41	24	1647392719	16	2025-10-29 07:55:42.625426	2025-10-29 07:55:42.625426
1111	2024-03-16	3	13	30	33	43	45	4	1714662540	16	2025-10-29 07:55:43.133782	2025-10-29 07:55:43.133782
1112	2024-03-23	16	20	26	36	42	44	24	2804455650	10	2025-10-29 07:55:43.641887	2025-10-29 07:55:43.641887
1113	2024-03-30	11	13	20	21	32	44	8	1987426822	14	2025-10-29 07:55:44.150872	2025-10-29 07:55:44.150872
1114	2024-04-06	10	16	19	32	33	38	3	1583813824	17	2025-10-29 07:55:44.658883	2025-10-29 07:55:44.658883
1115	2024-04-13	7	12	23	32	34	36	8	2257278282	12	2025-10-29 07:55:45.167636	2025-10-29 07:55:45.167636
1116	2024-04-20	15	16	17	25	30	31	32	2695000238	10	2025-10-29 07:55:45.67768	2025-10-29 07:55:45.67768
1117	2024-04-27	3	4	9	30	33	36	7	3028385542	9	2025-10-29 07:55:46.184818	2025-10-29 07:55:46.184818
1118	2024-05-04	11	13	14	15	16	45	3	1477445132	19	2025-10-29 07:55:46.693253	2025-10-29 07:55:46.693253
1119	2024-05-11	1	9	12	13	20	45	3	1396028764	19	2025-10-29 07:55:47.201605	2025-10-29 07:55:47.201605
1120	2024-05-18	2	19	26	31	38	41	34	2522163375	11	2025-10-29 07:55:47.710285	2025-10-29 07:55:47.710285
1121	2024-05-25	6	24	31	32	38	44	8	2524513262	11	2025-10-29 07:55:48.217971	2025-10-29 07:55:48.217971
1122	2024-06-01	3	6	21	30	34	35	22	2556266046	11	2025-10-29 07:55:48.726479	2025-10-29 07:55:48.726479
1123	2024-06-08	13	19	21	24	34	35	26	1731310711	16	2025-10-29 07:55:49.234091	2025-10-29 07:55:49.234091
1124	2024-06-15	3	8	17	30	33	34	28	2623327913	10	2025-10-29 07:55:49.742028	2025-10-29 07:55:49.742028
1125	2024-06-22	6	14	25	33	40	44	30	2195289188	12	2025-10-29 07:55:50.249294	2025-10-29 07:55:50.249294
1126	2024-06-29	4	5	9	11	37	40	7	2386382421	11	2025-10-29 07:55:50.756497	2025-10-29 07:55:50.756497
1127	2024-07-06	10	15	24	30	31	37	32	2267891969	12	2025-10-29 07:55:51.264855	2025-10-29 07:55:51.264855
1128	2024-07-13	1	5	8	16	28	33	45	419925560	63	2025-10-29 07:55:51.773616	2025-10-29 07:55:51.773616
1129	2024-07-20	5	10	11	17	28	34	22	2369567660	11	2025-10-29 07:55:52.281803	2025-10-29 07:55:52.281803
1130	2024-07-27	15	19	21	25	27	28	40	2263301219	12	2025-10-29 07:55:52.788613	2025-10-29 07:55:52.788613
1131	2024-08-03	1	2	6	14	27	38	33	1542367898	17	2025-10-29 07:55:53.296389	2025-10-29 07:55:53.296389
1132	2024-08-10	6	7	19	28	34	41	5	2404951807	11	2025-10-29 07:55:53.804244	2025-10-29 07:55:53.804244
1133	2024-08-17	13	14	20	28	29	34	23	2105079491	13	2025-10-29 07:55:54.311713	2025-10-29 07:55:54.311713
1134	2024-08-24	3	7	9	13	19	24	23	1755689384	14	2025-10-29 07:55:54.820104	2025-10-29 07:55:54.820104
1135	2024-08-31	1	6	13	19	21	33	4	2953726125	9	2025-10-29 07:55:55.327927	2025-10-29 07:55:55.327927
1136	2024-09-07	21	33	35	38	42	44	1	2314468157	12	2025-10-29 07:55:55.837591	2025-10-29 07:55:55.837591
1137	2024-09-14	4	9	12	15	33	45	26	2023447688	14	2025-10-29 07:55:56.346103	2025-10-29 07:55:56.346103
1138	2024-09-21	14	16	19	20	29	34	35	1902656786	14	2025-10-29 07:55:56.85386	2025-10-29 07:55:56.85386
1139	2024-09-28	5	12	15	30	37	40	18	2167490972	13	2025-10-29 07:55:57.361447	2025-10-29 07:55:57.361447
1140	2024-10-05	7	10	22	29	31	38	15	2279823938	12	2025-10-29 07:55:57.870195	2025-10-29 07:55:57.870195
1141	2024-10-12	7	11	12	21	26	35	20	2457758285	11	2025-10-29 07:55:58.377756	2025-10-29 07:55:58.377756
1142	2024-10-19	2	8	28	30	37	41	22	3117517709	9	2025-10-29 07:55:58.884755	2025-10-29 07:55:58.884755
1143	2024-10-26	10	16	17	27	28	36	6	2545657023	11	2025-10-29 07:55:59.393999	2025-10-29 07:55:59.393999
1144	2024-11-02	3	4	12	15	26	34	6	1489347375	18	2025-10-29 07:55:59.900948	2025-10-29 07:55:59.900948
1145	2024-11-09	2	11	31	33	37	44	32	3051630084	9	2025-10-29 07:56:00.408502	2025-10-29 07:56:00.408502
1146	2024-11-16	6	11	17	19	40	43	28	2526476353	11	2025-10-29 07:56:00.918232	2025-10-29 07:56:00.918232
1147	2024-11-23	7	11	24	26	27	37	32	3323422079	8	2025-10-29 07:56:01.42595	2025-10-29 07:56:01.42595
1148	2024-11-30	3	6	13	15	16	22	32	2073332308	13	2025-10-29 07:56:01.933587	2025-10-29 07:56:01.933587
1149	2024-12-07	8	15	19	21	32	36	38	1613380765	17	2025-10-29 07:56:02.440519	2025-10-29 07:56:02.440519
1150	2024-12-14	8	9	18	35	39	45	25	1570620309	17	2025-10-29 07:56:02.947817	2025-10-29 07:56:02.947817
1151	2024-12-21	2	3	9	15	27	29	8	1620503030	17	2025-10-29 08:01:09.860338	2025-10-29 08:01:09.860338
1152	2024-12-28	30	31	32	35	36	37	5	874349668	35	2025-10-29 08:01:10.461941	2025-10-29 08:01:10.461941
1153	2025-01-04	1	9	10	13	35	44	5	2027312925	15	2025-10-29 08:01:10.970751	2025-10-29 08:01:10.970751
1154	2025-01-11	4	8	22	26	32	38	27	1854965425	15	2025-10-29 08:01:11.478987	2025-10-29 08:01:11.478987
1155	2025-01-18	10	16	19	27	37	38	13	4066375179	7	2025-10-29 08:01:11.986568	2025-10-29 08:01:11.986568
1156	2025-01-25	30	31	34	39	41	45	7	1505207090	21	2025-10-29 08:01:12.496032	2025-10-29 08:01:12.496032
1157	2025-02-01	5	7	12	20	25	26	28	2257842157	12	2025-10-29 08:01:13.379153	2025-10-29 08:01:13.379153
1158	2025-02-08	21	25	27	32	37	38	20	1394358197	21	2025-10-29 08:01:13.975584	2025-10-29 08:01:13.975584
1159	2025-02-15	3	9	27	28	38	39	7	1284854250	23	2025-10-29 08:01:14.571922	2025-10-29 08:01:14.571922
1160	2025-02-22	7	13	18	36	39	45	19	2509359875	12	2025-10-29 08:01:15.081323	2025-10-29 08:01:15.081323
1161	2025-03-01	2	12	20	24	34	42	37	1792657969	16	2025-10-29 08:01:15.590819	2025-10-29 08:01:15.590819
1162	2025-03-08	20	21	22	25	28	29	6	823931021	36	2025-10-29 08:01:16.177143	2025-10-29 08:01:16.177143
1163	2025-03-15	2	13	15	16	33	43	4	1936891150	15	2025-10-29 08:01:16.686486	2025-10-29 08:01:16.686486
1164	2025-03-22	17	18	23	25	38	39	22	2193092164	13	2025-10-29 08:01:17.286534	2025-10-29 08:01:17.286534
1165	2025-03-29	6	7	27	29	38	45	17	2192485270	13	2025-10-29 08:01:17.881933	2025-10-29 08:01:17.881933
1166	2025-04-05	14	23	25	27	29	42	16	2072319938	14	2025-10-29 08:01:18.389697	2025-10-29 08:01:18.389697
1167	2025-04-12	8	23	31	35	39	40	24	2884087913	10	2025-10-29 08:01:18.986101	2025-10-29 08:01:18.986101
1168	2025-04-19	9	21	24	30	33	37	29	2136635914	13	2025-10-29 08:01:19.495737	2025-10-29 08:01:19.495737
1169	2025-04-26	5	12	24	26	39	42	20	2852735813	10	2025-10-29 08:01:20.087955	2025-10-29 08:01:20.087955
1170	2025-05-03	3	13	28	34	38	42	25	1386550969	20	2025-10-29 08:01:20.692606	2025-10-29 08:01:20.692606
1171	2025-05-10	3	6	7	11	12	17	19	1128345286	21	2025-10-29 08:01:21.200227	2025-10-29 08:01:21.200227
1172	2025-05-17	7	9	24	40	42	44	45	2203004452	13	2025-10-29 08:01:21.792609	2025-10-29 08:01:21.792609
1173	2025-05-24	1	5	18	20	30	35	3	1179946063	24	2025-10-29 08:01:22.300753	2025-10-29 08:01:22.300753
1174	2025-05-31	8	11	14	17	36	39	22	1910619425	15	2025-10-29 08:01:22.80863	2025-10-29 08:01:22.80863
1175	2025-06-07	3	4	6	8	32	42	31	1384026094	20	2025-10-29 08:01:23.402489	2025-10-29 08:01:23.402489
1176	2025-06-14	7	9	11	21	30	35	29	2052166154	13	2025-10-29 08:01:23.997762	2025-10-29 08:01:23.997762
1177	2025-06-21	3	7	15	16	19	43	21	4576672000	6	2025-10-29 08:01:24.505234	2025-10-29 08:01:24.505234
1178	2025-06-28	5	6	11	27	43	44	17	2391608407	12	2025-10-29 08:01:25.100382	2025-10-29 08:01:25.100382
1179	2025-07-05	3	16	18	24	40	44	21	2162821097	13	2025-10-29 08:01:25.809008	2025-10-29 08:01:25.809008
1180	2025-07-12	6	12	18	37	40	41	3	2535566421	11	2025-10-29 08:01:26.413123	2025-10-29 08:01:26.413123
1181	2025-07-19	8	10	14	20	33	41	28	1593643500	17	2025-10-29 08:01:27.010227	2025-10-29 08:01:27.010227
1182	2025-07-26	1	13	21	25	28	31	22	2124785424	13	2025-10-29 08:01:27.518705	2025-10-29 08:01:27.518705
1183	2025-08-02	4	15	17	23	27	36	31	2073966000	13	2025-10-29 08:01:28.107672	2025-10-29 08:01:28.107672
1184	2025-08-09	14	16	23	25	31	37	42	1910655600	15	2025-10-29 08:01:28.710127	2025-10-29 08:01:28.710127
1185	2025-08-16	6	17	22	28	29	32	38	2388695125	12	2025-10-29 08:01:29.218748	2025-10-29 08:01:29.218748
1186	2025-08-23	2	8	13	16	23	28	35	1985676911	14	2025-10-29 08:01:29.725956	2025-10-29 08:01:29.725956
1187	2025-08-30	5	13	26	29	37	40	42	2619380012	11	2025-10-29 08:01:30.233491	2025-10-29 08:01:30.233491
1188	2025-09-06	3	4	12	19	22	27	9	1074625172	24	2025-10-29 08:01:30.826205	2025-10-29 08:01:30.826205
1189	2025-09-13	9	19	29	35	37	38	31	2263651299	13	2025-10-29 08:01:31.423387	2025-10-29 08:01:31.423387
1190	2025-09-20	7	9	19	23	26	45	33	4622793813	6	2025-10-29 08:01:31.931827	2025-10-29 08:01:31.931827
1191	2025-09-27	1	4	11	12	20	41	2	1536334355	18	2025-10-29 08:01:32.523356	2025-10-29 08:01:32.523356
1192	2025-10-04	10	16	23	36	39	40	11	1079546587	29	2025-10-29 08:01:33.123962	2025-10-29 08:01:33.123962
1193	2025-10-11	6	9	16	19	24	28	17	1717013508	16	2025-10-29 08:01:33.634467	2025-10-29 08:01:33.634467
1194	2025-10-18	3	13	15	24	33	37	2	985155349	28	2025-10-29 08:01:34.141628	2025-10-29 08:01:34.141628
1195	2025-10-25	3	15	27	33	34	36	37	2939186738	10	2025-10-29 08:01:34.650679	2025-10-29 08:01:34.650679
1196	2025-11-01	8	12	15	29	40	45	14	2001627550	15	2025-11-01 15:00:11.442546	2025-11-01 15:00:11.442546
1197	2025-11-08	1	5	7	26	28	43	30	2205089827	13	2025-11-08 15:00:15.143167	2025-11-08 15:00:15.143167
1198	2025-11-15	26	30	33	38	39	41	21	2953686638	10	2025-11-15 15:00:13.069202	2025-11-15 15:00:13.069202
1199	2025-11-22	16	24	25	30	31	32	7	1695609839	17	2025-11-22 15:00:12.100801	2025-11-22 15:00:12.100801
1200	2025-11-29	1	2	4	16	20	32	45	2357299875	12	2025-11-29 15:00:12.28958	2025-11-29 15:00:12.28958
1201	2025-12-06	7	9	24	27	35	36	37	1414555718	19	2025-12-06 15:00:13.110564	2025-12-06 15:00:13.110564
1202	2025-12-13	5	12	21	33	37	40	7	1920410813	14	2025-12-13 15:00:14.825884	2025-12-13 15:00:14.825884
1203	2025-12-20	3	6	18	29	35	39	24	1368060733	21	2025-12-20 15:00:14.80569	2025-12-20 15:00:14.80569
1204	2025-12-27	8	16	28	30	31	44	27	1661007688	18	2025-12-27 15:00:12.940899	2025-12-27 15:00:12.940899
1205	2026-01-03	1	4	16	23	31	41	2	3226386263	10	2026-01-05 05:17:10.714791	2026-01-05 05:17:10.714791
1206	2026-01-10	1	3	17	26	27	42	23	1868807000	15	2026-01-11 04:11:09.213496	2026-01-11 04:11:09.213496
\.


--
-- Data for Name: generation_history; Type: TABLE DATA; Schema: lotto; Owner: appuser
--

COPY lotto.generation_history (id, session_id, user_id, algorithm, generated_numbers, analysis_data, created_at) FROM stdin;
\.


--
-- Data for Name: statistics_cache; Type: TABLE DATA; Schema: lotto; Owner: appuser
--

COPY lotto.statistics_cache (cache_key, cache_data, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_favorites; Type: TABLE DATA; Schema: lotto; Owner: appuser
--

COPY lotto.user_favorites (id, user_id, numbers, nickname, created_at) FROM stdin;
\.


--
-- Data for Name: ai_service_status; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.ai_service_status (id, service_name, status, reason, memory_usage_mb, total_memory_mb, memory_percent, last_check, auto_restart_at, created_at) FROM stdin;
1	ai-chatbot	active	Initial setup	\N	\N	\N	2025-10-22 00:24:42.77216	\N	2025-10-22 00:24:42.77216
2	ai-chatbot	active	auto_restart	537	956	56.00	2025-10-22 04:10:22.448763	\N	2025-10-22 04:10:22.448763
\.


--
-- Data for Name: analytics_events_2025_10; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.analytics_events_2025_10 (id, project_id, event_type, event_category, event_name, event_value, session_id, user_id, ip_address, user_agent, page_url, referrer, device_type, browser, os, metadata, created_at, date) FROM stdin;
1	lotto-master	test	system	deployment_test_2	\N	test-session-002	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:14.778796	2025-10-20
2	lotto-master	test	\N	rate_test_1	\N	test-1	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:33.861937	2025-10-20
3	lotto-master	test	\N	rate_test_5	\N	test-5	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:34.083295	2025-10-20
4	lotto-master	test	\N	rate_test_10	\N	test-10	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:34.082904	2025-10-20
5	lotto-master	test	\N	rate_test_4	\N	test-4	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:34.087018	2025-10-20
7	lotto-master	test	\N	rate_test_3	\N	test-3	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:34.156984	2025-10-20
8	lotto-master	test	\N	rate_test_7	\N	test-7	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:34.157558	2025-10-20
6	lotto-master	test	\N	rate_test_8	\N	test-8	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:34.157235	2025-10-20
9	lotto-master	test	\N	rate_test_6	\N	test-6	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:34.158677	2025-10-20
10	lotto-master	test	\N	rate_test_2	\N	test-2	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:34.161927	2025-10-20
11	lotto-master	test	\N	rate_test_9	\N	test-9	\N	172.20.0.1	curl/7.81.0	\N	\N	desktop	\N	\N	\N	2025-10-20 02:51:34.164332	2025-10-20
12	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-20 05:58:00.748702	2025-10-20
13	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-20 05:58:05.759248	2025-10-20
14	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-10-20 05:58:05.771247	2025-10-20
15	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-20 05:58:05.775843	2025-10-20
16	lotto-master	generation	lotto	numbers_generated	5.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 5, "algorithm": "random", "duration_ms": 2, "numbers_preview": [4, 12, 16, 41, 44, 45]}	2025-10-20 05:58:09.498777	2025-10-20
18	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-10-20 05:58:10.759524	2025-10-20
19	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-20 05:58:10.759607	2025-10-20
17	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-20 05:58:10.759412	2025-10-20
20	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-20 05:58:20.760258	2025-10-20
21	lotto-master	pageview	navigation	page_view	\N	sess_1760683694661_29kfh9bwk	\N	183.98.226.33	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-20 07:51:21.629327	2025-10-20
22	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-20 07:52:16.666464	2025-10-20
23	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 2, "numbers_preview": [1, 22, 24, 35, 41, 43]}	2025-10-20 09:00:43.629668	2025-10-20
24	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-20 09:00:44.878785	2025-10-20
25	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 22, 24, 35, 41, 43], "success": true, "algorithm": "random", "duration_ms": 22}	2025-10-20 09:00:44.888141	2025-10-20
26	lotto-master	pageview	navigation	page_view	\N	sess_1760762789028_di7kpgdds	\N	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-20 13:23:32.062792	2025-10-20
27	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 04:55:53.727116	2025-10-21
28	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 04:56:08.727127	2025-10-21
29	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 23, "numbers_preview": [7, 21, 26, 31, 38, 40]}	2025-10-21 04:56:09.579595	2025-10-21
30	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [7, 21, 26, 31, 38, 40], "success": true, "algorithm": "frequency", "duration_ms": 43}	2025-10-21 04:56:13.728115	2025-10-21
31	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 04:56:28.734671	2025-10-21
32	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "pattern", "duration_ms": 1, "numbers_preview": [1, 7, 17, 21, 35, 39]}	2025-10-21 04:56:29.095606	2025-10-21
33	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 7, 17, 21, 35, 39], "success": true, "algorithm": "pattern", "duration_ms": 18}	2025-10-21 04:56:33.736592	2025-10-21
34	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 04:56:33.749745	2025-10-21
35	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 05:05:57.736735	2025-10-21
36	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 05:05:57.736364	2025-10-21
37	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 06:05:36.245549	2025-10-21
40	today-fortune	deployment_verification	deployment_verification	deployment_verification	\N	test-session-123	test-verification-user	\N	\N	\N	\N	\N	\N	\N	{"test": true, "deployment_date": "2025-10-21"}	2025-10-21 06:43:59.532926	2025-10-21
41	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 07:09:31.002786	2025-10-21
42	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 96, "numbers_preview": [3, 12, 18, 34, 37, 43]}	2025-10-21 07:09:32.02018	2025-10-21
43	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [3, 12, 18, 34, 37, 43], "success": true, "algorithm": "frequency", "duration_ms": 149}	2025-10-21 07:09:36.017238	2025-10-21
44	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "pattern", "duration_ms": 96, "numbers_preview": [4, 5, 21, 29, 36, 41]}	2025-10-21 07:10:37.550583	2025-10-21
45	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 5, 21, 29, 36, 41], "success": true, "algorithm": "pattern", "duration_ms": 170}	2025-10-21 07:10:41.251673	2025-10-21
46	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "pattern", "duration_ms": 96, "numbers_preview": [2, 6, 22, 25, 37, 41]}	2025-10-21 07:11:00.910157	2025-10-21
47	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 6, 22, 25, 37, 41], "success": true, "algorithm": "pattern", "duration_ms": 152}	2025-10-21 07:11:01.309478	2025-10-21
48	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [2, 6, 8, 27, 28, 33]}	2025-10-21 07:11:03.82553	2025-10-21
49	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [2, 7, 30, 31, 35, 43]}	2025-10-21 07:11:04.626745	2025-10-21
50	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 0, "numbers_preview": [2, 8, 15, 20, 26, 41]}	2025-10-21 07:11:05.732817	2025-10-21
51	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 6, 8, 27, 28, 33], "success": true, "algorithm": "random", "duration_ms": 17}	2025-10-21 07:11:06.324035	2025-10-21
52	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [5, 12, 16, 24, 25, 29]}	2025-10-21 07:11:06.542062	2025-10-21
54	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 7, 30, 31, 35, 43], "success": true, "algorithm": "random", "duration_ms": 42}	2025-10-21 07:11:06.730397	2025-10-21
53	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 8, 15, 20, 26, 41], "success": true, "algorithm": "random", "duration_ms": 13}	2025-10-21 07:11:06.728198	2025-10-21
55	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [22, 25, 34, 37, 43, 45]}	2025-10-21 07:11:07.231342	2025-10-21
56	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [5, 10, 16, 24, 30, 44]}	2025-10-21 07:11:08.133774	2025-10-21
57	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [2, 5, 7, 18, 32, 40]}	2025-10-21 07:11:09.351303	2025-10-21
58	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [2, 8, 10, 34, 36, 42]}	2025-10-21 07:11:10.340523	2025-10-21
59	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 12, 16, 24, 25, 29], "success": true, "algorithm": "random", "duration_ms": 169}	2025-10-21 07:11:11.33838	2025-10-21
60	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [22, 25, 34, 37, 43, 45], "success": true, "algorithm": "random", "duration_ms": 60}	2025-10-21 07:11:11.338503	2025-10-21
61	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 10, 16, 24, 30, 44], "success": true, "algorithm": "random", "duration_ms": 85}	2025-10-21 07:11:11.338597	2025-10-21
63	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 5, 7, 18, 32, 40], "success": true, "algorithm": "random", "duration_ms": 347}	2025-10-21 07:11:11.740317	2025-10-21
64	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [2, 8, 10, 13, 19, 26]}	2025-10-21 07:11:11.655114	2025-10-21
62	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 8, 10, 34, 36, 42], "success": true, "algorithm": "random", "duration_ms": 337}	2025-10-21 07:11:11.740147	2025-10-21
65	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 0, "numbers_preview": [11, 14, 20, 27, 36, 44]}	2025-10-21 07:11:12.642046	2025-10-21
66	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 8, 10, 13, 19, 26], "success": true, "algorithm": "random", "duration_ms": 69}	2025-10-21 07:11:16.355012	2025-10-21
67	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [11, 14, 20, 27, 36, 44], "success": true, "algorithm": "random", "duration_ms": 32}	2025-10-21 07:11:16.355318	2025-10-21
68	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [10, 17, 18, 25, 28, 31]}	2025-10-21 07:11:28.598044	2025-10-21
69	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [10, 17, 18, 25, 28, 31], "success": true, "algorithm": "random", "duration_ms": 73}	2025-10-21 07:11:31.501201	2025-10-21
70	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [4, 5, 17, 18, 33, 42]}	2025-10-21 07:11:45.153033	2025-10-21
71	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 5, 17, 18, 33, 42], "success": true, "algorithm": "random", "duration_ms": 79}	2025-10-21 07:11:46.447429	2025-10-21
72	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [4, 6, 12, 21, 23, 33]}	2025-10-21 07:11:47.761624	2025-10-21
73	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [1, 23, 30, 38, 39, 43]}	2025-10-21 07:11:48.770142	2025-10-21
74	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [13, 26, 34, 40, 43, 44]}	2025-10-21 07:11:51.17451	2025-10-21
75	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 6, 12, 21, 23, 33], "success": true, "algorithm": "random", "duration_ms": 22}	2025-10-21 07:11:51.470906	2025-10-21
76	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [13, 26, 34, 40, 43, 44], "success": true, "algorithm": "random", "duration_ms": 59}	2025-10-21 07:11:52.177072	2025-10-21
144	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-29 06:39:46.64405	2025-10-29
77	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 23, 30, 38, 39, 43], "success": true, "algorithm": "random", "duration_ms": 52}	2025-10-21 07:11:52.571675	2025-10-21
78	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 304, "numbers_preview": [7, 17, 34, 38, 43, 45]}	2025-10-21 07:12:00.106513	2025-10-21
79	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [7, 17, 34, 38, 43, 45], "success": true, "algorithm": "frequency", "duration_ms": 361}	2025-10-21 07:12:01.501112	2025-10-21
80	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-21 07:12:16.538905	2025-10-21
81	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 07:12:26.578174	2025-10-21
82	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 07:43:41.06058	2025-10-21
83	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "home", "page_path": "/", "timestamp": "2025-10-21T07:49:11.630Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:11.660434	2025-10-21
84	today-fortune	fortune_generated	fortune_generated	fortune_generated	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"grade": "normal", "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "has_tarot": true, "page_path": "/", "timestamp": "2025-10-21T07:49:11.668Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "total_score": 52, "fortune_type": "daily", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:11.727586	2025-10-21
85	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "app_loaded", "page_path": "/", "timestamp": "2025-10-21T07:49:11.629Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:11.729523	2025-10-21
86	today-fortune	tarot_drawn	tarot_drawn	tarot_drawn	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"card_id": 1, "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "card_name": "The Magician", "page_path": "/", "timestamp": "2025-10-21T07:49:14.694Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "card_name_ko": "마법사", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:14.726811	2025-10-21
87	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "profile", "page_path": "/", "timestamp": "2025-10-21T07:49:19.569Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:19.57742	2025-10-21
89	today-fortune	fortune_generated	fortune_generated	fortune_generated	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"grade": "normal", "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "has_tarot": true, "page_path": "/", "timestamp": "2025-10-21T07:49:21.720Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "total_score": 52, "fortune_type": "daily", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:21.743153	2025-10-21
88	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "home", "page_path": "/", "timestamp": "2025-10-21T07:49:21.717Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:21.743153	2025-10-21
90	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "zodiac", "page_path": "/", "timestamp": "2025-10-21T07:49:25.181Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:25.189776	2025-10-21
91	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "home", "page_path": "/", "timestamp": "2025-10-21T07:49:25.799Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:25.805048	2025-10-21
92	today-fortune	fortune_generated	fortune_generated	fortune_generated	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"grade": "normal", "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "has_tarot": true, "page_path": "/", "timestamp": "2025-10-21T07:49:25.802Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "total_score": 52, "fortune_type": "daily", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:25.808234	2025-10-21
93	today-fortune	page_unload	page_unload	page_unload	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_path": "/", "timestamp": "2025-10-21T07:49:26.973Z", "time_spent": 16, "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:26.988373	2025-10-21
94	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "home", "page_path": "/", "timestamp": "2025-10-21T07:49:27.008Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:27.014144	2025-10-21
99	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "app_loaded", "page_path": "/", "timestamp": "2025-10-21T07:49:27.756Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:27.764092	2025-10-21
100	today-fortune	fortune_generated	fortune_generated	fortune_generated	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"grade": "normal", "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "has_tarot": true, "page_path": "/", "timestamp": "2025-10-21T07:49:27.785Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "total_score": 52, "fortune_type": "daily", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:27.79063	2025-10-21
95	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "app_loaded", "page_path": "/", "timestamp": "2025-10-21T07:49:27.008Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:27.01521	2025-10-21
96	today-fortune	fortune_generated	fortune_generated	fortune_generated	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"grade": "normal", "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "has_tarot": true, "page_path": "/", "timestamp": "2025-10-21T07:49:27.027Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "total_score": 52, "fortune_type": "daily", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:27.037018	2025-10-21
97	today-fortune	page_unload	page_unload	page_unload	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_path": "/", "timestamp": "2025-10-21T07:49:27.693Z", "time_spent": 1, "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:27.705628	2025-10-21
98	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "home", "page_path": "/", "timestamp": "2025-10-21T07:49:27.757Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:49:27.763721	2025-10-21
101	today-fortune	page_unload	page_unload	page_unload	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_path": "/", "timestamp": "2025-10-21T07:59:17.759Z", "time_spent": 590, "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:59:17.824678	2025-10-21
102	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "home", "page_path": "/", "timestamp": "2025-10-21T07:59:17.859Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:59:17.879529	2025-10-21
103	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "app_loaded", "page_path": "/", "timestamp": "2025-10-21T07:59:17.859Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:59:17.890114	2025-10-21
104	today-fortune	fortune_generated	fortune_generated	fortune_generated	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"grade": "normal", "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "has_tarot": true, "page_path": "/", "timestamp": "2025-10-21T07:59:17.885Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "total_score": 52, "fortune_type": "daily", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:59:17.900508	2025-10-21
105	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "profile", "page_path": "/", "timestamp": "2025-10-21T07:59:20.008Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:59:20.025595	2025-10-21
106	today-fortune	page_unload	page_unload	page_unload	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_path": "/", "timestamp": "2025-10-21T07:59:23.206Z", "time_spent": 5, "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:59:23.227282	2025-10-21
107	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "app_loaded", "page_path": "/", "timestamp": "2025-10-21T07:59:23.265Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:59:23.285231	2025-10-21
108	today-fortune	page_view	page_view	page_view	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "home", "page_path": "/", "timestamp": "2025-10-21T07:59:23.266Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:59:23.286021	2025-10-21
109	today-fortune	fortune_generated	fortune_generated	fortune_generated	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"grade": "normal", "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "has_tarot": true, "page_path": "/", "timestamp": "2025-10-21T07:59:23.298Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "total_score": 52, "fortune_type": "daily", "screen_width": 1920, "screen_height": 1080, "viewport_width": 616, "viewport_height": 926}	2025-10-21 07:59:23.312507	2025-10-21
110	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-21 08:56:29.196247	2025-10-21
111	today-fortune	page_unload	page_unload	page_unload	\N	mh09jtxaopdr6fx3igr	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_path": "/", "timestamp": "2025-10-21T09:12:03.650Z", "time_spent": 4360, "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 950, "viewport_height": 926}	2025-10-21 09:12:03.791332	2025-10-21
112	today-fortune	page_view	page_view	page_view	\N	mh19lkygxxg8wc0nku	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "app_loaded", "page_path": "/", "timestamp": "2025-10-22T00:38:19.487Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 950, "viewport_height": 926}	2025-10-22 00:38:19.674772	2025-10-22
113	today-fortune	fortune_generated	fortune_generated	fortune_generated	\N	mh19lkygxxg8wc0nku	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"grade": "good", "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "has_tarot": true, "page_path": "/", "timestamp": "2025-10-22T00:38:19.530Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "total_score": 74, "fortune_type": "daily", "screen_width": 1920, "screen_height": 1080, "viewport_width": 950, "viewport_height": 926}	2025-10-22 00:38:19.72717	2025-10-22
114	today-fortune	page_view	page_view	page_view	\N	mh19lkygxxg8wc0nku	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "home", "page_path": "/", "timestamp": "2025-10-22T00:38:19.488Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 950, "viewport_height": 926}	2025-10-22 00:38:19.731856	2025-10-22
115	today-fortune	page_unload	page_unload	page_unload	\N	mh19lkygxxg8wc0nku	dd550b68-b0c5-471c-b04e-45c2a8e7d7dc	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_path": "/", "timestamp": "2025-10-22T00:38:21.232Z", "time_spent": 2, "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 1920, "screen_height": 1080, "viewport_width": 950, "viewport_height": 926}	2025-10-22 00:38:21.399669	2025-10-22
116	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-22 00:38:23.744898	2025-10-22
117	lotto-master	pageview	navigation	page_view	\N	sess_1761132310647_pnec3bnw0	user_1761132310647_nus4jhizp	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	/	http://203.245.30.6:3001/	mobile	\N	\N	\N	2025-10-22 11:25:14.345288	2025-10-22
118	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 40, "numbers_preview": [14, 15, 18, 19, 27, 37]}	2025-10-22 11:25:14.97244	2025-10-22
119	lotto-master	generation	lotto	number_generated	\N	sess_1761132310647_pnec3bnw0	user_1761132310647_nus4jhizp	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [14, 15, 18, 19, 27, 37], "success": true, "algorithm": "frequency", "duration_ms": 90}	2025-10-22 11:25:19.364514	2025-10-22
120	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 0, "numbers_preview": [1, 3, 10, 11, 33, 38]}	2025-10-22 11:25:20.592743	2025-10-22
121	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 84, "numbers_preview": [13, 15, 18, 19, 34, 44]}	2025-10-22 11:25:21.478029	2025-10-22
122	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 1, "numbers_preview": [19, 27, 38, 39, 43, 45]}	2025-10-22 11:25:22.179059	2025-10-22
123	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 0, "numbers_preview": [12, 13, 17, 26, 37, 45]}	2025-10-22 11:25:22.718539	2025-10-22
124	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 1, "numbers_preview": [1, 3, 13, 15, 20, 31]}	2025-10-22 11:25:23.38415	2025-10-22
125	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 0, "numbers_preview": [3, 7, 11, 13, 18, 33]}	2025-10-22 11:25:24.187937	2025-10-22
126	lotto-master	generation	lotto	number_generated	\N	sess_1761132310647_pnec3bnw0	user_1761132310647_nus4jhizp	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [1, 3, 10, 11, 33, 38], "success": true, "algorithm": "frequency", "duration_ms": 41}	2025-10-22 11:25:24.38123	2025-10-22
127	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 0, "numbers_preview": [11, 12, 18, 20, 39, 43]}	2025-10-22 11:25:24.789616	2025-10-22
128	lotto-master	generation	lotto	number_generated	\N	sess_1761132310647_pnec3bnw0	user_1761132310647_nus4jhizp	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [13, 15, 18, 19, 34, 44], "success": true, "algorithm": "frequency", "duration_ms": 122}	2025-10-22 11:25:25.187049	2025-10-22
131	lotto-master	generation	lotto	number_generated	\N	sess_1761132310647_pnec3bnw0	user_1761132310647_nus4jhizp	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [1, 3, 13, 15, 20, 31], "success": true, "algorithm": "frequency", "duration_ms": 37}	2025-10-22 11:25:25.193668	2025-10-22
130	lotto-master	generation	lotto	number_generated	\N	sess_1761132310647_pnec3bnw0	user_1761132310647_nus4jhizp	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [12, 13, 17, 26, 37, 45], "success": true, "algorithm": "frequency", "duration_ms": 41}	2025-10-22 11:25:25.191218	2025-10-22
132	lotto-master	generation	lotto	number_generated	\N	sess_1761132310647_pnec3bnw0	user_1761132310647_nus4jhizp	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [3, 7, 11, 13, 18, 33], "success": true, "algorithm": "frequency", "duration_ms": 58}	2025-10-22 11:25:25.190443	2025-10-22
129	lotto-master	generation	lotto	number_generated	\N	sess_1761132310647_pnec3bnw0	user_1761132310647_nus4jhizp	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [19, 27, 38, 39, 43, 45], "success": true, "algorithm": "frequency", "duration_ms": 105}	2025-10-22 11:25:25.19094	2025-10-22
133	lotto-master	generation	lotto	number_generated	\N	sess_1761132310647_pnec3bnw0	user_1761132310647_nus4jhizp	211.234.200.204	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [11, 12, 18, 20, 39, 43], "success": true, "algorithm": "frequency", "duration_ms": 55}	2025-10-22 11:25:29.39577	2025-10-22
134	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-28 07:47:59.051793	2025-10-28
135	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency", "duration_ms": 6, "numbers_preview": [12, 13, 19, 33, 37, 43]}	2025-10-28 07:48:01.401845	2025-10-28
136	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [12, 13, 19, 33, 37, 43], "success": true, "algorithm": "frequency", "duration_ms": 21}	2025-10-28 07:48:04.046953	2025-10-28
137	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-28 07:48:29.063021	2025-10-28
138	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-28 07:48:29.132247	2025-10-28
139	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 2, "numbers_preview": [2, 9, 15, 31, 40, 41]}	2025-10-28 07:54:33.498194	2025-10-28
140	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-28 07:54:35.942515	2025-10-28
141	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 9, 15, 31, 40, 41], "success": true, "algorithm": "random", "duration_ms": 27}	2025-10-28 07:54:35.968566	2025-10-28
142	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 0, "numbers_preview": [1, 5, 9, 15, 31, 45]}	2025-10-28 07:54:52.830036	2025-10-28
143	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 5, 9, 15, 31, 45], "success": true, "algorithm": "random", "duration_ms": 14}	2025-10-28 07:54:55.956055	2025-10-28
145	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-29 08:02:26.897013	2025-10-29
146	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-29 08:02:31.891784	2025-10-29
147	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-29 08:02:31.906319	2025-10-29
148	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-29 08:03:22.160473	2025-10-29
149	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-29 08:03:23.260968	2025-10-29
150	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-29 08:03:27.063955	2025-10-29
151	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-29 08:03:27.064163	2025-10-29
152	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-29 08:04:12.130162	2025-10-29
153	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-29 08:04:12.140309	2025-10-29
154	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-29 08:32:16.659038	2025-10-29
155	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-29 08:32:21.653635	2025-10-29
156	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-29 08:32:21.666419	2025-10-29
157	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-29 08:32:26.653851	2025-10-29
158	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-29 08:32:31.65409	2025-10-29
159	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-29 08:32:31.654108	2025-10-29
160	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-29 08:32:31.664969	2025-10-29
161	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-29 09:16:03.326641	2025-10-29
162	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 00:04:52.929246	2025-10-30
163	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-30 00:04:57.925433	2025-10-30
164	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 00:04:57.933411	2025-10-30
165	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	172.20.0.1	curl/7.81.0	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 113, "numbers_preview": [14, 18, 20, 34, 37, 40]}	2025-10-30 00:24:08.899375	2025-10-30
166	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	172.20.0.1	curl/7.81.0	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "frequency-db", "duration_ms": 5, "numbers_preview": [1, 6, 19, 21, 43, 45]}	2025-10-30 00:24:09.495182	2025-10-30
167	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 00:49:02.756105	2025-10-30
168	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 00:49:02.767596	2025-10-30
169	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 00:50:07.791148	2025-10-30
170	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-30 00:50:07.803415	2025-10-30
171	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 00:50:52.809906	2025-10-30
172	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-10-30 00:50:57.812874	2025-10-30
173	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 00:51:02.813177	2025-10-30
174	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-30 00:54:58.125274	2025-10-30
175	lotto-master	generation	lotto	numbers_generated	5.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 5, "algorithm": "low-frequency-db", "duration_ms": 323, "numbers_preview": [1, 25, 28, 30, 31, 32]}	2025-10-30 00:55:05.034388	2025-10-30
176	lotto-master	generation	lotto	numbers_generated	5.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 5, "algorithm": "low-frequency-db", "duration_ms": 16, "numbers_preview": [28, 29, 31, 32, 39, 42]}	2025-10-30 00:55:09.112598	2025-10-30
177	lotto-master	generation	lotto	numbers_generated	5.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 5, "algorithm": "low-frequency-db", "duration_ms": 40, "numbers_preview": [9, 10, 30, 31, 41, 44]}	2025-10-30 00:55:10.289746	2025-10-30
178	lotto-master	generation	lotto	numbers_generated	5.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 5, "algorithm": "low-frequency-db", "duration_ms": 57, "numbers_preview": [8, 9, 29, 31, 39, 44]}	2025-10-30 00:55:11.140445	2025-10-30
179	lotto-master	generation	lotto	numbers_generated	10.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 10, "algorithm": "low-frequency-db", "duration_ms": 32, "numbers_preview": [1, 16, 25, 31, 43, 44]}	2025-10-30 00:55:13.166124	2025-10-30
180	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 01:29:13.728345	2025-10-30
181	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-30 01:29:18.727279	2025-10-30
182	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 01:29:18.727414	2025-10-30
183	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-10-30 01:29:18.727544	2025-10-30
184	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/my-numbers	http://203.245.30.6:3001/my-numbers	desktop	\N	\N	\N	2025-10-30 01:29:18.727733	2025-10-30
185	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-10-30 01:29:23.729546	2025-10-30
186	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 01:29:38.739038	2025-10-30
187	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "pattern", "duration_ms": 1, "numbers_preview": [3, 15, 22, 23, 38, 42]}	2025-10-30 01:29:41.467511	2025-10-30
188	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [3, 15, 22, 23, 38, 42], "success": true, "algorithm": "pattern", "duration_ms": 17}	2025-10-30 01:29:43.73973	2025-10-30
189	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/my-numbers	http://203.245.30.6:3001/my-numbers	desktop	\N	\N	\N	2025-10-30 01:29:48.739283	2025-10-30
190	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-30 01:31:03.791012	2025-10-30
191	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 01:31:03.801618	2025-10-30
192	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-10-30 01:31:08.791781	2025-10-30
193	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 01:31:13.791973	2025-10-30
194	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 01:31:18.794994	2025-10-30
195	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-30 01:31:23.795179	2025-10-30
196	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 01:31:23.795586	2025-10-30
197	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 01:31:23.809048	2025-10-30
198	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-30 01:31:38.798958	2025-10-30
199	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 01:31:38.799077	2025-10-30
200	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 01:34:38.928347	2025-10-30
201	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 05:58:17.948328	2025-10-30
202	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 06:06:03.504009	2025-10-30
203	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-30 06:06:33.510758	2025-10-30
204	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 06:06:38.511508	2025-10-30
205	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-10-30 06:06:38.532361	2025-10-30
206	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/my-numbers	http://203.245.30.6:3001/my-numbers	desktop	\N	\N	\N	2025-10-30 06:06:43.511907	2025-10-30
207	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 06:06:43.512176	2025-10-30
208	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 07:12:52.918259	2025-10-30
209	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 07:12:57.952672	2025-10-30
210	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 07:13:07.957817	2025-10-30
211	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-30 07:13:12.958272	2025-10-30
212	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 07:13:12.958762	2025-10-30
213	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 07:13:12.959019	2025-10-30
214	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-10-30 07:13:12.958779	2025-10-30
215	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 07:16:34.199351	2025-10-30
216	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 07:17:09.219546	2025-10-30
217	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 07:23:00.623822	2025-10-30
218	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 07:23:10.448649	2025-10-30
219	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-10-30 07:23:15.462701	2025-10-30
220	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-10-30 07:23:15.462194	2025-10-30
221	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-10-30 07:23:20.48674	2025-10-30
222	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-10-30 07:25:01.392656	2025-10-30
\.


--
-- Data for Name: analytics_events_2025_11; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.analytics_events_2025_11 (id, project_id, event_type, event_category, event_name, event_value, session_id, user_id, ip_address, user_agent, page_url, referrer, device_type, browser, os, metadata, created_at, date) FROM stdin;
223	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	tablet	\N	\N	\N	2025-11-02 01:08:33.447371	2025-11-02
224	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	tablet	\N	\N	\N	2025-11-02 01:08:43.446082	2025-11-02
225	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	tablet	\N	\N	\N	2025-11-02 01:08:43.44617	2025-11-02
226	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	tablet	\N	\N	\N	2025-11-02 01:08:43.44626	2025-11-02
227	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	tablet	\N	\N	\N	2025-11-02 01:11:03.530366	2025-11-02
228	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	tablet	\N	\N	\N	2025-11-02 02:26:22.789185	2025-11-02
229	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	tablet	\N	\N	\N	2025-11-02 02:26:27.789374	2025-11-02
230	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	tablet	\N	\N	\N	2025-11-02 02:26:52.803056	2025-11-02
231	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	tablet	\N	\N	\N	2025-11-02 02:27:02.808944	2025-11-02
232	today-fortune	page_view	page_view	page_view	\N	mhh3h48nurd9vhwg4a9	363e3ce9-bff5-482b-89fb-27cc23a4ef7a	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "profile", "page_path": "/", "timestamp": "2025-11-02T02:31:12.313Z", "user_agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 875, "screen_height": 971, "viewport_width": 874, "viewport_height": 820}	2025-11-02 02:31:12.972124	2025-11-02
233	today-fortune	page_view	page_view	page_view	\N	mhh3h48nurd9vhwg4a9	363e3ce9-bff5-482b-89fb-27cc23a4ef7a	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "app_loaded", "page_path": "/", "timestamp": "2025-11-02T02:31:12.312Z", "user_agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36", "screen_width": 875, "screen_height": 971, "viewport_width": 874, "viewport_height": 820}	2025-11-02 02:31:12.98426	2025-11-02
234	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/my-numbers	http://203.245.30.6:3001/my-numbers	tablet	\N	\N	\N	2025-11-02 02:34:03.585619	2025-11-02
235	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	tablet	\N	\N	\N	2025-11-02 02:34:03.602563	2025-11-02
237	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	tablet	\N	\N	\N	2025-11-02 02:34:08.584499	2025-11-02
236	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	tablet	\N	\N	\N	2025-11-02 02:34:08.58452	2025-11-02
238	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 3, "numbers_preview": [7, 10, 12, 14, 20, 22]}	2025-11-02 02:34:15.262071	2025-11-02
239	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [7, 10, 12, 14, 20, 22], "success": true, "algorithm": "random", "duration_ms": 102}	2025-11-02 02:34:18.627483	2025-11-02
240	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 15, "numbers_preview": [13, 14, 17, 33, 34, 40]}	2025-11-02 02:34:22.759586	2025-11-02
241	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.227.36	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [13, 14, 17, 33, 34, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 70}	2025-11-02 02:34:23.646154	2025-11-02
243	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-02 11:51:13.096248	2025-11-02
242	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-11-02 11:51:13.096419	2025-11-02
244	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-02 11:51:18.100197	2025-11-02
245	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-02 11:51:23.102141	2025-11-02
246	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-11-02 11:51:28.102377	2025-11-02
247	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-11-02 11:51:28.10254	2025-11-02
248	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-11-02 11:51:33.104119	2025-11-02
249	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-02 11:51:38.107063	2025-11-02
250	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-11-02 11:52:13.115986	2025-11-02
251	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-11-02 11:52:23.11888	2025-11-02
252	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-11-02 11:52:53.161824	2025-11-02
253	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-02 11:52:58.163885	2025-11-02
254	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-03 00:24:58.022808	2025-11-03
256	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-03 00:26:43.100493	2025-11-03
255	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-11-03 00:26:43.100069	2025-11-03
257	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-03 00:26:43.112225	2025-11-03
258	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-03 00:26:48.099878	2025-11-03
259	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-03 00:26:53.102542	2025-11-03
260	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-03 00:26:53.102691	2025-11-03
261	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-11-03 00:27:38.126548	2025-11-03
262	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-03 00:27:43.129025	2025-11-03
263	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-11-03 00:27:48.129102	2025-11-03
264	lotto-master	generation	lotto	numbers_generated	5.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 5, "algorithm": "ai-mixed-db", "duration_ms": 77, "numbers_preview": [12, 14, 19, 20, 27, 34]}	2025-11-03 00:27:52.440573	2025-11-03
265	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-03 00:42:08.802108	2025-11-03
266	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 6, "numbers_preview": [13, 14, 20, 27, 37, 45]}	2025-11-03 07:14:51.014639	2025-11-03
267	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-03 07:14:52.172307	2025-11-03
268	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [13, 14, 20, 27, 37, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 25}	2025-11-03 07:14:52.172339	2025-11-03
269	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "balanced-db", "duration_ms": 15, "numbers_preview": [7, 8, 9, 17, 34, 41]}	2025-11-03 07:14:55.831285	2025-11-03
270	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [7, 8, 9, 17, 34, 41], "success": true, "algorithm": "balanced-db", "duration_ms": 29}	2025-11-03 07:14:57.17413	2025-11-03
271	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "balanced-db", "duration_ms": 3, "numbers_preview": [10, 20, 23, 33, 37, 42]}	2025-11-03 07:14:58.398535	2025-11-03
272	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "balanced-db", "duration_ms": 3, "numbers_preview": [3, 5, 12, 23, 29, 45]}	2025-11-03 07:15:00.117464	2025-11-03
273	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "balanced-db", "duration_ms": 4, "numbers_preview": [8, 17, 18, 20, 23, 41]}	2025-11-03 07:15:00.498249	2025-11-03
274	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "balanced-db", "duration_ms": 3, "numbers_preview": [13, 14, 20, 29, 32, 35]}	2025-11-03 07:15:00.8802	2025-11-03
275	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [10, 20, 23, 33, 37, 42], "success": true, "algorithm": "balanced-db", "duration_ms": 14}	2025-11-03 07:15:02.17421	2025-11-03
289	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [9, 14, 17, 25, 30, 35], "success": true, "algorithm": "cold-db", "duration_ms": 17}	2025-11-03 07:15:07.176728	2025-11-03
303	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 5, 20, 22, 35, 43], "success": true, "algorithm": "cold-db", "duration_ms": 15}	2025-11-03 07:15:09.424197	2025-11-03
276	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [3, 5, 12, 23, 29, 45], "success": true, "algorithm": "balanced-db", "duration_ms": 16}	2025-11-03 07:15:02.174461	2025-11-03
277	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [8, 17, 18, 20, 23, 41], "success": true, "algorithm": "balanced-db", "duration_ms": 16}	2025-11-03 07:15:02.174384	2025-11-03
278	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [13, 14, 20, 29, 32, 35], "success": true, "algorithm": "balanced-db", "duration_ms": 15}	2025-11-03 07:15:02.223837	2025-11-03
279	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [5, 6, 7, 10, 18, 19]}	2025-11-03 07:15:03.937116	2025-11-03
280	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 8, "numbers_preview": [6, 7, 14, 19, 31, 32]}	2025-11-03 07:15:05.255085	2025-11-03
281	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 5, "numbers_preview": [7, 10, 16, 23, 26, 31]}	2025-11-03 07:15:05.712431	2025-11-03
282	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 5, "numbers_preview": [9, 14, 17, 25, 30, 35]}	2025-11-03 07:15:06.134495	2025-11-03
283	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 7, "numbers_preview": [2, 5, 30, 32, 39, 43]}	2025-11-03 07:15:06.499984	2025-11-03
284	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 8, "numbers_preview": [11, 17, 30, 35, 41, 42]}	2025-11-03 07:15:06.856218	2025-11-03
285	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 7, "numbers_preview": [1, 5, 21, 22, 39, 41]}	2025-11-03 07:15:07.16854	2025-11-03
286	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 6, 7, 10, 18, 19], "success": true, "algorithm": "cold-db", "duration_ms": 21}	2025-11-03 07:15:07.175022	2025-11-03
287	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [6, 7, 14, 19, 31, 32], "success": true, "algorithm": "cold-db", "duration_ms": 24}	2025-11-03 07:15:07.175474	2025-11-03
288	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [7, 10, 16, 23, 26, 31], "success": true, "algorithm": "cold-db", "duration_ms": 22}	2025-11-03 07:15:07.176418	2025-11-03
290	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 5, 30, 32, 39, 43], "success": true, "algorithm": "cold-db", "duration_ms": 23}	2025-11-03 07:15:07.176774	2025-11-03
291	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [11, 17, 30, 35, 41, 42], "success": true, "algorithm": "cold-db", "duration_ms": 36}	2025-11-03 07:15:07.177038	2025-11-03
292	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 6, "numbers_preview": [2, 19, 20, 21, 25, 44]}	2025-11-03 07:15:07.397038	2025-11-03
293	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [4, 7, 17, 30, 31, 32]}	2025-11-03 07:15:07.61606	2025-11-03
294	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [2, 5, 20, 22, 35, 43]}	2025-11-03 07:15:08.276431	2025-11-03
295	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [11, 16, 19, 32, 38, 41]}	2025-11-03 07:15:08.522707	2025-11-03
296	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [19, 20, 22, 31, 35, 38]}	2025-11-03 07:15:08.715673	2025-11-03
297	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [2, 9, 11, 19, 30, 39]}	2025-11-03 07:15:08.883202	2025-11-03
298	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [7, 11, 19, 22, 30, 31]}	2025-11-03 07:15:09.074899	2025-11-03
299	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [6, 19, 25, 26, 30, 44]}	2025-11-03 07:15:09.233338	2025-11-03
300	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [7, 17, 19, 26, 43, 44]}	2025-11-03 07:15:09.408144	2025-11-03
305	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 5, 21, 22, 39, 41], "success": true, "algorithm": "cold-db", "duration_ms": 19}	2025-11-03 07:15:09.424014	2025-11-03
301	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 19, 20, 21, 25, 44], "success": true, "algorithm": "cold-db", "duration_ms": 22}	2025-11-03 07:15:09.424094	2025-11-03
306	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [11, 16, 19, 32, 38, 41], "success": true, "algorithm": "cold-db", "duration_ms": 14}	2025-11-03 07:15:09.424546	2025-11-03
304	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [19, 20, 22, 31, 35, 38], "success": true, "algorithm": "cold-db", "duration_ms": 17}	2025-11-03 07:15:09.424425	2025-11-03
503	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "recent-db", "duration_ms": 15, "numbers_preview": [5, 9, 28, 34, 37, 43]}	2025-11-12 05:53:55.874857	2025-11-12
504	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 9, 28, 34, 37, 43], "success": true, "algorithm": "recent-db", "duration_ms": 30}	2025-11-12 05:53:57.847722	2025-11-12
505	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/my-numbers	http://203.245.30.6:3001/my-numbers	desktop	\N	\N	\N	2025-11-12 05:54:17.854572	2025-11-12
309	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [7, 17, 19, 26, 43, 44], "success": true, "algorithm": "cold-db", "duration_ms": 17}	2025-11-03 07:15:09.455961	2025-11-03
506	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-15 08:14:16.871955	2025-11-15
308	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [6, 19, 25, 26, 30, 44], "success": true, "algorithm": "cold-db", "duration_ms": 22}	2025-11-03 07:15:09.454013	2025-11-03
507	today-fortune	page_view	page_view	page_view	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "app_loaded", "page_path": "/", "timestamp": "2025-11-15T08:17:16.722Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:18.83116	2025-11-15
307	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 9, 11, 19, 30, 39], "success": true, "algorithm": "cold-db", "duration_ms": 15}	2025-11-03 07:15:09.453801	2025-11-03
508	today-fortune	page_view	page_view	page_view	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "profile", "page_path": "/", "timestamp": "2025-11-15T08:17:16.722Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:18.849268	2025-11-15
509	today-fortune	page_unload	page_unload	page_unload	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_path": "/", "timestamp": "2025-11-15T08:17:32.080Z", "time_spent": 16, "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:34.194767	2025-11-15
510	today-fortune	page_view	page_view	page_view	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "app_loaded", "page_path": "/", "timestamp": "2025-11-15T08:17:32.156Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:34.238662	2025-11-15
511	today-fortune	page_view	page_view	page_view	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "home", "page_path": "/", "timestamp": "2025-11-15T08:17:32.157Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:34.255522	2025-11-15
512	today-fortune	fortune_generated	fortune_generated	fortune_generated	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"grade": "normal", "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "has_tarot": true, "page_path": "/", "timestamp": "2025-11-15T08:17:32.207Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "total_score": 41, "fortune_type": "daily", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:34.281111	2025-11-15
513	today-fortune	page_view	page_view	page_view	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "profile", "page_path": "/", "timestamp": "2025-11-15T08:17:39.805Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:41.903097	2025-11-15
514	today-fortune	page_view	page_view	page_view	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "profile", "page_path": "/", "timestamp": "2025-11-15T08:17:44.839Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:46.942881	2025-11-15
515	today-fortune	page_unload	page_unload	page_unload	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_path": "/", "timestamp": "2025-11-15T08:17:49.905Z", "time_spent": 18, "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:52.035909	2025-11-15
516	today-fortune	page_view	page_view	page_view	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "app_loaded", "page_path": "/", "timestamp": "2025-11-15T08:17:49.997Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:52.082036	2025-11-15
310	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [7, 11, 19, 22, 30, 31], "success": true, "algorithm": "cold-db", "duration_ms": 15}	2025-11-03 07:15:09.523804	2025-11-03
311	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 8, "numbers_preview": [5, 6, 10, 22, 30, 44]}	2025-11-03 07:15:09.583164	2025-11-03
517	today-fortune	page_view	page_view	page_view	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_name": "home", "page_path": "/", "timestamp": "2025-11-15T08:17:49.998Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:52.098218	2025-11-15
518	today-fortune	fortune_generated	fortune_generated	fortune_generated	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"grade": "normal", "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "has_tarot": true, "page_path": "/", "timestamp": "2025-11-15T08:17:50.016Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "total_score": 41, "fortune_type": "daily", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:52.102664	2025-11-15
519	today-fortune	tarot_drawn	tarot_drawn	tarot_drawn	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"card_id": 0, "language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "card_name": "The Fool", "page_path": "/", "timestamp": "2025-11-15T08:17:52.663Z", "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "card_name_ko": "바보", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:17:54.793316	2025-11-15
520	today-fortune	page_unload	page_unload	page_unload	\N	mi00k8t48u60xlwoilb	017dfcaa-852a-4a79-913c-68fb1f557f16	\N	\N	\N	\N	\N	\N	\N	{"language": "ko-KR", "page_url": "http://203.245.30.6:3002/", "page_path": "/", "timestamp": "2025-11-15T08:18:01.627Z", "time_spent": 12, "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36", "screen_width": 1440, "screen_height": 900, "viewport_width": 1440, "viewport_height": 754}	2025-11-15 08:18:03.78243	2025-11-15
312	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 6, "numbers_preview": [10, 20, 21, 39, 42, 44]}	2025-11-03 07:15:09.750363	2025-11-03
313	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [2, 9, 16, 17, 32, 44]}	2025-11-03 07:15:09.91681	2025-11-03
314	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [9, 17, 18, 22, 42, 44]}	2025-11-03 07:15:10.082864	2025-11-03
315	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [5, 18, 23, 25, 26, 44]}	2025-11-03 07:15:10.242827	2025-11-03
316	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 25, "numbers_preview": [7, 10, 14, 17, 19, 25]}	2025-11-03 07:15:10.461704	2025-11-03
317	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [1, 2, 6, 18, 25, 39]}	2025-11-03 07:15:10.57644	2025-11-03
318	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [1, 2, 6, 18, 25, 39]}	2025-11-03 07:15:11.030415	2025-11-03
319	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 6, "numbers_preview": [19, 25, 26, 32, 35, 41]}	2025-11-03 07:15:11.209993	2025-11-03
320	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [5, 7, 11, 18, 20, 25]}	2025-11-03 07:15:11.363423	2025-11-03
321	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 6, 10, 22, 30, 44], "success": true, "algorithm": "cold-db", "duration_ms": 22}	2025-11-03 07:15:11.373265	2025-11-03
346	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 2, 5, 9, 32, 41], "success": true, "algorithm": "cold-db", "duration_ms": 14}	2025-11-03 07:15:17.177483	2025-11-03
521	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-15 12:13:32.808759	2025-11-15
323	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [9, 17, 18, 22, 42, 44], "success": true, "algorithm": "cold-db", "duration_ms": 16}	2025-11-03 07:15:11.373548	2025-11-03
522	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-18 08:51:46.371372	2025-11-18
523	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-11-18 08:51:51.378541	2025-11-18
324	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [7, 10, 14, 17, 19, 25], "success": true, "algorithm": "cold-db", "duration_ms": 47}	2025-11-03 07:15:11.373644	2025-11-03
524	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-18 08:51:56.380257	2025-11-18
325	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 18, 23, 25, 26, 44], "success": true, "algorithm": "cold-db", "duration_ms": 18}	2025-11-03 07:15:11.373583	2025-11-03
525	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-11-18 08:52:51.408732	2025-11-18
326	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 2, 6, 18, 25, 39], "success": true, "algorithm": "cold-db", "duration_ms": 16}	2025-11-03 07:15:11.373725	2025-11-03
526	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-18 08:53:41.437151	2025-11-18
527	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 6, "numbers_preview": [4, 25, 29, 41, 43, 44]}	2025-11-18 08:53:47.812173	2025-11-18
528	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [2, 10, 16, 26, 35, 42]}	2025-11-18 08:53:51.40355	2025-11-18
529	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 25, 29, 41, 43, 44], "success": true, "algorithm": "low-frequency-db", "duration_ms": 22}	2025-11-18 08:53:51.437936	2025-11-18
542	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [15, 23, 25, 29, 41, 42], "success": true, "algorithm": "low-frequency-db", "duration_ms": 18}	2025-11-18 08:53:55.95327	2025-11-18
569	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 5, 8, 16, 29, 43], "success": true, "algorithm": "low-frequency-db", "duration_ms": 18}	2025-11-18 08:54:00.104614	2025-11-18
590	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [15, 23, 24, 36, 41, 42], "success": true, "algorithm": "low-frequency-db", "duration_ms": 15}	2025-11-18 08:54:06.439276	2025-11-18
327	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [10, 20, 21, 39, 42, 44], "success": true, "algorithm": "cold-db", "duration_ms": 20}	2025-11-03 07:15:11.373367	2025-11-03
336	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 17, 25, 39, 43, 44], "success": true, "algorithm": "cold-db", "duration_ms": 15}	2025-11-03 07:15:12.174817	2025-11-03
344	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 9, 18, 20, 30, 35], "success": true, "algorithm": "cold-db", "duration_ms": 16}	2025-11-03 07:15:17.177331	2025-11-03
530	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 10, 16, 26, 35, 42], "success": true, "algorithm": "low-frequency-db", "duration_ms": 17}	2025-11-18 08:53:51.446967	2025-11-18
531	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 6, "numbers_preview": [9, 16, 23, 30, 42, 44]}	2025-11-18 08:53:52.674011	2025-11-18
532	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [15, 23, 25, 29, 41, 42]}	2025-11-18 08:53:53.414933	2025-11-18
533	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 2, "numbers_preview": [5, 9, 22, 28, 31, 41]}	2025-11-18 08:53:53.863672	2025-11-18
534	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [5, 6, 8, 22, 41, 42]}	2025-11-18 08:53:54.176002	2025-11-18
535	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [4, 11, 16, 25, 31, 41]}	2025-11-18 08:53:54.460209	2025-11-18
536	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [23, 29, 35, 41, 42, 44]}	2025-11-18 08:53:54.681619	2025-11-18
537	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [2, 4, 5, 26, 32, 35]}	2025-11-18 08:53:54.89589	2025-11-18
538	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [1, 4, 6, 9, 25, 29]}	2025-11-18 08:53:55.127854	2025-11-18
539	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [8, 11, 16, 25, 30, 32]}	2025-11-18 08:53:55.344347	2025-11-18
540	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [10, 11, 16, 24, 25, 26]}	2025-11-18 08:53:55.938605	2025-11-18
541	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [9, 16, 23, 30, 42, 44], "success": true, "algorithm": "low-frequency-db", "duration_ms": 25}	2025-11-18 08:53:55.953182	2025-11-18
570	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [6, 8, 9, 10, 28, 43], "success": true, "algorithm": "low-frequency-db", "duration_ms": 20}	2025-11-18 08:54:00.10468	2025-11-18
588	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [8, 9, 24, 28, 31, 41], "success": true, "algorithm": "low-frequency-db", "duration_ms": 19}	2025-11-18 08:54:06.439097	2025-11-18
328	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [19, 25, 26, 32, 35, 41], "success": true, "algorithm": "cold-db", "duration_ms": 20}	2025-11-03 07:15:11.374301	2025-11-03
348	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [7, 9, 14, 16, 19, 43], "success": true, "algorithm": "cold-db", "duration_ms": 15}	2025-11-03 07:15:17.177652	2025-11-03
543	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 4, 6, 9, 25, 29], "success": true, "algorithm": "low-frequency-db", "duration_ms": 20}	2025-11-18 08:53:56.046914	2025-11-18
571	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [6, 23, 28, 36, 41, 42], "success": true, "algorithm": "low-frequency-db", "duration_ms": 22}	2025-11-18 08:54:00.104483	2025-11-18
573	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 6, "numbers_preview": [24, 26, 29, 30, 41, 44]}	2025-11-18 08:54:00.43634	2025-11-18
574	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [2, 5, 8, 15, 23, 41]}	2025-11-18 08:54:00.801172	2025-11-18
575	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [5, 23, 24, 29, 30, 42]}	2025-11-18 08:54:01.156089	2025-11-18
576	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [24, 26, 29, 30, 41, 44], "success": true, "algorithm": "low-frequency-db", "duration_ms": 21}	2025-11-18 08:54:01.438597	2025-11-18
587	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 5, 8, 10, 24, 25], "success": true, "algorithm": "low-frequency-db", "duration_ms": 17}	2025-11-18 08:54:06.439039	2025-11-18
329	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 2, 6, 18, 25, 39], "success": true, "algorithm": "cold-db", "duration_ms": 23}	2025-11-03 07:15:11.374342	2025-11-03
335	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [10, 17, 21, 22, 35, 44], "success": true, "algorithm": "cold-db", "duration_ms": 18}	2025-11-03 07:15:12.174717	2025-11-03
337	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [5, 10, 18, 19, 32, 38]}	2025-11-03 07:15:12.329132	2025-11-03
338	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 5, "numbers_preview": [1, 9, 18, 20, 30, 35]}	2025-11-03 07:15:12.518775	2025-11-03
339	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 2, "numbers_preview": [14, 17, 19, 26, 32, 41]}	2025-11-03 07:15:12.719853	2025-11-03
340	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [7, 18, 21, 26, 39, 41]}	2025-11-03 07:15:12.933015	2025-11-03
341	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [1, 2, 5, 9, 32, 41]}	2025-11-03 07:15:13.145127	2025-11-03
342	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [7, 9, 14, 16, 19, 43]}	2025-11-03 07:15:13.404212	2025-11-03
343	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 10, 18, 19, 32, 38], "success": true, "algorithm": "cold-db", "duration_ms": 19}	2025-11-03 07:15:17.177245	2025-11-03
349	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/my-numbers	http://203.245.30.6:3001/my-numbers	desktop	\N	\N	\N	2025-11-03 07:15:22.17736	2025-11-03
544	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [23, 29, 35, 41, 42, 44], "success": true, "algorithm": "low-frequency-db", "duration_ms": 21}	2025-11-18 08:53:56.047112	2025-11-18
572	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 11, 23, 25, 26, 44], "success": true, "algorithm": "low-frequency-db", "duration_ms": 22}	2025-11-18 08:54:00.104558	2025-11-18
577	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 5, 8, 15, 23, 41], "success": true, "algorithm": "low-frequency-db", "duration_ms": 20}	2025-11-18 08:54:01.438686	2025-11-18
586	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 6, 15, 16, 31, 41], "success": true, "algorithm": "low-frequency-db", "duration_ms": 22}	2025-11-18 08:54:06.438972	2025-11-18
330	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 7, 11, 18, 20, 25], "success": true, "algorithm": "cold-db", "duration_ms": 16}	2025-11-03 07:15:11.374416	2025-11-03
347	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [7, 18, 21, 26, 39, 41], "success": true, "algorithm": "cold-db", "duration_ms": 15}	2025-11-03 07:15:17.177466	2025-11-03
545	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 11, 16, 25, 31, 41], "success": true, "algorithm": "low-frequency-db", "duration_ms": 20}	2025-11-18 08:53:56.047288	2025-11-18
568	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 8, 16, 24, 32, 43], "success": true, "algorithm": "low-frequency-db", "duration_ms": 16}	2025-11-18 08:54:00.104163	2025-11-18
578	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 23, 24, 29, 30, 42], "success": true, "algorithm": "low-frequency-db", "duration_ms": 17}	2025-11-18 08:54:01.438749	2025-11-18
579	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 5, "numbers_preview": [9, 10, 11, 15, 16, 42]}	2025-11-18 08:54:01.602283	2025-11-18
580	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [4, 6, 15, 16, 31, 41]}	2025-11-18 08:54:02.1921	2025-11-18
581	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [2, 5, 8, 10, 24, 25]}	2025-11-18 08:54:02.75197	2025-11-18
582	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [8, 9, 24, 28, 31, 41]}	2025-11-18 08:54:03.441707	2025-11-18
583	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [5, 22, 25, 30, 36, 44]}	2025-11-18 08:54:04.025836	2025-11-18
584	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [15, 23, 24, 36, 41, 42]}	2025-11-18 08:54:04.932757	2025-11-18
585	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [9, 10, 11, 15, 16, 42], "success": true, "algorithm": "low-frequency-db", "duration_ms": 27}	2025-11-18 08:54:06.438918	2025-11-18
322	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 9, 16, 17, 32, 44], "success": true, "algorithm": "cold-db", "duration_ms": 17}	2025-11-03 07:15:11.373452	2025-11-03
331	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 5, "numbers_preview": [6, 9, 20, 23, 30, 42]}	2025-11-03 07:15:11.554733	2025-11-03
332	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [10, 17, 21, 22, 35, 44]}	2025-11-03 07:15:11.947886	2025-11-03
333	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [4, 17, 25, 39, 43, 44]}	2025-11-03 07:15:12.135254	2025-11-03
334	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [6, 9, 20, 23, 30, 42], "success": true, "algorithm": "cold-db", "duration_ms": 18}	2025-11-03 07:15:12.174632	2025-11-03
345	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [14, 17, 19, 26, 32, 41], "success": true, "algorithm": "cold-db", "duration_ms": 15}	2025-11-03 07:15:17.177397	2025-11-03
546	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 9, 22, 28, 31, 41], "success": true, "algorithm": "low-frequency-db", "duration_ms": 20}	2025-11-18 08:53:56.046728	2025-11-18
567	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 25, 30, 31, 35, 36], "success": true, "algorithm": "low-frequency-db", "duration_ms": 18}	2025-11-18 08:54:00.10386	2025-11-18
589	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 22, 25, 30, 36, 44], "success": true, "algorithm": "low-frequency-db", "duration_ms": 18}	2025-11-18 08:54:06.439184	2025-11-18
591	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/my-numbers	http://203.245.30.6:3001/my-numbers	desktop	\N	\N	\N	2025-11-18 08:54:31.446082	2025-11-18
350	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-04 12:52:54.406387	2025-11-04
547	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 6, 8, 22, 41, 42], "success": true, "algorithm": "low-frequency-db", "duration_ms": 20}	2025-11-18 08:53:56.047735	2025-11-18
566	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 25, 26, 35, 36, 41], "success": true, "algorithm": "low-frequency-db", "duration_ms": 17}	2025-11-18 08:54:00.103463	2025-11-18
351	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-04 12:53:04.408309	2025-11-04
549	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [10, 11, 16, 24, 25, 26], "success": true, "algorithm": "low-frequency-db", "duration_ms": 16}	2025-11-18 08:53:56.126422	2025-11-18
565	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [9, 16, 24, 26, 35, 44], "success": true, "algorithm": "low-frequency-db", "duration_ms": 19}	2025-11-18 08:54:00.103455	2025-11-18
352	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-11-04 12:53:04.408405	2025-11-04
550	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [8, 11, 16, 25, 30, 32], "success": true, "algorithm": "low-frequency-db", "duration_ms": 18}	2025-11-18 08:53:56.129007	2025-11-18
564	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 23, 25, 28, 29, 44], "success": true, "algorithm": "low-frequency-db", "duration_ms": 15}	2025-11-18 08:54:00.103379	2025-11-18
353	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/my-numbers	http://203.245.30.6:3001/my-numbers	desktop	\N	\N	\N	2025-11-05 06:12:37.176587	2025-11-05
548	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 4, 5, 26, 32, 35], "success": true, "algorithm": "low-frequency-db", "duration_ms": 18}	2025-11-18 08:53:56.125748	2025-11-18
551	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 6, "numbers_preview": [1, 2, 8, 15, 28, 42]}	2025-11-18 08:53:56.310002	2025-11-18
552	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 2, 8, 15, 28, 42], "success": true, "algorithm": "low-frequency-db", "duration_ms": 19}	2025-11-18 08:53:56.438095	2025-11-18
553	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [8, 10, 11, 16, 29, 32]}	2025-11-18 08:53:57.077772	2025-11-18
554	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [1, 23, 25, 28, 29, 44]}	2025-11-18 08:53:57.822237	2025-11-18
555	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [9, 16, 24, 26, 35, 44]}	2025-11-18 08:53:58.353281	2025-11-18
556	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [4, 25, 26, 35, 36, 41]}	2025-11-18 08:53:58.570938	2025-11-18
557	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [1, 25, 30, 31, 35, 36]}	2025-11-18 08:53:58.767346	2025-11-18
558	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [1, 8, 16, 24, 32, 43]}	2025-11-18 08:53:58.949381	2025-11-18
559	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 6, "numbers_preview": [6, 23, 28, 36, 41, 42]}	2025-11-18 08:53:59.148158	2025-11-18
560	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [1, 11, 23, 25, 26, 44]}	2025-11-18 08:53:59.344221	2025-11-18
561	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [1, 5, 8, 16, 29, 43]}	2025-11-18 08:53:59.52747	2025-11-18
562	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [6, 8, 9, 10, 28, 43]}	2025-11-18 08:54:00.088707	2025-11-18
563	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [8, 10, 11, 16, 29, 32], "success": true, "algorithm": "low-frequency-db", "duration_ms": 18}	2025-11-18 08:54:00.103294	2025-11-18
354	lotto-master	pageview	navigation	page_view	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-05 06:12:42.174979	2025-11-05
592	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-23 11:38:27.703131	2025-11-23
355	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	tablet	\N	\N	\N	2025-11-06 07:37:11.073895	2025-11-06
356	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [8, 16, 25, 26, 28, 41]}	2025-11-06 07:37:26.022093	2025-11-06
357	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [8, 16, 25, 26, 28, 41], "success": true, "algorithm": "low-frequency-db", "duration_ms": 61}	2025-11-06 07:37:26.080003	2025-11-06
358	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [22, 25, 31, 32, 38, 43]}	2025-11-06 07:37:30.978931	2025-11-06
359	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [22, 25, 31, 32, 38, 43], "success": true, "algorithm": "cold-db", "duration_ms": 64}	2025-11-06 07:37:31.079299	2025-11-06
360	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [4, 14, 16, 18, 21, 30]}	2025-11-06 07:37:31.670448	2025-11-06
361	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 2, "numbers_preview": [2, 9, 14, 30, 38, 41]}	2025-11-06 07:37:32.331116	2025-11-06
370	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [2, 9, 14, 30, 38, 41], "success": true, "algorithm": "cold-db", "duration_ms": 66}	2025-11-06 07:37:34.576988	2025-11-06
395	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [1, 2, 19, 23, 39, 44], "success": true, "algorithm": "cold-db", "duration_ms": 59}	2025-11-06 07:37:36.080133	2025-11-06
411	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [5, 10, 11, 18, 20, 38], "success": true, "algorithm": "cold-db", "duration_ms": 51}	2025-11-06 07:37:37.68724	2025-11-06
434	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 7, 14, 18, 27, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 60}	2025-11-06 07:37:55.388044	2025-11-06
460	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 18, 19, 33, 37, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 59}	2025-11-06 07:37:59.837239	2025-11-06
593	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-23 11:41:42.811237	2025-11-23
594	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-11-23 11:41:47.839431	2025-11-23
597	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-23 11:42:07.845466	2025-11-23
601	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-23 11:42:12.847075	2025-11-23
362	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [1, 11, 17, 22, 35, 39]}	2025-11-06 07:37:32.801656	2025-11-06
363	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 7, "numbers_preview": [7, 19, 20, 26, 30, 35]}	2025-11-06 07:37:33.104455	2025-11-06
364	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 5, "numbers_preview": [1, 10, 16, 35, 41, 43]}	2025-11-06 07:37:33.301979	2025-11-06
365	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [2, 20, 25, 26, 32, 44]}	2025-11-06 07:37:33.498444	2025-11-06
366	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [1, 14, 17, 21, 38, 42]}	2025-11-06 07:37:33.661494	2025-11-06
367	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [7, 16, 17, 19, 38, 44]}	2025-11-06 07:37:33.851086	2025-11-06
368	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [4, 11, 19, 26, 35, 39]}	2025-11-06 07:37:33.999259	2025-11-06
369	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 2, "numbers_preview": [6, 17, 18, 21, 23, 44]}	2025-11-06 07:37:34.52963	2025-11-06
371	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [4, 14, 16, 18, 21, 30], "success": true, "algorithm": "cold-db", "duration_ms": 69}	2025-11-06 07:37:34.577084	2025-11-06
417	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [2, 7, 17, 19, 26, 35], "success": true, "algorithm": "cold-db", "duration_ms": 63}	2025-11-06 07:37:37.688226	2025-11-06
421	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [13, 17, 18, 19, 27, 34]}	2025-11-06 07:37:53.711408	2025-11-06
423	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 3, "numbers_preview": [13, 14, 17, 19, 20, 27]}	2025-11-06 07:37:54.150503	2025-11-06
424	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 3, "numbers_preview": [3, 7, 14, 18, 27, 40]}	2025-11-06 07:37:54.44051	2025-11-06
429	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [3, 13, 20, 27, 34, 40]}	2025-11-06 07:37:55.340751	2025-11-06
430	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [13, 14, 17, 20, 27, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 73}	2025-11-06 07:37:55.38741	2025-11-06
462	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 17, 18, 19, 20, 37], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 74}	2025-11-06 07:37:59.837417	2025-11-06
595	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-23 11:41:52.840014	2025-11-23
596	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-11-23 11:42:07.845474	2025-11-23
373	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [1, 11, 17, 22, 35, 39], "success": true, "algorithm": "cold-db", "duration_ms": 73}	2025-11-06 07:37:34.577568	2025-11-06
393	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [5, 7, 23, 39, 41, 43], "success": true, "algorithm": "cold-db", "duration_ms": 58}	2025-11-06 07:37:36.080053	2025-11-06
413	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [2, 23, 25, 38, 41, 43], "success": true, "algorithm": "cold-db", "duration_ms": 56}	2025-11-06 07:37:37.687461	2025-11-06
435	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 12, 14, 27, 33, 37], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 59}	2025-11-06 07:37:55.388114	2025-11-06
465	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [14, 27, 33, 34, 37, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 70}	2025-11-06 07:37:59.837762	2025-11-06
598	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-23 11:42:07.858188	2025-11-23
602	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-23 11:42:12.847078	2025-11-23
372	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [7, 19, 20, 26, 30, 35], "success": true, "algorithm": "cold-db", "duration_ms": 49}	2025-11-06 07:37:34.577613	2025-11-06
396	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [5, 6, 26, 38, 39, 44], "success": true, "algorithm": "cold-db", "duration_ms": 45}	2025-11-06 07:37:36.08026	2025-11-06
409	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [5, 6, 9, 14, 18, 42], "success": true, "algorithm": "cold-db", "duration_ms": 56}	2025-11-06 07:37:37.686933	2025-11-06
437	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 14, 17, 27, 33, 37], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 50}	2025-11-06 07:37:55.388421	2025-11-06
440	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 3, "numbers_preview": [13, 18, 20, 27, 34, 45]}	2025-11-06 07:37:55.51095	2025-11-06
442	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 5, "numbers_preview": [3, 13, 17, 18, 27, 37]}	2025-11-06 07:37:55.861903	2025-11-06
443	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [12, 13, 19, 20, 33, 40]}	2025-11-06 07:37:56.020222	2025-11-06
445	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [13, 18, 20, 27, 34, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 50}	2025-11-06 07:37:56.088114	2025-11-06
461	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 7, 13, 14, 37, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 55}	2025-11-06 07:37:59.837398	2025-11-06
599	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-23 11:42:07.858336	2025-11-23
600	lotto-master	pageview	navigation	page_view	\N	sess_1762084268653_ip1si7lww	user_1762084268653_mybiuktf7	58.238.165.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-23 11:42:12.846943	2025-11-23
375	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [2, 20, 25, 26, 32, 44], "success": true, "algorithm": "cold-db", "duration_ms": 62}	2025-11-06 07:37:34.577794	2025-11-06
397	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [1, 7, 9, 21, 22, 26], "success": true, "algorithm": "cold-db", "duration_ms": 43}	2025-11-06 07:37:36.08035	2025-11-06
412	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [4, 19, 22, 32, 38, 43], "success": true, "algorithm": "cold-db", "duration_ms": 61}	2025-11-06 07:37:37.687377	2025-11-06
436	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 12, 13, 27, 37, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 51}	2025-11-06 07:37:55.388166	2025-11-06
446	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 13, 17, 18, 27, 37], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 53}	2025-11-06 07:37:56.088266	2025-11-06
448	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 7, "numbers_preview": [3, 12, 14, 19, 27, 34]}	2025-11-06 07:37:56.19224	2025-11-06
453	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 5, "numbers_preview": [14, 27, 33, 34, 37, 45]}	2025-11-06 07:37:57.630372	2025-11-06
455	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 5, "numbers_preview": [7, 13, 17, 19, 20, 45]}	2025-11-06 07:37:58.780622	2025-11-06
456	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 3, "numbers_preview": [13, 18, 19, 33, 40, 45]}	2025-11-06 07:37:59.299816	2025-11-06
457	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [3, 12, 19, 20, 33, 34]}	2025-11-06 07:37:59.789342	2025-11-06
463	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 12, 14, 19, 27, 34], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 52}	2025-11-06 07:37:59.837017	2025-11-06
468	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 3, "numbers_preview": [3, 7, 12, 20, 34, 37]}	2025-11-06 07:38:00.309982	2025-11-06
469	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 7, 12, 20, 34, 37], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 64}	2025-11-06 07:38:01.088299	2025-11-06
603	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/my-numbers	http://203.245.30.6:3001/my-numbers	desktop	\N	\N	\N	2025-11-24 03:05:12.839183	2025-11-24
604	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-24 03:05:12.83906	2025-11-24
605	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-11-24 03:05:22.840442	2025-11-24
606	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-24 03:05:22.841031	2025-11-24
607	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-24 03:05:47.853727	2025-11-24
374	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [1, 10, 16, 35, 41, 43], "success": true, "algorithm": "cold-db", "duration_ms": 53}	2025-11-06 07:37:34.577718	2025-11-06
392	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [2, 5, 11, 18, 19, 20], "success": true, "algorithm": "cold-db", "duration_ms": 64}	2025-11-06 07:37:36.079912	2025-11-06
410	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [2, 5, 10, 32, 38, 41], "success": true, "algorithm": "cold-db", "duration_ms": 64}	2025-11-06 07:37:37.686973	2025-11-06
439	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 7, 12, 19, 20, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 51}	2025-11-06 07:37:55.388515	2025-11-06
467	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [13, 18, 19, 33, 40, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 65}	2025-11-06 07:37:59.837858	2025-11-06
608	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "random", "duration_ms": 1, "numbers_preview": [9, 11, 16, 27, 31, 43]}	2025-11-24 03:05:49.033669	2025-11-24
609	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [9, 11, 16, 27, 31, 43], "success": true, "algorithm": "random", "duration_ms": 21}	2025-11-24 03:05:52.853157	2025-11-24
610	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [1, 9, 15, 29, 30, 42]}	2025-11-24 03:05:53.467702	2025-11-24
611	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [2, 4, 8, 16, 24, 43]}	2025-11-24 03:05:54.674118	2025-11-24
612	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [4, 5, 10, 22, 24, 36]}	2025-11-24 03:05:55.027231	2025-11-24
613	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [4, 5, 6, 24, 25, 41]}	2025-11-24 03:05:55.26837	2025-11-24
614	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 5, "numbers_preview": [2, 15, 28, 29, 41, 43]}	2025-11-24 03:05:55.483096	2025-11-24
615	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [1, 8, 11, 16, 23, 26]}	2025-11-24 03:05:55.699062	2025-11-24
616	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 3, "numbers_preview": [2, 9, 15, 16, 22, 36]}	2025-11-24 03:05:55.863036	2025-11-24
617	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [4, 10, 11, 23, 31, 43]}	2025-11-24 03:05:56.053207	2025-11-24
618	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "low-frequency-db", "duration_ms": 4, "numbers_preview": [5, 25, 26, 31, 42, 43]}	2025-11-24 03:05:56.266925	2025-11-24
619	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 9, 15, 29, 30, 42], "success": true, "algorithm": "low-frequency-db", "duration_ms": 24}	2025-11-24 03:05:57.854654	2025-11-24
376	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [1, 14, 17, 21, 38, 42], "success": true, "algorithm": "cold-db", "duration_ms": 56}	2025-11-06 07:37:34.625884	2025-11-06
377	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [7, 16, 17, 19, 38, 44], "success": true, "algorithm": "cold-db", "duration_ms": 58}	2025-11-06 07:37:34.62605	2025-11-06
391	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [2, 14, 16, 19, 22, 41], "success": true, "algorithm": "cold-db", "duration_ms": 51}	2025-11-06 07:37:36.079904	2025-11-06
394	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [11, 16, 23, 38, 43, 44], "success": true, "algorithm": "cold-db", "duration_ms": 54}	2025-11-06 07:37:36.079765	2025-11-06
398	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 5, "numbers_preview": [10, 18, 19, 26, 31, 41]}	2025-11-06 07:37:36.182956	2025-11-06
399	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 7, "numbers_preview": [5, 6, 9, 14, 18, 42]}	2025-11-06 07:37:36.322898	2025-11-06
400	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [5, 10, 11, 18, 20, 38]}	2025-11-06 07:37:36.490458	2025-11-06
401	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [2, 5, 10, 32, 38, 41]}	2025-11-06 07:37:36.649399	2025-11-06
402	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [2, 23, 25, 38, 41, 43]}	2025-11-06 07:37:36.808012	2025-11-06
403	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 6, "numbers_preview": [4, 19, 22, 32, 38, 43]}	2025-11-06 07:37:36.983074	2025-11-06
404	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [10, 17, 32, 39, 41, 43]}	2025-11-06 07:37:37.130139	2025-11-06
405	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [2, 11, 17, 20, 26, 35]}	2025-11-06 07:37:37.299851	2025-11-06
406	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [10, 17, 18, 23, 25, 35]}	2025-11-06 07:37:37.449152	2025-11-06
407	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 6, "numbers_preview": [2, 7, 17, 19, 26, 35]}	2025-11-06 07:37:37.642155	2025-11-06
408	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [10, 18, 19, 26, 31, 41], "success": true, "algorithm": "cold-db", "duration_ms": 96}	2025-11-06 07:37:37.686848	2025-11-06
415	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [2, 11, 17, 20, 26, 35], "success": true, "algorithm": "cold-db", "duration_ms": 57}	2025-11-06 07:37:37.68792	2025-11-06
418	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 19, "numbers_preview": [9, 17, 21, 23, 26, 42]}	2025-11-06 07:37:37.795894	2025-11-06
378	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [4, 11, 19, 26, 35, 39], "success": true, "algorithm": "cold-db", "duration_ms": 43}	2025-11-06 07:37:34.634759	2025-11-06
390	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [1, 5, 6, 19, 21, 22], "success": true, "algorithm": "cold-db", "duration_ms": 52}	2025-11-06 07:37:36.079673	2025-11-06
414	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [10, 17, 32, 39, 41, 43], "success": true, "algorithm": "cold-db", "duration_ms": 54}	2025-11-06 07:37:37.687693	2025-11-06
431	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [13, 17, 18, 19, 27, 34], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 68}	2025-11-06 07:37:55.387562	2025-11-06
466	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 12, 19, 20, 33, 34], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 70}	2025-11-06 07:37:59.837857	2025-11-06
620	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 5, 6, 24, 25, 41], "success": true, "algorithm": "low-frequency-db", "duration_ms": 16}	2025-11-24 03:05:57.939732	2025-11-24
379	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [6, 17, 18, 21, 23, 44], "success": true, "algorithm": "cold-db", "duration_ms": 68}	2025-11-06 07:37:34.634922	2025-11-06
380	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 30, "numbers_preview": [4, 17, 18, 20, 23, 42]}	2025-11-06 07:37:34.727992	2025-11-06
381	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [1, 5, 6, 19, 21, 22]}	2025-11-06 07:37:34.84897	2025-11-06
382	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [11, 16, 23, 38, 43, 44]}	2025-11-06 07:37:35.010689	2025-11-06
383	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 3, "numbers_preview": [2, 14, 16, 19, 22, 41]}	2025-11-06 07:37:35.17995	2025-11-06
384	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [2, 5, 11, 18, 19, 20]}	2025-11-06 07:37:35.346132	2025-11-06
385	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [5, 7, 23, 39, 41, 43]}	2025-11-06 07:37:35.498862	2025-11-06
386	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [1, 2, 19, 23, 39, 44]}	2025-11-06 07:37:35.662586	2025-11-06
387	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [5, 6, 26, 38, 39, 44]}	2025-11-06 07:37:35.801495	2025-11-06
388	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "cold-db", "duration_ms": 4, "numbers_preview": [1, 7, 9, 21, 22, 26]}	2025-11-06 07:37:35.960998	2025-11-06
389	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [4, 17, 18, 20, 23, 42], "success": true, "algorithm": "cold-db", "duration_ms": 92}	2025-11-06 07:37:36.07959	2025-11-06
416	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [10, 17, 18, 23, 25, 35], "success": true, "algorithm": "cold-db", "duration_ms": 49}	2025-11-06 07:37:37.687937	2025-11-06
433	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [13, 14, 17, 19, 20, 27], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 50}	2025-11-06 07:37:55.387936	2025-11-06
447	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [12, 13, 19, 20, 33, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 52}	2025-11-06 07:37:56.088302	2025-11-06
459	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 13, 18, 20, 34, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 53}	2025-11-06 07:37:59.837143	2025-11-06
621	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [5, 25, 26, 31, 42, 43], "success": true, "algorithm": "low-frequency-db", "duration_ms": 17}	2025-11-24 03:05:57.940117	2025-11-24
419	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [9, 17, 21, 23, 26, 42], "success": true, "algorithm": "cold-db", "duration_ms": 76}	2025-11-06 07:37:41.082736	2025-11-06
420	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [13, 14, 17, 20, 27, 40]}	2025-11-06 07:37:53.19113	2025-11-06
422	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 5, "numbers_preview": [3, 7, 14, 19, 40, 45]}	2025-11-06 07:37:53.952365	2025-11-06
425	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [3, 12, 14, 27, 33, 37]}	2025-11-06 07:37:54.650957	2025-11-06
426	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [3, 12, 13, 27, 37, 40]}	2025-11-06 07:37:54.821495	2025-11-06
427	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 3, "numbers_preview": [3, 7, 12, 19, 20, 40]}	2025-11-06 07:37:55.000448	2025-11-06
428	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [3, 14, 17, 27, 33, 37]}	2025-11-06 07:37:55.181155	2025-11-06
432	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 7, 14, 19, 40, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 55}	2025-11-06 07:37:55.387608	2025-11-06
464	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [7, 13, 17, 19, 20, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 65}	2025-11-06 07:37:59.837631	2025-11-06
622	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 5, 10, 22, 24, 36], "success": true, "algorithm": "low-frequency-db", "duration_ms": 24}	2025-11-24 03:05:57.942769	2025-11-24
438	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 13, 20, 27, 34, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 50}	2025-11-06 07:37:55.388475	2025-11-06
441	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 5, "numbers_preview": [3, 12, 18, 19, 27, 37]}	2025-11-06 07:37:55.681703	2025-11-06
444	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 12, 18, 19, 27, 37], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 50}	2025-11-06 07:37:56.088206	2025-11-06
449	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 7, "numbers_preview": [3, 12, 20, 34, 37, 40]}	2025-11-06 07:37:56.382876	2025-11-06
450	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [3, 13, 18, 20, 34, 40]}	2025-11-06 07:37:56.559271	2025-11-06
451	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [3, 7, 13, 14, 37, 40]}	2025-11-06 07:37:56.749613	2025-11-06
452	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 3, "numbers_preview": [3, 18, 19, 33, 37, 40]}	2025-11-06 07:37:56.929888	2025-11-06
454	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 5, "numbers_preview": [3, 17, 18, 19, 20, 37]}	2025-11-06 07:37:58.272046	2025-11-06
458	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.180.10	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	tablet	\N	\N	{"count": 6, "numbers": [3, 12, 20, 34, 37, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 56}	2025-11-06 07:37:59.837053	2025-11-06
623	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 15, 28, 29, 41, 43], "success": true, "algorithm": "low-frequency-db", "duration_ms": 20}	2025-11-24 03:05:57.942865	2025-11-24
470	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [3, 7, 13, 14, 33, 40]}	2025-11-08 06:26:55.695662	2025-11-08
471	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	/	http://203.245.30.6:3001/	mobile	\N	\N	\N	2025-11-08 06:26:55.931386	2025-11-08
473	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 6, "numbers_preview": [7, 14, 17, 33, 40, 45]}	2025-11-08 06:27:11.334704	2025-11-08
476	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [13, 14, 27, 33, 40, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 67}	2025-11-08 06:27:15.941667	2025-11-08
479	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 6, "numbers_preview": [3, 7, 13, 19, 34, 40]}	2025-11-08 06:27:34.181091	2025-11-08
480	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [3, 7, 13, 19, 34, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 64}	2025-11-08 06:27:35.954912	2025-11-08
486	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [11, 15, 19, 23, 34, 36], "success": true, "algorithm": "recent-db", "duration_ms": 69}	2025-11-08 06:27:55.960135	2025-11-08
625	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 4, 8, 16, 24, 43], "success": true, "algorithm": "low-frequency-db", "duration_ms": 19}	2025-11-24 03:05:57.946322	2025-11-24
472	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [3, 7, 13, 14, 33, 40], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 82}	2025-11-08 06:26:55.931492	2025-11-08
474	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 7, "numbers_preview": [13, 14, 27, 33, 40, 45]}	2025-11-08 06:27:13.15578	2025-11-08
475	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 6, "numbers_preview": [12, 17, 18, 20, 33, 45]}	2025-11-08 06:27:14.654747	2025-11-08
477	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [7, 14, 17, 33, 40, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 65}	2025-11-08 06:27:15.941637	2025-11-08
624	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [1, 8, 11, 16, 23, 26], "success": true, "algorithm": "low-frequency-db", "duration_ms": 21}	2025-11-24 03:05:57.94613	2025-11-24
478	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [12, 17, 18, 20, 33, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 62}	2025-11-08 06:27:15.94212	2025-11-08
481	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [3, 18, 33, 37, 40, 45]}	2025-11-08 06:27:36.258548	2025-11-08
482	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [3, 18, 33, 37, 40, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 69}	2025-11-08 06:27:40.955427	2025-11-08
483	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "ai-mixed-db", "duration_ms": 4, "numbers_preview": [17, 33, 34, 37, 40, 45]}	2025-11-08 06:27:52.038177	2025-11-08
484	lotto-master	generation	lotto	numbers_generated	1.00	\N	\N	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	\N	\N	\N	\N	\N	{"count": 1, "algorithm": "recent-db", "duration_ms": 7, "numbers_preview": [11, 15, 19, 23, 34, 36]}	2025-11-08 06:27:55.521478	2025-11-08
485	lotto-master	generation	lotto	number_generated	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	mobile	\N	\N	{"count": 6, "numbers": [17, 33, 34, 37, 40, 45], "success": true, "algorithm": "ai-mixed-db", "duration_ms": 65}	2025-11-08 06:27:55.96011	2025-11-08
626	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [2, 9, 15, 16, 22, 36], "success": true, "algorithm": "low-frequency-db", "duration_ms": 16}	2025-11-24 03:05:58.023857	2025-11-24
487	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.181.138	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36	/	http://203.245.30.6:3001/	mobile	\N	\N	\N	2025-11-08 06:33:56.253289	2025-11-08
627	lotto-master	generation	lotto	number_generated	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 10, 11, 23, 31, 43], "success": true, "algorithm": "low-frequency-db", "duration_ms": 16}	2025-11-24 03:05:58.024461	2025-11-24
488	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.201.168	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	tablet	\N	\N	\N	2025-11-09 14:17:00.044073	2025-11-09
489	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.201.168	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	tablet	\N	\N	\N	2025-11-09 14:17:04.970354	2025-11-09
628	lotto-master	pageview	navigation	page_view	\N	sess_1764212899824_onbc4b77t	user_1764212899824_bzn2e81z7	183.98.226.33	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-27 03:08:21.529662	2025-11-27
490	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.201.168	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	tablet	\N	\N	\N	2025-11-09 14:17:04.970439	2025-11-09
491	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.201.168	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	tablet	\N	\N	\N	2025-11-09 14:17:09.970202	2025-11-09
492	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.201.168	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	tablet	\N	\N	\N	2025-11-09 14:17:19.974343	2025-11-09
493	lotto-master	pageview	navigation	page_view	\N	sess_1762045710970_fe38km61n	user_1762045710970_1t8yxsu2i	211.234.201.168	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	tablet	\N	\N	\N	2025-11-09 14:17:29.977636	2025-11-09
494	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-12 05:51:27.775311	2025-11-12
495	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-11-12 05:51:32.773789	2025-11-12
496	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-11-12 05:51:37.775082	2025-11-12
498	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics/latest	http://203.245.30.6:3001/statistics/latest	desktop	\N	\N	\N	2025-11-12 05:51:57.785699	2025-11-12
499	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/statistics	http://203.245.30.6:3001/statistics	desktop	\N	\N	\N	2025-11-12 05:52:02.785923	2025-11-12
497	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/history	http://203.245.30.6:3001/history	desktop	\N	\N	\N	2025-11-12 05:51:37.774762	2025-11-12
500	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/generator	http://203.245.30.6:3001/generator	desktop	\N	\N	\N	2025-11-12 05:52:02.78596	2025-11-12
501	lotto-master	generation	lotto	numbers_generated	5.00	\N	\N	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	\N	\N	\N	\N	\N	{"count": 5, "algorithm": "ai-mixed-db", "duration_ms": 95, "numbers_preview": [7, 17, 19, 20, 34, 45]}	2025-11-12 05:52:09.137255	2025-11-12
502	lotto-master	pageview	navigation	page_view	\N	sess_1762926685169_g4krh80dr	user_1762926685169_z7p66zrg9	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	/	http://203.245.30.6:3001/	desktop	\N	\N	\N	2025-11-12 05:53:52.845219	2025-11-12
302	lotto-master	generation	lotto	number_generated	\N	sess_1760682974268_bzsghz72p	user_1761026733598_fi0rkbb3a	1.220.74.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	http://203.245.30.6:3001/	http://203.245.30.6:3001/	desktop	\N	\N	{"count": 6, "numbers": [4, 7, 17, 30, 31, 32], "success": true, "algorithm": "cold-db", "duration_ms": 17}	2025-11-03 07:15:09.424161	2025-11-03
\.


--
-- Data for Name: api_logs_2025_10; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.api_logs_2025_10 (id, project_id, method, endpoint, status_code, response_time_ms, ip_address, user_agent, session_id, user_id, request_body, response_body, error_message, created_at, date) FROM stdin;
\.


--
-- Data for Name: api_logs_2025_11; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.api_logs_2025_11 (id, project_id, method, endpoint, status_code, response_time_ms, ip_address, user_agent, session_id, user_id, request_body, response_body, error_message, created_at, date) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.projects (id, name, display_name, emoji, description, category, status, version, url, internal_url, port, health_check_endpoint, db_schema, db_user, tags, developer, repository, docs_path, total_users, daily_active_users, total_requests, avg_response_time_ms, created_at, updated_at, deployed_at, last_health_check, health_status) FROM stdin;
dashboard	Dashboard	Dashboard	📊	Express.js 기반 동적 프로젝트 관리 대시보드	full-stack	active	2.5.0	http://172.20.0.10:3000	http://172.20.0.10:3000	80	/health	\N	\N	{Express.js,PostgreSQL,Node.js}	tom	\N	\N	0	0	0	\N	2025-10-22 11:00:11.62615	2025-10-30 00:00:00	2026-01-10 00:00:00	\N	unknown
lotto-master	lotto-master	LottoMaster	🎰	통계 기반 로또 번호 생성 및 분석 서비스 - 최신 회차 종합 분석 기능 추가	full-stack	active	0.4.2	http://203.245.30.6:3001	http://172.20.0.11:3000	3001	/api/health	lotto	lotto_user	{"Next.js 15",PostgreSQL,AI,Lottery,Analytics}	tom	\N	\N	0	0	0	11.00	2025-10-17 03:25:02.223885	2025-11-02 12:03:34.85024	2026-01-05 00:00:00	2025-10-21 05:51:52.290933	healthy
today-fortune	TodayFortune	오늘의 운세	🔮	사주팔자 기반 일일 운세, 궁합, 타로 서비스	frontend	active	1.1.1	http://203.245.30.6:3002	http://172.20.0.12:80	3002	/	\N	\N	{Vite,"Vanilla JS",사주팔자,SPA}	tom	\N	\N	0	0	0	380.00	2025-10-20 06:56:07.032078	2025-10-20 06:56:07.032078	2025-12-18 00:00:00	2025-10-21 05:51:52.271712	healthy
blog-automation	BlogAutomation	블로그 자동화	✍️	AI를 활용한 네이버 블로그 자동 생성 도구	ai-application	active	1.0.0	http://203.245.30.6:3005	http://203.245.30.6:3005	3005	/health	\N	\N	{"Vanilla JS",AI,LLM,"Naver Blog"}	tom	\N	\N	0	0	0	\N	2026-01-10 01:47:31.64765	2026-01-10 01:47:31.64765	2026-01-07 00:00:00	\N	unknown
author-clock	AuthorClock	작가의 시계	🕰️	명언과 함께하는 시계 서비스	full-stack	active	2.0.2	http://203.245.30.6:3004	http://172.20.0.16:80	3004	/api/health	\N	\N	{React,TypeScript,Vite,Express,PostgreSQL,Redis}	tom	\N	\N	0	0	0	\N	2025-10-31 05:38:30.966492	2025-10-31 07:52:55.763682	2025-10-31 00:00:00	\N	unknown
ai-chatbot	AIChatbot	AI 챗봇	🤖	RAG 기반 문서 검색 및 프로젝트 정보 챗봇	ai-application	active	1.0.0	http://172.20.0.14:8000	http://172.20.0.14:8000	8000	/health	\N	\N	{FastAPI,Ollama,SmolLM2,RAG,BM25,PostgreSQL}	tom	\N	\N	0	0	0	\N	2025-10-22 00:13:23.029934	2025-10-22 00:13:23.029934	2025-10-22 00:00:00	\N	unknown
\.


--
-- Data for Name: system_metrics_2025_10; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.system_metrics_2025_10 (id, project_id, metric_type, metric_name, value, unit, metadata, collected_at, date) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: appuser
--

COPY public.user_sessions (session_id, project_id, user_id, ip_address, user_agent, session_data, first_seen, last_seen, page_views, events_count, is_active, created_at, expires_at) FROM stdin;
\.


--
-- Name: daily_stats_id_seq; Type: SEQUENCE SET; Schema: analytics; Owner: appuser
--

SELECT pg_catalog.setval('analytics.daily_stats_id_seq', 26, true);


--
-- Name: hourly_stats_id_seq; Type: SEQUENCE SET; Schema: analytics; Owner: appuser
--

SELECT pg_catalog.setval('analytics.hourly_stats_id_seq', 1, false);


--
-- Name: user_behavior_id_seq; Type: SEQUENCE SET; Schema: analytics; Owner: appuser
--

SELECT pg_catalog.setval('analytics.user_behavior_id_seq', 1, false);


--
-- Name: anonymous_sessions_id_seq; Type: SEQUENCE SET; Schema: author_clock; Owner: appuser
--

SELECT pg_catalog.setval('author_clock.anonymous_sessions_id_seq', 6, true);


--
-- Name: daily_quotes_id_seq; Type: SEQUENCE SET; Schema: author_clock; Owner: appuser
--

SELECT pg_catalog.setval('author_clock.daily_quotes_id_seq', 5, true);


--
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: author_clock; Owner: appuser
--

SELECT pg_catalog.setval('author_clock.quotes_id_seq', 50, true);


--
-- Name: translations_id_seq; Type: SEQUENCE SET; Schema: author_clock; Owner: appuser
--

SELECT pg_catalog.setval('author_clock.translations_id_seq', 1, false);


--
-- Name: user_bookmarks_id_seq; Type: SEQUENCE SET; Schema: author_clock; Owner: appuser
--

SELECT pg_catalog.setval('author_clock.user_bookmarks_id_seq', 1, false);


--
-- Name: user_likes_id_seq; Type: SEQUENCE SET; Schema: author_clock; Owner: appuser
--

SELECT pg_catalog.setval('author_clock.user_likes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: author_clock; Owner: appuser
--

SELECT pg_catalog.setval('author_clock.users_id_seq', 6, true);


--
-- Name: generation_history_id_seq; Type: SEQUENCE SET; Schema: lotto; Owner: appuser
--

SELECT pg_catalog.setval('lotto.generation_history_id_seq', 1, false);


--
-- Name: user_favorites_id_seq; Type: SEQUENCE SET; Schema: lotto; Owner: appuser
--

SELECT pg_catalog.setval('lotto.user_favorites_id_seq', 1, false);


--
-- Name: ai_service_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.ai_service_status_id_seq', 2, true);


--
-- Name: analytics_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.analytics_events_id_seq', 836, true);


--
-- Name: api_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.api_logs_id_seq', 1, false);


--
-- Name: system_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: appuser
--

SELECT pg_catalog.setval('public.system_metrics_id_seq', 1, false);


--
-- Name: daily_stats daily_stats_pkey; Type: CONSTRAINT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.daily_stats
    ADD CONSTRAINT daily_stats_pkey PRIMARY KEY (id);


--
-- Name: daily_stats daily_stats_project_id_date_key; Type: CONSTRAINT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.daily_stats
    ADD CONSTRAINT daily_stats_project_id_date_key UNIQUE (project_id, date);


--
-- Name: hourly_stats hourly_stats_pkey; Type: CONSTRAINT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.hourly_stats
    ADD CONSTRAINT hourly_stats_pkey PRIMARY KEY (id);


--
-- Name: hourly_stats hourly_stats_project_id_hour_timestamp_key; Type: CONSTRAINT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.hourly_stats
    ADD CONSTRAINT hourly_stats_project_id_hour_timestamp_key UNIQUE (project_id, hour_timestamp);


--
-- Name: project_metrics project_metrics_pkey; Type: CONSTRAINT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.project_metrics
    ADD CONSTRAINT project_metrics_pkey PRIMARY KEY (project_id);


--
-- Name: user_behavior user_behavior_pkey; Type: CONSTRAINT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.user_behavior
    ADD CONSTRAINT user_behavior_pkey PRIMARY KEY (id);


--
-- Name: anonymous_sessions anonymous_sessions_pkey; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.anonymous_sessions
    ADD CONSTRAINT anonymous_sessions_pkey PRIMARY KEY (id);


--
-- Name: anonymous_sessions anonymous_sessions_session_id_key; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.anonymous_sessions
    ADD CONSTRAINT anonymous_sessions_session_id_key UNIQUE (session_id);


--
-- Name: daily_quotes daily_quotes_pkey; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.daily_quotes
    ADD CONSTRAINT daily_quotes_pkey PRIMARY KEY (id);


--
-- Name: daily_quotes daily_quotes_unique_date_lang; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.daily_quotes
    ADD CONSTRAINT daily_quotes_unique_date_lang UNIQUE (date, language);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: translations translations_pkey; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.translations
    ADD CONSTRAINT translations_pkey PRIMARY KEY (id);


--
-- Name: translations translations_unique; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.translations
    ADD CONSTRAINT translations_unique UNIQUE (quote_id, language);


--
-- Name: user_bookmarks user_bookmarks_pkey; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.user_bookmarks
    ADD CONSTRAINT user_bookmarks_pkey PRIMARY KEY (id);


--
-- Name: user_bookmarks user_bookmarks_user_id_quote_id_key; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.user_bookmarks
    ADD CONSTRAINT user_bookmarks_user_id_quote_id_key UNIQUE (user_id, quote_id);


--
-- Name: user_likes user_likes_pkey; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.user_likes
    ADD CONSTRAINT user_likes_pkey PRIMARY KEY (id);


--
-- Name: user_likes user_likes_unique; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.user_likes
    ADD CONSTRAINT user_likes_unique UNIQUE (user_id, quote_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: draw_results draw_results_pkey; Type: CONSTRAINT; Schema: lotto; Owner: appuser
--

ALTER TABLE ONLY lotto.draw_results
    ADD CONSTRAINT draw_results_pkey PRIMARY KEY (draw_no);


--
-- Name: draws draws_pkey; Type: CONSTRAINT; Schema: lotto; Owner: appuser
--

ALTER TABLE ONLY lotto.draws
    ADD CONSTRAINT draws_pkey PRIMARY KEY (draw_no);


--
-- Name: generation_history generation_history_pkey; Type: CONSTRAINT; Schema: lotto; Owner: appuser
--

ALTER TABLE ONLY lotto.generation_history
    ADD CONSTRAINT generation_history_pkey PRIMARY KEY (id);


--
-- Name: statistics_cache statistics_cache_pkey; Type: CONSTRAINT; Schema: lotto; Owner: appuser
--

ALTER TABLE ONLY lotto.statistics_cache
    ADD CONSTRAINT statistics_cache_pkey PRIMARY KEY (cache_key);


--
-- Name: user_favorites user_favorites_pkey; Type: CONSTRAINT; Schema: lotto; Owner: appuser
--

ALTER TABLE ONLY lotto.user_favorites
    ADD CONSTRAINT user_favorites_pkey PRIMARY KEY (id);


--
-- Name: ai_service_status ai_service_status_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.ai_service_status
    ADD CONSTRAINT ai_service_status_pkey PRIMARY KEY (id);


--
-- Name: analytics_events analytics_events_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.analytics_events
    ADD CONSTRAINT analytics_events_pkey PRIMARY KEY (id, date);


--
-- Name: analytics_events_2025_10 analytics_events_2025_10_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.analytics_events_2025_10
    ADD CONSTRAINT analytics_events_2025_10_pkey PRIMARY KEY (id, date);


--
-- Name: analytics_events_2025_11 analytics_events_2025_11_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.analytics_events_2025_11
    ADD CONSTRAINT analytics_events_2025_11_pkey PRIMARY KEY (id, date);


--
-- Name: api_logs api_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.api_logs
    ADD CONSTRAINT api_logs_pkey PRIMARY KEY (id, date);


--
-- Name: api_logs_2025_10 api_logs_2025_10_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.api_logs_2025_10
    ADD CONSTRAINT api_logs_2025_10_pkey PRIMARY KEY (id, date);


--
-- Name: api_logs_2025_11 api_logs_2025_11_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.api_logs_2025_11
    ADD CONSTRAINT api_logs_2025_11_pkey PRIMARY KEY (id, date);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id, date);


--
-- Name: system_metrics_2025_10 system_metrics_2025_10_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.system_metrics_2025_10
    ADD CONSTRAINT system_metrics_2025_10_pkey PRIMARY KEY (id, date);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: appuser
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (session_id);


--
-- Name: idx_behavior_flow; Type: INDEX; Schema: analytics; Owner: appuser
--

CREATE INDEX idx_behavior_flow ON analytics.user_behavior USING btree (project_id, from_page, to_page);


--
-- Name: idx_behavior_project_date; Type: INDEX; Schema: analytics; Owner: appuser
--

CREATE INDEX idx_behavior_project_date ON analytics.user_behavior USING btree (project_id, date DESC);


--
-- Name: idx_daily_stats_project_date; Type: INDEX; Schema: analytics; Owner: appuser
--

CREATE INDEX idx_daily_stats_project_date ON analytics.daily_stats USING btree (project_id, date DESC);


--
-- Name: idx_hourly_stats_project; Type: INDEX; Schema: analytics; Owner: appuser
--

CREATE INDEX idx_hourly_stats_project ON analytics.hourly_stats USING btree (project_id, hour_timestamp DESC);


--
-- Name: idx_anon_sessions_last_seen; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_anon_sessions_last_seen ON author_clock.anonymous_sessions USING btree (last_seen DESC);


--
-- Name: idx_anon_sessions_session; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_anon_sessions_session ON author_clock.anonymous_sessions USING btree (session_id);


--
-- Name: idx_anon_sessions_user; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_anon_sessions_user ON author_clock.anonymous_sessions USING btree (user_id);


--
-- Name: idx_daily_quotes_date; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_daily_quotes_date ON author_clock.daily_quotes USING btree (date DESC);


--
-- Name: idx_daily_quotes_quote_id; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_daily_quotes_quote_id ON author_clock.daily_quotes USING btree (quote_id);


--
-- Name: idx_quotes_approved; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_quotes_approved ON author_clock.quotes USING btree (is_approved);


--
-- Name: idx_quotes_category; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_quotes_category ON author_clock.quotes USING btree (category);


--
-- Name: idx_quotes_language; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_quotes_language ON author_clock.quotes USING btree (language);


--
-- Name: idx_translations_language; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_translations_language ON author_clock.translations USING btree (language);


--
-- Name: idx_translations_quote; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_translations_quote ON author_clock.translations USING btree (quote_id);


--
-- Name: idx_user_bookmarks_created; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_user_bookmarks_created ON author_clock.user_bookmarks USING btree (created_at DESC);


--
-- Name: idx_user_bookmarks_quote; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_user_bookmarks_quote ON author_clock.user_bookmarks USING btree (quote_id);


--
-- Name: idx_user_bookmarks_user; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_user_bookmarks_user ON author_clock.user_bookmarks USING btree (user_id);


--
-- Name: idx_user_likes_quote; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_user_likes_quote ON author_clock.user_likes USING btree (quote_id);


--
-- Name: idx_user_likes_user; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_user_likes_user ON author_clock.user_likes USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_users_email ON author_clock.users USING btree (email);


--
-- Name: idx_users_username; Type: INDEX; Schema: author_clock; Owner: appuser
--

CREATE INDEX idx_users_username ON author_clock.users USING btree (username);


--
-- Name: idx_cache_expires; Type: INDEX; Schema: lotto; Owner: appuser
--

CREATE INDEX idx_cache_expires ON lotto.statistics_cache USING btree (expires_at);


--
-- Name: idx_draw_date; Type: INDEX; Schema: lotto; Owner: appuser
--

CREATE INDEX idx_draw_date ON lotto.draw_results USING btree (draw_date DESC);


--
-- Name: idx_draws_created_at; Type: INDEX; Schema: lotto; Owner: appuser
--

CREATE INDEX idx_draws_created_at ON lotto.draws USING btree (created_at DESC);


--
-- Name: idx_draws_draw_date; Type: INDEX; Schema: lotto; Owner: appuser
--

CREATE INDEX idx_draws_draw_date ON lotto.draws USING btree (draw_date DESC);


--
-- Name: idx_favorites_user; Type: INDEX; Schema: lotto; Owner: appuser
--

CREATE INDEX idx_favorites_user ON lotto.user_favorites USING btree (user_id, created_at DESC);


--
-- Name: idx_generation_algorithm; Type: INDEX; Schema: lotto; Owner: appuser
--

CREATE INDEX idx_generation_algorithm ON lotto.generation_history USING btree (algorithm, created_at DESC);


--
-- Name: idx_generation_created; Type: INDEX; Schema: lotto; Owner: appuser
--

CREATE INDEX idx_generation_created ON lotto.generation_history USING btree (created_at DESC);


--
-- Name: idx_generation_session; Type: INDEX; Schema: lotto; Owner: appuser
--

CREATE INDEX idx_generation_session ON lotto.generation_history USING btree (session_id, created_at DESC);


--
-- Name: idx_analytics_event_type; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_analytics_event_type ON ONLY public.analytics_events USING btree (event_type, created_at DESC);


--
-- Name: analytics_events_2025_10_event_type_created_at_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX analytics_events_2025_10_event_type_created_at_idx ON public.analytics_events_2025_10 USING btree (event_type, created_at DESC);


--
-- Name: idx_analytics_metadata; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_analytics_metadata ON ONLY public.analytics_events USING gin (metadata);


--
-- Name: analytics_events_2025_10_metadata_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX analytics_events_2025_10_metadata_idx ON public.analytics_events_2025_10 USING gin (metadata);


--
-- Name: idx_analytics_project_date; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_analytics_project_date ON ONLY public.analytics_events USING btree (project_id, date DESC);


--
-- Name: analytics_events_2025_10_project_id_date_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX analytics_events_2025_10_project_id_date_idx ON public.analytics_events_2025_10 USING btree (project_id, date DESC);


--
-- Name: idx_analytics_session; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_analytics_session ON ONLY public.analytics_events USING btree (session_id, created_at DESC);


--
-- Name: analytics_events_2025_10_session_id_created_at_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX analytics_events_2025_10_session_id_created_at_idx ON public.analytics_events_2025_10 USING btree (session_id, created_at DESC);


--
-- Name: analytics_events_2025_11_event_type_created_at_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX analytics_events_2025_11_event_type_created_at_idx ON public.analytics_events_2025_11 USING btree (event_type, created_at DESC);


--
-- Name: analytics_events_2025_11_metadata_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX analytics_events_2025_11_metadata_idx ON public.analytics_events_2025_11 USING gin (metadata);


--
-- Name: analytics_events_2025_11_project_id_date_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX analytics_events_2025_11_project_id_date_idx ON public.analytics_events_2025_11 USING btree (project_id, date DESC);


--
-- Name: analytics_events_2025_11_session_id_created_at_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX analytics_events_2025_11_session_id_created_at_idx ON public.analytics_events_2025_11 USING btree (session_id, created_at DESC);


--
-- Name: idx_api_logs_endpoint; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_api_logs_endpoint ON ONLY public.api_logs USING btree (endpoint, status_code);


--
-- Name: api_logs_2025_10_endpoint_status_code_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX api_logs_2025_10_endpoint_status_code_idx ON public.api_logs_2025_10 USING btree (endpoint, status_code);


--
-- Name: idx_api_logs_project; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_api_logs_project ON ONLY public.api_logs USING btree (project_id, date DESC);


--
-- Name: api_logs_2025_10_project_id_date_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX api_logs_2025_10_project_id_date_idx ON public.api_logs_2025_10 USING btree (project_id, date DESC);


--
-- Name: idx_api_logs_slow; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_api_logs_slow ON ONLY public.api_logs USING btree (response_time_ms DESC) WHERE (response_time_ms > 1000);


--
-- Name: api_logs_2025_10_response_time_ms_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX api_logs_2025_10_response_time_ms_idx ON public.api_logs_2025_10 USING btree (response_time_ms DESC) WHERE (response_time_ms > 1000);


--
-- Name: idx_api_logs_status; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_api_logs_status ON ONLY public.api_logs USING btree (status_code, date DESC);


--
-- Name: api_logs_2025_10_status_code_date_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX api_logs_2025_10_status_code_date_idx ON public.api_logs_2025_10 USING btree (status_code, date DESC);


--
-- Name: api_logs_2025_11_endpoint_status_code_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX api_logs_2025_11_endpoint_status_code_idx ON public.api_logs_2025_11 USING btree (endpoint, status_code);


--
-- Name: api_logs_2025_11_project_id_date_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX api_logs_2025_11_project_id_date_idx ON public.api_logs_2025_11 USING btree (project_id, date DESC);


--
-- Name: api_logs_2025_11_response_time_ms_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX api_logs_2025_11_response_time_ms_idx ON public.api_logs_2025_11 USING btree (response_time_ms DESC) WHERE (response_time_ms > 1000);


--
-- Name: api_logs_2025_11_status_code_date_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX api_logs_2025_11_status_code_date_idx ON public.api_logs_2025_11 USING btree (status_code, date DESC);


--
-- Name: idx_ai_status_service; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_ai_status_service ON public.ai_service_status USING btree (service_name, last_check DESC);


--
-- Name: idx_metrics_date; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_metrics_date ON ONLY public.system_metrics USING btree (date DESC);


--
-- Name: idx_metrics_project_type; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_metrics_project_type ON ONLY public.system_metrics USING btree (project_id, metric_type, collected_at DESC);


--
-- Name: idx_projects_category; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_projects_category ON public.projects USING btree (category);


--
-- Name: idx_projects_health; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_projects_health ON public.projects USING btree (health_status);


--
-- Name: idx_projects_status; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_projects_status ON public.projects USING btree (status);


--
-- Name: idx_sessions_active; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_sessions_active ON public.user_sessions USING btree (is_active, last_seen DESC);


--
-- Name: idx_sessions_expires; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_sessions_expires ON public.user_sessions USING btree (expires_at) WHERE (is_active = true);


--
-- Name: idx_sessions_project; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_sessions_project ON public.user_sessions USING btree (project_id, last_seen DESC);


--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX idx_sessions_user ON public.user_sessions USING btree (user_id, project_id);


--
-- Name: system_metrics_2025_10_date_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX system_metrics_2025_10_date_idx ON public.system_metrics_2025_10 USING btree (date DESC);


--
-- Name: system_metrics_2025_10_project_id_metric_type_collected_at_idx; Type: INDEX; Schema: public; Owner: appuser
--

CREATE INDEX system_metrics_2025_10_project_id_metric_type_collected_at_idx ON public.system_metrics_2025_10 USING btree (project_id, metric_type, collected_at DESC);


--
-- Name: analytics_events_2025_10_event_type_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_analytics_event_type ATTACH PARTITION public.analytics_events_2025_10_event_type_created_at_idx;


--
-- Name: analytics_events_2025_10_metadata_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_analytics_metadata ATTACH PARTITION public.analytics_events_2025_10_metadata_idx;


--
-- Name: analytics_events_2025_10_pkey; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.analytics_events_pkey ATTACH PARTITION public.analytics_events_2025_10_pkey;


--
-- Name: analytics_events_2025_10_project_id_date_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_analytics_project_date ATTACH PARTITION public.analytics_events_2025_10_project_id_date_idx;


--
-- Name: analytics_events_2025_10_session_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_analytics_session ATTACH PARTITION public.analytics_events_2025_10_session_id_created_at_idx;


--
-- Name: analytics_events_2025_11_event_type_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_analytics_event_type ATTACH PARTITION public.analytics_events_2025_11_event_type_created_at_idx;


--
-- Name: analytics_events_2025_11_metadata_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_analytics_metadata ATTACH PARTITION public.analytics_events_2025_11_metadata_idx;


--
-- Name: analytics_events_2025_11_pkey; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.analytics_events_pkey ATTACH PARTITION public.analytics_events_2025_11_pkey;


--
-- Name: analytics_events_2025_11_project_id_date_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_analytics_project_date ATTACH PARTITION public.analytics_events_2025_11_project_id_date_idx;


--
-- Name: analytics_events_2025_11_session_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_analytics_session ATTACH PARTITION public.analytics_events_2025_11_session_id_created_at_idx;


--
-- Name: api_logs_2025_10_endpoint_status_code_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_api_logs_endpoint ATTACH PARTITION public.api_logs_2025_10_endpoint_status_code_idx;


--
-- Name: api_logs_2025_10_pkey; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.api_logs_pkey ATTACH PARTITION public.api_logs_2025_10_pkey;


--
-- Name: api_logs_2025_10_project_id_date_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_api_logs_project ATTACH PARTITION public.api_logs_2025_10_project_id_date_idx;


--
-- Name: api_logs_2025_10_response_time_ms_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_api_logs_slow ATTACH PARTITION public.api_logs_2025_10_response_time_ms_idx;


--
-- Name: api_logs_2025_10_status_code_date_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_api_logs_status ATTACH PARTITION public.api_logs_2025_10_status_code_date_idx;


--
-- Name: api_logs_2025_11_endpoint_status_code_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_api_logs_endpoint ATTACH PARTITION public.api_logs_2025_11_endpoint_status_code_idx;


--
-- Name: api_logs_2025_11_pkey; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.api_logs_pkey ATTACH PARTITION public.api_logs_2025_11_pkey;


--
-- Name: api_logs_2025_11_project_id_date_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_api_logs_project ATTACH PARTITION public.api_logs_2025_11_project_id_date_idx;


--
-- Name: api_logs_2025_11_response_time_ms_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_api_logs_slow ATTACH PARTITION public.api_logs_2025_11_response_time_ms_idx;


--
-- Name: api_logs_2025_11_status_code_date_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_api_logs_status ATTACH PARTITION public.api_logs_2025_11_status_code_date_idx;


--
-- Name: system_metrics_2025_10_date_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_metrics_date ATTACH PARTITION public.system_metrics_2025_10_date_idx;


--
-- Name: system_metrics_2025_10_pkey; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.system_metrics_pkey ATTACH PARTITION public.system_metrics_2025_10_pkey;


--
-- Name: system_metrics_2025_10_project_id_metric_type_collected_at_idx; Type: INDEX ATTACH; Schema: public; Owner: appuser
--

ALTER INDEX public.idx_metrics_project_type ATTACH PARTITION public.system_metrics_2025_10_project_id_metric_type_collected_at_idx;


--
-- Name: draws update_draws_updated_at; Type: TRIGGER; Schema: lotto; Owner: appuser
--

CREATE TRIGGER update_draws_updated_at BEFORE UPDATE ON lotto.draws FOR EACH ROW EXECUTE FUNCTION lotto.update_updated_at_column();


--
-- Name: daily_stats daily_stats_project_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.daily_stats
    ADD CONSTRAINT daily_stats_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: hourly_stats hourly_stats_project_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.hourly_stats
    ADD CONSTRAINT hourly_stats_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: project_metrics project_metrics_project_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.project_metrics
    ADD CONSTRAINT project_metrics_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: user_behavior user_behavior_project_id_fkey; Type: FK CONSTRAINT; Schema: analytics; Owner: appuser
--

ALTER TABLE ONLY analytics.user_behavior
    ADD CONSTRAINT user_behavior_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: anonymous_sessions anonymous_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.anonymous_sessions
    ADD CONSTRAINT anonymous_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES author_clock.users(id) ON DELETE CASCADE;


--
-- Name: daily_quotes daily_quotes_quote_id_fkey; Type: FK CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.daily_quotes
    ADD CONSTRAINT daily_quotes_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES author_clock.quotes(id) ON DELETE CASCADE;


--
-- Name: translations translations_quote_id_fkey; Type: FK CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.translations
    ADD CONSTRAINT translations_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES author_clock.quotes(id) ON DELETE CASCADE;


--
-- Name: translations translations_translated_by_fkey; Type: FK CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.translations
    ADD CONSTRAINT translations_translated_by_fkey FOREIGN KEY (translated_by) REFERENCES author_clock.users(id) ON DELETE SET NULL;


--
-- Name: user_bookmarks user_bookmarks_quote_id_fkey; Type: FK CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.user_bookmarks
    ADD CONSTRAINT user_bookmarks_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES author_clock.quotes(id) ON DELETE CASCADE;


--
-- Name: user_bookmarks user_bookmarks_user_id_fkey; Type: FK CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.user_bookmarks
    ADD CONSTRAINT user_bookmarks_user_id_fkey FOREIGN KEY (user_id) REFERENCES author_clock.users(id) ON DELETE CASCADE;


--
-- Name: user_likes user_likes_quote_id_fkey; Type: FK CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.user_likes
    ADD CONSTRAINT user_likes_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES author_clock.quotes(id) ON DELETE CASCADE;


--
-- Name: user_likes user_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: author_clock; Owner: appuser
--

ALTER TABLE ONLY author_clock.user_likes
    ADD CONSTRAINT user_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES author_clock.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA analytics; Type: ACL; Schema: -; Owner: appuser
--

GRANT USAGE ON SCHEMA analytics TO lotto_user;


--
-- Name: SCHEMA author_clock; Type: ACL; Schema: -; Owner: appuser
--

GRANT USAGE ON SCHEMA author_clock TO author_clock_user;


--
-- Name: SCHEMA lotto; Type: ACL; Schema: -; Owner: appuser
--

GRANT USAGE ON SCHEMA lotto TO lotto_user;


--
-- Name: TABLE daily_stats; Type: ACL; Schema: analytics; Owner: appuser
--

GRANT SELECT ON TABLE analytics.daily_stats TO lotto_user;


--
-- Name: TABLE hourly_stats; Type: ACL; Schema: analytics; Owner: appuser
--

GRANT SELECT ON TABLE analytics.hourly_stats TO lotto_user;


--
-- Name: TABLE project_metrics; Type: ACL; Schema: analytics; Owner: appuser
--

GRANT SELECT ON TABLE analytics.project_metrics TO lotto_user;


--
-- Name: TABLE user_behavior; Type: ACL; Schema: analytics; Owner: appuser
--

GRANT SELECT ON TABLE analytics.user_behavior TO lotto_user;


--
-- Name: TABLE anonymous_sessions; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE author_clock.anonymous_sessions TO author_clock_user;


--
-- Name: SEQUENCE anonymous_sessions_id_seq; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,USAGE ON SEQUENCE author_clock.anonymous_sessions_id_seq TO author_clock_user;


--
-- Name: TABLE daily_quotes; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE author_clock.daily_quotes TO author_clock_user;


--
-- Name: SEQUENCE daily_quotes_id_seq; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,USAGE ON SEQUENCE author_clock.daily_quotes_id_seq TO author_clock_user;


--
-- Name: TABLE quotes; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE author_clock.quotes TO author_clock_user;


--
-- Name: SEQUENCE quotes_id_seq; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,USAGE ON SEQUENCE author_clock.quotes_id_seq TO author_clock_user;


--
-- Name: TABLE translations; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE author_clock.translations TO author_clock_user;


--
-- Name: SEQUENCE translations_id_seq; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,USAGE ON SEQUENCE author_clock.translations_id_seq TO author_clock_user;


--
-- Name: TABLE user_bookmarks; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE author_clock.user_bookmarks TO author_clock_user;


--
-- Name: SEQUENCE user_bookmarks_id_seq; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,USAGE ON SEQUENCE author_clock.user_bookmarks_id_seq TO author_clock_user;


--
-- Name: TABLE user_likes; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE author_clock.user_likes TO author_clock_user;


--
-- Name: SEQUENCE user_likes_id_seq; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,USAGE ON SEQUENCE author_clock.user_likes_id_seq TO author_clock_user;


--
-- Name: TABLE users; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE author_clock.users TO author_clock_user;


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: author_clock; Owner: appuser
--

GRANT SELECT,USAGE ON SEQUENCE author_clock.users_id_seq TO author_clock_user;


--
-- Name: TABLE draw_results; Type: ACL; Schema: lotto; Owner: appuser
--

GRANT ALL ON TABLE lotto.draw_results TO lotto_user;


--
-- Name: TABLE draws; Type: ACL; Schema: lotto; Owner: appuser
--

GRANT ALL ON TABLE lotto.draws TO lotto_user;


--
-- Name: TABLE generation_history; Type: ACL; Schema: lotto; Owner: appuser
--

GRANT ALL ON TABLE lotto.generation_history TO lotto_user;


--
-- Name: SEQUENCE generation_history_id_seq; Type: ACL; Schema: lotto; Owner: appuser
--

GRANT ALL ON SEQUENCE lotto.generation_history_id_seq TO lotto_user;


--
-- Name: TABLE statistics_cache; Type: ACL; Schema: lotto; Owner: appuser
--

GRANT ALL ON TABLE lotto.statistics_cache TO lotto_user;


--
-- Name: TABLE user_favorites; Type: ACL; Schema: lotto; Owner: appuser
--

GRANT ALL ON TABLE lotto.user_favorites TO lotto_user;


--
-- Name: SEQUENCE user_favorites_id_seq; Type: ACL; Schema: lotto; Owner: appuser
--

GRANT ALL ON SEQUENCE lotto.user_favorites_id_seq TO lotto_user;


--
-- Name: TABLE analytics_events; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT,INSERT ON TABLE public.analytics_events TO lotto_user;


--
-- Name: SEQUENCE analytics_events_id_seq; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT,USAGE ON SEQUENCE public.analytics_events_id_seq TO lotto_user;


--
-- Name: TABLE analytics_events_2025_10; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT ON TABLE public.analytics_events_2025_10 TO lotto_user;


--
-- Name: TABLE analytics_events_2025_11; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT ON TABLE public.analytics_events_2025_11 TO lotto_user;


--
-- Name: TABLE api_logs; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT,INSERT ON TABLE public.api_logs TO lotto_user;


--
-- Name: TABLE api_logs_2025_10; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT ON TABLE public.api_logs_2025_10 TO lotto_user;


--
-- Name: TABLE api_logs_2025_11; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT ON TABLE public.api_logs_2025_11 TO lotto_user;


--
-- Name: TABLE projects; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT ON TABLE public.projects TO lotto_user;


--
-- Name: TABLE system_metrics; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT ON TABLE public.system_metrics TO lotto_user;


--
-- Name: TABLE system_metrics_2025_10; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT ON TABLE public.system_metrics_2025_10 TO lotto_user;


--
-- Name: TABLE user_sessions; Type: ACL; Schema: public; Owner: appuser
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.user_sessions TO lotto_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: author_clock; Owner: appuser
--

ALTER DEFAULT PRIVILEGES FOR ROLE appuser IN SCHEMA author_clock GRANT SELECT,USAGE ON SEQUENCES  TO author_clock_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: author_clock; Owner: appuser
--

ALTER DEFAULT PRIVILEGES FOR ROLE appuser IN SCHEMA author_clock GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO author_clock_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: lotto; Owner: appuser
--

ALTER DEFAULT PRIVILEGES FOR ROLE appuser IN SCHEMA lotto GRANT ALL ON SEQUENCES  TO lotto_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: lotto; Owner: appuser
--

ALTER DEFAULT PRIVILEGES FOR ROLE appuser IN SCHEMA lotto GRANT ALL ON TABLES  TO lotto_user;


--
-- PostgreSQL database dump complete
--

\unrestrict FDVLamLPpw3tiALCk9EvVr34bQIVCXfnufdtXUCDm9tct5K4hsw5ooSWIvjllGg

