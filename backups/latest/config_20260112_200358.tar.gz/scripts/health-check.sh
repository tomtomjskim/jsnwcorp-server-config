#!/bin/bash
# ============================================================================
# System Health Check Script
# ============================================================================
# Purpose: Monitor all services and log health status
# Schedule: Run every 5 minutes via cron
# ============================================================================

set -e

LOG_FILE="/home/deploy/logs/health-check.log"
DATE=$(date '+%Y-%m-%d %H:%M:%S')
ALL_HEALTHY=true

echo "[$DATE] ========== Health Check Start ==========" >> "$LOG_FILE"

# Check PostgreSQL
echo "[$DATE] Checking PostgreSQL..." >> "$LOG_FILE"
if docker exec postgres pg_isready -U appuser > /dev/null 2>&1; then
    echo "[$DATE] ✓ PostgreSQL: healthy" >> "$LOG_FILE"
else
    echo "[$DATE] ✗ PostgreSQL: unhealthy" >> "$LOG_FILE"
    ALL_HEALTHY=false
fi

# Check Redis
echo "[$DATE] Checking Redis..." >> "$LOG_FILE"
if docker exec redis redis-cli --raw incr ping > /dev/null 2>&1; then
    echo "[$DATE] ✓ Redis: healthy" >> "$LOG_FILE"
else
    echo "[$DATE] ✗ Redis: unhealthy" >> "$LOG_FILE"
    ALL_HEALTHY=false
fi

# Check Dashboard
echo "[$DATE] Checking Dashboard..." >> "$LOG_FILE"
DASHBOARD_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://172.20.0.10:3000/health)
if [ "$DASHBOARD_STATUS" == "200" ]; then
    echo "[$DATE] ✓ Dashboard: healthy (HTTP $DASHBOARD_STATUS)" >> "$LOG_FILE"
else
    echo "[$DATE] ✗ Dashboard: unhealthy (HTTP $DASHBOARD_STATUS)" >> "$LOG_FILE"
    ALL_HEALTHY=false
fi

# Check Dashboard Analytics API
echo "[$DATE] Checking Dashboard Analytics API..." >> "$LOG_FILE"
ANALYTICS_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://172.20.0.10:3000/api/analytics/health)
if [ "$ANALYTICS_STATUS" == "200" ]; then
    echo "[$DATE] ✓ Dashboard Analytics API: healthy (HTTP $ANALYTICS_STATUS)" >> "$LOG_FILE"
else
    echo "[$DATE] ✗ Dashboard Analytics API: unhealthy (HTTP $ANALYTICS_STATUS)" >> "$LOG_FILE"
    ALL_HEALTHY=false
fi

# Check Nginx
echo "[$DATE] Checking Nginx..." >> "$LOG_FILE"
NGINX_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://172.20.0.2/health)
if [ "$NGINX_STATUS" == "200" ]; then
    echo "[$DATE] ✓ Nginx: healthy (HTTP $NGINX_STATUS)" >> "$LOG_FILE"
else
    echo "[$DATE] ✗ Nginx: unhealthy (HTTP $NGINX_STATUS)" >> "$LOG_FILE"
    ALL_HEALTHY=false
fi

# Check LottoMaster (if container exists)
if docker ps --filter "name=lotto-service" --filter "status=running" | grep -q lotto-service; then
    echo "[$DATE] Checking LottoMaster..." >> "$LOG_FILE"
    LOTTO_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://172.20.0.11:3000/api/health)
    if [ "$LOTTO_STATUS" == "200" ]; then
        echo "[$DATE] ✓ LottoMaster: healthy (HTTP $LOTTO_STATUS)" >> "$LOG_FILE"
    else
        echo "[$DATE] ✗ LottoMaster: unhealthy (HTTP $LOTTO_STATUS)" >> "$LOG_FILE"
        ALL_HEALTHY=false
    fi
else
    echo "[$DATE] - LottoMaster: not running (skipped)" >> "$LOG_FILE"
fi

# Check disk space
echo "[$DATE] Checking disk space..." >> "$LOG_FILE"
DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ "$DISK_USAGE" -lt 85 ]; then
    echo "[$DATE] ✓ Disk space: ${DISK_USAGE}% used" >> "$LOG_FILE"
else
    echo "[$DATE] ⚠ Disk space: ${DISK_USAGE}% used (warning: >85%)" >> "$LOG_FILE"
    ALL_HEALTHY=false
fi

# Check memory usage
echo "[$DATE] Checking memory..." >> "$LOG_FILE"
MEMORY_USAGE=$(free | awk 'NR==2 {printf "%.0f", $3/$2 * 100}')
if [ "$MEMORY_USAGE" -lt 90 ]; then
    echo "[$DATE] ✓ Memory: ${MEMORY_USAGE}% used" >> "$LOG_FILE"
else
    echo "[$DATE] ⚠ Memory: ${MEMORY_USAGE}% used (warning: >90%)" >> "$LOG_FILE"
    ALL_HEALTHY=false
fi

# Summary
if [ "$ALL_HEALTHY" = true ]; then
    echo "[$DATE] ========== All Systems Healthy ==========" >> "$LOG_FILE"
else
    echo "[$DATE] ========== ALERT: Some Systems Unhealthy ==========" >> "$LOG_FILE"
    # TODO: Send alert notification (email, Slack, etc.)
fi

echo "" >> "$LOG_FILE"

exit 0
