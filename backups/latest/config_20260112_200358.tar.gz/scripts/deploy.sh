#!/bin/bash
# Simple Deployment Script
# Usage: ./scripts/deploy.sh [service_name or 'all']

set -e

SERVICE=${1:-all}

echo "=========================================="
echo " Deployment Script"
echo "=========================================="
echo ""

# Navigate to project directory
cd /home/deploy

# Pull latest code (if using git)
# git pull origin main

# Build and start containers
echo "[INFO] Building Docker images..."
if [ "$SERVICE" == "all" ]; then
    docker compose build
    docker compose up -d
else
    docker compose build $SERVICE
    docker compose up -d --no-deps $SERVICE
fi

echo ""
echo "[INFO] Waiting for containers to start..."
sleep 10

# Check container status
echo ""
echo "[INFO] Container Status:"
docker compose ps

echo ""
echo "[INFO] Deployment completed!"
echo "=========================================="
