#!/bin/bash
#
# GeoIP2 Database Auto-Update Script
# Updates the GeoLite2-Country.mmdb database monthly
# Installed in cron: 0 3 1 * * (runs at 3am on the 1st of every month)
#

set -e

LOG_FILE="/var/log/geoip-update.log"
GEOIP_VOLUME="deploy_geoip_data"
TEMP_DB="/tmp/GeoLite2-Country.mmdb"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "Starting GeoIP database update..."

# Download latest database
log "Downloading latest GeoLite2-Country database..."
if wget -q -O "$TEMP_DB" "https://git.io/GeoLite2-Country.mmdb" 2>/dev/null; then
    log "Database downloaded successfully from git.io"
elif wget -q -O "$TEMP_DB" "https://github.com/wp-statistics/GeoLite2-Country/raw/master/GeoLite2-Country.mmdb" 2>/dev/null; then
    log "Database downloaded successfully from wp-statistics mirror"
else
    log "ERROR: Failed to download GeoLite2 database from all sources"
    exit 1
fi

# Verify file size (should be > 1MB)
FILE_SIZE=$(stat -f%z "$TEMP_DB" 2>/dev/null || stat -c%s "$TEMP_DB" 2>/dev/null)
if [ "$FILE_SIZE" -lt 1000000 ]; then
    log "ERROR: Downloaded file is too small ($FILE_SIZE bytes), probably corrupted"
    rm -f "$TEMP_DB"
    exit 1
fi

log "Downloaded file size: $FILE_SIZE bytes"

# Copy to Docker volume
log "Copying database to Docker volume..."
docker run --rm \
    -v "$GEOIP_VOLUME:/geoip" \
    -v "$TEMP_DB:/tmp/new-db.mmdb:ro" \
    alpine sh -c "
        cp /tmp/new-db.mmdb /geoip/GeoLite2-Country.mmdb && \
        chmod 644 /geoip/GeoLite2-Country.mmdb && \
        ls -lh /geoip/GeoLite2-Country.mmdb
    "

if [ $? -ne 0 ]; then
    log "ERROR: Failed to copy database to Docker volume"
    rm -f "$TEMP_DB"
    exit 1
fi

# Cleanup
rm -f "$TEMP_DB"

# Reload nginx to apply new database (GeoIP2 has auto_reload but force reload anyway)
log "Reloading nginx configuration..."
docker exec nginx-proxy nginx -s reload

if [ $? -eq 0 ]; then
    log "GeoIP database update completed successfully"
else
    log "WARNING: nginx reload failed, but database was updated"
    exit 1
fi

# Optional: Log database age
DB_DATE=$(docker run --rm -v "$GEOIP_VOLUME:/geoip" alpine stat -c %y /geoip/GeoLite2-Country.mmdb 2>/dev/null || echo "unknown")
log "Database timestamp: $DB_DATE"

exit 0
