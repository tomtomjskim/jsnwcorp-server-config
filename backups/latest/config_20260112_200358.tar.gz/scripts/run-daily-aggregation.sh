#!/bin/bash

# Daily Stats Aggregation Wrapper Script
# Run via cron: 0 0 * * * /home/deploy/scripts/run-daily-aggregation.sh

LOGFILE="/home/deploy/logs/daily-aggregation.log"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

echo "[$TIMESTAMP] Starting daily stats aggregation..." >> "$LOGFILE"

# Run aggregation script in dashboard container (yesterday's data)
docker exec dashboard node /app/scripts/aggregate-daily-stats.js >> "$LOGFILE" 2>&1

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
  echo "[$TIMESTAMP] ✓ Daily stats aggregation completed successfully" >> "$LOGFILE"
else
  echo "[$TIMESTAMP] ✗ Daily stats aggregation failed with exit code $EXIT_CODE" >> "$LOGFILE"
fi

# Keep only last 30 days of logs
find /home/deploy/logs -name "daily-aggregation.log.*" -mtime +30 -delete 2>/dev/null

exit $EXIT_CODE
