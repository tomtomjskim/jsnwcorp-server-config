#!/bin/bash
# Deploy User Permission Verification Script

echo "=========================================="
echo "  Deploy User Permission Check"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

check_pass() {
    echo -e "${GREEN}✓${NC} $1"
}

check_fail() {
    echo -e "${RED}✗${NC} $1"
}

# 1. Current user check
echo "1. Current User:"
if [ "$(whoami)" = "deploy" ]; then
    check_pass "Running as deploy user"
else
    check_fail "NOT running as deploy user (current: $(whoami))"
fi
echo ""

# 2. Group membership
echo "2. Group Membership:"
if groups | grep -q '\bdocker\b'; then
    check_pass "Member of docker group"
else
    check_fail "NOT a member of docker group"
fi

if groups | grep -q '\bsudo\b'; then
    check_pass "Member of sudo group"
else
    check_fail "NOT a member of sudo group"
fi
echo ""

# 3. Docker access test
echo "3. Docker Access:"
if docker ps &>/dev/null; then
    check_pass "Can execute 'docker ps'"
else
    check_fail "CANNOT execute 'docker ps'"
fi

if docker compose ps &>/dev/null; then
    check_pass "Can execute 'docker compose ps'"
else
    check_fail "CANNOT execute 'docker compose ps'"
fi
echo ""

# 4. File ownership check
echo "4. File Ownership:"
if [ "$(stat -c '%U' /home/deploy)" = "deploy" ]; then
    check_pass "/home/deploy owned by deploy"
else
    check_fail "/home/deploy NOT owned by deploy"
fi
echo ""

# 5. Write permission check
echo "5. Write Permission:"
if touch /home/deploy/test_file.tmp 2>/dev/null; then
    check_pass "Can write to /home/deploy"
    rm /home/deploy/test_file.tmp
else
    check_fail "CANNOT write to /home/deploy"
fi
echo ""

# 6. Sudo access check
echo "6. Sudo Access:"
if sudo -n true 2>/dev/null; then
    check_pass "Can use sudo without password"
elif sudo -v 2>/dev/null; then
    check_pass "Can use sudo (with password)"
else
    check_fail "CANNOT use sudo"
fi
echo ""

echo "=========================================="
echo "  Verification Complete"
echo "=========================================="
