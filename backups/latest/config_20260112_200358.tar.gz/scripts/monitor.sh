#!/bin/bash
# System Monitoring Script

echo "=========================================="
echo "  System Monitoring Dashboard"
echo "=========================================="
echo ""

# System Resources
echo "[System Resources]"
echo "CPU Usage:"
top -bn1 | grep "Cpu(s)" | sed "s/.*, *\([0-9.]*\)%* id.*/\1/" | awk '{print "  Usage: " 100 - $1"%"}'

echo "Memory Usage:"
free -h | awk 'NR==2{printf "  Used: %s / %s (%.2f%%)\n", $3, $2, $3*100/$2}'

echo "Disk Usage:"
df -h / | awk 'NR==2{printf "  Used: %s / %s (%s)\n", $3, $2, $5}'

echo ""

# Docker Container Status
echo "[Container Status]"
cd /home/deploy
docker compose ps

echo ""

# Container Resources
echo "[Container Resources]"
docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}"

echo ""
echo "=========================================="
