#!/bin/bash

#############################################################################
# 로그 정리 자동화 스크립트
# 용도: 1개월(30일) 이상 된 오래된 로그 파일 자동 삭제
# 작성일: 2025-10-15
#############################################################################

set -e

# 설정
LOG_RETENTION_DAYS=30
LOG_DIR="/home/deploy/nginx/logs"
DOCKER_LOG_DIR="/var/lib/docker/containers"
BACKUP_DIR="/home/deploy/backups"
SCRIPT_LOG="/home/deploy/logs/cleanup.log"
DRY_RUN=false

# 색상 코드
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 로그 디렉토리 생성
mkdir -p /home/deploy/logs

# 로그 함수
log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1" | tee -a "$SCRIPT_LOG"
}

log_color() {
    echo -e "${2}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$SCRIPT_LOG"
}

# 사용법 출력
usage() {
    echo "사용법: $0 [OPTIONS]"
    echo ""
    echo "옵션:"
    echo "  -d DAYS     로그 보존 기간 (기본값: 30일)"
    echo "  -n          Dry-run 모드 (실제 삭제하지 않고 확인만)"
    echo "  -h          도움말 표시"
    echo ""
    echo "예시:"
    echo "  $0              # 30일 이상 된 로그 삭제"
    echo "  $0 -d 60        # 60일 이상 된 로그 삭제"
    echo "  $0 -n           # 삭제할 파일만 확인 (실제 삭제 안 함)"
    exit 0
}

# 옵션 파싱
while getopts "d:nh" opt; do
    case $opt in
        d) LOG_RETENTION_DAYS=$OPTARG ;;
        n) DRY_RUN=true ;;
        h) usage ;;
        *) usage ;;
    esac
done

#############################################################################
# 메인 로직 시작
#############################################################################

log_color "========================================" "$BLUE"
log_color "로그 정리 스크립트 시작" "$BLUE"
log_color "보존 기간: ${LOG_RETENTION_DAYS}일" "$BLUE"
if [ "$DRY_RUN" = true ]; then
    log_color "모드: DRY-RUN (실제 삭제 안 함)" "$YELLOW"
fi
log_color "========================================" "$BLUE"

# 초기 디스크 사용량
INITIAL_DISK=$(df -h / | awk 'NR==2{print $3}')
log "초기 디스크 사용량: $INITIAL_DISK"

#############################################################################
# 1. Nginx 로그 정리
#############################################################################

log_color "\n[1] Nginx 로그 파일 정리" "$GREEN"

if [ -d "$LOG_DIR" ]; then
    # 오래된 로그 파일 찾기
    OLD_NGINX_LOGS=$(find "$LOG_DIR" -name "*.log*" -type f -mtime +${LOG_RETENTION_DAYS} 2>/dev/null || true)

    if [ -n "$OLD_NGINX_LOGS" ]; then
        log "발견된 오래된 Nginx 로그:"
        echo "$OLD_NGINX_LOGS" | while read -r file; do
            FILE_SIZE=$(du -h "$file" 2>/dev/null | cut -f1)
            FILE_AGE=$(find "$file" -mtime +${LOG_RETENTION_DAYS} -printf "%Td일 전\n" 2>/dev/null)
            log "  - $file ($FILE_SIZE, $FILE_AGE)"
        done

        if [ "$DRY_RUN" = false ]; then
            COUNT=$(echo "$OLD_NGINX_LOGS" | wc -l)
            find "$LOG_DIR" -name "*.log*" -type f -mtime +${LOG_RETENTION_DAYS} -delete 2>/dev/null
            log_color "✓ $COUNT 개의 Nginx 로그 파일 삭제 완료" "$GREEN"
        else
            log_color "⚠ DRY-RUN: 삭제하지 않음" "$YELLOW"
        fi
    else
        log "삭제할 오래된 Nginx 로그 없음"
    fi
else
    log "Nginx 로그 디렉토리 없음: $LOG_DIR"
fi

#############################################################################
# 2. Docker 컨테이너 로그 정리
#############################################################################

log_color "\n[2] Docker 컨테이너 로그 정리" "$GREEN"

# Docker 컨테이너 로그는 json-file driver 사용 시 자동으로 쌓임
# 오래된 로그 파일 찾기
if [ -d "$DOCKER_LOG_DIR" ]; then
    OLD_DOCKER_LOGS=$(find "$DOCKER_LOG_DIR" -name "*-json.log*" -type f -mtime +${LOG_RETENTION_DAYS} 2>/dev/null || true)

    if [ -n "$OLD_DOCKER_LOGS" ]; then
        log "발견된 오래된 Docker 컨테이너 로그:"
        echo "$OLD_DOCKER_LOGS" | while read -r file; do
            FILE_SIZE=$(du -h "$file" 2>/dev/null | cut -f1)
            log "  - $file ($FILE_SIZE)"
        done

        if [ "$DRY_RUN" = false ]; then
            COUNT=$(echo "$OLD_DOCKER_LOGS" | wc -l)
            find "$DOCKER_LOG_DIR" -name "*-json.log*" -type f -mtime +${LOG_RETENTION_DAYS} -delete 2>/dev/null
            log_color "✓ $COUNT 개의 Docker 로그 파일 삭제 완료" "$GREEN"
        else
            log_color "⚠ DRY-RUN: 삭제하지 않음" "$YELLOW"
        fi
    else
        log "삭제할 오래된 Docker 로그 없음"
    fi
fi

#############################################################################
# 3. 백업 파일 정리 (60일 이상)
#############################################################################

log_color "\n[3] 오래된 백업 파일 정리 (60일 이상)" "$GREEN"

BACKUP_RETENTION_DAYS=60

if [ -d "$BACKUP_DIR" ]; then
    OLD_BACKUPS=$(find "$BACKUP_DIR" -name "*.tar.gz" -o -name "*.sql.gz" -type f -mtime +${BACKUP_RETENTION_DAYS} 2>/dev/null || true)

    if [ -n "$OLD_BACKUPS" ]; then
        log "발견된 오래된 백업 파일:"
        echo "$OLD_BACKUPS" | while read -r file; do
            FILE_SIZE=$(du -h "$file" 2>/dev/null | cut -f1)
            log "  - $file ($FILE_SIZE)"
        done

        if [ "$DRY_RUN" = false ]; then
            COUNT=$(echo "$OLD_BACKUPS" | wc -l)
            find "$BACKUP_DIR" -type f \( -name "*.tar.gz" -o -name "*.sql.gz" \) -mtime +${BACKUP_RETENTION_DAYS} -delete 2>/dev/null
            log_color "✓ $COUNT 개의 백업 파일 삭제 완료" "$GREEN"
        else
            log_color "⚠ DRY-RUN: 삭제하지 않음" "$YELLOW"
        fi
    else
        log "삭제할 오래된 백업 파일 없음"
    fi
else
    log "백업 디렉토리 없음: $BACKUP_DIR"
fi

#############################################################################
# 4. 스크립트 로그 자체 정리 (90일 이상)
#############################################################################

log_color "\n[4] 스크립트 로그 정리 (90일 이상)" "$GREEN"

SCRIPT_LOG_RETENTION=90
SCRIPT_LOG_DIR="/home/deploy/logs"

if [ -d "$SCRIPT_LOG_DIR" ]; then
    OLD_SCRIPT_LOGS=$(find "$SCRIPT_LOG_DIR" -name "*.log" -type f -mtime +${SCRIPT_LOG_RETENTION} ! -name "cleanup.log" 2>/dev/null || true)

    if [ -n "$OLD_SCRIPT_LOGS" ]; then
        log "발견된 오래된 스크립트 로그:"
        echo "$OLD_SCRIPT_LOGS" | while read -r file; do
            FILE_SIZE=$(du -h "$file" 2>/dev/null | cut -f1)
            log "  - $file ($FILE_SIZE)"
        done

        if [ "$DRY_RUN" = false ]; then
            COUNT=$(echo "$OLD_SCRIPT_LOGS" | wc -l)
            find "$SCRIPT_LOG_DIR" -name "*.log" -type f -mtime +${SCRIPT_LOG_RETENTION} ! -name "cleanup.log" -delete 2>/dev/null
            log_color "✓ $COUNT 개의 스크립트 로그 파일 삭제 완료" "$GREEN"
        else
            log_color "⚠ DRY-RUN: 삭제하지 않음" "$YELLOW"
        fi
    else
        log "삭제할 오래된 스크립트 로그 없음"
    fi
fi

#############################################################################
# 5. systemd journal 로그 정리
#############################################################################

log_color "\n[5] systemd journal 로그 정리" "$GREEN"

if command -v journalctl &> /dev/null; then
    JOURNAL_SIZE_BEFORE=$(journalctl --disk-usage 2>/dev/null | grep -oP '\d+\.\d+[A-Z]+' || echo "unknown")
    log "현재 journal 크기: $JOURNAL_SIZE_BEFORE"

    if [ "$DRY_RUN" = false ]; then
        # 30일 이상 된 journal 로그 삭제
        journalctl --vacuum-time=${LOG_RETENTION_DAYS}d 2>/dev/null || log "journal 정리 권한 부족 (sudo 필요)"

        JOURNAL_SIZE_AFTER=$(journalctl --disk-usage 2>/dev/null | grep -oP '\d+\.\d+[A-Z]+' || echo "unknown")
        log_color "✓ systemd journal 정리 완료 ($JOURNAL_SIZE_BEFORE → $JOURNAL_SIZE_AFTER)" "$GREEN"
    else
        log_color "⚠ DRY-RUN: 삭제하지 않음" "$YELLOW"
    fi
else
    log "journalctl 명령어 없음"
fi

#############################################################################
# 6. 임시 파일 정리
#############################################################################

log_color "\n[6] 임시 파일 정리" "$GREEN"

TEMP_DIRS=("/tmp" "/var/tmp")

for temp_dir in "${TEMP_DIRS[@]}"; do
    if [ -d "$temp_dir" ]; then
        OLD_TEMP_FILES=$(find "$temp_dir" -type f -mtime +7 -name "*.tmp" -o -name "*.temp" -o -name "*.cache" 2>/dev/null || true)

        if [ -n "$OLD_TEMP_FILES" ]; then
            COUNT=$(echo "$OLD_TEMP_FILES" | wc -l)
            log "발견된 오래된 임시 파일 ($temp_dir): $COUNT 개"

            if [ "$DRY_RUN" = false ]; then
                find "$temp_dir" -type f -mtime +7 \( -name "*.tmp" -o -name "*.temp" -o -name "*.cache" \) -delete 2>/dev/null || true
                log_color "✓ $temp_dir 임시 파일 정리 완료" "$GREEN"
            else
                log_color "⚠ DRY-RUN: 삭제하지 않음" "$YELLOW"
            fi
        fi
    fi
done

#############################################################################
# 최종 요약
#############################################################################

FINAL_DISK=$(df -h / | awk 'NR==2{print $3}')

log_color "\n========================================" "$BLUE"
log_color "로그 정리 완료" "$GREEN"
log_color "========================================" "$BLUE"
log "초기 디스크 사용량: $INITIAL_DISK"
log "최종 디스크 사용량: $FINAL_DISK"

# 디스크 여유 공간 확인
DISK_FREE=$(df -h / | awk 'NR==2{print $4}')
DISK_USAGE=$(df -h / | awk 'NR==2{print $5}')
log "현재 여유 공간: $DISK_FREE (사용률: $DISK_USAGE)"

if [ "$DRY_RUN" = false ]; then
    log_color "✓ 모든 로그 정리 작업 완료" "$GREEN"
else
    log_color "⚠ DRY-RUN 모드: 실제 파일은 삭제되지 않았습니다" "$YELLOW"
    log_color "실제 삭제를 원하시면 -n 옵션 없이 실행하세요" "$YELLOW"
fi

log_color "========================================" "$BLUE"

exit 0
