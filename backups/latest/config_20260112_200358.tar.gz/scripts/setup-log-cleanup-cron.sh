#!/bin/bash

#############################################################################
# 로그 정리 Cron Job 설정 스크립트
# 용도: 로그 정리 자동화를 위한 cron job 설치
# 작성일: 2025-10-15
#############################################################################

set -e

SCRIPT_PATH="/home/deploy/scripts/cleanup-logs.sh"
CRON_USER="root"

echo "========================================="
echo "로그 정리 Cron Job 설정"
echo "========================================="
echo ""

# cleanup-logs.sh 실행 권한 확인
if [ ! -x "$SCRIPT_PATH" ]; then
    echo "❌ 오류: $SCRIPT_PATH 파일이 실행 가능하지 않습니다."
    echo "다음 명령어를 실행하세요: chmod +x $SCRIPT_PATH"
    exit 1
fi

echo "✓ cleanup-logs.sh 스크립트 확인 완료"
echo ""

# 기존 cron job 확인
echo "기존 cron job 확인 중..."
EXISTING_CRON=$(crontab -l 2>/dev/null | grep -F "$SCRIPT_PATH" || true)

if [ -n "$EXISTING_CRON" ]; then
    echo "⚠️  이미 등록된 cron job이 있습니다:"
    echo "   $EXISTING_CRON"
    echo ""
    read -p "기존 설정을 덮어쓰시겠습니까? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "취소되었습니다."
        exit 0
    fi
    # 기존 cron job 제거
    crontab -l 2>/dev/null | grep -v -F "$SCRIPT_PATH" | crontab - || true
    echo "기존 cron job 제거 완료"
fi

# 새 cron job 추가
echo ""
echo "새로운 cron job을 추가합니다..."
echo ""
echo "선택 가능한 실행 주기:"
echo "  1) 매일 새벽 3시 (권장)"
echo "  2) 매주 일요일 새벽 3시"
echo "  3) 매월 1일 새벽 3시"
echo "  4) 사용자 정의"
echo ""
read -p "선택하세요 (1-4): " CHOICE

case $CHOICE in
    1)
        CRON_SCHEDULE="0 3 * * *"
        DESCRIPTION="매일 새벽 3시"
        ;;
    2)
        CRON_SCHEDULE="0 3 * * 0"
        DESCRIPTION="매주 일요일 새벽 3시"
        ;;
    3)
        CRON_SCHEDULE="0 3 1 * *"
        DESCRIPTION="매월 1일 새벽 3시"
        ;;
    4)
        echo ""
        echo "Cron 표현식을 입력하세요 (예: 0 3 * * *):"
        read -p "> " CRON_SCHEDULE
        DESCRIPTION="사용자 정의 ($CRON_SCHEDULE)"
        ;;
    *)
        echo "잘못된 선택입니다."
        exit 1
        ;;
esac

# 로그 보존 기간 설정
echo ""
echo "로그 보존 기간 (일)을 입력하세요:"
read -p "기본값: 30일, 입력 (엔터키: 기본값 사용): " RETENTION_DAYS
RETENTION_DAYS=${RETENTION_DAYS:-30}

# Cron job 생성
CRON_JOB="$CRON_SCHEDULE $SCRIPT_PATH -d $RETENTION_DAYS >> /home/deploy/logs/cleanup.log 2>&1"

# 현재 crontab에 추가
(crontab -l 2>/dev/null || true; echo "# 로그 자동 정리 - $DESCRIPTION (${RETENTION_DAYS}일 보존)"; echo "$CRON_JOB") | crontab -

echo ""
echo "========================================="
echo "✅ Cron Job 설정 완료!"
echo "========================================="
echo ""
echo "설정 내용:"
echo "  - 실행 주기: $DESCRIPTION"
echo "  - 실행 스크립트: $SCRIPT_PATH"
echo "  - 로그 보존 기간: ${RETENTION_DAYS}일"
echo "  - 로그 파일: /home/deploy/logs/cleanup.log"
echo ""
echo "현재 등록된 cron job 목록:"
echo "---"
crontab -l | grep -v "^#" | grep -v "^$" || echo "(없음)"
echo "---"
echo ""
echo "💡 팁:"
echo "  - cron job 목록 확인: crontab -l"
echo "  - cron job 편집: crontab -e"
echo "  - 실행 로그 확인: tail -f /home/deploy/logs/cleanup.log"
echo "  - 수동 실행: $SCRIPT_PATH"
echo ""

exit 0
