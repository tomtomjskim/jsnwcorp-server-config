#!/bin/bash
#
# Deploy User Setup Script
# 용도: deploy 사용자에게 Docker 및 시스템 권한 부여
# 실행: sudo bash /home/deploy/scripts/setup-deploy-user.sh
#

set -e  # 에러 발생 시 중단

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 로그 함수
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# root 권한 확인
if [ "$EUID" -ne 0 ]; then
    log_error "이 스크립트는 root 권한이 필요합니다."
    log_info "실행 방법: sudo bash $0"
    exit 1
fi

echo "=========================================="
echo "  Deploy User Setup Script"
echo "=========================================="
echo ""

# 1. deploy 사용자 존재 확인
log_info "1. deploy 사용자 확인 중..."
if id "deploy" &>/dev/null; then
    log_success "deploy 사용자가 이미 존재합니다."
else
    log_warning "deploy 사용자가 없습니다. 생성하시겠습니까? (y/n)"
    read -r answer
    if [ "$answer" = "y" ]; then
        useradd -m -s /bin/bash deploy
        log_success "deploy 사용자가 생성되었습니다."

        log_info "비밀번호를 설정해주세요:"
        passwd deploy
    else
        log_error "deploy 사용자가 필요합니다. 스크립트를 종료합니다."
        exit 1
    fi
fi

# 2. docker 그룹 추가
log_info "2. docker 그룹 권한 부여 중..."
if groups deploy | grep -q '\bdocker\b'; then
    log_success "deploy 사용자가 이미 docker 그룹에 속해 있습니다."
else
    usermod -aG docker deploy
    log_success "deploy 사용자를 docker 그룹에 추가했습니다."
fi

# 3. sudo 그룹 추가
log_info "3. sudo 그룹 권한 부여 중..."
if groups deploy | grep -q '\bsudo\b'; then
    log_success "deploy 사용자가 이미 sudo 그룹에 속해 있습니다."
else
    usermod -aG sudo deploy
    log_success "deploy 사용자를 sudo 그룹에 추가했습니다."
fi

# 4. /home/deploy 소유권 변경
log_info "4. /home/deploy 소유권 변경 중..."
if [ -d "/home/deploy" ]; then
    chown -R deploy:deploy /home/deploy
    log_success "/home/deploy의 소유권을 deploy:deploy로 변경했습니다."
else
    log_error "/home/deploy 디렉토리가 없습니다."
    exit 1
fi

# 5. Docker 소켓 권한 확인
log_info "5. Docker 소켓 권한 확인 중..."
if [ -S "/var/run/docker.sock" ]; then
    SOCKET_GROUP=$(stat -c '%G' /var/run/docker.sock)
    log_info "Docker 소켓 그룹: $SOCKET_GROUP"

    if [ "$SOCKET_GROUP" = "docker" ]; then
        log_success "Docker 소켓이 docker 그룹 소유입니다."
    else
        log_warning "Docker 소켓이 $SOCKET_GROUP 그룹 소유입니다."
        log_warning "필요시 'sudo chgrp docker /var/run/docker.sock' 실행"
    fi
else
    log_error "/var/run/docker.sock이 존재하지 않습니다. Docker가 실행 중인지 확인하세요."
fi

# 6. SSH 키 복사 (선택)
log_info "6. SSH 키 설정..."
if [ -d "/root/.ssh" ] && [ -f "/root/.ssh/authorized_keys" ]; then
    log_warning "root의 SSH 키를 deploy에 복사하시겠습니까? (y/n)"
    read -r answer
    if [ "$answer" = "y" ]; then
        mkdir -p /home/deploy/.ssh
        cp /root/.ssh/authorized_keys /home/deploy/.ssh/
        chown -R deploy:deploy /home/deploy/.ssh
        chmod 700 /home/deploy/.ssh
        chmod 600 /home/deploy/.ssh/authorized_keys
        log_success "SSH 키가 복사되었습니다."
    else
        log_info "SSH 키 복사를 건너뜁니다."
    fi
else
    log_warning "/root/.ssh/authorized_keys가 없습니다. SSH 키 복사를 건너뜁니다."
fi

# 7. sudoers 설정 (NOPASSWD)
log_info "7. sudo 비밀번호 없이 사용 설정..."
log_warning "deploy 사용자가 sudo 명령어를 비밀번호 없이 사용하도록 하시겠습니까? (y/n)"
log_warning "(포트폴리오 프로젝트용으로는 권장, 프로덕션에서는 비권장)"
read -r answer
if [ "$answer" = "y" ]; then
    # sudoers.d 파일 생성
    echo "deploy ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/deploy
    chmod 440 /etc/sudoers.d/deploy
    log_success "deploy 사용자가 sudo를 비밀번호 없이 사용할 수 있습니다."
else
    log_info "sudo 비밀번호 설정을 건너뜁니다. 사용 시 비밀번호가 요구됩니다."
fi

# 8. .bashrc 설정
log_info "8. .bashrc 별칭 추가 중..."
BASHRC="/home/deploy/.bashrc"

# 백업
if [ -f "$BASHRC" ]; then
    cp "$BASHRC" "$BASHRC.backup.$(date +%Y%m%d_%H%M%S)"
    log_info ".bashrc 백업 완료"
fi

# 별칭 추가 (중복 방지)
if ! grep -q "# Docker aliases" "$BASHRC" 2>/dev/null; then
    cat >> "$BASHRC" << 'EOF'

# Docker aliases
alias dc='docker compose'
alias dcup='docker compose up -d'
alias dcdown='docker compose down'
alias dclogs='docker compose logs -f'
alias dcps='docker compose ps'
alias dcrestart='docker compose restart'

# Project directory
export PROJECT_HOME=/home/deploy
alias cdp='cd $PROJECT_HOME'

# Safety aliases
alias rm='rm -i'
alias cp='cp -i'
alias mv='mv -i'

# Colorful prompt
export PS1='\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '
EOF
    chown deploy:deploy "$BASHRC"
    log_success ".bashrc에 별칭이 추가되었습니다."
else
    log_success ".bashrc에 별칭이 이미 존재합니다."
fi

# 9. 최종 확인
echo ""
echo "=========================================="
echo "  설정 완료 - 최종 확인"
echo "=========================================="
echo ""

log_info "사용자 정보:"
id deploy

log_info "그룹 정보:"
groups deploy

log_info "/home/deploy 소유권:"
ls -ld /home/deploy

if [ -S "/var/run/docker.sock" ]; then
    log_info "Docker 소켓 권한:"
    ls -la /var/run/docker.sock
fi

echo ""
echo "=========================================="
echo "  다음 단계"
echo "=========================================="
echo ""
log_success "설정이 완료되었습니다!"
echo ""
log_info "1. deploy 사용자로 전환:"
echo "   su - deploy"
echo ""
log_info "2. Docker 명령어 테스트:"
echo "   docker ps"
echo "   docker compose ps"
echo ""
log_info "3. SSH로 재접속 (그룹 변경 적용):"
echo "   exit"
echo "   ssh deploy@203.245.30.6"
echo ""
log_warning "주의: 그룹 변경사항은 재로그인 후 적용됩니다."
echo ""

# 10. 검증 스크립트 생성
log_info "검증 스크립트 생성 중..."
cat > /home/deploy/scripts/verify-permissions.sh << 'EOF'
#!/bin/bash
# Deploy User Permission Verification Script

echo "=========================================="
echo "  Deploy User Permission Check"
echo "=========================================="
echo ""

# 색상
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

check_pass() {
    echo -e "${GREEN}✓${NC} $1"
}

check_fail() {
    echo -e "${RED}✗${NC} $1"
}

# 1. 현재 사용자 확인
echo "1. Current User:"
if [ "$(whoami)" = "deploy" ]; then
    check_pass "Running as deploy user"
else
    check_fail "NOT running as deploy user (current: $(whoami))"
fi
echo ""

# 2. 그룹 확인
echo "2. Group Membership:"
if groups | grep -q '\bdocker\b'; then
    check_pass "Member of docker group"
else
    check_fail "NOT a member of docker group"
fi

if groups | grep -q '\bsudo\b'; then
    check_pass "Member of sudo group"
else
    check_fail "NOT a member of sudo group"
fi
echo ""

# 3. Docker 명령어 테스트
echo "3. Docker Access:"
if docker ps &>/dev/null; then
    check_pass "Can execute 'docker ps'"
else
    check_fail "CANNOT execute 'docker ps'"
fi

if docker compose ps &>/dev/null; then
    check_pass "Can execute 'docker compose ps'"
else
    check_fail "CANNOT execute 'docker compose ps'"
fi
echo ""

# 4. 파일 소유권 확인
echo "4. File Ownership:"
if [ "$(stat -c '%U' /home/deploy)" = "deploy" ]; then
    check_pass "/home/deploy owned by deploy"
else
    check_fail "/home/deploy NOT owned by deploy"
fi
echo ""

# 5. 쓰기 권한 확인
echo "5. Write Permission:"
if touch /home/deploy/test_file.tmp 2>/dev/null; then
    check_pass "Can write to /home/deploy"
    rm /home/deploy/test_file.tmp
else
    check_fail "CANNOT write to /home/deploy"
fi
echo ""

# 6. sudo 확인
echo "6. Sudo Access:"
if sudo -n true 2>/dev/null; then
    check_pass "Can use sudo without password"
elif sudo -v 2>/dev/null; then
    check_pass "Can use sudo (with password)"
else
    check_fail "CANNOT use sudo"
fi
echo ""

echo "=========================================="
echo "  Verification Complete"
echo "=========================================="
EOF

chmod +x /home/deploy/scripts/verify-permissions.sh
chown deploy:deploy /home/deploy/scripts/verify-permissions.sh
log_success "검증 스크립트가 생성되었습니다: /home/deploy/scripts/verify-permissions.sh"

echo ""
log_info "검증 스크립트 실행 방법:"
echo "   su - deploy"
echo "   bash /home/deploy/scripts/verify-permissions.sh"
echo ""

log_success "모든 설정이 완료되었습니다!"
