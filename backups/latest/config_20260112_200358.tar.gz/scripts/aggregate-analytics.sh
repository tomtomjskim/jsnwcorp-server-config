#!/bin/bash
# ============================================================================
# Analytics Data Aggregation Script
# ============================================================================
# Purpose: Aggregate analytics_events into daily/hourly statistics
# Schedule: Run daily at 00:05 AM via cron
# ============================================================================

set -e

LOG_FILE="/home/deploy/logs/analytics-aggregation.log"
DATE=$(date '+%Y-%m-%d %H:%M:%S')

echo "[$DATE] Starting analytics aggregation..." >> "$LOG_FILE"

# PostgreSQL connection details from environment
POSTGRES_HOST="${POSTGRES_HOST:-postgres}"
POSTGRES_PORT="${POSTGRES_PORT:-5432}"
POSTGRES_DB="${POSTGRES_DB:-maindb}"
POSTGRES_USER="${POSTGRES_USER:-appuser}"
export PGPASSWORD="${POSTGRES_PASSWORD:-SecurePassword123!ChangeMeInProduction}"

# SQL for daily aggregation
DAILY_AGGREGATION_SQL="
INSERT INTO analytics.daily_stats (
    project_id,
    stat_date,
    total_events,
    unique_users,
    total_sessions,
    avg_session_duration_seconds,
    page_views,
    created_at
)
SELECT
    project_id,
    date,
    COUNT(*) as total_events,
    COUNT(DISTINCT user_id) FILTER (WHERE user_id IS NOT NULL) as unique_users,
    COUNT(DISTINCT session_id) as total_sessions,
    0 as avg_session_duration_seconds,
    COUNT(*) FILTER (WHERE event_type = 'pageview') as page_views,
    NOW() as created_at
FROM public.analytics_events
WHERE date >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY project_id, date
ON CONFLICT (project_id, stat_date)
DO UPDATE SET
    total_events = EXCLUDED.total_events,
    unique_users = EXCLUDED.unique_users,
    total_sessions = EXCLUDED.total_sessions,
    page_views = EXCLUDED.page_views,
    updated_at = NOW();
"

# SQL for hourly aggregation
HOURLY_AGGREGATION_SQL="
INSERT INTO analytics.hourly_stats (
    project_id,
    stat_hour,
    total_events,
    unique_users,
    avg_response_time_ms,
    error_count,
    created_at
)
SELECT
    project_id,
    DATE_TRUNC('hour', created_at) as stat_hour,
    COUNT(*) as total_events,
    COUNT(DISTINCT user_id) FILTER (WHERE user_id IS NOT NULL) as unique_users,
    0 as avg_response_time_ms,
    COUNT(*) FILTER (WHERE event_type = 'error') as error_count,
    NOW() as created_at
FROM public.analytics_events
WHERE created_at >= NOW() - INTERVAL '48 hours'
GROUP BY project_id, DATE_TRUNC('hour', created_at)
ON CONFLICT (project_id, stat_hour)
DO UPDATE SET
    total_events = EXCLUDED.total_events,
    unique_users = EXCLUDED.unique_users,
    error_count = EXCLUDED.error_count,
    updated_at = NOW();
"

# Execute aggregation
echo "[$DATE] Aggregating daily statistics..." >> "$LOG_FILE"
docker exec postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "$DAILY_AGGREGATION_SQL" >> "$LOG_FILE" 2>&1

if [ $? -eq 0 ]; then
    echo "[$DATE] Daily aggregation completed successfully" >> "$LOG_FILE"
else
    echo "[$DATE] ERROR: Daily aggregation failed" >> "$LOG_FILE"
    exit 1
fi

echo "[$DATE] Aggregating hourly statistics..." >> "$LOG_FILE"
docker exec postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "$HOURLY_AGGREGATION_SQL" >> "$LOG_FILE" 2>&1

if [ $? -eq 0 ]; then
    echo "[$DATE] Hourly aggregation completed successfully" >> "$LOG_FILE"
else
    echo "[$DATE] ERROR: Hourly aggregation failed" >> "$LOG_FILE"
    exit 1
fi

# Cleanup old events (older than 90 days)
CLEANUP_SQL="DELETE FROM public.analytics_events WHERE date < CURRENT_DATE - INTERVAL '90 days';"

echo "[$DATE] Cleaning up old events..." >> "$LOG_FILE"
docker exec postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "$CLEANUP_SQL" >> "$LOG_FILE" 2>&1

echo "[$DATE] Analytics aggregation completed" >> "$LOG_FILE"
echo "========================================" >> "$LOG_FILE"

exit 0
