#!/bin/bash
################################################################################
# AI Service Memory Monitoring Script
#
# Purpose: Monitor system memory and automatically manage AI services
#          to prevent system-wide memory overflow
#
# Actions:
#   - If memory >= 85%: Stop AI services (ai-chatbot, ollama)
#   - If memory <= 60%: Restart AI services if they were stopped
#   - Log all actions to /home/deploy/logs/ai-monitor.log
#   - Update PostgreSQL ai_service_status table
#
# Usage: Run via cron every 5 minutes
#   */5 * * * * /home/deploy/scripts/ai-monitor.sh
################################################################################

# Configuration
MEMORY_THRESHOLD=85  # Stop AI services if memory >= 85%
MEMORY_SAFE=60       # Restart AI services if memory <= 60%
LOG_FILE="/home/deploy/logs/ai-monitor.log"
COMPOSE_DIR="/home/deploy"

# Ensure log directory exists
mkdir -p "$(dirname "$LOG_FILE")"

# Function: Get current memory usage
check_memory() {
  total=$(free -m | awk '/^Mem:/{print $2}')
  used=$(free -m | awk '/^Mem:/{print $3}')
  percent=$((used * 100 / total))
  echo "$percent $used $total"
}

# Function: Check if AI services are running
check_ai_services() {
  ai_running=$(docker ps --filter "name=ai-chatbot" --filter "status=running" -q)
  ollama_running=$(docker ps --filter "name=ollama" --filter "status=running" -q)

  if [ -n "$ai_running" ] && [ -n "$ollama_running" ]; then
    echo "active"
  elif [ -z "$ai_running" ] && [ -z "$ollama_running" ]; then
    echo "stopped"
  else
    echo "partial"
  fi
}

# Function: Stop AI services
stop_ai_services() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] Stopping AI services (Memory: ${1}%)" >> "$LOG_FILE"

  cd "$COMPOSE_DIR" || exit 1
  docker compose stop ai-chatbot ollama

  # Update PostgreSQL
  docker exec postgres psql -U appuser -d maindb -c \
    "INSERT INTO public.ai_service_status (service_name, status, reason, memory_usage_mb, total_memory_mb, memory_percent)
     VALUES ('ai-chatbot', 'paused', 'memory_overload', ${2}, ${3}, ${1});" \
    >> "$LOG_FILE" 2>&1

  echo "$(date '+%Y-%m-%d %H:%M:%S') [SUCCESS] AI services stopped successfully" >> "$LOG_FILE"
}

# Function: Start AI services
start_ai_services() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] Starting AI services (Memory: ${1}%)" >> "$LOG_FILE"

  cd "$COMPOSE_DIR" || exit 1

  # Start Ollama first
  docker compose start ollama
  sleep 10  # Wait for Ollama to initialize

  # Then start AI chatbot
  docker compose start ai-chatbot
  sleep 5   # Wait for chatbot to initialize

  # Update PostgreSQL
  docker exec postgres psql -U appuser -d maindb -c \
    "INSERT INTO public.ai_service_status (service_name, status, reason, memory_usage_mb, total_memory_mb, memory_percent)
     VALUES ('ai-chatbot', 'active', 'auto_restart', ${2}, ${3}, ${1});" \
    >> "$LOG_FILE" 2>&1

  echo "$(date '+%Y-%m-%d %H:%M:%S') [SUCCESS] AI services started successfully" >> "$LOG_FILE"
}

# Main Logic
read percent used total <<< $(check_memory)
ai_status=$(check_ai_services)

echo "$(date '+%Y-%m-%d %H:%M:%S') [CHECK] Memory: ${percent}% (${used}MB/${total}MB), AI Status: ${ai_status}" >> "$LOG_FILE"

# Memory overload - stop services
if [ $percent -ge $MEMORY_THRESHOLD ]; then
  if [ "$ai_status" == "active" ]; then
    stop_ai_services "$percent" "$used" "$total"
  elif [ "$ai_status" == "partial" ]; then
    # Ensure both are stopped
    cd "$COMPOSE_DIR" || exit 1
    docker compose stop ai-chatbot ollama
    echo "$(date '+%Y-%m-%d %H:%M:%S') [WARN] Partial AI services detected, stopping all" >> "$LOG_FILE"
  fi

# Memory safe - restart services
elif [ $percent -le $MEMORY_SAFE ]; then
  if [ "$ai_status" == "stopped" ]; then
    start_ai_services "$percent" "$used" "$total"
  elif [ "$ai_status" == "partial" ]; then
    # Restart all to ensure consistency
    cd "$COMPOSE_DIR" || exit 1
    docker compose stop ai-chatbot ollama
    start_ai_services "$percent" "$used" "$total"
  fi

# Memory in warning zone (60% < memory < 85%)
else
  echo "$(date '+%Y-%m-%d %H:%M:%S') [OK] Memory in normal range, no action needed" >> "$LOG_FILE"
fi

exit 0
