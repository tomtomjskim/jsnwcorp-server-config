# 🎰 LottoMaster

데이터 기반 로또 번호 추천 서비스

## 🚀 기능

- **번호 생성**: 3가지 알고리즘 (랜덤, 빈도, 패턴)
- **당첨 이력**: 역대 당첨번호 조회
- **통계 분석**: 번호별 출현 빈도 통계

## 🛠 기술 스택

- Next.js 15 (App Router)
- TypeScript 5
- Tailwind CSS 4
- shadcn/ui
- Recharts

## 📦 설치 및 실행

### 로컬 개발

```bash
# 의존성 설치
npm install

# 개발 서버 실행
npm run dev

# 빌드
npm run build

# 프로덕션 실행
npm start
```

### Docker 배포

```bash
# 이미지 빌드
docker build -f Dockerfile.prod -t lotto-master .

# 컨테이너 실행
docker run -p 3000:3000 lotto-master
```

## 📁 프로젝트 구조

```
src/
├── app/              # Next.js App Router
│   ├── api/          # API Routes
│   ├── history/      # 당첨 이력 페이지
│   └── stats/        # 통계 페이지
├── components/       # React 컴포넌트
│   ├── ui/           # shadcn/ui
│   └── lotto/        # 로또 컴포넌트
├── lib/              # 유틸리티 & 로직
│   ├── algorithms/   # 번호 생성 알고리즘
│   └── data/         # 데이터 로더
└── types/            # TypeScript 타입
```

## 🎯 API 엔드포인트

- `POST /api/lotto/generate` - 번호 생성
- `GET /api/lotto/history` - 당첨번호 조회
- `GET /api/stats/dashboard` - 통계 데이터
- `GET /api/health` - 헬스체크

## 📊 데이터

- 정적 JSON 파일 기반 (`public/data/lotto-data.json`)
- 데이터베이스 불필요
- 클라이언트 사이드 통계 계산

## 🔧 환경 변수

`.env.example` 참조

## 📝 License

MIT
