---
description: Build and deploy lotto-service with backup and verification
---

# Build and Deploy LottoMaster

Build and deploy the lotto-service Docker container with automated backup and verification.

## Steps to perform:

1. **Backup**: Run `/home/deploy/scripts/backup.sh` to create a backup before deployment
2. **Build**: Build the Docker image with `docker compose build lotto-service`
3. **Deploy**: Deploy with `docker compose up -d lotto-service`
4. **Verify**:
   - Check container status: `docker compose ps`
   - View logs: `docker compose logs lotto-service --tail 50`
   - Test health endpoint: `docker exec lotto-service wget --quiet --tries=1 --spider http://127.0.0.1:3000/api/health`
   - Test external access: `curl -s -o /dev/null -w "%{http_code}" http://203.245.30.6:3001/`

## Important Notes:

- Uses build cache for faster builds (no --no-cache flag)
- Rolling deployment with zero downtime
- Automatic health checks via Docker healthcheck
- All services remain running during deployment
- Backup stored in `/home/deploy/backups/` with timestamp

## Expected Result:

- Successful build in ~6-7 minutes (with cache)
- Container restarts with new image
- Service becomes (healthy) within 1-2 seconds
- HTTP 200 response on port 3001
