/** @type {import('next').NextConfig} */
const nextConfig = {
  // Standalone 모드 (Docker 최적화)
  output: 'standalone',

  // 이미지 최적화 비활성화 (메모리 절약)
  images: {
    unoptimized: true,
  },

  // 압축 활성화
  compress: true,

  // 메모리 최적화
  experimental: {
    workerThreads: false,
    cpus: 1,
    turbo: false,
  },

  // TypeScript 엄격 모드
  typescript: {
    ignoreBuildErrors: false,
  },
}

module.exports = nextConfig
