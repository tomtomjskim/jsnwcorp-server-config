#!/bin/bash
###############################################################################
# 로또 당첨번호 자동 수집 스크립트
#
# 설명:
#   - 일요일 또는 월요일에 최신 로또 당첨번호를 자동으로 수집
#   - 중복 체크 및 데이터 무결성 보장
#
# 사용법:
#   1. 실행 권한 부여: chmod +x scripts/lotto-cron.sh
#   2. crontab 등록:
#      # 매주 일요일 오전 9시에 실행
#      0 9 * * 0 cd /home/deploy/projects/lotto-master && ./scripts/lotto-cron.sh >> /var/log/lotto-cron.log 2>&1
#
#      # 매주 월요일 오전 9시에 실행
#      0 9 * * 1 cd /home/deploy/projects/lotto-master && ./scripts/lotto-cron.sh >> /var/log/lotto-cron.log 2>&1
#
###############################################################################

# 에러 발생 시 스크립트 중단
set -e

# 프로젝트 디렉토리 (스크립트 위치 기준)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# 로그 설정
LOG_FILE="${LOG_FILE:-/var/log/lotto-cron.log}"
DATE_FORMAT="+%Y-%m-%d %H:%M:%S"

# 로그 함수
log() {
    echo "[$(date "$DATE_FORMAT")] $1"
}

log_error() {
    echo "[$(date "$DATE_FORMAT")] ERROR: $1" >&2
}

# 시작 로그
log "=========================================="
log "로또 당첨번호 자동 수집 시작"
log "프로젝트 경로: $PROJECT_DIR"
log "=========================================="

# 프로젝트 디렉토리로 이동
cd "$PROJECT_DIR" || {
    log_error "프로젝트 디렉토리로 이동 실패: $PROJECT_DIR"
    exit 1
}

# 환경변수 로드 (.env 파일이 있는 경우)
if [ -f .env ]; then
    log ".env 파일 로드 중..."
    export $(grep -v '^#' .env | xargs)
fi

# Node.js 및 npm 경로 확인
if ! command -v node &> /dev/null; then
    log_error "Node.js를 찾을 수 없습니다."
    exit 1
fi

if ! command -v npm &> /dev/null; then
    log_error "npm을 찾을 수 없습니다."
    exit 1
fi

log "Node.js: $(node --version)"
log "npm: $(npm --version)"

# PostgreSQL 연결 확인
log "PostgreSQL 연결 확인 중..."
if ! PGPASSWORD="$POSTGRES_PASSWORD" psql -h "${POSTGRES_HOST:-postgres}" \
    -U "${POSTGRES_USER:-lotto_user}" \
    -d "${POSTGRES_DB:-maindb}" \
    -c "SELECT 1" > /dev/null 2>&1; then
    log_error "PostgreSQL 연결 실패"
    exit 1
fi
log "✅ PostgreSQL 연결 성공"

# 로또 데이터 수집 실행
log "로또 당첨번호 수집 시작..."
if npm run fetch-data-db -- --latest; then
    log "✅ 로또 당첨번호 수집 성공"
else
    log_error "❌ 로또 당첨번호 수집 실패"
    exit 1
fi

# 종료 로그
log "=========================================="
log "로또 당첨번호 자동 수집 완료"
log "=========================================="

exit 0
