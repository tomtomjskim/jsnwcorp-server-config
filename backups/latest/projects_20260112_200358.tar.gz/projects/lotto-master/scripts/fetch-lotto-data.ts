#!/usr/bin/env tsx
/**
 * 동행복권 로또 당첨번호 크롤러
 *
 * 사용법:
 *   npm run fetch-data
 *   또는
 *   npx tsx scripts/fetch-lotto-data.ts
 *
 * 옵션:
 *   --from=1 --to=1145  : 특정 범위만 수집
 *   --latest            : 최신 회차만 수집
 */

interface LottoApiResponse {
  returnValue: string
  drwNo: number
  drwNoDate: string
  drwtNo1: number
  drwtNo2: number
  drwtNo3: number
  drwtNo4: number
  drwtNo5: number
  drwtNo6: number
  bnusNo: number
  firstWinamnt: number
  firstPrzwnerCo: number
}

interface DrawResult {
  drawNo: number
  drawDate: string
  numbers: number[]
  bonusNum: number
  firstWinAmount: number | null
  firstWinCount: number | null
}

interface LottoData {
  meta: {
    lastUpdate: string
    totalDraws: number
    source: string
  }
  draws: DrawResult[]
}

const DHLOTTERY_API = 'https://www.dhlottery.co.kr/common.do?method=getLottoNumber'
const OUTPUT_FILE = './public/data/lotto-data.json'
const DELAY_MS = 200 // API 호출 간격 (Rate limiting)

// 최신 회차 번호 가져오기
async function getLatestDrawNo(): Promise<number> {
  try {
    const response = await fetch(`${DHLOTTERY_API}&drwNo=9999`)
    const data: LottoApiResponse = await response.json()

    if (data.returnValue === 'success') {
      console.log(`✅ 최신 회차: ${data.drwNo}회`)
      return data.drwNo
    }

    // 실패 시 수동 지정 (2025-10-16 기준)
    console.warn('⚠️  최신 회차 자동 감지 실패, 기본값 사용: 1145회')
    return 1145
  } catch (error) {
    console.error('❌ 최신 회차 조회 오류:', error)
    return 1145
  }
}

// 특정 회차 데이터 가져오기
async function fetchDrawData(drawNo: number): Promise<DrawResult | null> {
  try {
    const response = await fetch(`${DHLOTTERY_API}&drwNo=${drawNo}`)
    const data: LottoApiResponse = await response.json()

    if (data.returnValue !== 'success') {
      console.warn(`⚠️  ${drawNo}회 데이터 없음`)
      return null
    }

    return {
      drawNo: data.drwNo,
      drawDate: data.drwNoDate,
      numbers: [
        data.drwtNo1,
        data.drwtNo2,
        data.drwtNo3,
        data.drwtNo4,
        data.drwtNo5,
        data.drwtNo6,
      ].sort((a, b) => a - b),
      bonusNum: data.bnusNo,
      firstWinAmount: data.firstWinamnt || null,
      firstWinCount: data.firstPrzwnerCo || null,
    }
  } catch (error) {
    console.error(`❌ ${drawNo}회 조회 오류:`, error)
    return null
  }
}

// Sleep 함수
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

// 진행률 표시
function printProgress(current: number, total: number) {
  const percentage = ((current / total) * 100).toFixed(1)
  const bar = '='.repeat(Math.floor(current / total * 40))
  const empty = ' '.repeat(40 - bar.length)
  process.stdout.write(`\r진행: [${bar}${empty}] ${current}/${total} (${percentage}%)`)
}

// 메인 함수
async function main() {
  console.log('🎰 로또 당첨번호 크롤러 시작...\n')

  // 명령줄 인자 파싱
  const args = process.argv.slice(2)
  let fromDraw = 1
  let toDraw = 0
  let latestOnly = false

  args.forEach(arg => {
    if (arg.startsWith('--from=')) {
      fromDraw = parseInt(arg.split('=')[1])
    } else if (arg.startsWith('--to=')) {
      toDraw = parseInt(arg.split('=')[1])
    } else if (arg === '--latest') {
      latestOnly = true
    }
  })

  // 최신 회차 확인
  const latestDraw = await getLatestDrawNo()

  if (latestOnly) {
    fromDraw = latestDraw
    toDraw = latestDraw
    console.log(`📥 최신 회차만 수집: ${latestDraw}회\n`)
  } else if (toDraw === 0) {
    toDraw = latestDraw
  }

  console.log(`📊 수집 범위: ${fromDraw}회 ~ ${toDraw}회 (총 ${toDraw - fromDraw + 1}회)\n`)

  const draws: DrawResult[] = []
  let successCount = 0
  let failCount = 0

  // 데이터 수집
  for (let drawNo = fromDraw; drawNo <= toDraw; drawNo++) {
    const result = await fetchDrawData(drawNo)

    if (result) {
      draws.push(result)
      successCount++
    } else {
      failCount++
    }

    printProgress(drawNo - fromDraw + 1, toDraw - fromDraw + 1)

    // Rate limiting
    if (drawNo < toDraw) {
      await sleep(DELAY_MS)
    }
  }

  console.log('\n')
  console.log(`✅ 성공: ${successCount}회`)
  console.log(`❌ 실패: ${failCount}회\n`)

  if (draws.length === 0) {
    console.error('❌ 수집된 데이터가 없습니다.')
    process.exit(1)
  }

  // 회차 번호 역순 정렬 (최신 회차가 먼저)
  draws.sort((a, b) => b.drawNo - a.drawNo)

  // JSON 생성
  const lottoData: LottoData = {
    meta: {
      lastUpdate: new Date().toISOString().split('T')[0],
      totalDraws: draws.length,
      source: 'https://www.dhlottery.co.kr',
    },
    draws,
  }

  // 파일 저장
  const fs = await import('fs')
  const path = await import('path')

  const outputPath = path.resolve(process.cwd(), OUTPUT_FILE)
  const outputDir = path.dirname(outputPath)

  // 디렉토리 생성
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true })
  }

  fs.writeFileSync(outputPath, JSON.stringify(lottoData, null, 2), 'utf-8')

  console.log(`💾 저장 완료: ${outputPath}`)
  console.log(`📈 총 회차: ${draws.length}회`)
  console.log(`📅 최신: ${draws[0].drawNo}회 (${draws[0].drawDate})`)
  console.log(`📅 최초: ${draws[draws.length - 1].drawNo}회 (${draws[draws.length - 1].drawDate})`)

  // 통계 미리보기
  const numbers = draws.flatMap(d => d.numbers)
  const numberCounts = new Map<number, number>()

  numbers.forEach(num => {
    numberCounts.set(num, (numberCounts.get(num) || 0) + 1)
  })

  const sorted = Array.from(numberCounts.entries())
    .sort((a, b) => b[1] - a[1])

  console.log('\n📊 빈출 번호 TOP 5:')
  sorted.slice(0, 5).forEach(([num, count], idx) => {
    console.log(`   ${idx + 1}. ${num}번: ${count}회`)
  })

  console.log('\n✨ 완료!\n')
}

// 실행
main().catch(error => {
  console.error('❌ 실행 오류:', error)
  process.exit(1)
})
