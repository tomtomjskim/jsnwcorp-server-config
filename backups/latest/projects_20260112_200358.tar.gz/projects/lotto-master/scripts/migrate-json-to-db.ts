#!/usr/bin/env tsx
/**
 * JSON 데이터를 PostgreSQL DB로 마이그레이션
 *
 * 사용법:
 *   npx tsx scripts/migrate-json-to-db.ts
 */

import { Pool } from 'pg';
import { readFileSync } from 'fs';
import { resolve } from 'path';

interface DrawResult {
  drawNo: number;
  drawDate: string;
  numbers: number[];
  bonusNum: number;
  firstWinAmount: number | null;
  firstWinCount: number | null;
}

interface LottoData {
  meta: {
    lastUpdate: string;
    totalDraws: number;
    source: string;
  };
  draws: DrawResult[];
}

const pool = new Pool({
  host: process.env.POSTGRES_HOST || 'postgres',
  port: parseInt(process.env.POSTGRES_PORT || '5432'),
  database: process.env.POSTGRES_DB || 'maindb',
  user: process.env.POSTGRES_USER || 'lotto_user',
  password: process.env.POSTGRES_PASSWORD,
  options: `-c search_path=${process.env.POSTGRES_SCHEMA || 'lotto'},public`
});

async function migrateData() {
  console.log('🔄 JSON → PostgreSQL 마이그레이션 시작...\n');

  try {
    // 1. JSON 파일 읽기
    const jsonPath = resolve(process.cwd(), 'public/data/lotto-data.json');
    console.log(`📂 JSON 파일 로딩: ${jsonPath}`);

    const jsonData = readFileSync(jsonPath, 'utf-8');
    const lottoData: LottoData = JSON.parse(jsonData);

    console.log(`✅ 총 ${lottoData.draws.length}개 회차 데이터 로드 완료\n`);

    // 2. DB 연결 확인
    const client = await pool.connect();
    console.log('✅ PostgreSQL 연결 성공\n');

    try {
      // 3. 테이블 존재 확인
      const tableCheck = await client.query(`
        SELECT EXISTS (
          SELECT FROM information_schema.tables
          WHERE table_schema = 'lotto'
          AND table_name = 'draws'
        );
      `);

      if (!tableCheck.rows[0].exists) {
        console.error('❌ lotto.draws 테이블이 존재하지 않습니다.');
        console.error('   먼저 scripts/init-db.sql을 실행하세요.\n');
        process.exit(1);
      }

      // 4. 기존 데이터 확인
      const countResult = await client.query('SELECT COUNT(*) FROM lotto.draws');
      const existingCount = parseInt(countResult.rows[0].count);
      console.log(`📊 DB 기존 데이터: ${existingCount}개 회차`);

      // 5. 데이터 삽입 (중복 시 업데이트)
      console.log('🔄 데이터 삽입 중...\n');

      let insertCount = 0;
      let updateCount = 0;
      let errorCount = 0;

      for (const draw of lottoData.draws) {
        try {
          const result = await client.query(`
            INSERT INTO lotto.draws (
              draw_no, draw_date,
              num1, num2, num3, num4, num5, num6,
              bonus_num, first_win_amount, first_win_count
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            ON CONFLICT (draw_no)
            DO UPDATE SET
              draw_date = EXCLUDED.draw_date,
              num1 = EXCLUDED.num1,
              num2 = EXCLUDED.num2,
              num3 = EXCLUDED.num3,
              num4 = EXCLUDED.num4,
              num5 = EXCLUDED.num5,
              num6 = EXCLUDED.num6,
              bonus_num = EXCLUDED.bonus_num,
              first_win_amount = EXCLUDED.first_win_amount,
              first_win_count = EXCLUDED.first_win_count,
              updated_at = CURRENT_TIMESTAMP
            RETURNING (xmax = 0) AS inserted;
          `, [
            draw.drawNo,
            draw.drawDate,
            draw.numbers[0],
            draw.numbers[1],
            draw.numbers[2],
            draw.numbers[3],
            draw.numbers[4],
            draw.numbers[5],
            draw.bonusNum,
            draw.firstWinAmount,
            draw.firstWinCount
          ]);

          if (result.rows[0].inserted) {
            insertCount++;
          } else {
            updateCount++;
          }

          // 진행률 표시
          const progress = ((insertCount + updateCount + errorCount) / lottoData.draws.length * 100).toFixed(1);
          process.stdout.write(`\r진행: ${insertCount + updateCount + errorCount}/${lottoData.draws.length} (${progress}%)`);

        } catch (error) {
          errorCount++;
          console.error(`\n❌ ${draw.drawNo}회 삽입 실패:`, error);
        }
      }

      console.log('\n');
      console.log('✅ 마이그레이션 완료!\n');
      console.log(`📊 결과:`);
      console.log(`   - 신규 삽입: ${insertCount}개`);
      console.log(`   - 업데이트: ${updateCount}개`);
      console.log(`   - 실패: ${errorCount}개`);

      // 6. 최종 데이터 확인
      const finalCount = await client.query('SELECT COUNT(*) FROM lotto.draws');
      const latestDraw = await client.query(`
        SELECT draw_no, draw_date
        FROM lotto.draws
        ORDER BY draw_no DESC
        LIMIT 1
      `);

      console.log(`\n📈 DB 최종 데이터: ${finalCount.rows[0].count}개 회차`);
      console.log(`📅 최신 회차: ${latestDraw.rows[0].draw_no}회 (${latestDraw.rows[0].draw_date})`);

    } finally {
      client.release();
    }

  } catch (error) {
    console.error('❌ 마이그레이션 오류:', error);
    process.exit(1);
  } finally {
    await pool.end();
  }

  console.log('\n✨ 완료!\n');
}

// 실행
migrateData().catch(error => {
  console.error('❌ 실행 오류:', error);
  process.exit(1);
});
