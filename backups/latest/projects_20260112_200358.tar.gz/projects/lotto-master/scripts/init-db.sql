-- 로또 당첨 번호 데이터베이스 스키마
-- 실행 방법: psql -U lotto_user -d maindb -f scripts/init-db.sql

-- lotto 스키마가 없으면 생성
CREATE SCHEMA IF NOT EXISTS lotto;

-- 기존 테이블이 있으면 삭제 (주의: 개발 환경에서만)
-- DROP TABLE IF EXISTS lotto.draws CASCADE;

-- 로또 추첨 결과 테이블
CREATE TABLE IF NOT EXISTS lotto.draws (
    draw_no INTEGER PRIMARY KEY,                    -- 회차 번호
    draw_date DATE NOT NULL,                        -- 추첨일
    num1 INTEGER NOT NULL CHECK (num1 BETWEEN 1 AND 45),
    num2 INTEGER NOT NULL CHECK (num2 BETWEEN 1 AND 45),
    num3 INTEGER NOT NULL CHECK (num3 BETWEEN 1 AND 45),
    num4 INTEGER NOT NULL CHECK (num4 BETWEEN 1 AND 45),
    num5 INTEGER NOT NULL CHECK (num5 BETWEEN 1 AND 45),
    num6 INTEGER NOT NULL CHECK (num6 BETWEEN 1 AND 45),
    bonus_num INTEGER NOT NULL CHECK (bonus_num BETWEEN 1 AND 45),
    first_win_amount BIGINT,                        -- 1등 당첨금
    first_win_count INTEGER,                        -- 1등 당첨자 수
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- 데이터 삽입 시각
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  -- 데이터 수정 시각
);

-- 인덱스 생성
CREATE INDEX IF NOT EXISTS idx_draws_draw_date ON lotto.draws(draw_date DESC);
CREATE INDEX IF NOT EXISTS idx_draws_created_at ON lotto.draws(created_at DESC);

-- 업데이트 시간 자동 갱신 트리거
CREATE OR REPLACE FUNCTION lotto.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS update_draws_updated_at ON lotto.draws;
CREATE TRIGGER update_draws_updated_at
    BEFORE UPDATE ON lotto.draws
    FOR EACH ROW
    EXECUTE FUNCTION lotto.update_updated_at_column();

-- 권한 부여 (lotto_user가 사용할 수 있도록)
GRANT USAGE ON SCHEMA lotto TO lotto_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA lotto TO lotto_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA lotto TO lotto_user;

-- 확인 쿼리
SELECT
    schemaname,
    tablename,
    tableowner
FROM pg_tables
WHERE schemaname = 'lotto';

COMMENT ON TABLE lotto.draws IS '로또 당첨번호 추첨 결과';
COMMENT ON COLUMN lotto.draws.draw_no IS '회차 번호 (Primary Key)';
COMMENT ON COLUMN lotto.draws.draw_date IS '추첨일 (토요일)';
COMMENT ON COLUMN lotto.draws.bonus_num IS '보너스 번호';
COMMENT ON COLUMN lotto.draws.first_win_amount IS '1등 당첨금액';
COMMENT ON COLUMN lotto.draws.first_win_count IS '1등 당첨자 수';
