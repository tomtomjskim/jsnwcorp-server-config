#!/usr/bin/env tsx
/**
 * 동행복권 로또 당첨번호 크롤러 (PostgreSQL 버전)
 *
 * 사용법:
 *   npm run fetch-data-db
 *   또는
 *   npx tsx scripts/fetch-lotto-data-db.ts
 *
 * 옵션:
 *   --from=1 --to=1145  : 특정 범위만 수집
 *   --latest            : 최신 회차만 수집 (기본값)
 *
 * 특징:
 *   - 중복 체크: 이미 DB에 존재하는 회차는 건너뜀
 *   - 자동 업데이트: 중복 시 데이터 업데이트
 */

// .env 파일 로드
import { readFileSync } from 'fs';
import { resolve } from 'path';

try {
  const envPath = resolve(process.cwd(), '.env');
  const envContent = readFileSync(envPath, 'utf-8');
  envContent.split('\n').forEach(line => {
    line = line.trim();
    if (line && !line.startsWith('#')) {
      const [key, ...valueParts] = line.split('=');
      if (key && valueParts.length > 0) {
        const value = valueParts.join('=').trim();
        if (!process.env[key]) {
          process.env[key] = value;
        }
      }
    }
  });
  console.log('✅ .env 파일 로드 완료');
} catch (error) {
  console.warn('⚠️  .env 파일을 찾을 수 없습니다. 환경변수를 직접 설정하세요.');
}

import { Pool } from 'pg';

// 새로운 동행복권 API 응답 형식 (2025년 12월 리뉴얼 이후)
interface NewLottoApiResponse {
  resultCode: string | null;
  resultMessage: string | null;
  data: {
    list: Array<{
      ltEpsd: number;           // 회차
      tm1WnNo: number;          // 번호1
      tm2WnNo: number;          // 번호2
      tm3WnNo: number;          // 번호3
      tm4WnNo: number;          // 번호4
      tm5WnNo: number;          // 번호5
      tm6WnNo: number;          // 번호6
      bnsWnNo: number;          // 보너스
      ltRflYmd: string;         // 추첨일 (YYYYMMDD)
      rnk1WnAmt: number;        // 1등 당첨금
      rnk1WnNope: number;       // 1등 당첨자수
    }>;
  };
}

// 기존 API 응답 형식 (호환성 유지용, deprecated)
interface LottoApiResponse {
  returnValue: string;
  drwNo: number;
  drwNoDate: string;
  drwtNo1: number;
  drwtNo2: number;
  drwtNo3: number;
  drwtNo4: number;
  drwtNo5: number;
  drwtNo6: number;
  bnusNo: number;
  firstWinamnt: number;
  firstPrzwnerCo: number;
}

interface DrawResult {
  drawNo: number;
  drawDate: string;
  numbers: number[];
  bonusNum: number;
  firstWinAmount: number | null;
  firstWinCount: number | null;
}

// 새로운 API 엔드포인트 (2025년 12월 리뉴얼 이후)
const DHLOTTERY_API_NEW = 'https://www.dhlottery.co.kr/lt645/selectPstLt645Info.do';
// 기존 API (deprecated, 더 이상 작동하지 않음)
const DHLOTTERY_API_OLD = 'https://www.dhlottery.co.kr/common.do?method=getLottoNumber';
const DELAY_MS = 500; // API 호출 간격 (Rate limiting) - 봇 차단 방지를 위해 500ms로 증가

// User-Agent 헤더 (새 API 필수)
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

// 날짜 형식 변환 (YYYYMMDD → YYYY-MM-DD)
function formatDate(dateStr: string): string {
  if (dateStr.length === 8) {
    return `${dateStr.slice(0, 4)}-${dateStr.slice(4, 6)}-${dateStr.slice(6, 8)}`;
  }
  return dateStr;
}

// PostgreSQL 연결 설정
const pool = new Pool({
  host: process.env.POSTGRES_HOST || 'postgres',
  port: parseInt(process.env.POSTGRES_PORT || '5432'),
  database: process.env.POSTGRES_DB || 'maindb',
  user: process.env.POSTGRES_USER || 'lotto_user',
  password: process.env.POSTGRES_PASSWORD,
  options: `-c search_path=${process.env.POSTGRES_SCHEMA || 'lotto'},public`
});

// 최신 회차 번호 가져오기 (새 API 사용)
async function getLatestDrawNo(): Promise<number> {
  try {
    // 로또 1회차: 2002-12-07 (토요일)
    // 매주 토요일마다 1회씩 추첨
    const firstDrawDate = new Date('2002-12-07');
    const today = new Date();
    const weeksDiff = Math.floor((today.getTime() - firstDrawDate.getTime()) / (7 * 24 * 60 * 60 * 1000));
    const estimatedLatest = Math.min(weeksDiff + 10, 2000); // 여유있게 +10, 최대 2000회

    console.log(`🔍 최신 회차 탐색 중... (예상: ${estimatedLatest}회 근처)`);

    // 예상 회차부터 역순으로 조회하여 첫 번째 성공하는 회차 찾기
    for (let drawNo = estimatedLatest; drawNo >= estimatedLatest - 100; drawNo--) {
      try {
        const response = await fetch(`${DHLOTTERY_API_NEW}?drwNo=${drawNo}`, {
          headers: {
            'User-Agent': USER_AGENT,
            'Accept': 'application/json',
          },
        });
        const data: NewLottoApiResponse = await response.json();

        // 새 API는 data.list 배열에 결과가 있으면 성공
        if (data.data?.list?.length > 0) {
          const latestDraw = data.data.list[0].ltEpsd;
          console.log(`✅ 최신 회차: ${latestDraw}회`);
          return latestDraw;
        }
      } catch (err) {
        // 개별 조회 실패는 무시하고 계속
      }

      // 과도한 API 호출 방지
      if (drawNo % 10 === 0) {
        await sleep(100);
      }
    }

    // 모두 실패 시 DB에서 가져오기
    const dbLatest = await getLatestDrawNoFromDB();
    if (dbLatest > 0) {
      console.warn(`⚠️  API 조회 실패, DB 최신 회차 사용: ${dbLatest}회`);
      return dbLatest;
    }

    // 최후의 기본값
    console.warn('⚠️  최신 회차 자동 감지 실패, 기본값 사용: 1205회');
    return 1205;
  } catch (error) {
    console.error('❌ 최신 회차 조회 오류:', error);
    const dbLatest = await getLatestDrawNoFromDB();
    return dbLatest > 0 ? dbLatest : 1205;
  }
}

// DB에서 최신 회차 번호 가져오기
async function getLatestDrawNoFromDB(): Promise<number> {
  try {
    const result = await pool.query(
      'SELECT MAX(draw_no) as max_draw FROM lotto.draws'
    );
    return result.rows[0].max_draw || 0;
  } catch (error) {
    console.error('❌ DB 최신 회차 조회 오류:', error);
    return 0;
  }
}

// 특정 회차가 DB에 존재하는지 확인
async function drawExistsInDB(drawNo: number): Promise<boolean> {
  try {
    const result = await pool.query(
      'SELECT 1 FROM lotto.draws WHERE draw_no = $1',
      [drawNo]
    );
    return result.rows.length > 0;
  } catch (error) {
    console.error(`❌ ${drawNo}회 존재 확인 오류:`, error);
    return false;
  }
}

// 특정 회차 데이터 가져오기 (새 API 사용)
async function fetchDrawData(drawNo: number): Promise<DrawResult | null> {
  try {
    const response = await fetch(`${DHLOTTERY_API_NEW}?drwNo=${drawNo}`, {
      headers: {
        'User-Agent': USER_AGENT,
        'Accept': 'application/json',
      },
    });
    const data: NewLottoApiResponse = await response.json();

    // 새 API 응답 검증
    if (!data.data?.list?.length) {
      console.warn(`⚠️  ${drawNo}회 데이터 없음`);
      return null;
    }

    const item = data.data.list[0];

    return {
      drawNo: item.ltEpsd,
      drawDate: formatDate(item.ltRflYmd),  // YYYYMMDD → YYYY-MM-DD
      numbers: [
        item.tm1WnNo,
        item.tm2WnNo,
        item.tm3WnNo,
        item.tm4WnNo,
        item.tm5WnNo,
        item.tm6WnNo,
      ].sort((a, b) => a - b),
      bonusNum: item.bnsWnNo,
      firstWinAmount: item.rnk1WnAmt || null,
      firstWinCount: item.rnk1WnNope || null,
    };
  } catch (error) {
    console.error(`❌ ${drawNo}회 조회 오류:`, error);
    return null;
  }
}

// DB에 데이터 저장 (중복 시 업데이트)
async function saveDrawToDB(draw: DrawResult): Promise<'inserted' | 'updated' | 'error'> {
  try {
    const result = await pool.query(`
      INSERT INTO lotto.draws (
        draw_no, draw_date,
        num1, num2, num3, num4, num5, num6,
        bonus_num, first_win_amount, first_win_count
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      ON CONFLICT (draw_no)
      DO UPDATE SET
        draw_date = EXCLUDED.draw_date,
        num1 = EXCLUDED.num1,
        num2 = EXCLUDED.num2,
        num3 = EXCLUDED.num3,
        num4 = EXCLUDED.num4,
        num5 = EXCLUDED.num5,
        num6 = EXCLUDED.num6,
        bonus_num = EXCLUDED.bonus_num,
        first_win_amount = EXCLUDED.first_win_amount,
        first_win_count = EXCLUDED.first_win_count,
        updated_at = CURRENT_TIMESTAMP
      RETURNING (xmax = 0) AS inserted;
    `, [
      draw.drawNo,
      draw.drawDate,
      draw.numbers[0],
      draw.numbers[1],
      draw.numbers[2],
      draw.numbers[3],
      draw.numbers[4],
      draw.numbers[5],
      draw.bonusNum,
      draw.firstWinAmount,
      draw.firstWinCount
    ]);

    return result.rows[0].inserted ? 'inserted' : 'updated';
  } catch (error) {
    console.error(`❌ ${draw.drawNo}회 DB 저장 오류:`, error);
    return 'error';
  }
}

// Sleep 함수
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 진행률 표시
function printProgress(current: number, total: number) {
  const percentage = ((current / total) * 100).toFixed(1);
  const bar = '='.repeat(Math.floor(current / total * 40));
  const empty = ' '.repeat(40 - bar.length);
  process.stdout.write(`\r진행: [${bar}${empty}] ${current}/${total} (${percentage}%)`);
}

// 메인 함수
async function main() {
  console.log('🎰 로또 당첨번호 크롤러 (PostgreSQL) 시작...\n');

  try {
    // 1. DB 연결 확인
    const client = await pool.connect();
    console.log('✅ PostgreSQL 연결 성공');
    client.release();

    // 2. 명령줄 인자 파싱
    const args = process.argv.slice(2);
    let fromDraw = 0;
    let toDraw = 0;
    let latestOnly = true; // 기본값: 최신 회차만

    args.forEach(arg => {
      if (arg.startsWith('--from=')) {
        fromDraw = parseInt(arg.split('=')[1]);
        latestOnly = false;
      } else if (arg.startsWith('--to=')) {
        toDraw = parseInt(arg.split('=')[1]);
        latestOnly = false;
      } else if (arg === '--latest') {
        latestOnly = true;
      } else if (arg === '--all') {
        latestOnly = false;
      }
    });

    // 3. 최신 회차 확인
    const latestDrawFromAPI = await getLatestDrawNo();
    const latestDrawFromDB = await getLatestDrawNoFromDB();

    console.log(`📊 DB 최신 회차: ${latestDrawFromDB}회`);
    console.log(`📊 API 최신 회차: ${latestDrawFromAPI}회\n`);

    if (latestOnly) {
      // 최신 회차만 수집 (DB에 없는 회차들)
      fromDraw = latestDrawFromDB + 1;
      toDraw = latestDrawFromAPI;

      if (fromDraw > toDraw) {
        console.log('✅ 이미 최신 데이터입니다. 수집할 회차가 없습니다.\n');
        process.exit(0);
      }

      console.log(`📥 신규 회차 수집: ${fromDraw}회 ~ ${toDraw}회 (${toDraw - fromDraw + 1}개)\n`);
    } else {
      if (fromDraw === 0) fromDraw = 1;
      if (toDraw === 0) toDraw = latestDrawFromAPI;
      console.log(`📊 수집 범위: ${fromDraw}회 ~ ${toDraw}회 (총 ${toDraw - fromDraw + 1}회)\n`);
    }

    // 4. 데이터 수집 및 저장
    let insertCount = 0;
    let updateCount = 0;
    let skipCount = 0;
    let errorCount = 0;

    const totalDraws = toDraw - fromDraw + 1;
    const startTime = Date.now();

    for (let drawNo = fromDraw; drawNo <= toDraw; drawNo++) {
      const currentIndex = drawNo - fromDraw + 1;
      // 중복 체크 (옵션)
      // const exists = await drawExistsInDB(drawNo);
      // if (exists && latestOnly) {
      //   skipCount++;
      //   continue;
      // }

      const drawData = await fetchDrawData(drawNo);

      if (drawData) {
        const saveResult = await saveDrawToDB(drawData);

        if (saveResult === 'inserted') {
          insertCount++;
        } else if (saveResult === 'updated') {
          updateCount++;
        } else {
          errorCount++;
        }
      } else {
        errorCount++;
      }

      // 진행률 및 예상 시간 표시
      const elapsed = Date.now() - startTime;
      const avgTimePerDraw = elapsed / currentIndex;
      const remainingDraws = totalDraws - currentIndex;
      const estimatedRemaining = avgTimePerDraw * remainingDraws;
      const estimatedMinutes = Math.ceil(estimatedRemaining / 60000);

      process.stdout.write(`\r진행: ${currentIndex}/${totalDraws} (${((currentIndex / totalDraws) * 100).toFixed(1)}%) | `);
      process.stdout.write(`삽입: ${insertCount} | 업데이트: ${updateCount} | 실패: ${errorCount} | `);
      process.stdout.write(`예상 남은 시간: ${estimatedMinutes}분    `);

      // Rate limiting - 봇 차단 방지
      if (drawNo < toDraw) {
        await sleep(DELAY_MS);
      }

      // 100회차마다 잠시 대기 (추가 안전장치)
      if (drawNo % 100 === 0 && drawNo < toDraw) {
        process.stdout.write('\n');
        log_info(`${drawNo}회차 완료. 5초 대기 중... (봇 차단 방지)`);
        await sleep(5000);
      }
    }

    // 로그 헬퍼
    function log_info(msg: string) {
      const timestamp = new Date().toISOString().split('T')[1].split('.')[0];
      console.log(`[${timestamp}] ${msg}`);
    }

    console.log('\n');
    console.log('✅ 수집 완료!\n');
    console.log(`📊 결과:`);
    console.log(`   - 신규 삽입: ${insertCount}회`);
    console.log(`   - 업데이트: ${updateCount}회`);
    console.log(`   - 건너뜀: ${skipCount}회`);
    console.log(`   - 실패: ${errorCount}회`);

    // 5. 최종 통계
    const stats = await pool.query(`
      SELECT
        COUNT(*) as total_draws,
        MAX(draw_no) as latest_draw,
        MAX(draw_date) as latest_date
      FROM lotto.draws
    `);

    console.log(`\n📈 DB 현황:`);
    console.log(`   - 총 회차: ${stats.rows[0].total_draws}회`);
    console.log(`   - 최신: ${stats.rows[0].latest_draw}회 (${stats.rows[0].latest_date})`);

  } catch (error) {
    console.error('\n❌ 실행 오류:', error);
    process.exit(1);
  } finally {
    await pool.end();
  }

  console.log('\n✨ 완료!\n');
}

// 실행
main().catch(error => {
  console.error('❌ 실행 오류:', error);
  process.exit(1);
});
