#!/bin/bash

###############################################################################
# 로또 데이터 자동 수집 스크립트 (스마트 재시도 로직)
#
# 기능:
# - 주 단위 성공 플래그로 중복 실행 방지
# - PostgreSQL 연결 테스트
# - 최신 회차 자동 수집
# - 성공/실패 로그 기록
#
# 크론 설정 (옵션 2: 균형적 수집):
# 0 0,9 * * 0 /home/deploy/projects/lotto-master/scripts/lotto-cron-smart.sh
# 0 0 * * 1,2 /home/deploy/projects/lotto-master/scripts/lotto-cron-smart.sh
###############################################################################

# 설정
SCRIPT_DIR="/home/deploy/projects/lotto-master"
LOG_FILE="/var/log/lotto-cron.log"
SUCCESS_FLAG_DIR="/tmp/lotto-cron"
WEEK_ID=$(date +%Y-%W)  # 연도-주차 (예: 2025-43)
SUCCESS_FLAG="$SUCCESS_FLAG_DIR/success-week-$WEEK_ID.flag"

# PostgreSQL 설정
POSTGRES_HOST="172.20.0.20"
POSTGRES_PORT="5432"
POSTGRES_DB="maindb"
POSTGRES_USER="appuser"
POSTGRES_PASSWORD="SecurePassword123!ChangeMeInProduction"
POSTGRES_SCHEMA="lotto"

# 플래그 디렉토리 생성
mkdir -p "$SUCCESS_FLAG_DIR"

# 로그 시작
echo "========================================" >> "$LOG_FILE"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] 크롤링 시작" >> "$LOG_FILE"

# 이번 주에 이미 성공했는지 확인
if [ -f "$SUCCESS_FLAG" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 이번 주 데이터 이미 수집 완료 (Week $WEEK_ID)" >> "$LOG_FILE"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 플래그 파일: $SUCCESS_FLAG" >> "$LOG_FILE"
    exit 0
fi

# PostgreSQL 연결 테스트 (Docker 사용)
echo "[$(date '+%Y-%m-%d %H:%M:%S')] PostgreSQL 연결 테스트 중..." >> "$LOG_FILE"
docker exec postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "SELECT 1;" &>/dev/null

if [ $? -ne 0 ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ❌ PostgreSQL 연결 실패" >> "$LOG_FILE"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Docker 컨테이너 'postgres' 상태를 확인하세요" >> "$LOG_FILE"
    exit 1
fi

echo "[$(date '+%Y-%m-%d %H:%M:%S')] ✓ PostgreSQL 연결 성공" >> "$LOG_FILE"

# 현재 DB의 최신 회차 확인
CURRENT_MAX=$(docker exec postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -t -c "SELECT MAX(draw_no) FROM $POSTGRES_SCHEMA.draws;" | xargs)
echo "[$(date '+%Y-%m-%d %H:%M:%S')] 현재 DB 최신 회차: $CURRENT_MAX" >> "$LOG_FILE"

# 크롤링 실행
echo "[$(date '+%Y-%m-%d %H:%M:%S')] 최신 회차 크롤링 시작..." >> "$LOG_FILE"
cd "$SCRIPT_DIR" || exit 1

# tsx로 직접 실행 (npm 대신 node_modules/.bin/tsx 사용)
./node_modules/.bin/tsx scripts/fetch-lotto-data-db.ts --latest >> "$LOG_FILE" 2>&1
EXIT_CODE=$?

# 결과 확인
if [ $EXIT_CODE -eq 0 ]; then
    # 새로운 최신 회차 확인
    NEW_MAX=$(docker exec postgres psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -t -c "SELECT MAX(draw_no) FROM $POSTGRES_SCHEMA.draws;" | xargs)

    if [ "$NEW_MAX" -gt "$CURRENT_MAX" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] ✅ 크롤링 성공! 새로운 회차 수집: $NEW_MAX" >> "$LOG_FILE"
        # 성공 플래그 생성
        touch "$SUCCESS_FLAG"
        echo "$NEW_MAX" > "$SUCCESS_FLAG"
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] ⚠️  크롤링 완료했지만 새로운 데이터 없음 (최신: $NEW_MAX)" >> "$LOG_FILE"
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 추첨이 아직 발표되지 않았거나, 이미 최신 데이터입니다." >> "$LOG_FILE"
    fi

    # 오래된 플래그 파일 정리 (7일 이상 된 파일 삭제)
    find "$SUCCESS_FLAG_DIR" -name "success-week-*.flag" -mtime +7 -delete

else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ❌ 크롤링 실패 (Exit Code: $EXIT_CODE)" >> "$LOG_FILE"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 다음 스케줄에서 재시도됩니다." >> "$LOG_FILE"
fi

echo "[$(date '+%Y-%m-%d %H:%M:%S')] 크롤링 종료" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

exit $EXIT_CODE
