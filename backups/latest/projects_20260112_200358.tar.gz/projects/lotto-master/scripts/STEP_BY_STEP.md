# 로또 프로젝트 단계별 설정 가이드

이 문서는 로또 데이터베이스를 처음부터 구축하는 단계별 가이드입니다.

---

## 📋 전체 단계 요약

1. ✅ 환경변수 설정
2. ✅ 데이터베이스 스키마 생성
3. ✅ 데이터 수집 (1회차 ~ 최신 회차) ⏰ **약 10~15분 소요**
4. ✅ 데이터 검증
5. ✅ 자동 스케줄러 설정

---

## 1단계: 환경변수 설정

### `.env` 파일 확인

```bash
cd /home/deploy/projects/lotto-master

# .env 파일이 있는지 확인
ls -la .env

# 없으면 생성
cat > .env << 'EOF'
POSTGRES_HOST=postgres
POSTGRES_PORT=5432
POSTGRES_DB=maindb
POSTGRES_USER=lotto_user
POSTGRES_PASSWORD=your_password_here
POSTGRES_SCHEMA=lotto
NODE_ENV=production
EOF
```

**중요**: `POSTGRES_PASSWORD`를 실제 비밀번호로 변경하세요!

### 환경변수 로드 테스트

```bash
source .env
echo $POSTGRES_HOST
echo $POSTGRES_USER
```

---

## 2단계: 데이터베이스 스키마 생성

### PostgreSQL 연결 확인

```bash
PGPASSWORD=$POSTGRES_PASSWORD psql -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB -c "SELECT version();"
```

연결이 안되면:
- PostgreSQL 서비스 확인: `sudo systemctl status postgresql`
- 방화벽 확인
- 비밀번호 확인

### 스키마 생성

```bash
cd /home/deploy/projects/lotto-master

# 방법 1: psql 직접 사용 (권장)
PGPASSWORD=$POSTGRES_PASSWORD psql -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB -f scripts/init-db.sql

# 방법 2: npm 스크립트 사용
# npm run init-db
```

### 테이블 생성 확인

```bash
PGPASSWORD=$POSTGRES_PASSWORD psql -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB << 'EOF'
\dt lotto.*
SELECT COUNT(*) FROM lotto.draws;
EOF
```

결과:
```
           List of relations
 Schema |  Name  | Type  |   Owner
--------+--------+-------+------------
 lotto  | draws  | table | lotto_user

 count
-------
     0
```

---

## 3단계: 데이터 수집 (중요! ⏰ 시간 소요)

### 🚨 주의사항

- **소요 시간**: 약 10~15분 (1,100회차 기준)
- **봇 차단 방지**: 500ms 간격 + 100회차마다 5초 대기
- **중단해도 안전**: 중복 체크로 언제든지 재시작 가능

### 전체 데이터 수집 시작

```bash
cd /home/deploy/projects/lotto-master

# 1회차부터 최신 회차까지 수집
npm run fetch-data-db -- --from=1 --all

# 또는 직접 실행
npx tsx scripts/fetch-lotto-data-db.ts --from=1 --all
```

### 실행 화면 예시

```
🎰 로또 당첨번호 크롤러 (PostgreSQL) 시작...
✅ PostgreSQL 연결 성공
✅ 최신 회차: 1145회
📊 DB 최신 회차: 0회
📊 API 최신 회차: 1145회

📊 수집 범위: 1회 ~ 1145회 (총 1145회)

진행: 100/1145 (8.7%) | 삽입: 98 | 업데이트: 0 | 실패: 2 | 예상 남은 시간: 12분
[09:15:30] 100회차 완료. 5초 대기 중... (봇 차단 방지)
진행: 200/1145 (17.5%) | 삽입: 198 | 업데이트: 0 | 실패: 2 | 예상 남은 시간: 10분
...
```

### 중간에 중단되었다면?

걱정하지 마세요! 언제든지 다시 실행하면 됩니다:

```bash
# 마지막으로 수집된 회차부터 자동으로 이어서 수집
npm run fetch-data-db -- --all

# 또는 특정 구간만
npm run fetch-data-db -- --from=500 --to=1145
```

### 백그라운드로 실행 (선택사항)

시간이 오래 걸리므로 백그라운드 실행을 추천합니다:

```bash
# nohup 사용
nohup npm run fetch-data-db -- --from=1 --all > lotto-fetch.log 2>&1 &

# 또는 screen 사용
screen -S lotto-fetch
npm run fetch-data-db -- --from=1 --all
# Ctrl+A, D로 detach

# 나중에 다시 붙기
screen -r lotto-fetch

# 또는 tmux 사용
tmux new -s lotto-fetch
npm run fetch-data-db -- --from=1 --all
# Ctrl+B, D로 detach
```

### 로그 확인 (백그라운드 실행 시)

```bash
tail -f lotto-fetch.log
```

---

## 4단계: 데이터 검증

데이터 수집이 완료되면 반드시 검증하세요!

### 기본 통계 확인

```bash
PGPASSWORD=$POSTGRES_PASSWORD psql -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB << 'EOF'
-- 총 회차 수
SELECT COUNT(*) as total_draws FROM lotto.draws;

-- 최신 회차
SELECT draw_no, draw_date FROM lotto.draws ORDER BY draw_no DESC LIMIT 1;

-- 최초 회차
SELECT draw_no, draw_date FROM lotto.draws ORDER BY draw_no ASC LIMIT 1;

-- 빠진 회차 확인 (연속성 체크)
WITH RECURSIVE seq AS (
    SELECT 1 as num
    UNION ALL
    SELECT num + 1 FROM seq WHERE num < (SELECT MAX(draw_no) FROM lotto.draws)
)
SELECT seq.num as missing_draw
FROM seq
LEFT JOIN lotto.draws ON seq.num = draws.draw_no
WHERE draws.draw_no IS NULL
LIMIT 10;
EOF
```

### 예상 결과

```
 total_draws
-------------
        1145

 draw_no | draw_date
---------+------------
    1145 | 2025-10-16

 draw_no | draw_date
---------+------------
       1 | 2002-12-07

 missing_draw
--------------
(0 rows)  -- 빠진 회차가 없어야 정상!
```

### 최신 10개 회차 확인

```bash
PGPASSWORD=$POSTGRES_PASSWORD psql -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB << 'EOF'
SELECT
    draw_no,
    draw_date,
    num1, num2, num3, num4, num5, num6,
    bonus_num,
    first_win_count,
    first_win_amount
FROM lotto.draws
ORDER BY draw_no DESC
LIMIT 10;
EOF
```

### 빈출 번호 TOP 10 확인

```bash
PGPASSWORD=$POSTGRES_PASSWORD psql -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB << 'EOF'
WITH all_numbers AS (
    SELECT num1 as num FROM lotto.draws
    UNION ALL SELECT num2 FROM lotto.draws
    UNION ALL SELECT num3 FROM lotto.draws
    UNION ALL SELECT num4 FROM lotto.draws
    UNION ALL SELECT num5 FROM lotto.draws
    UNION ALL SELECT num6 FROM lotto.draws
)
SELECT num, COUNT(*) as count
FROM all_numbers
GROUP BY num
ORDER BY count DESC, num ASC
LIMIT 10;
EOF
```

---

## 5단계: 자동 스케줄러 설정

데이터가 정상적으로 수집되었으면 이제 자동 스케줄러를 설정합니다!

### Cron Job 등록

```bash
# Crontab 편집
crontab -e

# 다음 라인 추가 (매주 일요일 오전 9시)
0 9 * * 0 cd /home/deploy/projects/lotto-master && ./scripts/lotto-cron.sh >> /var/log/lotto-cron.log 2>&1
```

**또는 일요일과 월요일 모두 (이중 체크 - 권장):**
```cron
0 9 * * 0,1 cd /home/deploy/projects/lotto-master && ./scripts/lotto-cron.sh >> /var/log/lotto-cron.log 2>&1
```

### Cron 설정 확인

```bash
crontab -l
```

### 수동 테스트

Cron이 제대로 작동하는지 테스트:

```bash
cd /home/deploy/projects/lotto-master
./scripts/lotto-cron.sh
```

결과:
```
==========================================
[2025-10-28 09:00:00] 로또 당첨번호 자동 수집 시작
[2025-10-28 09:00:00] 프로젝트 경로: /home/deploy/projects/lotto-master
==========================================
[2025-10-28 09:00:01] .env 파일 로드 중...
[2025-10-28 09:00:01] Node.js: v18.x.x
[2025-10-28 09:00:01] PostgreSQL 연결 확인 중...
[2025-10-28 09:00:02] ✅ PostgreSQL 연결 성공
[2025-10-28 09:00:02] 로또 당첨번호 수집 시작...
[2025-10-28 09:00:05] ✅ 로또 당첨번호 수집 성공
==========================================
```

### 로그 파일 생성

```bash
# 로그 파일 생성 및 권한 설정
sudo touch /var/log/lotto-cron.log
sudo chown $USER:$USER /var/log/lotto-cron.log
```

### 로그 확인

```bash
# 실시간 로그 보기
tail -f /var/log/lotto-cron.log

# 최근 로그 보기
tail -50 /var/log/lotto-cron.log
```

---

## ✅ 완료 체크리스트

모든 단계가 완료되었는지 확인하세요:

- [ ] `.env` 파일 설정 완료
- [ ] PostgreSQL 연결 확인
- [ ] `lotto.draws` 테이블 생성 완료
- [ ] 1회차부터 최신 회차까지 데이터 수집 완료
- [ ] 총 회차 수 확인 (1,000회 이상)
- [ ] 빠진 회차 없음 확인
- [ ] Cron Job 등록 완료
- [ ] Cron 수동 테스트 성공
- [ ] 로그 파일 생성 및 확인 가능

---

## 🎯 다음 실행 일정

- **다음 추첨**: 매주 토요일 20:45
- **자동 수집**: 매주 일요일/월요일 09:00
- **수동 확인**: `npm run fetch-data-db`

---

## 🔧 문제 해결

### Q1. "PostgreSQL 연결 실패"

```bash
# PostgreSQL 서비스 확인
sudo systemctl status postgresql
sudo systemctl start postgresql

# 포트 확인
sudo netstat -tlnp | grep 5432

# 방화벽 확인
sudo ufw status
```

### Q2. "데이터 수집 중 너무 많은 실패"

```bash
# API 응답 테스트
curl "https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=1"

# 딜레이 증가 (scripts/fetch-lotto-data-db.ts 수정)
# DELAY_MS = 1000 (500 → 1000)
```

### Q3. "중간에 멈췄어요"

```bash
# 현재 DB 상태 확인
PGPASSWORD=$POSTGRES_PASSWORD psql -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB -c "SELECT MAX(draw_no) FROM lotto.draws;"

# 이어서 수집
npm run fetch-data-db -- --all
```

### Q4. "Cron이 실행 안돼요"

```bash
# Cron 서비스 확인
sudo systemctl status cron
sudo systemctl start cron

# 권한 확인
chmod +x /home/deploy/projects/lotto-master/scripts/lotto-cron.sh

# 환경변수 확인 (Cron은 환경변수를 자동으로 불러오지 않음)
# crontab -e에서 PATH와 환경변수 추가
```

---

## 📞 지원

문제가 해결되지 않으면:
1. 로그 확인: `tail -f /var/log/lotto-cron.log`
2. DB 상태 확인: `SELECT COUNT(*) FROM lotto.draws;`
3. API 테스트: `curl "https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=1145"`
