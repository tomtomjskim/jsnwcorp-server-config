#!/bin/bash
###############################################################################
# 로또 자동 수집 스케줄러 설정 스크립트
#
# 이 스크립트는 다음 작업을 자동으로 수행합니다:
#   1. 데이터베이스 스키마 생성
#   2. JSON 데이터를 DB로 마이그레이션
#   3. Cron Job 설정
#
# 사용법:
#   chmod +x scripts/setup-scheduler.sh
#   ./scripts/setup-scheduler.sh
###############################################################################

set -e

# 색상 코드
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 로그 함수
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 배너
echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                                                           ║"
echo "║         로또 자동 수집 스케줄러 설정 스크립트             ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# 프로젝트 디렉토리
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

log_info "프로젝트 경로: $PROJECT_DIR"
cd "$PROJECT_DIR"

# 1. 환경변수 확인
log_info "환경변수 확인 중..."
if [ ! -f .env ]; then
    log_error ".env 파일이 없습니다. .env.example을 참고하여 생성하세요."
    exit 1
fi

source .env
log_success ".env 파일 로드 완료"

# 2. PostgreSQL 연결 확인
log_info "PostgreSQL 연결 확인 중..."
if ! PGPASSWORD="$POSTGRES_PASSWORD" psql -h "${POSTGRES_HOST:-postgres}" \
    -U "${POSTGRES_USER:-lotto_user}" \
    -d "${POSTGRES_DB:-maindb}" \
    -c "SELECT 1" > /dev/null 2>&1; then
    log_error "PostgreSQL 연결 실패. 데이터베이스 설정을 확인하세요."
    exit 1
fi
log_success "PostgreSQL 연결 성공"

# 3. 데이터베이스 스키마 생성
log_info "데이터베이스 스키마 생성 중..."
if PGPASSWORD="$POSTGRES_PASSWORD" psql -h "${POSTGRES_HOST:-postgres}" \
    -U "${POSTGRES_USER:-lotto_user}" \
    -d "${POSTGRES_DB:-maindb}" \
    -f scripts/init-db.sql > /dev/null 2>&1; then
    log_success "데이터베이스 스키마 생성 완료"
else
    log_warning "스키마가 이미 존재하거나 생성 중 경고 발생 (무시 가능)"
fi

# 4. 데이터 마이그레이션
read -p "기존 JSON 데이터를 DB로 마이그레이션하시겠습니까? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log_info "데이터 마이그레이션 중..."
    if npm run migrate-db; then
        log_success "데이터 마이그레이션 완료"
    else
        log_error "데이터 마이그레이션 실패"
        exit 1
    fi
else
    log_info "데이터 마이그레이션을 건너뜁니다."
fi

# 5. Cron 스크립트 실행 권한 부여
log_info "Cron 스크립트 실행 권한 부여 중..."
chmod +x scripts/lotto-cron.sh
log_success "실행 권한 부여 완료"

# 6. Cron Job 설정
log_info "Cron Job 설정 중..."
echo ""
echo "다음 중 하나를 선택하세요:"
echo "  1) 매주 일요일 오전 9시"
echo "  2) 매주 월요일 오전 9시"
echo "  3) 매주 일요일과 월요일 오전 9시 (권장)"
echo "  4) 수동 설정 (나중에 직접 crontab 편집)"
echo ""
read -p "선택 (1-4): " -n 1 -r CRON_CHOICE
echo ""

CRON_COMMAND="cd $PROJECT_DIR && ./scripts/lotto-cron.sh >> /var/log/lotto-cron.log 2>&1"

case $CRON_CHOICE in
    1)
        CRON_SCHEDULE="0 9 * * 0"
        CRON_DESC="매주 일요일 오전 9시"
        ;;
    2)
        CRON_SCHEDULE="0 9 * * 1"
        CRON_DESC="매주 월요일 오전 9시"
        ;;
    3)
        CRON_SCHEDULE="0 9 * * 0,1"
        CRON_DESC="매주 일요일과 월요일 오전 9시"
        ;;
    4)
        log_info "수동 설정을 선택했습니다. 다음 명령어로 crontab을 편집하세요:"
        echo ""
        echo "  crontab -e"
        echo ""
        echo "추가할 라인:"
        echo "  0 9 * * 0,1 $CRON_COMMAND"
        echo ""
        exit 0
        ;;
    *)
        log_error "잘못된 선택입니다."
        exit 1
        ;;
esac

# Crontab에 추가
log_info "Crontab에 작업 추가 중... ($CRON_DESC)"

# 기존 crontab 백업
crontab -l > /tmp/crontab.backup 2>/dev/null || true

# 중복 확인
if crontab -l 2>/dev/null | grep -q "lotto-cron.sh"; then
    log_warning "이미 lotto-cron.sh 관련 작업이 존재합니다."
    read -p "기존 작업을 덮어쓰시겠습니까? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        # 기존 작업 제거
        crontab -l 2>/dev/null | grep -v "lotto-cron.sh" | crontab -
        log_info "기존 작업 제거 완료"
    else
        log_info "Cron Job 설정을 건너뜁니다."
        exit 0
    fi
fi

# 새 작업 추가
(crontab -l 2>/dev/null; echo "$CRON_SCHEDULE $CRON_COMMAND") | crontab -
log_success "Cron Job 추가 완료: $CRON_DESC"

# 7. Cron Job 확인
log_info "현재 설정된 Cron Jobs:"
echo ""
crontab -l | grep "lotto-cron" || true
echo ""

# 8. 로그 디렉토리 권한 확인
log_info "로그 파일 권한 확인 중..."
if [ ! -f /var/log/lotto-cron.log ]; then
    sudo touch /var/log/lotto-cron.log 2>/dev/null || touch $HOME/lotto-cron.log
    log_info "로그 파일 생성: /var/log/lotto-cron.log (또는 $HOME/lotto-cron.log)"
fi

# 9. 테스트 실행
read -p "지금 수동으로 테스트를 실행하시겠습니까? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log_info "테스트 실행 중..."
    ./scripts/lotto-cron.sh
    log_success "테스트 실행 완료"
fi

# 완료
echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                                                           ║"
echo "║                  🎉 설정 완료! 🎉                         ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""
log_success "다음 명령어로 로그를 확인할 수 있습니다:"
echo "  tail -f /var/log/lotto-cron.log"
echo ""
log_success "다음 명령어로 Cron Job을 확인할 수 있습니다:"
echo "  crontab -l"
echo ""
log_info "첫 자동 수집 시간: $CRON_DESC"
echo ""
