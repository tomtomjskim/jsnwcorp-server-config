# 🎯 LottoMaster 구현 실행 계획
## DB 없는 경량 아키텍처 (최종 결정)

**작성일**: 2025-10-16
**예상 소요 시간**: 12-15시간 (DB 제거로 8-10시간 단축)
**배포 위치**: /home/deploy/projects/lotto-master

---

## 🔍 핵심 설계 결정

### ❌ PostgreSQL DB 사용 안 함

**이유**:
1. **데이터 크기 매우 작음**: 전체 당첨번호 약 120KB
2. **읽기 전용 데이터**: 당첨번호는 변경되지 않음
3. **메모리 절약**: PostgreSQL 192MB 불필요
4. **빠른 구현**: Prisma, 마이그레이션 생략
5. **단순한 배포**: 의존성 감소

### ✅ 대안: 정적 JSON + 클라이언트 계산

```
public/data/lotto-data.json (120KB)
    ↓
Next.js 빌드 시 포함
    ↓
API 또는 클라이언트에서 로드
    ↓
브라우저에서 통계 계산
```

---

## 📊 최종 아키텍처

### 기술 스택

```yaml
Frontend & Backend:
  - Next.js 14.2 (App Router)
  - TypeScript 5+
  - React Server Components

Styling:
  - Tailwind CSS 3.4+
  - shadcn/ui

Data:
  - Static JSON (no database)
  - Client-side calculation

Charts:
  - Recharts

Deployment:
  - Docker (Alpine)
  - Nginx reverse proxy
```

### 리소스 할당

```
lotto-service:
  메모리: 192MB (기존 256MB → 64MB 절약)
  CPU: 0.25 core
  디스크: ~150MB (이미지 + 데이터)
  포트: 3000 (내부), nginx → 3001 (외부)
```

---

## 📁 최종 디렉토리 구조

```
/home/deploy/projects/lotto-master/
├── docs/
│   ├── lotto-service.md                 # 원본 설계
│   ├── lotto-service-implementation.md  # 구현 가이드 (DB 버전)
│   └── IMPLEMENTATION_PLAN.md           # 이 문서 (최종 계획)
│
├── public/
│   ├── data/
│   │   └── lotto-data.json             # 정적 당첨번호 데이터 ⭐
│   ├── images/
│   │   └── logo.svg
│   └── favicon.ico
│
├── src/
│   ├── app/
│   │   ├── layout.tsx                  # Root Layout
│   │   ├── page.tsx                    # 메인 (번호 생성)
│   │   ├── globals.css
│   │   │
│   │   ├── api/                        # API Routes
│   │   │   ├── health/route.ts         # 헬스체크
│   │   │   ├── lotto/
│   │   │   │   ├── generate/route.ts   # 번호 생성
│   │   │   │   └── history/route.ts    # 당첨번호 조회
│   │   │   └── stats/
│   │   │       └── dashboard/route.ts  # 통계
│   │   │
│   │   ├── history/                    # 당첨번호 이력 페이지
│   │   │   └── page.tsx
│   │   │
│   │   └── stats/                      # 통계 페이지
│   │       └── page.tsx
│   │
│   ├── components/
│   │   ├── ui/                         # shadcn/ui
│   │   │   ├── button.tsx
│   │   │   ├── card.tsx
│   │   │   ├── select.tsx
│   │   │   └── table.tsx
│   │   │
│   │   ├── lotto/                      # 로또 컴포넌트
│   │   │   ├── NumberGenerator.tsx     # 번호 생성기
│   │   │   ├── NumberBall.tsx          # 번호 공 UI
│   │   │   ├── NumberDisplay.tsx       # 번호 표시
│   │   │   └── AlgorithmSelector.tsx   # 알고리즘 선택
│   │   │
│   │   └── stats/                      # 통계 차트
│   │       ├── FrequencyChart.tsx      # 빈도 차트
│   │       └── StatsSummary.tsx        # 통계 요약
│   │
│   ├── lib/
│   │   ├── algorithms/                 # 번호 생성 알고리즘
│   │   │   ├── random.ts               # 완전 랜덤
│   │   │   ├── frequency.ts            # 빈도 기반
│   │   │   ├── pattern.ts              # 패턴 기반
│   │   │   └── index.ts                # Export
│   │   │
│   │   ├── data/
│   │   │   └── loader.ts               # JSON 데이터 로더 ⭐
│   │   │
│   │   ├── stats/
│   │   │   └── calculator.ts           # 통계 계산
│   │   │
│   │   └── utils.ts                    # 유틸리티
│   │
│   └── types/
│       ├── lotto.ts                    # 로또 타입
│       └── api.ts                      # API 타입
│
├── Dockerfile.prod                      # 프로덕션 Dockerfile
├── next.config.js                       # Next.js 설정
├── package.json
├── tsconfig.json
├── tailwind.config.ts
├── components.json                      # shadcn/ui 설정
├── .env.local                          # 로컬 환경 변수
└── README.md                           # 프로젝트 README
```

---

## 🎯 단계별 실행 계획

### Task 1: 프로젝트 초기화 (예상 30분)

#### 1.1 Next.js 프로젝트 생성
```bash
cd /home/deploy/projects
npx create-next-app@latest lotto-master \
  --typescript \
  --tailwind \
  --app \
  --no-src-dir \
  --import-alias "@/*"
```

**선택 옵션**:
- ✅ TypeScript
- ✅ Tailwind CSS
- ✅ App Router
- ❌ src/ directory (수동 생성)
- ✅ Import alias (@/*)

#### 1.2 디렉토리 구조 생성
```bash
cd lotto-master
mkdir -p src/{app,components,lib,types}
mkdir -p src/app/{api,history,stats}
mkdir -p src/components/{ui,lotto,stats}
mkdir -p src/lib/{algorithms,data,stats}
mkdir -p public/{data,images}
mkdir -p docs
```

#### 1.3 의존성 설치
```bash
# 차트 라이브러리
npm install recharts

# 유틸리티
npm install date-fns clsx

# 개발 의존성
npm install -D @types/node
```

**체크리스트**:
- [ ] Next.js 프로젝트 생성 완료
- [ ] 디렉토리 구조 생성 완료
- [ ] 패키지 설치 완료
- [ ] 개발 서버 실행 확인 (`npm run dev`)

---

### Task 2: shadcn/ui 설정 (예상 20분)

#### 2.1 shadcn/ui 초기화
```bash
npx shadcn-ui@latest init
```

**설정 옵션**:
- Style: Default
- Base color: Slate
- CSS variables: Yes

#### 2.2 필요한 컴포넌트 설치
```bash
npx shadcn-ui@latest add button
npx shadcn-ui@latest add card
npx shadcn-ui@latest add select
npx shadcn-ui@latest add table
npx shadcn-ui@latest add tabs
```

**체크리스트**:
- [ ] shadcn/ui 초기화 완료
- [ ] components.json 생성 확인
- [ ] UI 컴포넌트 설치 완료
- [ ] src/components/ui/ 디렉토리 생성 확인

---

### Task 3: 정적 데이터 준비 (예상 1시간)

#### 3.1 로또 데이터 JSON 생성

**파일**: `public/data/lotto-data.json`

```json
{
  "meta": {
    "lastUpdate": "2025-10-16",
    "totalDraws": 1145,
    "source": "https://www.dhlottery.co.kr"
  },
  "draws": [
    {
      "drawNo": 1145,
      "drawDate": "2025-10-12",
      "numbers": [3, 12, 23, 28, 35, 42],
      "bonusNum": 15,
      "firstWinAmount": 2500000000,
      "firstWinCount": 12
    },
    // ... (최소 최근 100회차 데이터)
  ]
}
```

#### 3.2 데이터 로더 구현

**파일**: `src/lib/data/loader.ts`

```typescript
import lottoData from '@/public/data/lotto-data.json'

export interface DrawResult {
  drawNo: number
  drawDate: string
  numbers: number[]
  bonusNum: number
  firstWinAmount?: number
  firstWinCount?: number
}

export interface LottoData {
  meta: {
    lastUpdate: string
    totalDraws: number
    source: string
  }
  draws: DrawResult[]
}

// 전체 데이터
export function getLottoData(): LottoData {
  return lottoData as LottoData
}

// 특정 회차 조회
export function getDrawByNumber(drawNo: number): DrawResult | undefined {
  return lottoData.draws.find(d => d.drawNo === drawNo)
}

// 최근 N회차 조회
export function getRecentDraws(limit: number = 10): DrawResult[] {
  return lottoData.draws.slice(0, limit)
}

// 번호별 통계 계산
export function calculateNumberStats() {
  const stats = Array.from({ length: 45 }, (_, i) => ({
    number: i + 1,
    totalCount: 0,
    bonusCount: 0,
    lastDrawNo: null as number | null,
  }))

  lottoData.draws.forEach(draw => {
    draw.numbers.forEach(num => {
      stats[num - 1].totalCount++
      stats[num - 1].lastDrawNo = draw.drawNo
    })
    stats[draw.bonusNum - 1].bonusCount++
  })

  return stats
}
```

#### 3.3 초기 데이터 수집 방법

**옵션 1**: 수동 입력 (최소 데이터)
- 최근 20회차만 입력 (테스트용)

**옵션 2**: 크롤링 스크립트 (권장)
```bash
# 별도 스크립트로 동행복권 API 호출
node scripts/fetch-lotto-data.js > public/data/lotto-data.json
```

**체크리스트**:
- [ ] lotto-data.json 파일 생성
- [ ] 최소 20회차 데이터 입력
- [ ] loader.ts 구현 완료
- [ ] 데이터 로드 테스트 통과

---

### Task 4: 번호 생성 알고리즘 구현 (예상 2시간)

#### 4.1 완전 랜덤 알고리즘

**파일**: `src/lib/algorithms/random.ts`

```typescript
export function generateRandomNumbers(): number[] {
  const numbers = new Set<number>()

  while (numbers.size < 6) {
    const num = Math.floor(Math.random() * 45) + 1
    numbers.add(num)
  }

  return Array.from(numbers).sort((a, b) => a - b)
}
```

#### 4.2 빈도 기반 알고리즘

**파일**: `src/lib/algorithms/frequency.ts`

```typescript
import { calculateNumberStats } from '@/lib/data/loader'

export function generateFrequencyNumbers(): number[] {
  const stats = calculateNumberStats()

  // 상위 60% 빈출 번호에 가중치 부여
  const topCount = Math.ceil(45 * 0.6)
  const sorted = [...stats].sort((a, b) => b.totalCount - a.totalCount)
  const topNumbers = sorted.slice(0, topCount)

  // 가중 랜덤 선택
  const selected = new Set<number>()
  while (selected.size < 6) {
    const weighted = topNumbers[Math.floor(Math.random() * topNumbers.length)]
    selected.add(weighted.number)
  }

  return Array.from(selected).sort((a, b) => a - b)
}
```

#### 4.3 패턴 기반 알고리즘

**파일**: `src/lib/algorithms/pattern.ts`

```typescript
export function generatePatternNumbers(): number[] {
  const numbers: number[] = []

  // 1. 홀짝 비율 (3:3 또는 4:2)
  const oddCount = Math.random() > 0.5 ? 3 : 4
  const evenCount = 6 - oddCount

  // 2. 구간 분산 (1-15, 16-30, 31-45)
  const ranges = [
    { min: 1, max: 15, count: 2 },
    { min: 16, max: 30, count: 2 },
    { min: 31, max: 45, count: 2 },
  ]

  ranges.forEach(range => {
    const rangeNumbers = new Set<number>()
    while (rangeNumbers.size < range.count) {
      const num = Math.floor(Math.random() * (range.max - range.min + 1)) + range.min
      rangeNumbers.add(num)
    }
    numbers.push(...rangeNumbers)
  })

  return numbers.sort((a, b) => a - b).slice(0, 6)
}
```

#### 4.4 통합 Export

**파일**: `src/lib/algorithms/index.ts`

```typescript
export { generateRandomNumbers } from './random'
export { generateFrequencyNumbers } from './frequency'
export { generatePatternNumbers } from './pattern'

export type Algorithm = 'random' | 'frequency' | 'pattern'

export function generateNumbers(algorithm: Algorithm = 'random'): number[] {
  switch (algorithm) {
    case 'frequency':
      return generateFrequencyNumbers()
    case 'pattern':
      return generatePatternNumbers()
    case 'random':
    default:
      return generateRandomNumbers()
  }
}
```

**체크리스트**:
- [ ] random.ts 구현
- [ ] frequency.ts 구현
- [ ] pattern.ts 구현
- [ ] index.ts Export 완료
- [ ] 각 알고리즘 단위 테스트

---

### Task 5: API Routes 구현 (예상 2시간)

#### 5.1 헬스체크 API

**파일**: `src/app/api/health/route.ts`

```typescript
import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'lotto-master',
  })
}
```

#### 5.2 번호 생성 API

**파일**: `src/app/api/lotto/generate/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server'
import { generateNumbers, type Algorithm } from '@/lib/algorithms'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { algorithm = 'random', count = 1 } = body

    if (count < 1 || count > 10) {
      return NextResponse.json(
        { success: false, error: '생성 개수는 1~10 사이여야 합니다.' },
        { status: 400 }
      )
    }

    const numbers = Array.from({ length: count }, () =>
      generateNumbers(algorithm as Algorithm)
    )

    return NextResponse.json({
      success: true,
      data: {
        numbers,
        algorithm,
        generatedAt: new Date().toISOString(),
      },
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: '번호 생성 중 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}
```

#### 5.3 당첨번호 조회 API

**파일**: `src/app/api/lotto/history/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server'
import { getLottoData, getDrawByNumber, getRecentDraws } from '@/lib/data/loader'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const drawNo = searchParams.get('drawNo')
    const limit = parseInt(searchParams.get('limit') || '10')

    if (drawNo) {
      const draw = getDrawByNumber(parseInt(drawNo))
      if (!draw) {
        return NextResponse.json(
          { success: false, error: '해당 회차를 찾을 수 없습니다.' },
          { status: 404 }
        )
      }
      return NextResponse.json({ success: true, data: draw })
    }

    const draws = getRecentDraws(limit)
    return NextResponse.json({
      success: true,
      data: {
        results: draws,
        pagination: {
          limit,
          total: getLottoData().meta.totalDraws,
        },
      },
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: '조회 중 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}
```

#### 5.4 통계 API

**파일**: `src/app/api/stats/dashboard/route.ts`

```typescript
import { NextResponse } from 'next/server'
import { getLottoData, calculateNumberStats } from '@/lib/data/loader'

export const revalidate = 300 // 5분 캐싱

export async function GET() {
  try {
    const data = getLottoData()
    const stats = calculateNumberStats()

    const sorted = [...stats].sort((a, b) => b.totalCount - a.totalCount)
    const topFrequent = sorted.slice(0, 5)
    const leastFrequent = sorted.slice(-5)

    // 홀짝 비율
    const oddCount = stats
      .filter(s => s.number % 2 === 1)
      .reduce((sum, s) => sum + s.totalCount, 0)
    const evenCount = stats
      .filter(s => s.number % 2 === 0)
      .reduce((sum, s) => sum + s.totalCount, 0)
    const total = oddCount + evenCount

    return NextResponse.json({
      success: true,
      data: {
        totalDraws: data.meta.totalDraws,
        lastUpdate: data.meta.lastUpdate,
        topFrequent,
        leastFrequent,
        oddEvenRatio: {
          odd: ((oddCount / total) * 100).toFixed(1),
          even: ((evenCount / total) * 100).toFixed(1),
        },
      },
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: '통계 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}
```

**체크리스트**:
- [ ] /api/health 구현
- [ ] /api/lotto/generate 구현
- [ ] /api/lotto/history 구현
- [ ] /api/stats/dashboard 구현
- [ ] API 테스트 (curl 또는 Postman)

---

### Task 6: UI 컴포넌트 구현 (예상 3시간)

#### 6.1 NumberBall (번호 공)

**파일**: `src/components/lotto/NumberBall.tsx`

```typescript
interface NumberBallProps {
  number: number
  isBonus?: boolean
}

export default function NumberBall({ number, isBonus = false }: NumberBallProps) {
  const getColorClass = () => {
    if (isBonus) return 'bg-red-500'
    if (number <= 10) return 'bg-yellow-500'
    if (number <= 20) return 'bg-blue-500'
    if (number <= 30) return 'bg-red-500'
    if (number <= 40) return 'bg-gray-500'
    return 'bg-green-500'
  }

  return (
    <div
      className={`
        w-12 h-12 rounded-full flex items-center justify-center
        text-white font-bold text-lg shadow-lg
        ${getColorClass()}
      `}
    >
      {number}
    </div>
  )
}
```

#### 6.2 NumberDisplay (번호 세트 표시)

**파일**: `src/components/lotto/NumberDisplay.tsx`

```typescript
import NumberBall from './NumberBall'

interface NumberDisplayProps {
  numbers: number[]
  bonusNum?: number
}

export default function NumberDisplay({ numbers, bonusNum }: NumberDisplayProps) {
  return (
    <div className="flex items-center gap-3">
      {numbers.map((num, i) => (
        <NumberBall key={i} number={num} />
      ))}
      {bonusNum && (
        <>
          <span className="text-2xl text-gray-400">+</span>
          <NumberBall number={bonusNum} isBonus />
        </>
      )}
    </div>
  )
}
```

#### 6.3 NumberGenerator (번호 생성기)

**파일**: `src/components/lotto/NumberGenerator.tsx`

```typescript
'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Select } from '@/components/ui/select'
import { Card } from '@/components/ui/card'
import NumberDisplay from './NumberDisplay'
import type { Algorithm } from '@/lib/algorithms'

export default function NumberGenerator() {
  const [algorithm, setAlgorithm] = useState<Algorithm>('random')
  const [numbers, setNumbers] = useState<number[][]>([])
  const [loading, setLoading] = useState(false)

  const handleGenerate = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/lotto/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ algorithm, count: 5 }),
      })

      const data = await res.json()
      if (data.success) {
        setNumbers(data.data.numbers)
      }
    } catch (error) {
      console.error('생성 오류:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="p-6 max-w-3xl mx-auto">
      <div className="space-y-6">
        {/* 알고리즘 선택 */}
        <div>
          <label className="block text-sm font-medium mb-2">
            생성 알고리즘
          </label>
          <select
            value={algorithm}
            onChange={(e) => setAlgorithm(e.target.value as Algorithm)}
            className="w-full p-2 border rounded"
          >
            <option value="random">완전 랜덤</option>
            <option value="frequency">빈도 기반</option>
            <option value="pattern">패턴 기반</option>
          </select>
        </div>

        {/* 생성 버튼 */}
        <Button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full"
        >
          {loading ? '생성 중...' : '번호 생성 (5개)'}
        </Button>

        {/* 생성된 번호 */}
        {numbers.length > 0 && (
          <div className="space-y-4 mt-6">
            <h3 className="font-semibold text-lg">생성된 번호</h3>
            {numbers.map((set, i) => (
              <div key={i} className="p-4 bg-gray-50 rounded-lg">
                <NumberDisplay numbers={set} />
              </div>
            ))}
          </div>
        )}
      </div>
    </Card>
  )
}
```

**체크리스트**:
- [ ] NumberBall 컴포넌트
- [ ] NumberDisplay 컴포넌트
- [ ] NumberGenerator 컴포넌트
- [ ] UI 테스트 (브라우저)

---

### Task 7: 페이지 구현 (예상 2시간)

#### 7.1 메인 페이지

**파일**: `src/app/page.tsx`

```typescript
import NumberGenerator from '@/components/lotto/NumberGenerator'

export default function Home() {
  return (
    <main className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold mb-2">🎰 LottoMaster</h1>
        <p className="text-gray-600">데이터 기반 로또 번호 추천</p>
      </div>

      <NumberGenerator />
    </main>
  )
}
```

#### 7.2 당첨번호 이력 페이지

**파일**: `src/app/history/page.tsx`

```typescript
import { getLottoData } from '@/lib/data/loader'
import NumberDisplay from '@/components/lotto/NumberDisplay'

export default function HistoryPage() {
  const data = getLottoData()
  const recentDraws = data.draws.slice(0, 20)

  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">당첨번호 이력</h1>

      <div className="space-y-4">
        {recentDraws.map((draw) => (
          <div key={draw.drawNo} className="p-4 border rounded-lg">
            <div className="flex justify-between items-center mb-3">
              <span className="font-semibold text-lg">
                {draw.drawNo}회차
              </span>
              <span className="text-gray-600">{draw.drawDate}</span>
            </div>
            <NumberDisplay
              numbers={draw.numbers}
              bonusNum={draw.bonusNum}
            />
          </div>
        ))}
      </div>
    </main>
  )
}
```

**체크리스트**:
- [ ] 메인 페이지 구현
- [ ] 당첨번호 이력 페이지 구현
- [ ] 네비게이션 추가 (layout.tsx)
- [ ] 페이지 간 이동 테스트

---

### Task 8: Docker 설정 (예상 1시간)

#### 8.1 Dockerfile.prod

**파일**: `Dockerfile.prod`

```dockerfile
FROM node:20-alpine AS deps
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev

FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
ENV NEXT_TELEMETRY_DISABLED=1
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
ENV NEXT_TELEMETRY_DISABLED=1

RUN addgroup --system --gid 1001 nodejs && \
    adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs
EXPOSE 3000
ENV PORT=3000

CMD ["node", "server.js"]
```

#### 8.2 next.config.js

**파일**: `next.config.js`

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  images: {
    unoptimized: true,
  },
  compress: true,
  experimental: {
    workerThreads: false,
    cpus: 1,
  },
}

module.exports = nextConfig
```

#### 8.3 .env.local (로컬 개발용)

```bash
NEXT_PUBLIC_APP_URL=http://localhost:3000
NODE_ENV=development
```

**체크리스트**:
- [ ] Dockerfile.prod 작성
- [ ] next.config.js 설정
- [ ] .dockerignore 작성
- [ ] 로컬 빌드 테스트

---

### Task 9: Docker Compose 통합 (예상 30분)

#### 9.1 docker-compose.yml 수정

**파일**: `/home/deploy/docker-compose.yml`

```yaml
services:
  # ... 기존 서비스

  lotto-service:
    build:
      context: ./projects/lotto-master
      dockerfile: Dockerfile.prod
    container_name: lotto-service
    restart: unless-stopped

    deploy:
      resources:
        limits:
          cpus: '0.25'
          memory: 192M
        reservations:
          memory: 128M

    environment:
      - NODE_ENV=production
      - NEXT_PUBLIC_APP_URL=http://203.245.30.6:3001

    networks:
      app-network:
        ipv4_address: 172.20.0.11

    expose:
      - "3000"

    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://127.0.0.1:3000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 30s

    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
```

#### 9.2 Nginx 설정 추가

**파일**: `/home/deploy/nginx/conf.d/port-based.conf`

```nginx
# 추가
upstream lotto_backend {
    server lotto-service:3000;
}

server {
    listen 3001;
    server_name _;

    include /etc/nginx/conf.d/korean-ips.conf;

    location / {
        proxy_pass http://lotto_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

**체크리스트**:
- [ ] docker-compose.yml 업데이트
- [ ] Nginx 설정 추가
- [ ] 컨테이너 빌드
- [ ] 서비스 시작 및 헬스체크

---

### Task 10: 배포 및 테스트 (예상 1시간)

#### 10.1 빌드 및 배포

```bash
cd /home/deploy

# 백업
./scripts/backup.sh

# 빌드
docker compose build lotto-service

# 시작
docker compose up -d lotto-service

# 확인
docker compose ps
docker compose logs -f lotto-service
```

#### 10.2 테스트

```bash
# 헬스체크
curl http://203.245.30.6:3001/api/health

# 번호 생성
curl -X POST http://203.245.30.6:3001/api/lotto/generate \
  -H "Content-Type: application/json" \
  -d '{"algorithm":"random","count":3}'

# 당첨번호 조회
curl http://203.245.30.6:3001/api/lotto/history?limit=5

# 통계
curl http://203.245.30.6:3001/api/stats/dashboard

# 웹 접근
open http://203.245.30.6:3001
```

**체크리스트**:
- [ ] 컨테이너 정상 실행
- [ ] 헬스체크 통과
- [ ] API 응답 확인
- [ ] 웹 페이지 로드 확인
- [ ] 번호 생성 기능 테스트

---

## 📊 예상 작업 시간 요약

| Task | 내용 | 시간 |
|------|------|------|
| 1 | 프로젝트 초기화 | 30분 |
| 2 | shadcn/ui 설정 | 20분 |
| 3 | 정적 데이터 준비 | 1시간 |
| 4 | 알고리즘 구현 | 2시간 |
| 5 | API Routes 구현 | 2시간 |
| 6 | UI 컴포넌트 | 3시간 |
| 7 | 페이지 구현 | 2시간 |
| 8 | Docker 설정 | 1시간 |
| 9 | Docker Compose 통합 | 30분 |
| 10 | 배포 및 테스트 | 1시간 |
| **합계** | | **13시간 20분** |

**여유 시간 포함**: 15-16시간

---

## ✅ 최종 체크리스트

### 개발 환경
- [ ] Node.js 20+ 설치 확인
- [ ] npm 또는 yarn 사용 가능
- [ ] Docker 실행 중

### 필수 구현
- [ ] 3가지 번호 생성 알고리즘
- [ ] 정적 JSON 데이터 로더
- [ ] 4개 API 엔드포인트
- [ ] 번호 표시 UI
- [ ] 당첨번호 이력 페이지

### 배포
- [ ] Docker 이미지 빌드 성공
- [ ] 컨테이너 헬스체크 통과
- [ ] Nginx 라우팅 정상 동작
- [ ] 외부 접근 테스트 (http://203.245.30.6:3001)

### 문서화
- [ ] README.md 작성
- [ ] API 문서 작성
- [ ] 운영 가이드 업데이트

---

## 🚀 시작 명령어

```bash
# 1. 프로젝트 생성
cd /home/deploy/projects
npx create-next-app@latest lotto-master --typescript --tailwind --app

# 2. 이 계획서를 참조하여 단계별 진행
cd lotto-master
cat docs/IMPLEMENTATION_PLAN.md

# 3. 개발 서버 실행 (로컬 테스트)
npm run dev

# 4. 프로덕션 빌드 테스트
npm run build
npm start
```

---

**문서 버전**: 1.0 (DB 제거 버전)
**최종 수정**: 2025-10-16
**예상 완료일**: 착수 후 2-3일
**상태**: 구현 준비 완료 ✅
