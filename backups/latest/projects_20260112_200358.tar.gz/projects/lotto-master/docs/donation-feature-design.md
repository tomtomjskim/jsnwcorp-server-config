# 후원/커피사주기 기능 설계

## 개요

사용자가 서비스에 만족할 경우 개발자에게 소액 후원을 할 수 있는 기능을 추가합니다.
퀵 버튼 + 모달 형태로 구현하여 사용자 경험을 해치지 않으면서 후원 옵션을 제공합니다.

## 후원 플랫폼 비교

| 플랫폼 | 수수료 | 한국 지원 | 연동 난이도 | 비고 |
|--------|--------|-----------|-------------|------|
| **Buy Me a Coffee** | 5% | O | 쉬움 | 위젯/버튼 제공, 국제적 인지도 |
| **Ko-fi** | 0% (선택적 5%) | O | 쉬움 | 무료 옵션, PayPal 연동 |
| **Toss (토스)** | 3.3%+ | O | 중간 | 송금 링크 활용, 가맹점 불필요 |
| **카카오페이** | - | O | 쉬움 | 송금 링크 QR |
| **PayPal.me** | 2.9%+0.3$ | O | 쉬움 | 해외 결제 |

### 추천 조합

**1차 (즉시 구현 가능)**
- Toss 송금 링크
- 카카오페이 송금 QR
- Buy Me a Coffee 위젯

**2차 (추후 확장)**
- Ko-fi 연동
- 정기 후원 옵션

## UI/UX 설계

### 1. 퀵 버튼 위치

```
┌─────────────────────────────────────┐
│  Header                             │
├─────────────────────────────────────┤
│                                     │
│  Main Content                       │
│                                     │
│                          [☕ 후원]  │  ← 우측 하단 플로팅 버튼
├─────────────────────────────────────┤
│  Footer                             │
└─────────────────────────────────────┘
```

### 2. 플로팅 버튼 디자인

```tsx
// 우측 하단 고정 플로팅 버튼
<button className="fixed bottom-6 right-6 z-50
  bg-gradient-to-r from-yellow-400 to-orange-500
  text-white px-4 py-3 rounded-full shadow-lg
  hover:shadow-xl hover:scale-105 transition-all
  flex items-center gap-2">
  <span>☕</span>
  <span className="hidden sm:inline">커피 한 잔</span>
</button>
```

### 3. 모달 디자인

```
┌────────────────────────────────────────┐
│  ☕ 개발자에게 커피 한 잔 사주기      X │
├────────────────────────────────────────┤
│                                        │
│  LottoMaster를 유용하게 사용하셨다면   │
│  커피 한 잔으로 응원해주세요!          │
│                                        │
│  ┌──────────┐ ┌──────────┐            │
│  │  💙 토스  │ │ 💛 카카오 │            │
│  │  송금하기 │ │ 페이 송금 │            │
│  └──────────┘ └──────────┘            │
│                                        │
│  ┌────────────────────────┐           │
│  │  ☕ Buy Me a Coffee    │           │
│  └────────────────────────┘           │
│                                        │
│  ─────────────────────────────────    │
│  💌 응원 메시지도 환영합니다!          │
│  jsnetwork.corp@gmail.com             │
│                                        │
└────────────────────────────────────────┘
```

## 기술 구현

### 파일 구조

```
src/
├── components/
│   └── donation/
│       ├── DonationButton.tsx    # 플로팅 버튼
│       └── DonationModal.tsx     # 후원 모달
└── app/
    └── layout.tsx                # 버튼 추가
```

### DonationButton.tsx

```tsx
'use client';

import { useState } from 'react';
import DonationModal from './DonationModal';

export default function DonationButton() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-40
          bg-gradient-to-r from-yellow-400 to-orange-500
          text-white px-4 py-3 rounded-full shadow-lg
          hover:shadow-xl hover:scale-105 transition-all
          flex items-center gap-2 font-medium"
        aria-label="후원하기"
      >
        <span className="text-lg">☕</span>
        <span className="hidden sm:inline text-sm">커피 한 잔</span>
      </button>

      <DonationModal isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
}
```

### DonationModal.tsx

```tsx
'use client';

interface DonationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// 후원 링크 설정 (실제 사용시 업데이트 필요)
const DONATION_LINKS = {
  toss: 'https://toss.me/사용자명',           // Toss 송금 링크
  kakao: 'https://qr.kakaopay.com/xxx',       // 카카오페이 QR
  buymeacoffee: 'https://buymeacoffee.com/xxx', // Buy Me a Coffee
};

export default function DonationModal({ isOpen, onClose }: DonationModalProps) {
  if (!isOpen) return null;

  const handleDonate = (platform: keyof typeof DONATION_LINKS) => {
    window.open(DONATION_LINKS[platform], '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6 animate-in fade-in zoom-in duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
          aria-label="닫기"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <span className="text-4xl mb-3 block">☕</span>
          <h2 className="text-xl font-bold text-gray-900">
            개발자에게 커피 한 잔 사주기
          </h2>
          <p className="text-gray-600 mt-2 text-sm">
            LottoMaster를 유용하게 사용하셨다면<br />
            커피 한 잔으로 응원해주세요!
          </p>
        </div>

        {/* Donation Options */}
        <div className="space-y-3">
          {/* Korean Payment Options */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => handleDonate('toss')}
              className="flex items-center justify-center gap-2 p-4 bg-blue-50 hover:bg-blue-100 rounded-xl transition-colors border border-blue-200"
            >
              <span className="text-2xl">💙</span>
              <div className="text-left">
                <div className="font-semibold text-blue-700">토스</div>
                <div className="text-xs text-blue-600">송금하기</div>
              </div>
            </button>

            <button
              onClick={() => handleDonate('kakao')}
              className="flex items-center justify-center gap-2 p-4 bg-yellow-50 hover:bg-yellow-100 rounded-xl transition-colors border border-yellow-200"
            >
              <span className="text-2xl">💛</span>
              <div className="text-left">
                <div className="font-semibold text-yellow-700">카카오페이</div>
                <div className="text-xs text-yellow-600">송금하기</div>
              </div>
            </button>
          </div>

          {/* International Option */}
          <button
            onClick={() => handleDonate('buymeacoffee')}
            className="w-full flex items-center justify-center gap-2 p-4 bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-white rounded-xl transition-all font-semibold"
          >
            <span className="text-xl">☕</span>
            Buy Me a Coffee
          </button>
        </div>

        {/* Contact Info */}
        <div className="mt-6 pt-4 border-t border-gray-200 text-center">
          <p className="text-sm text-gray-500">
            💌 응원 메시지도 환영합니다!
          </p>
          <a
            href="mailto:jsnetwork.corp@gmail.com"
            className="text-sm text-blue-600 hover:text-blue-700 font-medium"
          >
            jsnetwork.corp@gmail.com
          </a>
        </div>
      </div>
    </div>
  );
}
```

## 후원 링크 설정 방법

### 1. Toss 송금 링크

1. 토스 앱 → 더보기 → 송금 링크 만들기
2. 링크 생성 후 `https://toss.me/사용자명` 형태로 사용

### 2. 카카오페이 송금

1. 카카오페이 앱 → 송금 → QR 코드 생성
2. QR 코드 링크를 복사하여 사용
3. 또는 카카오톡 채널 개설하여 결제 링크 활용

### 3. Buy Me a Coffee

1. https://buymeacoffee.com 가입
2. 프로필 설정 후 개인 링크 획득
3. 위젯 코드도 제공됨 (선택적 사용)

## 구현 체크리스트

- [ ] DonationButton.tsx 컴포넌트 생성
- [ ] DonationModal.tsx 컴포넌트 생성
- [ ] Layout에 DonationButton 추가
- [ ] 후원 링크 설정 (Toss, 카카오페이, BMC)
- [ ] 모바일 반응형 테스트
- [ ] 접근성 테스트 (키보드 네비게이션)

## 향후 개선 사항

1. **후원자 명단 표시** (선택적, 동의 받은 경우)
2. **후원 목표 프로그레스 바**
3. **정기 후원 옵션** (Patreon, GitHub Sponsors 연동)
4. **애널리틱스 연동** (후원 버튼 클릭 추적)

## 참고 자료

- [Buy Me a Coffee Widgets](https://www.buymeacoffee.com/widgets)
- [Toss 송금 링크 가이드](https://toss.im/tossletter)
- [카카오페이 QR 결제](https://www.kakaopay.com)

---

작성일: 2026-01-11
버전: 1.0.0
