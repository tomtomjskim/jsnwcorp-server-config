# 로또 마스터 프로젝트 개선사항

## 완료된 작업 (2025-10-29)

### 데이터베이스 마이그레이션
- [x] PostgreSQL 스키마 설정 (`lotto.draws` 테이블)
- [x] JSON → PostgreSQL 마이그레이션 스크립트
- [x] DB 기반 데이터 로더 (`src/lib/data/db-loader.ts`)
- [x] 전체 1195회차 데이터 수집 완료 (2002-12-07 ~ 2025-10-25)

### API 개선
- [x] DB 기반 통계 API (`/api/stats/dashboard-db`)
- [x] DB 기반 히스토리 API (`/api/lotto/history-db`)
- [x] 다음 추첨 정보 계산 로직 추가
  - 추첨 전: "다음 추첨: YYYY-MM-DD (요일) 20:45"
  - 추첨 후 데이터 없음: "N회차 당첨정보 수집중..."

### 번호 생성 알고리즘 확장
- [x] `frequency-db`: DB 빈출 번호 (상위 60%)
- [x] `low-frequency-db`: DB 저빈도 번호 (하위 60%)
- [x] `recent-db`: DB 최근 출현 (20회 이내)
- [x] `cold-db`: DB 콜드 번호 (20회+ 미출현)
- [x] `balanced-db`: DB 균형 조합 (빈출3 + 저빈도3)
- [x] `ai-mixed-db`: DB AI 혼합 (종합 전략)

### 자동화
- [x] 크롤링 스크립트 개선 (`scripts/fetch-lotto-data-db.ts`)
  - 날짜 기반 최신 회차 계산
  - UPSERT 쿼리로 중복 방지
  - 봇 차단 방지 (500ms 딜레이, 100회마다 5초 휴식)
- [x] 빌드 성공 (TypeScript 타입 에러 모두 해결)

---

## 진행 중

### 크론 스케줄러 설정
- [ ] 스마트 크롤링 스크립트 작성 (`scripts/lotto-cron-smart.sh`)
- [ ] 크론탭 등록 (옵션 2: 균형적 수집)
  - 일요일 자정, 오전 9시 (2회)
  - 월요일 자정 (1회)
  - 화요일 자정 (안전망)
- [ ] 성공 플래그 파일 메커니즘 구현
- [ ] 로그 파일 설정 (`/var/log/lotto-cron.log`)

---

## 차후 개선사항

### 1. 알림 시스템 (Priority: Medium)
- [ ] 크롤링 실패 시 알림
  - Slack 웹훅 연동
  - 이메일 알림
  - Discord 웹훅
- [ ] 데이터 수집 성공 알림 (선택)
- [ ] 데이터 누락 감지 및 알림

### 2. 프론트엔드 개선 (Priority: High)
- [ ] Dashboard에 "다음 추첨" 카드 UI 추가
  - 추첨 대기 상태 표시
  - 당첨정보 수집중 상태 표시
  - 카운트다운 타이머 (선택)
- [ ] 새로운 DB 알고리즘 UI 통합
  - 알고리즘 설명 툴팁 추가
  - 알고리즘별 통계 표시
- [ ] 통계 페이지 개선
  - 차트 추가 (Chart.js 또는 Recharts)
  - 번호별 출현 빈도 그래프
  - 홀짝/고저 비율 시각화
- [ ] 반응형 디자인 최적화
- [ ] 다크 모드 지원

### 3. 성능 최적화 (Priority: Medium)
- [ ] API 응답 캐싱 전략 개선
  - Redis 도입 검토
  - Next.js ISR 최적화
- [ ] 데이터베이스 쿼리 최적화
  - 인덱스 추가 (draw_date, draw_no)
  - 통계 쿼리 Materialized View 검토
- [ ] 번들 크기 최적화
  - Dynamic import 활용
  - Tree-shaking 개선

### 4. 데이터 분석 기능 (Priority: Low)
- [ ] 번호 조합 패턴 분석
  - 연속 번호 출현 빈도
  - 구간별 분포 (1-9, 10-19, ...)
  - 홀짝 패턴 분석
- [ ] 당첨 번호 예측 모델
  - 머신러닝 모델 (선택)
  - 통계적 확률 분석
- [ ] 당첨금 통계 분석
  - 회차별 당첨금 추이
  - 당첨자 수 통계

### 5. 보안 및 안정성 (Priority: High)
- [ ] API Rate Limiting
  - IP 기반 제한
  - User 기반 제한
- [ ] CORS 설정 검토
- [ ] 환경 변수 보안 강화
  - Vault 또는 AWS Secrets Manager 검토
- [ ] 데이터베이스 백업 자동화
  - 일일 백업
  - 주간 전체 백업
- [ ] 모니터링 설정
  - Uptime 모니터링
  - 에러 추적 (Sentry)
  - 성능 모니터링 (New Relic)

### 6. 사용자 기능 (Priority: Low)
- [ ] 사용자 계정 시스템
  - 회원가입/로그인
  - OAuth (Google, Kakao)
- [ ] 즐겨찾기 번호 관리
  - 클라우드 동기화
  - 여러 디바이스 간 공유
- [ ] 번호 추천 히스토리
  - 생성한 번호 기록
  - 당첨 확인 기능
- [ ] 당첨 알림 기능
  - 내 번호 당첨 여부 자동 확인
  - 푸시 알림 또는 이메일

### 7. DevOps 개선 (Priority: Medium)
- [ ] Docker Compose 설정 최적화
- [ ] CI/CD 파이프라인 구축
  - GitHub Actions
  - 자동 테스트
  - 자동 배포
- [ ] 로그 관리 시스템
  - Logrotate 설정
  - 중앙 로그 수집 (ELK Stack)
- [ ] Health Check 엔드포인트 강화
  - DB 연결 상태
  - 최신 데이터 업데이트 시간

### 8. 테스트 (Priority: High)
- [ ] 유닛 테스트 작성
  - 알고리즘 테스트
  - API 테스트
- [ ] 통합 테스트
  - DB 연동 테스트
  - 크롤링 테스트
- [ ] E2E 테스트
  - Playwright 또는 Cypress

### 9. 문서화 (Priority: Medium)
- [ ] API 문서 자동 생성 (Swagger/OpenAPI)
- [ ] 사용자 가이드 작성
- [ ] 개발자 가이드 작성
- [ ] 아키텍처 다이어그램 추가
- [ ] 배포 가이드 업데이트

### 10. 기타 개선사항
- [ ] Next.js 설정 경고 해결
  - `experimental.turbo` 설정 수정
- [ ] ESLint/Prettier 규칙 정리
- [ ] 타입스크립트 strict 모드 적용
- [ ] 에러 핸들링 표준화
- [ ] 로깅 표준화

---

## 버그 및 이슈

### 현재 알려진 이슈
- [ ] Next.js config 경고: `experimental.turbo` 타입 불일치
- [ ] 타임존 처리 개선 필요 (KST vs UTC)

---

## 기술 부채
- [ ] JSON 기반 API 완전히 제거 검토
  - `/api/stats/dashboard` (legacy)
  - `/api/lotto/history` (일부 legacy)
- [ ] 중복 코드 리팩토링
  - 알고리즘 공통 로직 추출
  - DB 연결 풀 관리 개선

---

## 참고 링크
- [DATABASE_SETUP.md](../DATABASE_SETUP.md) - PostgreSQL 설정 가이드
- [IMPLEMENTATION_PLAN.md](../IMPLEMENTATION_PLAN.md) - 초기 구현 계획
- 동행복권 API: https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo={회차}

---

**최종 업데이트**: 2025-10-29
**작성자**: Claude Code
