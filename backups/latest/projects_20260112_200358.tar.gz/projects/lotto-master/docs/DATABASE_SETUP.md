# 로또 프로젝트 데이터베이스 설정 가이드

이 문서는 로또 프로젝트를 JSON 파일 기반에서 PostgreSQL 데이터베이스 기반으로 마이그레이션하고 자동 스케줄러를 설정하는 방법을 안내합니다.

## 📋 목차

1. [개요](#개요)
2. [데이터베이스 초기 설정](#데이터베이스-초기-설정)
3. [데이터 마이그레이션](#데이터-마이그레이션)
4. [자동 스케줄러 설정](#자동-스케줄러-설정)
5. [사용 방법](#사용-방법)
6. [문제 해결](#문제-해결)

---

## 개요

### 변경 사항

- **기존**: JSON 파일 (`public/data/lotto-data.json`)에 로또 데이터 저장
- **신규**: PostgreSQL 데이터베이스에 저장 + 자동 수집 스케줄러

### 주요 기능

1. ✅ **중복 방지**: 이미 존재하는 회차는 건너뜀 (또는 업데이트)
2. ✅ **자동 수집**: 매주 일요일/월요일에 최신 당첨번호 자동 수집
3. ✅ **데이터 무결성**: PostgreSQL 제약 조건으로 데이터 품질 보장
4. ✅ **성능 향상**: 인덱스를 통한 빠른 조회

---

## 데이터베이스 초기 설정

### 1. 환경변수 설정

`.env` 파일 생성 (또는 기존 파일 수정):

```bash
POSTGRES_HOST=postgres
POSTGRES_PORT=5432
POSTGRES_DB=maindb
POSTGRES_USER=lotto_user
POSTGRES_PASSWORD=your_secure_password
POSTGRES_SCHEMA=lotto
```

### 2. 데이터베이스 스키마 생성

다음 명령어로 테이블을 생성합니다:

```bash
# 방법 1: npm script 사용 (권장)
npm run init-db

# 방법 2: psql 직접 사용
psql -U lotto_user -d maindb -h postgres -f scripts/init-db.sql
```

생성되는 테이블 구조:

```sql
lotto.draws (
    draw_no INTEGER PRIMARY KEY,          -- 회차 번호
    draw_date DATE NOT NULL,              -- 추첨일
    num1, num2, num3, num4, num5, num6    -- 당첨번호 (1-45)
    bonus_num INTEGER,                     -- 보너스 번호
    first_win_amount BIGINT,              -- 1등 당첨금
    first_win_count INTEGER,              -- 1등 당첨자 수
    created_at TIMESTAMP,                 -- 생성 시각
    updated_at TIMESTAMP                  -- 수정 시각
)
```

---

## 데이터 마이그레이션

기존 JSON 데이터를 데이터베이스로 마이그레이션합니다.

### 마이그레이션 실행

```bash
npm run migrate-db
```

실행 결과:
```
🔄 JSON → PostgreSQL 마이그레이션 시작...
✅ 총 1145개 회차 데이터 로드 완료
✅ PostgreSQL 연결 성공
🔄 데이터 삽입 중...
✅ 마이그레이션 완료!

📊 결과:
   - 신규 삽입: 1145개
   - 업데이트: 0개
   - 실패: 0개

📈 DB 최종 데이터: 1145개 회차
📅 최신 회차: 1145회 (2025-10-16)
```

---

## 자동 스케줄러 설정

### 스케줄러 방식 선택

한국 로또는 매주 **토요일 저녁 8시 45분**에 추첨이 이루어집니다.
따라서 **일요일 아침** 또는 **월요일 아침**에 데이터를 수집하는 것이 적합합니다.

### 옵션 1: Linux Cron 사용 (권장)

#### 1. 스크립트 실행 권한 부여

```bash
chmod +x /home/deploy/projects/lotto-master/scripts/lotto-cron.sh
```

#### 2. Crontab 편집

```bash
crontab -e
```

#### 3. Cron Job 추가

**매주 일요일 오전 9시에 실행:**
```cron
0 9 * * 0 cd /home/deploy/projects/lotto-master && ./scripts/lotto-cron.sh >> /var/log/lotto-cron.log 2>&1
```

**매주 월요일 오전 9시에 실행:**
```cron
0 9 * * 1 cd /home/deploy/projects/lotto-master && ./scripts/lotto-cron.sh >> /var/log/lotto-cron.log 2>&1
```

**또는 일요일과 월요일 모두 (이중 체크):**
```cron
0 9 * * 0,1 cd /home/deploy/projects/lotto-master && ./scripts/lotto-cron.sh >> /var/log/lotto-cron.log 2>&1
```

#### 4. Cron Job 확인

```bash
crontab -l
```

#### 5. 로그 확인

```bash
tail -f /var/log/lotto-cron.log
```

### 옵션 2: Systemd Timer 사용

#### 1. Service 파일 생성

`/etc/systemd/system/lotto-fetch.service`:

```ini
[Unit]
Description=Lotto Data Fetch Service
After=network.target postgresql.service

[Service]
Type=oneshot
User=deploy
WorkingDirectory=/home/deploy/projects/lotto-master
Environment="NODE_ENV=production"
EnvironmentFile=/home/deploy/projects/lotto-master/.env
ExecStart=/usr/bin/npm run fetch-data-db -- --latest
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

#### 2. Timer 파일 생성

`/etc/systemd/system/lotto-fetch.timer`:

```ini
[Unit]
Description=Lotto Data Fetch Timer
Requires=lotto-fetch.service

[Timer]
# 매주 일요일 오전 9시
OnCalendar=Sun *-*-* 09:00:00
# 매주 월요일 오전 9시 (선택사항)
# OnCalendar=Mon *-*-* 09:00:00
Persistent=true

[Install]
WantedBy=timers.target
```

#### 3. Timer 활성화

```bash
sudo systemctl daemon-reload
sudo systemctl enable lotto-fetch.timer
sudo systemctl start lotto-fetch.timer
```

#### 4. Timer 상태 확인

```bash
sudo systemctl status lotto-fetch.timer
sudo systemctl list-timers --all
```

### 옵션 3: PM2 Cron 사용 (Node.js 환경)

```bash
pm2 start scripts/fetch-lotto-data-db.ts --cron "0 9 * * 0" --name "lotto-cron" --no-autorestart
```

---

## 사용 방법

### 수동 데이터 수집

#### 최신 회차만 수집 (기본)
```bash
npm run fetch-data-db
# 또는
npm run fetch-data-db -- --latest
```

#### 특정 범위 수집
```bash
npm run fetch-data-db -- --from=1 --to=100
```

#### 전체 수집
```bash
npm run fetch-data-db -- --from=1 --to=9999
```

### API 엔드포인트

#### JSON 기반 API (기존)
```
GET /api/lotto/history?drawNo=1145
GET /api/lotto/history?limit=20
```

#### 데이터베이스 기반 API (신규)
```
GET /api/lotto/history-db?drawNo=1145
GET /api/lotto/history-db?limit=20
```

### 응답 예시

```json
{
  "success": true,
  "data": {
    "drawNo": 1145,
    "drawDate": "2025-10-16",
    "numbers": [3, 12, 15, 28, 35, 42],
    "bonusNum": 7,
    "firstWinAmount": 2500000000,
    "firstWinCount": 8
  }
}
```

---

## 문제 해결

### 1. 데이터베이스 연결 실패

**증상:**
```
❌ PostgreSQL 연결 실패
```

**해결 방법:**
```bash
# 1. PostgreSQL 서비스 확인
sudo systemctl status postgresql

# 2. 연결 테스트
psql -U lotto_user -d maindb -h postgres -c "SELECT 1"

# 3. 환경변수 확인
echo $POSTGRES_HOST
echo $POSTGRES_USER
```

### 2. 테이블이 존재하지 않음

**증상:**
```
❌ lotto.draws 테이블이 존재하지 않습니다.
```

**해결 방법:**
```bash
# 스키마 생성 스크립트 실행
npm run init-db
```

### 3. 중복 키 에러

**증상:**
```
duplicate key value violates unique constraint "draws_pkey"
```

**해결 방법:**
이미 존재하는 회차입니다. 스크립트는 자동으로 `ON CONFLICT` 처리하므로 정상입니다.

### 4. Cron이 실행되지 않음

**증상:**
로그에 아무것도 출력되지 않음

**해결 방법:**
```bash
# 1. Cron 서비스 확인
sudo systemctl status cron

# 2. Crontab 확인
crontab -l

# 3. 수동 실행 테스트
cd /home/deploy/projects/lotto-master
./scripts/lotto-cron.sh

# 4. 로그 권한 확인
ls -la /var/log/lotto-cron.log
```

### 5. 환경변수가 Cron에서 인식되지 않음

**해결 방법:**

Crontab에 환경변수 추가:
```cron
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin

0 9 * * 0 cd /home/deploy/projects/lotto-master && ./scripts/lotto-cron.sh
```

---

## 데이터 확인

### PostgreSQL에서 직접 확인

```sql
-- 전체 회차 수
SELECT COUNT(*) FROM lotto.draws;

-- 최신 10개 회차
SELECT draw_no, draw_date, num1, num2, num3, num4, num5, num6, bonus_num
FROM lotto.draws
ORDER BY draw_no DESC
LIMIT 10;

-- 특정 회차 조회
SELECT * FROM lotto.draws WHERE draw_no = 1145;

-- 번호별 출현 빈도
WITH all_numbers AS (
    SELECT num1 as num FROM lotto.draws
    UNION ALL SELECT num2 FROM lotto.draws
    UNION ALL SELECT num3 FROM lotto.draws
    UNION ALL SELECT num4 FROM lotto.draws
    UNION ALL SELECT num5 FROM lotto.draws
    UNION ALL SELECT num6 FROM lotto.draws
)
SELECT num, COUNT(*) as count
FROM all_numbers
GROUP BY num
ORDER BY count DESC, num ASC;
```

---

## 다음 단계

1. ✅ 데이터베이스 설정 완료
2. ✅ 데이터 마이그레이션 완료
3. ✅ Cron Job 설정 완료
4. 🔄 기존 API를 DB 기반으로 교체 (선택사항)
5. 🔄 프론트엔드에서 새로운 API 사용 (선택사항)

---

## 참고

- 로또 추첨: 매주 토요일 20:45
- 데이터 소스: https://www.dhlottery.co.kr
- Rate Limiting: 200ms (API 호출 간격)
- 최대 회차: 동적 조회 (9999회로 조회)
