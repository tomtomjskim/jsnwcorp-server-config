# 🎰 로또 번호 추천 & 통계 웹서비스 설계 문서

## 📋 프로젝트 개요

### 서비스 이름
**LottoMaster** (가칭)

### 핵심 가치
- 데이터 기반 로또 번호 추천
- 역대 당첨 번호 통계 분석 및 시각화
- 직관적인 UI/UX

### 주요 기능
1. **번호 추천 시스템**
   - 완전 랜덤 생성
   - 통계 기반 알고리즘 (빈출/미출 번호)
   - 패턴 분석 기반 추천

2. **통계 대시보드**
   - 번호별 출현 빈도
   - 회차별 당첨 번호 조회
   - 연속/간격 분석
   - 홀짝/고저 비율

3. **추가 기능**
   - 생성 번호 저장 (로컬)
   - 당첨 확인 시뮬레이터
   - 통계 차트 시각화

---

## 🛠 기술 스택 상세

### Frontend & Backend
```
Next.js 14.2+ (App Router)
├── React 18+
├── TypeScript 5+
└── Server Components + Client Components
```

### Database
```
PostgreSQL 15+
└── Prisma ORM 5+
    ├── Type-safe queries
    └── Migration 관리
```

### Styling
```
Tailwind CSS 3.4+
└── shadcn/ui Components
    ├── Button, Card, Dialog
    ├── Table, Select, Tabs
    └── Chart Components
```

### Data Visualization
```
Recharts
├── BarChart (빈도 분석)
├── LineChart (트렌드)
└── PieChart (분포도)
```

### Development Tools
```
- ESLint + Prettier
- Husky (Git Hooks)
- TypeScript Strict Mode
```

### Deployment
```
Vercel
├── PostgreSQL (Vercel Postgres)
├── Edge Functions
└── Automatic CI/CD
```

---

## 🏗 시스템 아키텍처

```
┌─────────────────────────────────────────────────┐
│                   Client Layer                   │
│  (Next.js App Router - React Server Components) │
└────────────┬────────────────────────┬────────────┘
             │                        │
             ├─ Static Pages          ├─ Dynamic Pages
             │  (/, /about)           │  (/stats, /history)
             │                        │
             ↓                        ↓
┌────────────────────────────────────────────────┐
│              Application Layer                  │
│         (Next.js API Routes / Actions)         │
├────────────────────────────────────────────────┤
│  /api/lotto/generate   - 번호 생성             │
│  /api/lotto/history    - 당첨 번호 조회        │
│  /api/stats/*          - 통계 데이터           │
│  /api/admin/sync       - 당첨번호 동기화       │
└────────────┬───────────────────────────────────┘
             │
             ↓
┌────────────────────────────────────────────────┐
│               Data Access Layer                 │
│              (Prisma Client)                    │
└────────────┬───────────────────────────────────┘
             │
             ↓
┌────────────────────────────────────────────────┐
│               Database Layer                    │
│          (PostgreSQL - Vercel)                  │
└─────────────────────────────────────────────────┘
```

---

## 🗄 데이터베이스 스키마

### Prisma Schema

```prisma
// prisma/schema.prisma

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

// 로또 회차별 당첨 번호
model DrawResult {
  id            Int      @id @default(autoincrement())
  drawNo        Int      @unique // 회차 번호
  drawDate      DateTime // 추첨일
  
  // 당첨 번호 (1~45)
  num1          Int
  num2          Int
  num3          Int
  num4          Int
  num5          Int
  num6          Int
  bonusNum      Int      // 보너스 번호
  
  // 당첨 정보
  firstWinAmount  BigInt?  // 1등 당첨금
  firstWinCount   Int?     // 1등 당첨자 수
  
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
  
  @@index([drawNo])
  @@index([drawDate])
}

// 번호별 통계 (집계 테이블)
model NumberStatistics {
  id            Int      @id @default(autoincrement())
  number        Int      @unique // 1~45
  
  // 출현 통계
  totalCount    Int      @default(0) // 총 출현 횟수
  bonusCount    Int      @default(0) // 보너스 출현 횟수
  lastDrawNo    Int?                 // 마지막 출현 회차
  lastDrawDate  DateTime?            // 마지막 출현일
  
  // 연속 통계
  maxConsecutive Int     @default(0) // 최대 연속 출현
  currentStreak  Int     @default(0) // 현재 미출현 횟수
  
  updatedAt     DateTime @updatedAt
  
  @@index([number])
  @@index([totalCount])
}

// 사용자 생성 번호 (로컬 저장용 - 선택사항)
model GeneratedNumber {
  id            String   @id @default(cuid())
  sessionId     String   // 브라우저 세션 ID
  
  numbers       Int[]    // 생성된 6개 번호
  algorithm     String   // 생성 알고리즘 타입
  
  createdAt     DateTime @default(now())
  
  @@index([sessionId])
  @@index([createdAt])
}
```

---

## 🔌 API 설계

### REST API Endpoints

#### 1. 번호 생성 API
```typescript
POST /api/lotto/generate
Content-Type: application/json

Request Body:
{
  "algorithm": "random" | "frequency" | "pattern",
  "count": 1-10 // 생성할 번호 세트 개수
}

Response: 200 OK
{
  "success": true,
  "data": {
    "numbers": [
      [3, 12, 23, 28, 35, 42],
      [7, 15, 19, 31, 38, 44]
    ],
    "algorithm": "frequency",
    "generatedAt": "2025-10-16T10:30:00Z"
  }
}
```

#### 2. 당첨 번호 조회
```typescript
GET /api/lotto/history?drawNo=1145&limit=10

Response: 200 OK
{
  "success": true,
  "data": {
    "results": [
      {
        "drawNo": 1145,
        "drawDate": "2025-10-12",
        "numbers": [3, 12, 23, 28, 35, 42],
        "bonusNum": 15,
        "firstWinAmount": 2500000000,
        "firstWinCount": 12
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 115,
      "totalResults": 1145
    }
  }
}
```

#### 3. 번호별 통계
```typescript
GET /api/stats/numbers

Response: 200 OK
{
  "success": true,
  "data": [
    {
      "number": 1,
      "totalCount": 185,
      "bonusCount": 15,
      "lastDrawNo": 1140,
      "frequency": 16.2, // 출현율 (%)
      "currentStreak": 5  // 미출현 횟수
    },
    // ... 1~45 모든 번호
  ]
}
```

#### 4. 대시보드 통계
```typescript
GET /api/stats/dashboard

Response: 200 OK
{
  "success": true,
  "data": {
    "totalDraws": 1145,
    "lastUpdate": "2025-10-12T21:00:00Z",
    "topFrequent": [
      { "number": 34, "count": 195 },
      { "number": 43, "count": 192 }
    ],
    "leastFrequent": [
      { "number": 13, "count": 145 },
      { "number": 2, "count": 148 }
    ],
    "oddEvenRatio": {
      "odd": 51.2,
      "even": 48.8
    },
    "highLowRatio": {
      "low": 49.5,   // 1-22
      "high": 50.5   // 23-45
    }
  }
}
```

#### 5. 당첨 번호 동기화 (Admin)
```typescript
POST /api/admin/sync
Authorization: Bearer {ADMIN_TOKEN}

Response: 200 OK
{
  "success": true,
  "data": {
    "synced": 3,
    "latestDrawNo": 1145
  }
}
```

---

## 📁 프로젝트 폴더 구조

```
lotto-master/
├── src/
│   ├── app/                          # Next.js App Router
│   │   ├── layout.tsx               # Root Layout
│   │   ├── page.tsx                 # 홈페이지 (번호 생성)
│   │   ├── globals.css              # Global Styles
│   │   │
│   │   ├── generate/                # 번호 생성 페이지
│   │   │   └── page.tsx
│   │   │
│   │   ├── history/                 # 당첨 번호 이력
│   │   │   ├── page.tsx
│   │   │   └── [drawNo]/
│   │   │       └── page.tsx         # 회차별 상세
│   │   │
│   │   ├── stats/                   # 통계 페이지
│   │   │   ├── page.tsx             # 대시보드
│   │   │   ├── numbers/             # 번호별 통계
│   │   │   │   └── page.tsx
│   │   │   └── analysis/            # 고급 분석
│   │   │       └── page.tsx
│   │   │
│   │   └── api/                     # API Routes
│   │       ├── lotto/
│   │       │   ├── generate/
│   │       │   │   └── route.ts
│   │       │   └── history/
│   │       │       └── route.ts
│   │       ├── stats/
│   │       │   ├── numbers/
│   │       │   │   └── route.ts
│   │       │   └── dashboard/
│   │       │       └── route.ts
│   │       └── admin/
│   │           └── sync/
│   │               └── route.ts
│   │
│   ├── components/                   # React Components
│   │   ├── ui/                      # shadcn/ui components
│   │   │   ├── button.tsx
│   │   │   ├── card.tsx
│   │   │   ├── table.tsx
│   │   │   └── ...
│   │   │
│   │   ├── lotto/                   # 로또 전용 컴포넌트
│   │   │   ├── NumberBall.tsx       # 번호 공 UI
│   │   │   ├── NumberGenerator.tsx  # 번호 생성기
│   │   │   ├── NumberDisplay.tsx    # 번호 표시
│   │   │   └── AlgorithmSelector.tsx
│   │   │
│   │   ├── stats/                   # 통계 컴포넌트
│   │   │   ├── FrequencyChart.tsx   # 빈도 차트
│   │   │   ├── TrendChart.tsx       # 트렌드 차트
│   │   │   ├── HeatMap.tsx          # 히트맵
│   │   │   └── StatsSummary.tsx     # 통계 요약
│   │   │
│   │   └── layout/                  # 레이아웃 컴포넌트
│   │       ├── Header.tsx
│   │       ├── Footer.tsx
│   │       └── Navigation.tsx
│   │
│   ├── lib/                         # 유틸리티 & 로직
│   │   ├── prisma.ts               # Prisma Client 싱글톤
│   │   ├── utils.ts                # 공통 유틸
│   │   │
│   │   ├── algorithms/             # 번호 생성 알고리즘
│   │   │   ├── random.ts          # 완전 랜덤
│   │   │   ├── frequency.ts       # 빈도 기반
│   │   │   ├── pattern.ts         # 패턴 기반
│   │   │   └── index.ts           # 알고리즘 팩토리
│   │   │
│   │   ├── stats/                 # 통계 계산 로직
│   │   │   ├── calculator.ts     # 통계 계산
│   │   │   └── analyzer.ts       # 데이터 분석
│   │   │
│   │   └── crawlers/              # 당첨번호 크롤러 (선택)
│   │       └── dhlottery.ts      # 동행복권 크롤러
│   │
│   ├── types/                     # TypeScript 타입 정의
│   │   ├── lotto.ts
│   │   ├── api.ts
│   │   └── stats.ts
│   │
│   └── config/                    # 설정 파일
│       └── constants.ts          # 상수 정의
│
├── prisma/
│   ├── schema.prisma             # Prisma 스키마
│   ├── migrations/               # DB 마이그레이션
│   └── seed.ts                   # 초기 데이터 Seed
│
├── public/                        # 정적 파일
│   ├── images/
│   └── fonts/
│
├── scripts/                       # 스크립트
│   └── sync-lotto-data.ts       # 당첨번호 동기화 스크립트
│
├── .env                          # 환경 변수
├── .env.example                  # 환경 변수 예제
├── next.config.js               # Next.js 설정
├── tailwind.config.ts           # Tailwind 설정
├── tsconfig.json                # TypeScript 설정
└── package.json                 # 의존성 관리
```

---

## 🎨 주요 기능 구현 상세

### 1. 번호 생성 알고리즘

#### A. 완전 랜덤 (random.ts)
```typescript
export function generateRandomNumbers(): number[] {
  const numbers = new Set<number>();
  
  while (numbers.size < 6) {
    const num = Math.floor(Math.random() * 45) + 1;
    numbers.add(num);
  }
  
  return Array.from(numbers).sort((a, b) => a - b);
}
```

#### B. 빈도 기반 (frequency.ts)
```typescript
export async function generateFrequencyNumbers(
  stats: NumberStatistics[]
): Promise<number[]> {
  // 1. 출현 빈도 높은 번호에 가중치 부여
  const weights = stats.map(s => ({
    number: s.number,
    weight: s.totalCount
  }));
  
  // 2. 가중치 기반 랜덤 선택
  const selected = weightedRandomSelection(weights, 6);
  
  return selected.sort((a, b) => a - b);
}
```

#### C. 패턴 기반 (pattern.ts)
```typescript
export async function generatePatternNumbers(): Promise<number[]> {
  // 1. 홀짝 비율 고려 (3:3 또는 4:2)
  // 2. 고저 비율 고려 (1-22: 3개, 23-45: 3개)
  // 3. 연속 번호 제한 (최대 2개)
  // 4. 구간별 분산 (1-15, 16-30, 31-45)
  
  // 구현...
}
```

### 2. 통계 대시보드 구성

#### 주요 차트
1. **빈도 분석 바 차트** - 1~45번 출현 횟수
2. **트렌드 라인 차트** - 최근 20회 번호 흐름
3. **히트맵** - 번호 조합 패턴
4. **파이 차트** - 홀짝/고저 비율

### 3. 당첨 번호 크롤링

```typescript
// lib/crawlers/dhlottery.ts
export async function fetchLatestDrawResult(): Promise<DrawResult> {
  // 동행복권 API 호출
  const response = await fetch(
    'https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=latest'
  );
  
  const data = await response.json();
  
  return {
    drawNo: data.drwNo,
    drawDate: new Date(data.drwNoDate),
    num1: data.drwtNo1,
    num2: data.drwtNo2,
    // ... 변환 로직
  };
}
```

---

## 🚀 개발 로드맵 (4주 계획)

### Week 1: 프로젝트 세팅 & 기본 구조
- [ ] Next.js 프로젝트 초기화
- [ ] Prisma 스키마 작성 & 마이그레이션
- [ ] 기본 레이아웃 & 네비게이션
- [ ] shadcn/ui 컴포넌트 설치
- [ ] 환경 변수 설정

### Week 2: 핵심 기능 개발
- [ ] 번호 생성 알고리즘 구현 (3가지)
- [ ] 번호 생성 UI 구현
- [ ] API 라우트 개발 (generate, history)
- [ ] 당첨 번호 크롤러 개발
- [ ] 데이터베이스 Seed 스크립트

### Week 3: 통계 & 분석 기능
- [ ] 번호별 통계 계산 로직
- [ ] 통계 API 개발
- [ ] Recharts 차트 구현
- [ ] 대시보드 페이지 개발
- [ ] 히스토리 페이지 개발

### Week 4: 최적화 & 배포
- [ ] 성능 최적화 (캐싱, 이미지 최적화)
- [ ] 반응형 디자인 완성
- [ ] SEO 메타태그 설정
- [ ] Vercel 배포
- [ ] 모니터링 & 에러 트래킹

---

## 🌐 배포 전략

### Vercel 배포 설정

```javascript
// vercel.json
{
  "buildCommand": "prisma generate && prisma migrate deploy && next build",
  "devCommand": "next dev",
  "installCommand": "npm install",
  "env": {
    "DATABASE_URL": "@database_url",
    "NEXT_PUBLIC_APP_URL": "@app_url"
  }
}
```

### 환경 변수 (.env.example)
```bash
# Database
DATABASE_URL="postgresql://user:password@host:5432/lotto_db"

# App
NEXT_PUBLIC_APP_URL="http://localhost:3000"
NEXT_PUBLIC_APP_NAME="LottoMaster"

# Admin (당첨번호 동기화)
ADMIN_API_KEY="your-secret-key"

# Optional: Analytics
NEXT_PUBLIC_GA_ID=""
```

---

## 📊 성능 최적화 전략

### 1. Database 최적화
- 인덱스 활용 (drawNo, number, drawDate)
- 통계 테이블 집계 (실시간 계산 방지)
- Connection Pooling

### 2. API 최적화
- Next.js API Route Cache (revalidate)
- React Server Components (데이터 fetch)
- Incremental Static Regeneration (ISR)

### 3. Frontend 최적화
- Code Splitting
- Image Optimization (next/image)
- Font Optimization (next/font)
- Lazy Loading (차트 컴포넌트)

---

## 🔒 보안 고려사항

1. **API Rate Limiting** - 번호 생성 API 남용 방지
2. **Admin API 보호** - API Key 인증
3. **SQL Injection 방지** - Prisma ORM 사용
4. **XSS 방지** - React 자동 이스케이핑
5. **CORS 설정** - 허용된 도메인만 접근

---

## 📈 향후 확장 가능성

### Phase 2 기능
- [ ] 사용자 계정 시스템 (NextAuth.js)
- [ ] 생성 번호 저장 & 관리
- [ ] 당첨 확인 자동화
- [ ] 번호 공유 기능 (SNS)
- [ ] 모바일 앱 (React Native)

### Phase 3 고급 기능
- [ ] AI 기반 번호 예측 (TensorFlow.js)
- [ ] 실시간 당첨 알림 (WebSocket)
- [ ] 커뮤니티 기능 (댓글, 평가)
- [ ] 프리미엄 통계 서비스

---

## 🎯 개발 시작 커맨드

```bash
# 1. 프로젝트 생성
npx create-next-app@latest lotto-master --typescript --tailwind --app

# 2. 의존성 설치
cd lotto-master
npm install prisma @prisma/client
npm install recharts
npm install @radix-ui/react-dialog @radix-ui/react-select
npm install date-fns
npm install -D prisma

# 3. Prisma 초기화
npx prisma init

# 4. shadcn/ui 설치
npx shadcn-ui@latest init

# 5. 개발 서버 실행
npm run dev
```

---

이 설계 문서를 기반으로 개발을 시작하시면 됩니다! 🚀

