# 🎰 LottoMaster 서비스 구현 가이드
## Docker 기반 멀티 프로젝트 서버 환경 맞춤형 설계

**작성일**: 2025-10-16
**대상 서버**: 203.245.30.6
**기반 문서**: lotto-service.md (원본 설계), architecture.md (서버 아키텍처)
**배포 위치**: /home/deploy/projects/lotto-master

---

## 📋 목차

1. [현재 서버 환경 분석](#1-현재-서버-환경-분석)
2. [로또 서비스 통합 전략](#2-로또-서비스-통합-전략)
3. [리소스 재할당 계획](#3-리소스-재할당-계획)
4. [디렉토리 구조 통합](#4-디렉토리-구조-통합)
5. [Docker 설정 수정](#5-docker-설정-수정)
6. [Nginx 라우팅 설정](#6-nginx-라우팅-설정)
7. [데이터베이스 스키마 구현](#7-데이터베이스-스키마-구현)
8. [API 구현 계획](#8-api-구현-계획)
9. [프론트엔드 구현 계획](#9-프론트엔드-구현-계획)
10. [단계별 구현 체크리스트](#10-단계별-구현-체크리스트)

---

## 1. 현재 서버 환경 분석

### 1.1 기존 서버 구성

#### 시스템 사양
- **메모리**: 1GB RAM
- **스토리지**: 30GB (현재 37% 사용)
- **OS**: Ubuntu 22.04 LTS
- **IP**: 203.245.30.6
- **도메인**: jsnwcorp.com (구매 예정)

#### 실행 중인 서비스 (Phase 1 완료)
```
nginx-proxy   : 64MB  → 리버스 프록시 (포트 80, 443, 3001-3003)
dashboard     : 128MB → 메인 대시보드 (Node.js)
postgres      : 192MB → PostgreSQL 15
redis         : 96MB  → Redis 7
─────────────────────────────────────
현재 사용 중  : 480MB (약 50%)
여유 메모리   : 520MB
```

#### 디렉토리 구조
```
/home/deploy/
├── docker-compose.yml
├── nginx/
│   ├── nginx.conf
│   ├── conf.d/
│   │   ├── port-based.conf
│   │   └── korean-ips.conf
│   └── logs/
├── projects/
│   └── dashboard/          # 기존 프로젝트
├── scripts/
│   ├── deploy.sh
│   ├── backup.sh
│   ├── monitor.sh
│   └── cleanup-logs.sh
├── data/
│   ├── postgres/
│   └── redis/
└── backups/
```

#### 현재 포트 사용 현황
- **80**: nginx-proxy (메인 엔트리포인트)
- **443**: nginx-proxy (SSL 준비)
- **3001-3003**: 예약됨 (미사용)
- **5432**: postgres (내부 네트워크)
- **6379**: redis (내부 네트워크)

---

## 2. 로또 서비스 통합 전략

### 2.1 서비스 배치 전략

#### 옵션 1: 독립 실행 (권장)
로또 서비스를 별도의 Docker 컨테이너로 실행

**장점**:
- 기존 서비스와 격리
- 독립적인 업데이트 가능
- 리소스 제한 명확

**단점**:
- 메모리 사용량 증가

#### 옵션 2: Dashboard 통합
기존 Dashboard에 로또 기능 통합

**장점**:
- 메모리 절약
- 관리 포인트 감소

**단점**:
- 코드베이스 복잡도 증가
- 의존성 충돌 가능성

### 2.2 선택된 전략: 옵션 1 (독립 실행)

**이유**:
1. Next.js 14.2+ 사용 → 기존 Node.js Express와 다른 스택
2. Prisma ORM 사용 → 별도 DB 마이그레이션 필요
3. 향후 확장성 고려 (AI 기능, 실시간 알림 등)
4. 여유 메모리 충분 (520MB)

**배포 방식**:
- **포트**: 3001 (Service1 슬롯 사용)
- **URL**: http://203.245.30.6:3001 → http://lotto.jsnwcorp.com (향후)
- **메모리 할당**: 256MB (Next.js 최적화)
- **컨테이너명**: lotto-service

---

## 3. 리소스 재할당 계획

### 3.1 메모리 재할당

#### 현재 (480MB 사용)
```
nginx-proxy   : 64MB
dashboard     : 128MB
postgres      : 192MB
redis         : 96MB
```

#### 변경 후 (736MB 사용 → 여유 264MB)
```
nginx-proxy   : 64MB  (변경 없음)
dashboard     : 128MB (변경 없음)
lotto-service : 256MB (NEW)
postgres      : 192MB (변경 없음)
redis         : 96MB  (변경 없음)
─────────────────────────────────────
합계          : 736MB
시스템 버퍼   : 264MB
```

### 3.2 스토리지 할당

#### 현재 (9.9GB 사용 / 26GB)
```
OS + 시스템     : 5GB
Docker 이미지   : 3GB
기존 데이터     : 1.9GB
```

#### 추가 예상
```
Next.js 이미지  : ~200MB (Alpine 기반 최적화)
로또 데이터     : ~50MB (최근 1145회차)
로그 파일       : ~20MB
─────────────────────────────────────
추가 필요       : ~270MB
변경 후 총 사용 : 10.2GB (39%)
```

### 3.3 네트워크 할당

#### Docker 내부 네트워크 (172.20.0.0/16)
```
172.20.0.2  : nginx-proxy
172.20.0.10 : dashboard
172.20.0.11 : lotto-service (NEW)
172.20.0.20 : postgres
172.20.0.21 : redis
```

---

## 4. 디렉토리 구조 통합

### 4.1 프로젝트 디렉토리 추가

```bash
/home/deploy/projects/
├── dashboard/              # 기존 프로젝트
│   ├── Dockerfile
│   ├── package.json
│   └── public/
│       └── favicon.svg
│
└── lotto-master/          # 신규 프로젝트
    ├── Dockerfile
    ├── Dockerfile.prod     # 프로덕션 최적화 버전
    ├── next.config.js
    ├── package.json
    ├── tsconfig.json
    ├── tailwind.config.ts
    │
    ├── prisma/
    │   ├── schema.prisma
    │   ├── migrations/
    │   └── seed.ts
    │
    ├── src/
    │   ├── app/                    # Next.js App Router
    │   │   ├── layout.tsx
    │   │   ├── page.tsx           # 홈 (번호 생성)
    │   │   ├── globals.css
    │   │   │
    │   │   ├── api/               # API Routes
    │   │   │   ├── lotto/
    │   │   │   │   ├── generate/route.ts
    │   │   │   │   └── history/route.ts
    │   │   │   └── stats/
    │   │   │       ├── numbers/route.ts
    │   │   │       └── dashboard/route.ts
    │   │   │
    │   │   ├── history/           # 당첨번호 이력
    │   │   │   └── page.tsx
    │   │   │
    │   │   └── stats/             # 통계 페이지
    │   │       └── page.tsx
    │   │
    │   ├── components/
    │   │   ├── ui/                # shadcn/ui
    │   │   ├── lotto/             # 로또 컴포넌트
    │   │   └── stats/             # 통계 차트
    │   │
    │   ├── lib/
    │   │   ├── prisma.ts          # Prisma 클라이언트
    │   │   ├── algorithms/        # 번호 생성 로직
    │   │   │   ├── random.ts
    │   │   │   ├── frequency.ts
    │   │   │   └── pattern.ts
    │   │   └── stats/
    │   │       └── calculator.ts
    │   │
    │   └── types/
    │       ├── lotto.ts
    │       └── api.ts
    │
    ├── public/
    │   ├── favicon.ico
    │   └── images/
    │
    └── .env
```

### 4.2 Nginx 설정 추가

```bash
/home/deploy/nginx/conf.d/
├── port-based.conf         # 수정 필요
├── korean-ips.conf        # 변경 없음
└── lotto.conf             # 신규 추가 (선택)
```

### 4.3 데이터 디렉토리

```bash
/home/deploy/data/
├── postgres/
│   └── lotto_data/        # 로또 데이터 (Prisma 자동 생성)
└── redis/
```

---

## 5. Docker 설정 수정

### 5.1 docker-compose.yml 업데이트

**추가할 서비스 정의**:

```yaml
services:
  # ... 기존 서비스 (nginx-proxy, dashboard, postgres, redis)

  # 로또 서비스 추가
  lotto-service:
    build:
      context: ./projects/lotto-master
      dockerfile: Dockerfile.prod
    container_name: lotto-service
    restart: unless-stopped

    # 리소스 제한
    deploy:
      resources:
        limits:
          cpus: '0.3'
          memory: 256M
        reservations:
          memory: 128M

    # 환경 변수
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres:5432/${POSTGRES_DB}
      - REDIS_URL=redis://redis:6379
      - NEXT_PUBLIC_APP_URL=http://203.245.30.6:3001

    # 네트워크
    networks:
      app-network:
        ipv4_address: 172.20.0.11

    # 포트 (내부 전용, nginx가 프록시)
    expose:
      - "3000"

    # 헬스체크
    healthcheck:
      test: ["CMD", "node", "-e", "require('http').get('http://127.0.0.1:3000/api/health', (res) => process.exit(res.statusCode === 200 ? 0 : 1))"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

    # 의존성
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy

    # 로그 설정
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

    # 볼륨 (선택: 정적 파일 캐싱)
    volumes:
      - lotto-cache:/app/.next/cache

# 볼륨 추가
volumes:
  postgres-data:
  redis-data:
  lotto-cache:    # 신규 추가
```

### 5.2 Dockerfile.prod (Next.js 최적화)

```dockerfile
# /home/deploy/projects/lotto-master/Dockerfile.prod

# Stage 1: Dependencies
FROM node:20-alpine AS deps
WORKDIR /app

# Prisma 바이너리를 위한 openssl 설치
RUN apk add --no-cache libc6-compat openssl

# 의존성 파일 복사
COPY package.json package-lock.json* ./
COPY prisma ./prisma/

# 의존성 설치
RUN npm ci --omit=dev && \
    npx prisma generate

# Stage 2: Builder
FROM node:20-alpine AS builder
WORKDIR /app

# 의존성 복사
COPY --from=deps /app/node_modules ./node_modules
COPY . .

# 빌드 환경 변수
ENV NEXT_TELEMETRY_DISABLED=1
ENV NODE_ENV=production

# 빌드 실행
RUN npm run build

# Stage 3: Runner
FROM node:20-alpine AS runner
WORKDIR /app

ENV NODE_ENV=production
ENV NEXT_TELEMETRY_DISABLED=1

# 사용자 추가 (보안)
RUN addgroup --system --gid 1001 nodejs && \
    adduser --system --uid 1001 nextjs

# 필요한 파일만 복사
COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static
COPY --from=builder /app/prisma ./prisma
COPY --from=builder /app/node_modules/.prisma ./node_modules/.prisma

# 헬스체크 파일 추가 (선택)
USER nextjs

EXPOSE 3000

ENV PORT=3000
ENV HOSTNAME="0.0.0.0"

# 시작 명령
CMD ["node", "server.js"]
```

### 5.3 next.config.js 설정

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  // Standalone 모드 (Docker 최적화)
  output: 'standalone',

  // 이미지 최적화 비활성화 (메모리 절약)
  images: {
    unoptimized: true,
  },

  // 압축 활성화
  compress: true,

  // 메모리 최적화
  experimental: {
    // Worker 스레드 제한
    workerThreads: false,
    cpus: 1,
  },

  // 환경 변수 노출
  env: {
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
  },
}

module.exports = nextConfig
```

---

## 6. Nginx 라우팅 설정

### 6.1 port-based.conf 업데이트

**파일 위치**: `/home/deploy/nginx/conf.d/port-based.conf`

**추가할 upstream 및 server 블록**:

```nginx
# Upstream 정의
upstream dashboard_backend {
    server dashboard:3000;
}

upstream lotto_backend {
    server lotto-service:3000;
}

# 메인 서버 (포트 80)
server {
    listen 80 default_server;
    server_name _;

    # 한국 IP 화이트리스트 포함
    include /etc/nginx/conf.d/korean-ips.conf;

    # Dashboard (기본)
    location / {
        proxy_pass http://dashboard_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Health check
    location /health {
        access_log off;
        return 200 "OK\n";
    }
}

# 로또 서비스 (포트 3001)
server {
    listen 3001;
    server_name _;

    # 한국 IP 화이트리스트 포함
    include /etc/nginx/conf.d/korean-ips.conf;

    # 로또 서비스 프록시
    location / {
        proxy_pass http://lotto_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Next.js 웹소켓 지원 (향후 실시간 기능용)
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    # API 캐싱 (통계 데이터)
    location ~* ^/api/stats/ {
        proxy_pass http://lotto_backend;
        proxy_cache my_cache;
        proxy_cache_valid 200 5m;
        proxy_cache_key "$scheme$request_method$host$request_uri";
        add_header X-Cache-Status $upstream_cache_status;

        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### 6.2 향후 서브도메인 설정 (subdomain.conf)

**Phase 2 전환 시 사용**:

```nginx
# 로또 서비스 (서브도메인)
server {
    listen 80;
    listen 443 ssl http2;
    server_name lotto.jsnwcorp.com;

    # SSL 설정
    ssl_certificate /etc/nginx/ssl/jsnwcorp.com.crt;
    ssl_certificate_key /etc/nginx/ssl/jsnwcorp.com.key;

    # 한국 IP 화이트리스트
    include /etc/nginx/conf.d/korean-ips.conf;

    # HTTP → HTTPS 리다이렉션
    if ($scheme = http) {
        return 301 https://$server_name$request_uri;
    }

    location / {
        proxy_pass http://lotto_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

---

## 7. 데이터베이스 스키마 구현

### 7.1 Prisma 설정

**파일**: `/home/deploy/projects/lotto-master/prisma/schema.prisma`

```prisma
// prisma/schema.prisma

generator client {
  provider = "prisma-client-js"
  binaryTargets = ["native", "linux-musl-openssl-3.0.x"]
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

// 로또 회차별 당첨 번호
model DrawResult {
  id            Int      @id @default(autoincrement())
  drawNo        Int      @unique // 회차 번호
  drawDate      DateTime // 추첨일

  // 당첨 번호 (1~45)
  num1          Int
  num2          Int
  num3          Int
  num4          Int
  num5          Int
  num6          Int
  bonusNum      Int      // 보너스 번호

  // 당첨 정보
  firstWinAmount  BigInt?  // 1등 당첨금
  firstWinCount   Int?     // 1등 당첨자 수

  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  @@index([drawNo])
  @@index([drawDate])
  @@map("draw_results")
}

// 번호별 통계 (집계 테이블)
model NumberStatistics {
  id            Int      @id @default(autoincrement())
  number        Int      @unique // 1~45

  // 출현 통계
  totalCount    Int      @default(0) // 총 출현 횟수
  bonusCount    Int      @default(0) // 보너스 출현 횟수
  lastDrawNo    Int?                 // 마지막 출현 회차
  lastDrawDate  DateTime?            // 마지막 출현일

  // 연속 통계
  maxConsecutive Int     @default(0) // 최대 연속 출현
  currentStreak  Int     @default(0) // 현재 미출현 횟수

  updatedAt     DateTime @updatedAt

  @@index([number])
  @@index([totalCount])
  @@map("number_statistics")
}

// 사용자 생성 번호 (로컬 저장용 - 선택사항)
model GeneratedNumber {
  id            String   @id @default(cuid())
  sessionId     String   // 브라우저 세션 ID

  numbers       Int[]    // 생성된 6개 번호
  algorithm     String   // 생성 알고리즘 타입

  createdAt     DateTime @default(now())

  @@index([sessionId])
  @@index([createdAt])
  @@map("generated_numbers")
}
```

### 7.2 마이그레이션 실행 스크립트

**파일**: `/home/deploy/scripts/setup-lotto-db.sh`

```bash
#!/bin/bash

set -e

echo "🗄️  로또 서비스 데이터베이스 마이그레이션 시작..."

# 컨테이너 실행 확인
if ! docker ps | grep -q lotto-service; then
    echo "❌ lotto-service 컨테이너가 실행되지 않았습니다."
    exit 1
fi

# Prisma 마이그레이션
echo "📦 Prisma 마이그레이션 실행 중..."
docker exec lotto-service npx prisma migrate deploy

# Seed 데이터 (선택)
echo "🌱 초기 데이터 시딩 (선택)..."
read -p "초기 로또 데이터를 가져오시겠습니까? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    docker exec lotto-service npx prisma db seed
fi

echo "✅ 데이터베이스 설정 완료!"
```

### 7.3 Seed 스크립트 (초기 데이터)

**파일**: `/home/deploy/projects/lotto-master/prisma/seed.ts`

```typescript
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // 번호 통계 초기화 (1~45)
  for (let num = 1; num <= 45; num++) {
    await prisma.numberStatistics.upsert({
      where: { number: num },
      update: {},
      create: {
        number: num,
        totalCount: 0,
        bonusCount: 0,
        currentStreak: 0,
      },
    })
  }

  console.log('✅ Seeding completed!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
```

---

## 8. API 구현 계획

### 8.1 API 구조

```
/api
├── health              # 헬스체크
├── lotto
│   ├── generate        # POST - 번호 생성
│   └── history         # GET  - 당첨번호 조회
└── stats
    ├── numbers         # GET  - 번호별 통계
    └── dashboard       # GET  - 대시보드 통계
```

### 8.2 핵심 API 구현

#### A. 번호 생성 API

**파일**: `src/app/api/lotto/generate/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server'
import { generateRandomNumbers } from '@/lib/algorithms/random'
import { generateFrequencyNumbers } from '@/lib/algorithms/frequency'
import { generatePatternNumbers } from '@/lib/algorithms/pattern'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { algorithm = 'random', count = 1 } = body

    // 입력 검증
    if (count < 1 || count > 10) {
      return NextResponse.json(
        { success: false, error: '생성 개수는 1~10 사이여야 합니다.' },
        { status: 400 }
      )
    }

    // 알고리즘 선택
    let generatorFn
    switch (algorithm) {
      case 'frequency':
        generatorFn = generateFrequencyNumbers
        break
      case 'pattern':
        generatorFn = generatePatternNumbers
        break
      case 'random':
      default:
        generatorFn = generateRandomNumbers
    }

    // 번호 생성
    const numbers = []
    for (let i = 0; i < count; i++) {
      const generated = await generatorFn()
      numbers.push(generated)
    }

    return NextResponse.json({
      success: true,
      data: {
        numbers,
        algorithm,
        generatedAt: new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error('번호 생성 오류:', error)
    return NextResponse.json(
      { success: false, error: '번호 생성 중 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}
```

#### B. 통계 API

**파일**: `src/app/api/stats/dashboard/route.ts`

```typescript
import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export const revalidate = 300 // 5분 캐싱

export async function GET() {
  try {
    // 총 회차 수
    const totalDraws = await prisma.drawResult.count()

    // 최근 업데이트
    const lastDraw = await prisma.drawResult.findFirst({
      orderBy: { drawNo: 'desc' },
      select: { drawDate: true },
    })

    // 빈도 통계
    const stats = await prisma.numberStatistics.findMany({
      orderBy: { totalCount: 'desc' },
      take: 45,
    })

    const topFrequent = stats.slice(0, 5).map((s) => ({
      number: s.number,
      count: s.totalCount,
    }))

    const leastFrequent = stats.slice(-5).map((s) => ({
      number: s.number,
      count: s.totalCount,
    }))

    // 홀짝 비율 계산
    const oddCount = stats.filter((s) => s.number % 2 === 1)
      .reduce((sum, s) => sum + s.totalCount, 0)
    const evenCount = stats.filter((s) => s.number % 2 === 0)
      .reduce((sum, s) => sum + s.totalCount, 0)
    const totalNumbers = oddCount + evenCount

    return NextResponse.json({
      success: true,
      data: {
        totalDraws,
        lastUpdate: lastDraw?.drawDate,
        topFrequent,
        leastFrequent,
        oddEvenRatio: {
          odd: ((oddCount / totalNumbers) * 100).toFixed(1),
          even: ((evenCount / totalNumbers) * 100).toFixed(1),
        },
      },
    })
  } catch (error) {
    console.error('대시보드 통계 오류:', error)
    return NextResponse.json(
      { success: false, error: '통계 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}
```

---

## 9. 프론트엔드 구현 계획

### 9.1 메인 페이지 (번호 생성)

**파일**: `src/app/page.tsx`

```typescript
import NumberGenerator from '@/components/lotto/NumberGenerator'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'LottoMaster - 로또 번호 추천',
  description: '데이터 기반 로또 번호 추천 서비스',
}

export default function Home() {
  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-center mb-8">
        🎰 로또 번호 추천
      </h1>

      <NumberGenerator />
    </main>
  )
}
```

### 9.2 주요 컴포넌트

#### A. NumberGenerator (번호 생성기)

**파일**: `src/components/lotto/NumberGenerator.tsx`

```typescript
'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Select } from '@/components/ui/select'
import NumberDisplay from './NumberDisplay'

export default function NumberGenerator() {
  const [algorithm, setAlgorithm] = useState('random')
  const [numbers, setNumbers] = useState<number[][]>([])
  const [loading, setLoading] = useState(false)

  const handleGenerate = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/lotto/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ algorithm, count: 5 }),
      })

      const data = await res.json()
      if (data.success) {
        setNumbers(data.data.numbers)
      }
    } catch (error) {
      console.error('생성 오류:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* 알고리즘 선택 */}
      <div className="mb-4">
        <Select value={algorithm} onChange={setAlgorithm}>
          <option value="random">완전 랜덤</option>
          <option value="frequency">빈도 기반</option>
          <option value="pattern">패턴 기반</option>
        </Select>
      </div>

      {/* 생성 버튼 */}
      <Button onClick={handleGenerate} disabled={loading}>
        {loading ? '생성 중...' : '번호 생성'}
      </Button>

      {/* 생성된 번호 표시 */}
      {numbers.length > 0 && (
        <div className="mt-8 space-y-4">
          {numbers.map((set, i) => (
            <NumberDisplay key={i} numbers={set} />
          ))}
        </div>
      )}
    </div>
  )
}
```

---

## 10. 단계별 구현 체크리스트

### Phase 1: 프로젝트 세팅 (예상 2시간)

- [ ] Next.js 프로젝트 생성
  ```bash
  cd /home/deploy/projects
  npx create-next-app@latest lotto-master --typescript --tailwind --app
  ```

- [ ] 의존성 설치
  ```bash
  cd lotto-master
  npm install prisma @prisma/client
  npm install recharts date-fns
  npm install -D @types/node
  ```

- [ ] Prisma 초기화 및 스키마 작성
  ```bash
  npx prisma init
  # schema.prisma 작성
  ```

- [ ] Dockerfile.prod 작성

- [ ] .env 파일 설정
  ```bash
  DATABASE_URL="postgresql://appuser:your_password@postgres:5432/maindb"
  REDIS_URL="redis://redis:6379"
  ```

### Phase 2: Docker 통합 (예상 1시간)

- [ ] docker-compose.yml에 lotto-service 추가

- [ ] Nginx 설정 업데이트 (port-based.conf)

- [ ] 컨테이너 빌드 및 시작
  ```bash
  cd /home/deploy
  docker compose build lotto-service
  docker compose up -d lotto-service
  ```

- [ ] 헬스체크 확인
  ```bash
  docker compose ps
  curl http://203.245.30.6:3001
  ```

### Phase 3: 데이터베이스 마이그레이션 (예상 30분)

- [ ] Prisma 마이그레이션 실행
  ```bash
  docker exec lotto-service npx prisma migrate dev --name init
  ```

- [ ] Seed 데이터 실행
  ```bash
  docker exec lotto-service npx prisma db seed
  ```

- [ ] 데이터 확인
  ```bash
  docker exec postgres psql -U appuser -d maindb -c "SELECT * FROM number_statistics LIMIT 10;"
  ```

### Phase 4: API 개발 (예상 4-6시간)

- [ ] 번호 생성 API (`/api/lotto/generate`)
- [ ] 통계 API (`/api/stats/dashboard`)
- [ ] 당첨번호 조회 API (`/api/lotto/history`)
- [ ] 헬스체크 API (`/api/health`)

### Phase 5: 프론트엔드 개발 (예상 6-8시간)

- [ ] shadcn/ui 설치 및 설정
  ```bash
  npx shadcn-ui@latest init
  npx shadcn-ui@latest add button card table
  ```

- [ ] 메인 페이지 (번호 생성)
- [ ] 통계 페이지
- [ ] 번호 표시 컴포넌트
- [ ] 차트 컴포넌트 (Recharts)

### Phase 6: 알고리즘 구현 (예상 3-4시간)

- [ ] 완전 랜덤 알고리즘
- [ ] 빈도 기반 알고리즘
- [ ] 패턴 기반 알고리즘

### Phase 7: 테스트 및 최적화 (예상 2-3시간)

- [ ] API 응답 시간 측정
- [ ] 메모리 사용량 모니터링
  ```bash
  docker stats lotto-service
  ```

- [ ] 캐싱 동작 확인 (Redis)
- [ ] Lighthouse 성능 점수 확인

### Phase 8: 문서화 및 배포 (예상 1-2시간)

- [ ] README.md 작성
- [ ] API 문서 작성
- [ ] 운영 가이드 업데이트
- [ ] 백업 스크립트 업데이트

---

## 11. 운영 가이드

### 11.1 배포 명령어

```bash
# 프로젝트 루트로 이동
cd /home/deploy

# 백업 실행
./scripts/backup.sh

# 이미지 빌드
docker compose build lotto-service

# 컨테이너 시작 (무중단)
docker compose up -d lotto-service

# 상태 확인
docker compose ps
docker compose logs -f lotto-service
```

### 11.2 모니터링

```bash
# 리소스 사용량
docker stats lotto-service

# 로그 확인
docker compose logs --tail=100 lotto-service

# 헬스체크
curl http://203.245.30.6:3001/api/health
```

### 11.3 데이터베이스 관리

```bash
# Prisma Studio (개발용)
docker exec -it lotto-service npx prisma studio

# 마이그레이션 확인
docker exec lotto-service npx prisma migrate status

# 데이터 백업
docker exec postgres pg_dump -U appuser maindb > lotto-backup.sql
```

### 11.4 트러블슈팅

#### 컨테이너 시작 실패
```bash
# 로그 확인
docker compose logs lotto-service

# 강제 재시작
docker compose restart lotto-service

# 완전 재빌드
docker compose down
docker compose build --no-cache lotto-service
docker compose up -d
```

#### 메모리 부족
```bash
# 메모리 사용량 확인
docker stats

# 캐시 정리
docker system prune -a

# 컨테이너 메모리 제한 조정 (docker-compose.yml 수정)
```

---

## 12. 향후 확장 계획

### 12.1 단기 (1-2개월)
- [ ] 당첨번호 자동 크롤링 스크립트
- [ ] 번호 저장 기능 (로컬스토리지)
- [ ] 당첨 확인 시뮬레이터
- [ ] 통계 차트 고도화

### 12.2 중기 (3-6개월)
- [ ] 사용자 인증 (NextAuth.js)
- [ ] 실시간 당첨 알림 (WebSocket)
- [ ] 모바일 반응형 최적화
- [ ] PWA 지원

### 12.3 장기 (6개월+)
- [ ] AI 기반 번호 예측 (TensorFlow.js)
- [ ] 커뮤니티 기능
- [ ] 프리미엄 구독 모델
- [ ] 다른 복권 게임 추가

---

## 부록

### A. 환경 변수 예제

**파일**: `/home/deploy/projects/lotto-master/.env`

```bash
# Database
DATABASE_URL="postgresql://appuser:secure_password@postgres:5432/maindb"

# Redis
REDIS_URL="redis://redis:6379"

# App
NEXT_PUBLIC_APP_URL="http://203.245.30.6:3001"
NODE_ENV="production"

# Optional: 동행복권 크롤링
DHLOTTERY_API_URL="https://www.dhlottery.co.kr/common.do?method=getLottoNumber"
```

### B. package.json 스크립트

```json
{
  "scripts": {
    "dev": "next dev",
    "build": "prisma generate && next build",
    "start": "next start",
    "lint": "next lint",
    "prisma:generate": "prisma generate",
    "prisma:migrate": "prisma migrate deploy",
    "prisma:seed": "prisma db seed"
  },
  "prisma": {
    "seed": "ts-node --compiler-options {\"module\":\"CommonJS\"} prisma/seed.ts"
  }
}
```

### C. 유용한 명령어

```bash
# 전체 시스템 상태
cd /home/deploy && ./scripts/monitor.sh

# 로또 서비스만 재시작
docker compose restart lotto-service

# 데이터베이스 접속
docker exec -it postgres psql -U appuser -d maindb

# Redis 접속
docker exec -it redis redis-cli

# 로그 실시간 보기
docker compose logs -f lotto-service

# 디스크 사용량
df -h
docker system df
```

---

**문서 버전**: 1.0
**최종 수정**: 2025-10-16
**작성자**: AI Assistant
**상태**: 설계 완료, 구현 준비

**총 예상 소요 시간**: 20-25시간
**필요 리소스**: 메모리 +256MB, 디스크 +270MB
**기술 스택**: Next.js 14.2, Prisma, PostgreSQL, Redis, Docker
