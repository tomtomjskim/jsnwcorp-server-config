export interface DrawResult {
  drawNo: number
  drawDate: string
  numbers: number[]
  bonusNum: number
  firstWinAmount: number | null
  firstWinCount: number | null
}

export interface LottoData {
  meta: {
    lastUpdate: string
    totalDraws: number
    source: string
  }
  draws: DrawResult[]
}

export interface NumberStat {
  number: number
  totalCount: number
  bonusCount: number
  lastDrawNo: number | null
  lastDrawDate: string | null
}

export type Algorithm =
  | 'random'
  | 'frequency'
  | 'pattern'
  | 'frequency-db'
  | 'low-frequency-db'
  | 'recent-db'
  | 'cold-db'
  | 'balanced-db'
  | 'ai-mixed-db'

export interface GenerateRequest {
  algorithm: Algorithm
  count: number
}

export interface GenerateResponse {
  success: boolean
  data?: {
    numbers: number[][]
    algorithm: Algorithm
    generatedAt: string
  }
  error?: string
}
