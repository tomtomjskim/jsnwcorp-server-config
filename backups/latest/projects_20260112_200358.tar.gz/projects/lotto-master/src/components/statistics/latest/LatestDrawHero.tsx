/**
 * Latest Draw Hero Component
 *
 * Displays the latest draw information with headline insights.
 *
 * Features:
 * - Draw number and date
 * - Winning numbers with visual balls
 * - Bonus number
 * - Rarity grade badge
 * - Key headline insight
 *
 * @author Claude Code
 * @version 1.0.0
 */

'use client';

import type { DrawInfo, RarityAnalysis, InsightGroup } from '@/lib/analysis/latestDrawAnalysis';

interface LatestDrawHeroProps {
  drawInfo: DrawInfo;
  rarity: RarityAnalysis;
  insights: InsightGroup[];
}

export default function LatestDrawHero({ drawInfo, rarity, insights }: LatestDrawHeroProps) {
  // Get rarity color based on grade
  const getRarityColor = (grade: string): string => {
    switch (grade) {
      case '극히 희귀': return 'from-purple-600 to-pink-600';
      case '희귀': return 'from-violet-600 to-purple-600';
      case '특이함': return 'from-blue-600 to-indigo-600';
      case '평범': return 'from-gray-500 to-gray-600';
      case '매우 평범': return 'from-gray-400 to-gray-500';
      default: return 'from-blue-600 to-indigo-600';
    }
  };

  // Get number color (1-10: yellow, 11-20: blue, 21-30: red, 31-40: gray, 41-45: green)
  const getNumberColor = (num: number): string => {
    if (num <= 10) return 'bg-gradient-to-br from-yellow-400 to-yellow-500 text-white';
    if (num <= 20) return 'bg-gradient-to-br from-blue-500 to-blue-600 text-white';
    if (num <= 30) return 'bg-gradient-to-br from-red-500 to-red-600 text-white';
    if (num <= 40) return 'bg-gradient-to-br from-gray-500 to-gray-600 text-white';
    return 'bg-gradient-to-br from-green-500 to-green-600 text-white';
  };

  // Find headline insight
  const headlineInsight = insights
    .flatMap(group => group.insights)
    .find(insight => insight.priority === 'high');

  return (
    <div className="bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 rounded-2xl shadow-2xl p-8 mb-8 text-white">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-3xl font-bold mb-1">
              제 {drawInfo.drawNo}회 추첨
            </h2>
            <p className="text-indigo-100">
              {new Date(drawInfo.drawDate).toLocaleDateString('ko-KR', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                weekday: 'long'
              })}
            </p>
          </div>

          {/* Rarity badge */}
          <div className={`px-6 py-3 rounded-xl bg-gradient-to-r ${getRarityColor(rarity.grade)} shadow-lg`}>
            <div className="text-xs font-semibold text-white/80 mb-1">희귀도</div>
            <div className="text-2xl font-bold">{rarity.grade}</div>
            <div className="text-xs text-white/80">{rarity.score}점</div>
          </div>
        </div>

        {/* Winning numbers */}
        <div className="mb-6">
          <div className="flex items-center justify-center gap-3 mb-4">
            {drawInfo.numbers.map((num, index) => (
              <div
                key={index}
                className={`w-16 h-16 rounded-full ${getNumberColor(num)} shadow-lg flex items-center justify-center text-2xl font-bold transform hover:scale-110 transition-transform`}
              >
                {num}
              </div>
            ))}

            {/* Plus sign */}
            <div className="text-3xl font-bold text-white/60 mx-2">+</div>

            {/* Bonus number */}
            <div className="relative">
              <div
                className={`w-16 h-16 rounded-full ${getNumberColor(drawInfo.bonusNumber)} shadow-lg flex items-center justify-center text-2xl font-bold transform hover:scale-110 transition-transform`}
              >
                {drawInfo.bonusNumber}
              </div>
              <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs text-white/80 whitespace-nowrap">
                보너스
              </div>
            </div>
          </div>
        </div>

        {/* Headline insight */}
        {headlineInsight && (
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
            <div className="flex items-start gap-3">
              <div className="text-2xl">💡</div>
              <div className="flex-1">
                <div className="text-sm font-semibold text-white/80 mb-1">
                  {headlineInsight.category}
                </div>
                <p className="text-lg font-medium leading-relaxed">
                  {headlineInsight.message}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
