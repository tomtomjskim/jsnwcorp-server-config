/**
 * Refresh Button Component
 *
 * Client-side button for page refresh functionality.
 *
 * @author Claude Code
 * @version 1.0.0
 */

'use client';

export default function RefreshButton() {
  return (
    <button
      onClick={() => window.location.reload()}
      className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
    >
      새로고침
    </button>
  );
}
