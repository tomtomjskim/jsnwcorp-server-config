/**
 * Rarity Section Component
 *
 * Displays rarity analysis with score breakdown.
 *
 * Shows:
 * - Rarity score (0-100)
 * - Grade classification
 * - Rank and percentile
 * - Scoring factors breakdown
 *
 * @author Claude Code
 * @version 1.0.0
 */

'use client';

import type { RarityAnalysis, DrawInfo } from '@/lib/analysis/latestDrawAnalysis';

interface RaritySectionProps {
  rarity: RarityAnalysis;
  drawInfo: DrawInfo;
}

export default function RaritySection({ rarity, drawInfo }: RaritySectionProps) {
  // Get grade color
  const getGradeColor = (grade: string): { bg: string; text: string; border: string } => {
    switch (grade) {
      case '극히 희귀':
        return { bg: 'from-purple-600 to-pink-600', text: 'text-purple-600', border: 'border-purple-300' };
      case '희귀':
        return { bg: 'from-violet-600 to-purple-600', text: 'text-violet-600', border: 'border-violet-300' };
      case '특이함':
        return { bg: 'from-blue-600 to-indigo-600', text: 'text-blue-600', border: 'border-blue-300' };
      case '평범':
        return { bg: 'from-gray-500 to-gray-600', text: 'text-gray-600', border: 'border-gray-300' };
      case '매우 평범':
        return { bg: 'from-gray-400 to-gray-500', text: 'text-gray-500', border: 'border-gray-300' };
      default:
        return { bg: 'from-blue-600 to-indigo-600', text: 'text-blue-600', border: 'border-blue-300' };
    }
  };

  const colors = getGradeColor(rarity.grade);

  // Calculate score percentage for visual gauge
  const scorePercentage = rarity.score;

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
        <span>💎</span>
        희귀도 분석
      </h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Score Display */}
        <div className="lg:col-span-1">
          <div className={`bg-gradient-to-br ${colors.bg} rounded-2xl p-8 text-white shadow-xl`}>
            <div className="text-center">
              <div className="text-sm font-semibold text-white/80 mb-2">희귀도 점수</div>
              <div className="text-6xl font-bold mb-2">{rarity.score}</div>
              <div className="text-sm text-white/80 mb-6">/ 100</div>

              <div className="mb-4">
                <div className="text-2xl font-bold mb-1">{rarity.grade}</div>
                <div className="text-sm text-white/80">등급</div>
              </div>

              <div className="pt-4 border-t border-white/20">
                <div className="text-sm text-white/80 mb-1">전체 순위</div>
                <div className="text-xl font-bold">
                  {rarity.rank}위 / {rarity.totalDraws}회
                </div>
                <div className="text-xs text-white/80 mt-2">
                  상위 {rarity.percentile.toFixed(1)}%
                </div>
              </div>
            </div>
          </div>

          {/* Score gauge */}
          <div className="mt-4">
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div
                className={`bg-gradient-to-r ${colors.bg} h-4 rounded-full transition-all`}
                style={{ width: `${scorePercentage}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>매우 평범</span>
              <span>극히 희귀</span>
            </div>
          </div>
        </div>

        {/* Right: Factors Breakdown */}
        <div className="lg:col-span-2">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">점수 산출 요인</h3>

          <div className="space-y-3">
            {rarity.factors.map((factor, index) => {
              const isPositive = factor.impact > 0;
              const isNegative = factor.impact < 0;

              return (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 ${
                    isPositive
                      ? 'bg-green-50 border-green-200'
                      : isNegative
                      ? 'bg-red-50 border-red-200'
                      : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="font-semibold text-gray-900 mb-1">
                        {factor.factor}
                      </div>
                      <p className="text-sm text-gray-600">
                        {factor.reason}
                      </p>
                    </div>
                    <div className={`ml-4 px-3 py-1 rounded-full font-bold text-sm ${
                      isPositive
                        ? 'bg-green-200 text-green-800'
                        : isNegative
                        ? 'bg-red-200 text-red-800'
                        : 'bg-gray-200 text-gray-800'
                    }`}>
                      {isPositive ? '+' : ''}{factor.impact}
                    </div>
                  </div>

                  {/* Impact bar */}
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        isPositive
                          ? 'bg-gradient-to-r from-green-400 to-green-600'
                          : isNegative
                          ? 'bg-gradient-to-r from-red-400 to-red-600'
                          : 'bg-gray-400'
                      }`}
                      style={{
                        width: `${Math.abs(factor.impact) * 5}%`,
                        marginLeft: isNegative ? `${50 - Math.abs(factor.impact) * 2.5}%` : '50%'
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Message */}
      <div className="mt-6 p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
        <div className="flex items-start gap-2">
          <span className="text-lg">📝</span>
          <div className="flex-1">
            <p className="text-sm text-indigo-900">
              {rarity.message}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
