/**
 * Frequency Section Component
 *
 * Displays frequency analysis of numbers.
 *
 * Categories:
 * - Very Hot (상위 10%)
 * - Hot (상위 11-30%)
 * - Normal (중간 31-70%)
 * - Cold (하위 71-90%)
 * - Very Cold (하위 91-100%)
 *
 * @author Claude Code
 * @version 1.0.0
 */

'use client';

import type { FrequencyAnalysis } from '@/lib/analysis/latestDrawAnalysis';

interface FrequencySectionProps {
  frequency: FrequencyAnalysis;
  numbers: number[];
}

export default function FrequencySection({ frequency, numbers }: FrequencySectionProps) {
  // Get frequency category color
  const getCategoryColor = (category: string): string => {
    switch (category) {
      case '매우 높음': return 'from-red-600 to-orange-600';
      case '높음': return 'from-orange-500 to-yellow-500';
      case '보통': return 'from-gray-400 to-gray-500';
      case '낮음': return 'from-blue-400 to-blue-500';
      case '매우 낮음': return 'from-blue-600 to-indigo-600';
      default: return 'from-gray-400 to-gray-500';
    }
  };

  // Get category badge color
  const getCategoryBadgeColor = (category: string): string => {
    switch (category) {
      case '매우 높음': return 'bg-red-100 text-red-800 border-red-300';
      case '높음': return 'bg-orange-100 text-orange-800 border-orange-300';
      case '보통': return 'bg-gray-100 text-gray-800 border-gray-300';
      case '낮음': return 'bg-blue-100 text-blue-800 border-blue-300';
      case '매우 낮음': return 'bg-indigo-100 text-indigo-800 border-indigo-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  // Get category icon
  const getCategoryIcon = (category: string): string => {
    switch (category) {
      case '매우 높음': return '🔥';
      case '높음': return '♨️';
      case '보통': return '➖';
      case '낮음': return '❄️';
      case '매우 낮음': return '🧊';
      default: return '➖';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
        <span>📊</span>
        빈도 분석
      </h2>

      {/* Summary */}
      <div className="mb-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
        <p className="text-sm text-gray-700">
          {frequency.summary}
        </p>
      </div>

      {/* Numbers with frequency data */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        {frequency.numbers.map((item, index) => (
          <div
            key={index}
            className="relative bg-white border-2 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow"
            style={{ borderColor: item.category === '매우 높음' ? '#dc2626' : item.category === '높음' ? '#f59e0b' : item.category === '보통' ? '#9ca3af' : item.category === '낮음' ? '#3b82f6' : '#4f46e5' }}
          >
            {/* Number */}
            <div className={`w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br ${getCategoryColor(item.category)} flex items-center justify-center text-white text-xl font-bold shadow-lg`}>
              {item.number}
            </div>

            {/* Frequency */}
            <div className="text-center mb-2">
              <div className="text-2xl font-bold text-gray-900">{item.frequency}</div>
              <div className="text-xs text-gray-500">회 출현</div>
            </div>

            {/* Rank */}
            <div className="text-center text-xs text-gray-600 mb-2">
              {item.rank}위 / 45개
            </div>

            {/* Category badge */}
            <div className={`text-center text-xs font-semibold px-2 py-1 rounded-full border ${getCategoryBadgeColor(item.category)}`}>
              {getCategoryIcon(item.category)} {item.category}
            </div>
          </div>
        ))}
      </div>

      {/* Category Distribution */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">카테고리별 분포</h3>

        <div className="space-y-3">
          {Object.entries(frequency.categoryCounts).map(([category, count], index) => {
            const percentage = (count / 6) * 100;

            return (
              <div key={index}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600 flex items-center gap-2">
                    <span>{getCategoryIcon(category)}</span>
                    {category}
                  </span>
                  <span className="text-sm font-semibold text-gray-900">
                    {count}개 ({percentage.toFixed(1)}%)
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`bg-gradient-to-r ${getCategoryColor(category)} h-2 rounded-full transition-all`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Insights */}
      <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
        <div className="flex items-start gap-2">
          <span className="text-lg">💡</span>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-yellow-900 mb-1">빈도 분석 인사이트</h4>
            <p className="text-sm text-yellow-800">
              {frequency.categoryCounts['매우 높음'] > 0 && '매우 높은 빈도의 번호가 포함되어 있습니다. '}
              {frequency.categoryCounts['매우 낮음'] > 0 && '매우 낮은 빈도의 번호가 포함되어 있습니다. '}
              {frequency.categoryCounts['매우 높음'] === 0 && frequency.categoryCounts['매우 낮음'] === 0 && '극단적인 빈도의 번호는 없습니다. '}
              전체적으로 {frequency.categoryCounts['보통'] >= 3 ? '균형잡힌' : frequency.categoryCounts['매우 높음'] + frequency.categoryCounts['높음'] > frequency.categoryCounts['낮음'] + frequency.categoryCounts['매우 낮음'] ? '높은 빈도 위주의' : '낮은 빈도 위주의'} 조합입니다.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
