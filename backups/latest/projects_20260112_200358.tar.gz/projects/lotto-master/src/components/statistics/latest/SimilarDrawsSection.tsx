/**
 * Similar Draws Section Component
 *
 * Displays historically similar draws.
 *
 * Shows TOP 5 similar draws with:
 * - Draw number and date
 * - Similarity score
 * - Matching numbers
 * - Statistical similarities
 *
 * @author Claude Code
 * @version 1.0.0
 */

'use client';

import type { SimilarDraw, DrawInfo } from '@/lib/analysis/latestDrawAnalysis';

interface SimilarDrawsSectionProps {
  similarDraws: SimilarDraw[];
  currentDraw: DrawInfo;
}

export default function SimilarDrawsSection({ similarDraws, currentDraw }: SimilarDrawsSectionProps) {
  // Get number color
  const getNumberColor = (num: number): string => {
    if (num <= 10) return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    if (num <= 20) return 'bg-blue-100 text-blue-800 border-blue-300';
    if (num <= 30) return 'bg-red-100 text-red-800 border-red-300';
    if (num <= 40) return 'bg-gray-100 text-gray-800 border-gray-300';
    return 'bg-green-100 text-green-800 border-green-300';
  };

  // Get similarity color based on score
  const getSimilarityColor = (score: number): string => {
    if (score >= 90) return 'from-purple-600 to-pink-600';
    if (score >= 80) return 'from-blue-600 to-indigo-600';
    if (score >= 70) return 'from-green-600 to-teal-600';
    if (score >= 60) return 'from-yellow-600 to-orange-600';
    return 'from-gray-600 to-gray-700';
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
        <span>🔍</span>
        유사한 회차
      </h2>

      <p className="text-gray-600 mb-6">
        현재 회차와 통계적으로 가장 유사한 과거 추첨 결과 TOP 5입니다.
      </p>

      <div className="space-y-6">
        {similarDraws.map((draw, index) => (
          <div
            key={index}
            className="border-2 border-gray-200 rounded-xl p-6 hover:border-blue-300 hover:shadow-md transition-all"
          >
            <div className="flex items-start justify-between mb-4">
              {/* Rank badge */}
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${getSimilarityColor(draw.similarityScore)} flex items-center justify-center text-white font-bold text-lg shadow-lg`}>
                  {index + 1}
                </div>
                <div>
                  <div className="text-lg font-bold text-gray-900">
                    제 {draw.drawNo}회
                  </div>
                  <div className="text-sm text-gray-600">
                    {new Date(draw.drawDate).toLocaleDateString('ko-KR')}
                  </div>
                </div>
              </div>

              {/* Similarity score */}
              <div className="text-right">
                <div className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  {draw.similarityScore.toFixed(1)}
                </div>
                <div className="text-xs text-gray-500">유사도</div>
              </div>
            </div>

            {/* Numbers */}
            <div className="mb-4">
              <div className="text-xs text-gray-500 mb-2">추첨 번호</div>
              <div className="flex flex-wrap gap-2">
                {draw.numbers.map((num, numIndex) => {
                  const isMatching = currentDraw.numbers.includes(num);
                  return (
                    <div
                      key={numIndex}
                      className={`w-10 h-10 rounded-lg border-2 ${
                        isMatching
                          ? 'border-blue-500 ' + getNumberColor(num)
                          : getNumberColor(num)
                      } flex items-center justify-center font-bold text-sm ${
                        isMatching ? 'ring-2 ring-blue-300 ring-offset-1' : ''
                      }`}
                    >
                      {num}
                    </div>
                  );
                })}
              </div>
              {draw.matchingNumbers > 0 && (
                <div className="text-xs text-blue-600 font-semibold mt-2">
                  {draw.matchingNumbers}개 번호 일치
                </div>
              )}
            </div>

            {/* Similarity reasons */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {draw.reasons.map((reason, reasonIndex) => (
                <div
                  key={reasonIndex}
                  className="bg-gray-50 rounded-lg p-3 text-center"
                >
                  <div className="text-xs text-gray-600 mb-1">
                    {reason.aspect}
                  </div>
                  <div className="text-sm font-semibold text-gray-900">
                    {reason.value}
                  </div>
                  <div className="text-xs text-gray-500">
                    유사도 {reason.similarity.toFixed(0)}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Note */}
      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start gap-2">
          <span className="text-lg">ℹ️</span>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-blue-900 mb-1">유사도 계산 방식</h4>
            <p className="text-sm text-blue-800">
              평균값, 홀짝비율, 고저비율, 연속번호, 등차수열 등 여러 통계적 요소를 종합하여 유사도를 계산합니다.
              유사도가 높다고 해서 향후 결과를 예측할 수 있는 것은 아니며, 과거 패턴 분석을 위한 참고 자료입니다.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
