/**
 * Pattern Section Component
 *
 * Displays pattern analysis results.
 *
 * Patterns:
 * - Consecutive numbers
 * - Arithmetic sequence
 * - Previous draw repetition
 *
 * @author Claude Code
 * @version 1.0.0
 */

'use client';

import type { PatternAnalysis, DrawInfo } from '@/lib/analysis/latestDrawAnalysis';

interface PatternSectionProps {
  patterns: PatternAnalysis;
  drawInfo: DrawInfo;
}

export default function PatternSection({ patterns, drawInfo }: PatternSectionProps) {
  // Get number color
  const getNumberColor = (num: number): string => {
    if (num <= 10) return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    if (num <= 20) return 'bg-blue-100 text-blue-800 border-blue-300';
    if (num <= 30) return 'bg-red-100 text-red-800 border-red-300';
    if (num <= 40) return 'bg-gray-100 text-gray-800 border-gray-300';
    return 'bg-green-100 text-green-800 border-green-300';
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
        <span>🔗</span>
        패턴 분석
      </h2>

      <div className="space-y-6">
        {/* Consecutive Numbers */}
        <div className="border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">연속 번호</h3>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${
              patterns.consecutive.count > 0
                ? 'bg-green-100 text-green-800'
                : 'bg-gray-100 text-gray-600'
            }`}>
              {patterns.consecutive.count}개
            </div>
          </div>

          {patterns.consecutive.count > 0 ? (
            <div>
              <p className="text-sm text-gray-600 mb-3">{patterns.consecutive.description}</p>
              <div className="flex flex-wrap gap-2">
                {patterns.consecutive.sequences.map((seq, index) => (
                  <div key={index} className="flex items-center gap-1">
                    {seq.map((num, numIndex) => (
                      <div
                        key={numIndex}
                        className={`w-10 h-10 rounded-lg border-2 ${getNumberColor(num)} flex items-center justify-center font-bold text-sm`}
                      >
                        {num}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-sm text-gray-500">{patterns.consecutive.description}</p>
          )}
        </div>

        {/* Arithmetic Sequence */}
        <div className="border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">등차수열</h3>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${
              patterns.arithmeticSequence.found
                ? 'bg-purple-100 text-purple-800'
                : 'bg-gray-100 text-gray-600'
            }`}>
              {patterns.arithmeticSequence.found ? '발견됨' : '없음'}
            </div>
          </div>

          <div className="space-y-3">
            {patterns.arithmeticSequence.found && (
              <div className="flex flex-wrap gap-2 mb-3">
                {patterns.arithmeticSequence.sequences.map((seq, index) => (
                  <div key={index} className="flex items-center gap-1">
                    {seq.numbers.map((num, numIndex) => (
                      <div
                        key={numIndex}
                        className={`w-10 h-10 rounded-lg border-2 ${getNumberColor(num)} flex items-center justify-center font-bold text-sm`}
                      >
                        {num}
                      </div>
                    ))}
                    <div className="text-xs text-gray-500 ml-2">
                      (공차: {seq.difference})
                    </div>
                  </div>
                ))}
              </div>
            )}
            <p className="text-sm text-gray-600">{patterns.arithmeticSequence.description}</p>
          </div>
        </div>

        {/* Previous Draw Repetition */}
        <div className="border border-gray-200 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">이전 회차 반복</h3>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${
              patterns.repeatedFromPrev.count > 0
                ? 'bg-orange-100 text-orange-800'
                : 'bg-gray-100 text-gray-600'
            }`}>
              {patterns.repeatedFromPrev.count}개
            </div>
          </div>

          {patterns.repeatedFromPrev.count > 0 ? (
            <div>
              <p className="text-sm text-gray-600 mb-3">{patterns.repeatedFromPrev.description}</p>

              {/* Repeated numbers */}
              <div className="mb-4">
                <div className="text-xs text-gray-500 mb-2">반복된 번호:</div>
                <div className="flex flex-wrap gap-2">
                  {patterns.repeatedFromPrev.repeatedNumbers.map((num, index) => (
                    <div
                      key={index}
                      className={`w-10 h-10 rounded-lg border-2 ${getNumberColor(num)} flex items-center justify-center font-bold text-sm`}
                    >
                      {num}
                    </div>
                  ))}
                </div>
              </div>

              {/* Previous draw info */}
              {patterns.repeatedFromPrev.previousDraw && (
                <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                  <div className="text-xs text-gray-500 mb-2">
                    이전 회차 (제 {patterns.repeatedFromPrev.previousDraw.drawNo}회)
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {patterns.repeatedFromPrev.previousDraw.numbers.map((num, index) => (
                      <div
                        key={index}
                        className={`w-8 h-8 rounded ${
                          patterns.repeatedFromPrev.repeatedNumbers.includes(num)
                            ? getNumberColor(num) + ' border-2'
                            : 'bg-gray-100 text-gray-400'
                        } flex items-center justify-center text-xs font-semibold`}
                      >
                        {num}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <p className="text-sm text-gray-500">{patterns.repeatedFromPrev.description}</p>
          )}
        </div>
      </div>
    </div>
  );
}
