/**
 * Distribution Section Component
 *
 * Visualizes number distribution analysis.
 *
 * Displays:
 * - Odd/Even ratio with bar chart
 * - High/Low distribution with bar chart
 * - Range segments (1-9, 10-19, 20-29, 30-39, 40-45)
 * - Comparison with historical average
 *
 * @author Claude Code
 * @version 1.0.0
 */

'use client';

import type { DistributionAnalysis, ComparisonAnalysis } from '@/lib/analysis/latestDrawAnalysis';

interface DistributionSectionProps {
  distribution: DistributionAnalysis;
  comparison: ComparisonAnalysis;
}

export default function DistributionSection({ distribution, comparison }: DistributionSectionProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
        <span>📈</span>
        분포 분석
      </h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Odd/Even Distribution */}
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-4">홀짝 분포</h3>

          <div className="space-y-3">
            {/* Odd bar */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-gray-600">홀수</span>
                <span className="text-sm font-semibold text-gray-900">
                  {distribution.oddEven.odd}개 ({distribution.oddEven.oddPercentage.toFixed(1)}%)
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all"
                  style={{ width: `${distribution.oddEven.oddPercentage}%` }}
                />
              </div>
            </div>

            {/* Even bar */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-gray-600">짝수</span>
                <span className="text-sm font-semibold text-gray-900">
                  {distribution.oddEven.even}개 ({distribution.oddEven.evenPercentage.toFixed(1)}%)
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-purple-500 to-purple-600 h-3 rounded-full transition-all"
                  style={{ width: `${distribution.oddEven.evenPercentage}%` }}
                />
              </div>
            </div>
          </div>

          {/* Balance indicator */}
          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-600">
              균형도: <span className="font-semibold text-gray-900">{distribution.oddEven.balance}</span>
            </div>
          </div>
        </div>

        {/* High/Low Distribution */}
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-4">고저 분포</h3>

          <div className="space-y-3">
            {/* Low bar */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-gray-600">저번호 (1-22)</span>
                <span className="text-sm font-semibold text-gray-900">
                  {distribution.highLow.low}개 ({distribution.highLow.lowPercentage.toFixed(1)}%)
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-green-500 to-green-600 h-3 rounded-full transition-all"
                  style={{ width: `${distribution.highLow.lowPercentage}%` }}
                />
              </div>
            </div>

            {/* High bar */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-gray-600">고번호 (23-45)</span>
                <span className="text-sm font-semibold text-gray-900">
                  {distribution.highLow.high}개 ({distribution.highLow.highPercentage.toFixed(1)}%)
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-orange-500 to-orange-600 h-3 rounded-full transition-all"
                  style={{ width: `${distribution.highLow.highPercentage}%` }}
                />
              </div>
            </div>
          </div>

          {/* Balance indicator */}
          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-600">
              균형도: <span className="font-semibold text-gray-900">{distribution.highLow.balance}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Range Segments */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">구간별 분포</h3>

        <div className="grid grid-cols-5 gap-4">
          {distribution.ranges.map((range, index) => {
            const colors = [
              'from-yellow-400 to-yellow-500',
              'from-blue-500 to-blue-600',
              'from-red-500 to-red-600',
              'from-gray-500 to-gray-600',
              'from-green-500 to-green-600'
            ];

            return (
              <div
                key={index}
                className="bg-gray-50 rounded-lg p-4 text-center"
              >
                <div className="text-sm text-gray-600 mb-2">{range.range}</div>
                <div className={`text-3xl font-bold bg-gradient-to-r ${colors[index]} bg-clip-text text-transparent mb-2`}>
                  {range.count}
                </div>
                <div className="text-xs text-gray-500">
                  {range.percentage.toFixed(1)}%
                </div>
                {range.numbers.length > 0 && (
                  <div className="text-xs text-gray-400 mt-2">
                    [{range.numbers.join(', ')}]
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Historical Comparison */}
      <div className="mt-8 p-4 bg-indigo-50 rounded-lg border border-indigo-300">
        <h3 className="text-sm font-semibold text-indigo-900 mb-3">역대 평균과 비교</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <div className="text-xs text-indigo-800 mb-1 font-bold">홀짝 비율</div>
            <div className="text-sm text-gray-900">
              현재: <span className="font-bold text-gray-900">{distribution.oddEven.odd}:{distribution.oddEven.even}</span>
              {' / '}
              평균: <span className="font-bold text-gray-900">
                {comparison.distribution.historical.oddEven.odd.toFixed(1)}:
                {comparison.distribution.historical.oddEven.even.toFixed(1)}
              </span>
            </div>
          </div>

          <div>
            <div className="text-xs text-indigo-800 mb-1 font-bold">고저 비율</div>
            <div className="text-sm text-gray-900">
              현재: <span className="font-bold text-gray-900">{distribution.highLow.low}:{distribution.highLow.high}</span>
              {' / '}
              평균: <span className="font-bold text-gray-900">
                {comparison.distribution.historical.highLow.low.toFixed(1)}:
                {comparison.distribution.historical.highLow.high.toFixed(1)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
