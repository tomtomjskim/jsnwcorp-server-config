/**
 * Insights Section Component
 *
 * Displays AI-generated natural language insights.
 *
 * Groups insights by category:
 * - 기본 통계
 * - 분포 분석
 * - 패턴 분석
 * - 빈도 분석
 * - 희귀도 분석
 * - 유사 회차
 * - 역대 비교
 * - 전체 평가
 *
 * Priority levels: high, medium, low
 *
 * @author Claude Code
 * @version 1.0.0
 */

'use client';

import { useState } from 'react';
import type { InsightGroup } from '@/lib/analysis/latestDrawAnalysis';

interface InsightsSectionProps {
  insights: InsightGroup[];
}

export default function InsightsSection({ insights }: InsightsSectionProps) {
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(
    new Set(insights.map(g => g.category))
  );

  const toggleGroup = (category: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(category)) {
      newExpanded.delete(category);
    } else {
      newExpanded.add(category);
    }
    setExpandedGroups(newExpanded);
  };

  // Get category icon
  const getCategoryIcon = (category: string): string => {
    switch (category) {
      case '기본 통계': return '📊';
      case '분포 분석': return '📈';
      case '패턴 분석': return '🔗';
      case '빈도 분석': return '🔥';
      case '희귀도 분석': return '💎';
      case '유사 회차': return '🔍';
      case '역대 비교': return '⚖️';
      case '전체 평가': return '🎯';
      default: return '💡';
    }
  };

  // Get priority color
  const getPriorityColor = (priority: string): string => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  // Get priority label
  const getPriorityLabel = (priority: string): string => {
    switch (priority) {
      case 'high': return '중요';
      case 'medium': return '보통';
      case 'low': return '참고';
      default: return '';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
        <span>💡</span>
        AI 인사이트
      </h2>

      <p className="text-gray-600 mb-6">
        AI가 분석한 통계적 특징과 의미 있는 패턴을 자연어로 요약했습니다.
      </p>

      <div className="space-y-4">
        {insights.map((group, groupIndex) => {
          const isExpanded = expandedGroups.has(group.category);

          return (
            <div
              key={groupIndex}
              className="border-2 border-gray-200 rounded-xl overflow-hidden"
            >
              {/* Group header */}
              <button
                onClick={() => toggleGroup(group.category)}
                className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{getCategoryIcon(group.category)}</span>
                  <div className="text-left">
                    <div className="font-semibold text-gray-900">
                      {group.category}
                    </div>
                    <div className="text-sm text-gray-600">
                      {group.insights.length}개 인사이트
                    </div>
                  </div>
                </div>

                {/* Expand icon */}
                <svg
                  className={`w-5 h-5 text-gray-500 transition-transform ${
                    isExpanded ? 'transform rotate-180' : ''
                  }`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </button>

              {/* Group insights */}
              {isExpanded && (
                <div className="p-4 space-y-3">
                  {group.insights.map((insight, insightIndex) => (
                    <div
                      key={insightIndex}
                      className={`p-4 rounded-lg border-2 ${
                        insight.priority === 'high'
                          ? 'bg-red-50 border-red-200'
                          : insight.priority === 'medium'
                          ? 'bg-yellow-50 border-yellow-200'
                          : 'bg-blue-50 border-blue-200'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`text-xs font-semibold px-2 py-1 rounded-full border ${getPriorityColor(insight.priority)}`}>
                              {getPriorityLabel(insight.priority)}
                            </span>
                            <span className="text-sm text-gray-600">
                              {insight.category}
                            </span>
                          </div>
                          <p className="text-gray-900 leading-relaxed">
                            {insight.message}
                          </p>
                        </div>
                      </div>

                      {/* Supporting data */}
                      {insight.data && Object.keys(insight.data).length > 0 && (
                        <div className="mt-3 pt-3 border-t border-gray-200">
                          <div className="text-xs text-gray-500 mb-2">관련 데이터:</div>
                          <div className="flex flex-wrap gap-3">
                            {Object.entries(insight.data).map(([key, value], dataIndex) => (
                              <div
                                key={dataIndex}
                                className="bg-white rounded px-2 py-1 text-xs"
                              >
                                <span className="text-gray-600">{key}:</span>{' '}
                                <span className="font-semibold text-gray-900">
                                  {typeof value === 'number' ? value.toFixed(2) : value}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Disclaimer */}
      <div className="mt-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
        <div className="flex items-start gap-2">
          <span className="text-lg">⚠️</span>
          <div className="flex-1">
            <h4 className="text-sm font-semibold text-gray-900 mb-1">면책 조항</h4>
            <p className="text-sm text-gray-600">
              이 인사이트는 과거 데이터를 기반으로 한 통계적 분석 결과입니다.
              로또는 완전한 무작위 추첨이므로, 이 분석이 미래 추첨 결과를 예측하거나 당첨 확률을 높일 수 없습니다.
              오락적 목적으로만 참고하시기 바랍니다.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
