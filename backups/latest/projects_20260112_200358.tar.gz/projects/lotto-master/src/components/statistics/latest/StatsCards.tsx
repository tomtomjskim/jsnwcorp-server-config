/**
 * Stats Cards Component
 *
 * Displays quick overview metrics in card format.
 *
 * Cards:
 * 1. Average & Range
 * 2. Odd/Even Ratio
 * 3. Consecutive Count
 * 4. Rarity Score
 *
 * @author Claude Code
 * @version 1.0.0
 */

'use client';

import type { BasicStats, DistributionAnalysis, PatternAnalysis, RarityAnalysis } from '@/lib/analysis/latestDrawAnalysis';

interface StatsCardsProps {
  basicStats: BasicStats;
  distribution: DistributionAnalysis;
  patterns: PatternAnalysis;
  rarity: RarityAnalysis;
}

export default function StatsCards({ basicStats, distribution, patterns, rarity }: StatsCardsProps) {
  const cards = [
    {
      title: '평균 & 범위',
      icon: '📊',
      metrics: [
        { label: '평균', value: basicStats.average.toFixed(1), unit: '' },
        { label: '범위', value: basicStats.range.toString(), unit: '' },
        { label: '중앙값', value: basicStats.median.toFixed(1), unit: '' }
      ],
      color: 'from-blue-500 to-cyan-500'
    },
    {
      title: '홀짝 분포',
      icon: '⚖️',
      metrics: [
        { label: '홀수', value: distribution.oddEven.odd.toString(), unit: '개' },
        { label: '짝수', value: distribution.oddEven.even.toString(), unit: '개' },
        { label: '비율', value: `${distribution.oddEven.odd}:${distribution.oddEven.even}`, unit: '' }
      ],
      color: 'from-purple-500 to-pink-500'
    },
    {
      title: '패턴',
      icon: '🔗',
      metrics: [
        { label: '연속 번호', value: patterns.consecutive.count.toString(), unit: '개' },
        { label: '등차수열', value: patterns.arithmeticSequence.found ? 'O' : 'X', unit: '' },
        { label: '이전 회차', value: patterns.repeatedFromPrev.count.toString(), unit: '개' }
      ],
      color: 'from-orange-500 to-red-500'
    },
    {
      title: '희귀도',
      icon: '💎',
      metrics: [
        { label: '점수', value: rarity.score.toString(), unit: '점' },
        { label: '등급', value: rarity.grade, unit: '' },
        { label: '상위', value: rarity.percentile.toFixed(1), unit: '%' }
      ],
      color: 'from-emerald-500 to-teal-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => (
        <div
          key={index}
          className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow"
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">{card.title}</h3>
            <div className="text-3xl">{card.icon}</div>
          </div>

          {/* Metrics */}
          <div className="space-y-3">
            {card.metrics.map((metric, metricIndex) => (
              <div key={metricIndex} className="flex items-baseline justify-between">
                <span className="text-sm text-gray-600">{metric.label}</span>
                <div className={`text-xl font-bold bg-gradient-to-r ${card.color} bg-clip-text text-transparent`}>
                  {metric.value}
                  {metric.unit && <span className="text-sm ml-1">{metric.unit}</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
