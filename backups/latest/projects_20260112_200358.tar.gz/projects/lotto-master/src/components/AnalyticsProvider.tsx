'use client';

import { usePathname } from 'next/navigation';
import { useEffect } from 'react';
import { clientAnalytics } from '@/lib/analytics-client';

/**
 * Analytics Provider
 * - 자동 페이지뷰 추적
 * - pathname 변경 시 이벤트 전송
 */
export default function AnalyticsProvider({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  useEffect(() => {
    // 페이지뷰 추적
    clientAnalytics.trackPageView(pathname);
  }, [pathname]);

  return <>{children}</>;
}
