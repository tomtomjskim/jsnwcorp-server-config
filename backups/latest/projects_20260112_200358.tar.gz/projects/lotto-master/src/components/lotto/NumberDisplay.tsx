import { useState } from 'react'
import NumberBall from './NumberBall'
import { copyToClipboard } from '@/lib/utils'

interface NumberDisplayProps {
  numbers: number[]
  bonusNum?: number
  showCopy?: boolean
}

export default function NumberDisplay({
  numbers,
  bonusNum,
  showCopy = false,
}: NumberDisplayProps) {
  const [copySuccess, setCopySuccess] = useState(false)

  const handleCopy = async () => {
    const text = bonusNum
      ? `${numbers.join(', ')} + ${bonusNum}`
      : numbers.join(', ')

    const success = await copyToClipboard(text)
    if (success) {
      setCopySuccess(true)
      setTimeout(() => setCopySuccess(false), 2000)
    }
  }

  return (
    <div className="flex items-center gap-2 md:gap-3 flex-wrap">
      {numbers.map((num, i) => (
        <NumberBall key={i} number={num} />
      ))}
      {bonusNum && (
        <>
          <span className="text-xl md:text-2xl text-gray-400 mx-0.5 md:mx-1">+</span>
          <NumberBall number={bonusNum} isBonus />
        </>
      )}
      {showCopy && (
        <button
          onClick={handleCopy}
          className="ml-2 px-3 py-1 text-sm text-gray-700 hover:text-gray-900 hover:bg-gray-100 border border-gray-300 rounded transition-colors"
        >
          {copySuccess ? '✓ 복사됨' : '복사'}
        </button>
      )}
    </div>
  )
}
