interface NumberBallProps {
  number: number
  isBonus?: boolean
}

export default function NumberBall({ number, isBonus = false }: NumberBallProps) {
  const getColorClass = () => {
    if (isBonus) return 'bg-red-600'
    if (number <= 10) return 'bg-yellow-500'
    if (number <= 20) return 'bg-blue-500'
    if (number <= 30) return 'bg-red-500'
    if (number <= 40) return 'bg-gray-600'
    return 'bg-green-600'
  }

  return (
    <div
      className={`
        w-12 h-12 rounded-full flex items-center justify-center
        text-white font-bold text-lg shadow-lg
        ${getColorClass()}
      `}
    >
      {number}
    </div>
  )
}
