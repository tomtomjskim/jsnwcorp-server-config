'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Select } from '@/components/ui/select'
import { useToast } from '@/components/ui/toast'
import { ConfirmModal } from '@/components/ui/modal'
import NumberDisplay from './NumberDisplay'
import type { Algorithm } from '@/types/lotto'
import { saveMultipleNumberSets, getSavedNumbers, deleteNumberSet, type SavedNumberSet } from '@/lib/storage'
import { copyToClipboard } from '@/lib/utils'

export default function NumberGenerator() {
  const { showToast } = useToast()
  const [algorithm, setAlgorithm] = useState<Algorithm>('random')
  const [count, setCount] = useState<number>(5)
  const [customCount, setCustomCount] = useState<string>('')
  const [showCustomInput, setShowCustomInput] = useState(false)
  const [numbers, setNumbers] = useState<number[][]>([])
  const [loading, setLoading] = useState(false)
  const [savedNumbers, setSavedNumbers] = useState<SavedNumberSet[]>([])
  const [showSaved, setShowSaved] = useState(true)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  // Edit mode states
  const [editMode, setEditMode] = useState(false)
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [showDeleteModal, setShowDeleteModal] = useState(false)

  // Load saved preferences and numbers on mount
  useEffect(() => {
    loadSavedNumbers()
    const savedCount = localStorage.getItem('lotto_generate_count')
    if (savedCount) {
      setCount(parseInt(savedCount, 10))
    }
  }, [])

  const loadSavedNumbers = () => {
    const saved = getSavedNumbers()
    setSavedNumbers(saved)
  }

  const handleCountChange = (newCount: number) => {
    setCount(newCount)
    setShowCustomInput(false)
    setCustomCount('')
    localStorage.setItem('lotto_generate_count', newCount.toString())
  }

  const handleCustomCountSubmit = () => {
    const num = parseInt(customCount, 10)
    if (num >= 1 && num <= 100) {
      setCount(num)
      setShowCustomInput(false)
      localStorage.setItem('lotto_generate_count', num.toString())
      showToast(`${num}개로 설정되었습니다`)
    } else {
      showToast('1~100 사이의 숫자를 입력해주세요', 'error')
    }
  }

  const handleGenerate = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/lotto/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ algorithm, count }),
      })

      const data = await res.json()
      if (data.success) {
        setNumbers(data.data.numbers)

        // Save to localStorage
        try {
          saveMultipleNumberSets(data.data.numbers, algorithm)
          loadSavedNumbers() // Reload saved numbers
        } catch (saveError) {
          console.error('저장 오류:', saveError)
          // Continue even if save fails
        }
      } else {
        alert(data.error || '번호 생성 실패')
      }
    } catch (error) {
      console.error('생성 오류:', error)
      alert('번호 생성 중 오류가 발생했습니다.')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = (id: string) => {
    // Start fade out animation
    setDeletingId(id)

    // Delete after animation
    setTimeout(() => {
      deleteNumberSet(id)
      loadSavedNumbers()
      setDeletingId(null)
    }, 300)
  }

  const handleCopy = async (numbers: number[]) => {
    const text = numbers.join(', ')
    const success = await copyToClipboard(text)
    if (success) {
      showToast('번호가 복사되었습니다')
    } else {
      showToast('복사 실패', 'error')
    }
  }

  // Edit mode functions
  const toggleEditMode = () => {
    setEditMode(!editMode)
    setSelectedIds(new Set())
  }

  const toggleSelectAll = () => {
    if (selectedIds.size === savedNumbers.length) {
      setSelectedIds(new Set())
    } else {
      setSelectedIds(new Set(savedNumbers.map(n => n.id)))
    }
  }

  const toggleSelect = (id: string) => {
    const newSelected = new Set(selectedIds)
    if (newSelected.has(id)) {
      newSelected.delete(id)
    } else {
      newSelected.add(id)
    }
    setSelectedIds(newSelected)
  }

  const handleBulkCopy = async () => {
    const selectedNumbers = savedNumbers
      .filter(n => selectedIds.has(n.id))
      .map(n => n.numbers.join(', '))
      .join('\n')

    const success = await copyToClipboard(selectedNumbers)
    if (success) {
      showToast(`${selectedIds.size}개 번호가 복사되었습니다`)
    } else {
      showToast('복사 실패', 'error')
    }
  }

  const handleBulkDelete = () => {
    setShowDeleteModal(true)
  }

  const confirmBulkDelete = () => {
    selectedIds.forEach(id => deleteNumberSet(id))
    loadSavedNumbers()
    setSelectedIds(new Set())
    setEditMode(false)
    showToast(`${selectedIds.size}개 번호가 삭제되었습니다`)
  }

  const algorithmLabels: Record<Algorithm, string> = {
    random: '완전 랜덤',
    frequency: '빈도 기반',
    pattern: '패턴 기반',
    'frequency-db': 'DB 빈출 번호',
    'low-frequency-db': 'DB 저빈도 번호',
    'recent-db': 'DB 최근 출현',
    'cold-db': 'DB 콜드 번호',
    'balanced-db': 'DB 균형 조합',
    'ai-mixed-db': 'DB AI 혼합',
  }

  return (
    <Card className="p-6 max-w-3xl mx-auto">
      <div className="space-y-6">
        {/* 알고리즘 선택 */}
        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">
            생성 알고리즘
          </label>
          <Select
            value={algorithm}
            onChange={(e) => setAlgorithm(e.target.value as Algorithm)}
            disabled={loading}
          >
            {(Object.keys(algorithmLabels) as Algorithm[]).map((key) => (
              <option key={key} value={key}>
                {algorithmLabels[key]}
              </option>
            ))}
          </Select>
          <p className="text-sm text-gray-700 mt-2">
            {algorithm === 'random' && '1~45 중 완전 무작위로 6개 선택'}
            {algorithm === 'frequency' &&
              '출현 빈도가 높은 번호 중심으로 선택'}
            {algorithm === 'pattern' && '구간 분산 및 패턴 고려하여 선택'}
          </p>
        </div>

        {/* 생성 개수 선택 */}
        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">
            생성 개수
          </label>
          <div className="flex gap-2 flex-wrap items-center">
            {[1, 3, 5, 10].map((num) => (
              <button
                key={num}
                onClick={() => handleCountChange(num)}
                disabled={loading}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  count === num && !showCustomInput
                    ? 'bg-blue-600 text-white shadow-md scale-105'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                {num}개
              </button>
            ))}
            <button
              onClick={() => setShowCustomInput(!showCustomInput)}
              disabled={loading}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                showCustomInput
                  ? 'bg-blue-600 text-white shadow-md scale-105'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              사용자 정의
            </button>
          </div>

          {/* Custom Count Input */}
          {showCustomInput && (
            <div className="mt-3 flex gap-2 items-center animate-in fade-in duration-200">
              <input
                type="number"
                min="1"
                max="100"
                value={customCount}
                onChange={(e) => setCustomCount(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleCustomCountSubmit()}
                placeholder="1-100"
                className="w-24 px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">개</span>
              <Button
                onClick={handleCustomCountSubmit}
                size="sm"
                className="ml-2"
              >
                적용
              </Button>
            </div>
          )}
        </div>

        {/* 생성 버튼 */}
        <Button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full"
          size="lg"
        >
          {loading ? '생성 중...' : `번호 생성 (${count}개)`}
        </Button>

        {/* 생성된 번호 */}
        {numbers.length > 0 && (
          <div className="space-y-3 mt-6">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-lg text-gray-900">생성된 번호</h3>
              <span className="text-sm px-3 py-1 bg-blue-100 text-blue-700 rounded-full font-medium">
                {algorithmLabels[algorithm]}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {numbers.map((set, i) => (
                <div key={i} className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-semibold text-gray-900">#{i + 1}</span>
                  </div>
                  <NumberDisplay numbers={set} showCopy />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 저장된 번호 */}
        {savedNumbers.length > 0 && (
          <div className="space-y-4 mt-8 pt-6 border-t">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3 className="font-semibold text-lg text-gray-900">
                저장된 번호 ({savedNumbers.length})
              </h3>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={toggleEditMode}
                >
                  {editMode ? '완료' : '편집'}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowSaved(!showSaved)}
                >
                  {showSaved ? '숨기기' : '보기'}
                </Button>
              </div>
            </div>

            {/* Edit Mode Actions */}
            {editMode && showSaved && (
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedIds.size === savedNumbers.length && savedNumbers.length > 0}
                      onChange={toggleSelectAll}
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span className="text-sm font-medium text-gray-900">
                      전체 선택 ({selectedIds.size}/{savedNumbers.length})
                    </span>
                  </label>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleBulkCopy}
                    disabled={selectedIds.size === 0}
                  >
                    일괄 복사
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={handleBulkDelete}
                    disabled={selectedIds.size === 0}
                  >
                    일괄 삭제
                  </Button>
                </div>
              </div>
            )}

            {showSaved && (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {savedNumbers.map((saved) => (
                  <div
                    key={saved.id}
                    className={`p-4 bg-white border border-gray-200 rounded-lg hover:border-gray-300 transition-all duration-300 ${
                      deletingId === saved.id ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {/* Checkbox (Edit Mode Only) */}
                      {editMode && (
                        <input
                          type="checkbox"
                          checked={selectedIds.has(saved.id)}
                          onChange={() => toggleSelect(saved.id)}
                          className="mt-1 w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500 cursor-pointer"
                        />
                      )}

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-700 font-medium">
                              {new Date(saved.timestamp).toLocaleString('ko-KR', {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                            <span className="text-xs px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full">
                              {algorithmLabels[saved.algorithm as Algorithm] || saved.algorithm}
                            </span>
                          </div>
                          {!editMode && (
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleCopy(saved.numbers)}
                                className="text-xs px-3 py-1.5 text-gray-700 hover:text-gray-900 hover:bg-gray-100 border border-gray-300 rounded-md transition-colors font-medium"
                                title="복사"
                              >
                                복사
                              </button>
                              <button
                                onClick={() => handleDelete(saved.id)}
                                className="text-xs px-3 py-1.5 text-red-600 hover:text-red-700 hover:bg-red-50 border border-red-200 rounded-md transition-colors font-medium"
                                title="삭제"
                              >
                                삭제
                              </button>
                            </div>
                          )}
                        </div>
                        <NumberDisplay numbers={saved.numbers} showCopy={false} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Confirm Modal */}
        <ConfirmModal
          isOpen={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          onConfirm={confirmBulkDelete}
          title="번호 삭제"
          message={`선택한 ${selectedIds.size}개의 번호를 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.`}
          confirmText="삭제"
          cancelText="취소"
          variant="danger"
        />
      </div>
    </Card>
  )
}
