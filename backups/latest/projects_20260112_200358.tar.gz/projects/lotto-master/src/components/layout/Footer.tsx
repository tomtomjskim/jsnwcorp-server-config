/**
 * Footer Component
 *
 * Global footer with navigation, info, and version
 *
 * @version 0.4.0
 * @updated 2025-11-02 - Improved UI: repositioned analysis links, enhanced text contrast
 */

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <h3 className="text-lg font-bold mb-4 flex items-center">
              <span className="mr-2">🎰</span>
              LottoMaster
            </h3>
            <p className="text-gray-400 text-sm mb-3">
              통계 기반 로또 번호 추천 서비스
              <br />
              과학적 분석으로 행운의 번호를 찾아보세요
            </p>
            <div className="text-xs text-gray-500">
              Version 0.4.0
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">바로가기</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="/" className="text-gray-400 hover:text-white transition-colors">
                  홈
                </a>
              </li>
              <li>
                <a href="/generator" className="text-gray-400 hover:text-white transition-colors">
                  번호생성
                </a>
              </li>
              <li>
                <a href="/statistics" className="text-gray-400 hover:text-white transition-colors">
                  통계 분석
                </a>
              </li>
              <li>
                <a href="/history" className="text-gray-400 hover:text-white transition-colors">
                  당첨 내역
                </a>
              </li>
            </ul>
          </div>

          {/* Info */}
          <div>
            <h3 className="text-lg font-bold mb-4">기능 안내</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>📊 자동 수집 (주 2회, 일/월/화)</li>
              <li>🎯 3가지 생성 알고리즘 제공</li>
              <li>📈 상세 통계 분석 (10가지 지표)</li>
              <li>💎 최신 회차 종합 분석</li>
              <li>💡 무료 서비스</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold mb-4">문의</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a
                  href="mailto:jsnetwork.corp@gmail.com"
                  className="text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                >
                  <svg className="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span className="break-all">jsnetwork.corp@gmail.com</span>
                </a>
              </li>
              <li className="text-gray-500 text-xs pt-2">
                서비스 관련 문의, 버그 제보,<br />
                기능 제안 등을 보내주세요.
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-400">
            <div className="text-center md:text-left">
              <p>© 2025 LottoMaster. All rights reserved.</p>
              <p className="mt-1 text-xs">
                ※ 본 서비스는 참고용이며 당첨을 보장하지 않습니다.
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <a
                href="mailto:jsnetwork.corp@gmail.com"
                className="text-gray-400 hover:text-white transition-colors flex items-center gap-1"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                문의하기
              </a>
              <span className="text-gray-600">|</span>
              <span>v0.4.0</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
