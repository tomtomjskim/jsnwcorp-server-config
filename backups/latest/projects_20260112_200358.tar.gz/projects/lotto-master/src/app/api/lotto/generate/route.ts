import { NextRequest, NextResponse } from 'next/server';
import { generateNumbersAsync } from '@/lib/algorithms';
import { analytics } from '@/lib/analytics';
import type { Algorithm, GenerateRequest, GenerateResponse } from '@/types/lotto';

const VALID_ALGORITHMS: Algorithm[] = [
  'random',
  'frequency',
  'pattern',
  'frequency-db',
  'low-frequency-db',
  'recent-db',
  'cold-db',
  'balanced-db',
  'ai-mixed-db',
];

export async function POST(request: NextRequest) {
  const startTime = Date.now();

  try {
    const body = await request.json() as GenerateRequest;
    const { algorithm = 'random', count = 1 } = body;

    // Validate input
    if (!VALID_ALGORITHMS.includes(algorithm)) {
      return NextResponse.json<GenerateResponse>(
        {
          success: false,
          error: `Invalid algorithm. Must be one of: ${VALID_ALGORITHMS.join(', ')}`
        },
        { status: 400 }
      );
    }

    if (count < 1 || count > 10) {
      return NextResponse.json<GenerateResponse>(
        {
          success: false,
          error: 'Invalid count. Must be between 1 and 10'
        },
        { status: 400 }
      );
    }

    // Generate numbers (using async version to support DB-based algorithms)
    const numbers: number[][] = [];
    for (let i = 0; i < count; i++) {
      const generated = await generateNumbersAsync(algorithm);
      numbers.push(generated);
    }

    const duration = Date.now() - startTime;

    // Track analytics (non-blocking)
    const ipAddress = request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
    const userAgent = request.headers.get('user-agent') || undefined;
    const sessionId = request.headers.get('x-session-id') || undefined;

    analytics.trackEvent({
      eventType: 'generation',
      eventCategory: 'lotto',
      eventName: 'numbers_generated',
      eventValue: count,
      sessionId,
      ipAddress,
      userAgent,
      metadata: {
        algorithm,
        count,
        duration_ms: duration,
        numbers_preview: numbers[0] // Store first set as preview
      }
    }).catch(err => {
      console.error('[Analytics] Failed to track generation event:', err);
    });

    const response: GenerateResponse = {
      success: true,
      data: {
        numbers,
        algorithm,
        generatedAt: new Date().toISOString()
      }
    };

    return NextResponse.json(response, { status: 200 });
  } catch (error) {
    console.error('[API] Generate error:', error);

    const response: GenerateResponse = {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to generate numbers'
    };

    return NextResponse.json(response, { status: 500 });
  }
}
