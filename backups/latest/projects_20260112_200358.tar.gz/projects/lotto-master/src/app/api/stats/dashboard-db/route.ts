import { NextResponse } from 'next/server';
import {
  getTotalDrawsCount,
  calculateNumberStats,
  calculateOddEvenRatio,
  calculateHighLowRatio,
  getLatestDrawNo,
  getLatestDraw,
  getDrawByNumber,
} from '@/lib/data/db-loader';

export const revalidate = 300; // 5분 캐싱
export const dynamic = 'force-dynamic';

/**
 * 다음 추첨 정보 계산
 */
function calculateNextDraw(latestDraw: any, latestDrawNo: number) {
  const now = new Date();
  const nextDrawNo = latestDrawNo + 1;

  // 최신 회차의 날짜에서 7일 추가 (다음 추첨일)
  const latestDrawDate = new Date(latestDraw.drawDate);
  const nextDrawDate = new Date(latestDrawDate);
  nextDrawDate.setDate(nextDrawDate.getDate() + 7);

  // 추첨 시간 (토요일 20:45)
  const drawDateTime = new Date(nextDrawDate);
  drawDateTime.setHours(20, 45, 0, 0);

  // 요일 한글
  const dayNames = ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'];
  const dayOfWeek = dayNames[nextDrawDate.getDay()];

  // 날짜 포맷 (YYYY-MM-DD)
  const dateStr = nextDrawDate.toISOString().split('T')[0];

  // 상태 결정
  let status: 'waiting' | 'collecting' = 'waiting';
  let message = `다음 추첨: ${dateStr} (${dayOfWeek}) 20:45`;

  // 추첨 시간이 지났는지 확인
  if (now > drawDateTime) {
    status = 'collecting';
    message = `${nextDrawNo}회차 당첨정보 수집중...`;
  }

  return {
    nextDrawNo,
    nextDrawDate: dateStr,
    nextDrawTime: '20:45',
    dayOfWeek,
    status,
    message,
    drawDateTime: drawDateTime.toISOString(),
  };
}

export async function GET() {
  try {
    const [totalDraws, stats, oddEvenRatio, highLowRatio, latestDrawNo, latestDraw] = await Promise.all([
      getTotalDrawsCount(),
      calculateNumberStats(),
      calculateOddEvenRatio(),
      calculateHighLowRatio(),
      getLatestDrawNo(),
      getLatestDraw(),
    ]);

    // 빈도순 정렬
    const sorted = [...stats].sort((a, b) => b.totalCount - a.totalCount);

    // 상위 10개 (빈출)
    const topFrequent = sorted.slice(0, 10).map((s) => ({
      number: s.number,
      count: s.totalCount,
      percentage: ((s.totalCount / (totalDraws * 6)) * 100).toFixed(1),
    }));

    // 하위 10개 (저빈도)
    const leastFrequent = sorted.slice(-10).reverse().map((s) => ({
      number: s.number,
      count: s.totalCount,
      percentage: ((s.totalCount / (totalDraws * 6)) * 100).toFixed(1),
    }));

    // 최근 미출현 번호 (lastDrawNo 기준)
    const coldNumbers = [...stats]
      .filter((s) => s.lastDrawNo !== null)
      .sort((a, b) => {
        const aGap = latestDrawNo - (a.lastDrawNo || 0);
        const bGap = latestDrawNo - (b.lastDrawNo || 0);
        return bGap - aGap;
      })
      .slice(0, 10)
      .map((s) => ({
        number: s.number,
        lastDrawNo: s.lastDrawNo,
        lastDrawDate: s.lastDrawDate,
        gapDraws: latestDrawNo - (s.lastDrawNo || 0),
      }));

    // 최근 출현 번호
    const hotNumbers = [...stats]
      .filter((s) => s.lastDrawNo !== null)
      .sort((a, b) => (b.lastDrawNo || 0) - (a.lastDrawNo || 0))
      .slice(0, 10)
      .map((s) => ({
        number: s.number,
        lastDrawNo: s.lastDrawNo,
        lastDrawDate: s.lastDrawDate,
        totalCount: s.totalCount,
      }));

    // 다음 추첨 정보 계산
    const nextDrawInfo = latestDraw ? calculateNextDraw(latestDraw, latestDrawNo) : null;

    return NextResponse.json({
      success: true,
      data: {
        totalDraws,
        latestDrawNo,
        latestDrawDate: latestDraw?.drawDate || null,
        lastUpdate: new Date().toISOString().split('T')[0],
        nextDraw: nextDrawInfo,
        topFrequent,
        leastFrequent,
        coldNumbers,
        hotNumbers,
        oddEvenRatio: {
          odd: oddEvenRatio.odd.toFixed(1),
          even: oddEvenRatio.even.toFixed(1),
        },
        highLowRatio: {
          low: highLowRatio.low.toFixed(1),
          high: highLowRatio.high.toFixed(1),
        },
        allStats: stats, // 전체 통계 (필요시 프론트엔드에서 사용)
      },
    });
  } catch (error) {
    console.error('[API] 통계 조회 오류:', error);
    return NextResponse.json(
      {
        success: false,
        error: '통계 조회 중 오류가 발생했습니다.',
        message: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}
