/**
 * Latest Draw Analysis API Endpoint
 *
 * GET /api/stats/latest-draw-analysis
 *
 * Provides comprehensive statistical analysis of the most recent lottery draw.
 *
 * Features:
 * - Basic statistics (average, median, std dev, variance)
 * - Distribution analysis (odd/even, high/low, range segments)
 * - Pattern detection (consecutive, arithmetic, repetition)
 * - Frequency analysis (hot/cold numbers)
 * - Rarity scoring (0-100 with grade)
 * - Similar draws search (TOP 5)
 * - Historical comparison
 * - AI-powered insights
 *
 * Cache: 5 minutes (revalidate: 300)
 *
 * @author Claude Code
 * @version 1.0.0
 * @created 2025-11-02
 */

import { NextRequest, NextResponse } from 'next/server';
import { getPool } from '@/lib/db';
import {
  calculateBasicStats,
  analyzeDistribution,
  analyzePatterns,
  analyzeFrequency,
  calculateRarityScore,
  findSimilarDraws,
  compareWithHistory,
  generateStructuredInsights,
  type LatestDrawAnalysis
} from '@/lib/analysis/latestDrawAnalysis';

/**
 * GET handler for latest draw analysis
 */
export async function GET(request: NextRequest) {
  const startTime = Date.now();
  const pool = await getPool();

  try {
    // Step 1: Fetch latest draw from database (lotto.draws 테이블 사용)
    const latestDrawQuery = `
      SELECT
        draw_no,
        draw_date,
        num1, num2, num3, num4, num5, num6,
        bonus_num
      FROM lotto.draws
      ORDER BY draw_no DESC
      LIMIT 1
    `;

    const result = await pool.query(latestDrawQuery);

    if (result.rows.length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'No draw data found',
          message: '추첨 결과를 찾을 수 없습니다.'
        },
        { status: 404 }
      );
    }

    const latestDraw = result.rows[0];
    const drawNo = latestDraw.draw_no;
    const drawDate = latestDraw.draw_date;
    const numbers = [
      latestDraw.num1,
      latestDraw.num2,
      latestDraw.num3,
      latestDraw.num4,
      latestDraw.num5,
      latestDraw.num6
    ];
    const bonusNumber = latestDraw.bonus_num;

    console.log(`[Latest Draw Analysis] Processing draw #${drawNo} (${drawDate})`);
    console.log(`[Latest Draw Analysis] Numbers: ${numbers.join(', ')} + ${bonusNumber}`);

    // Step 2: Run all analysis functions in parallel where possible
    // Group 1: Independent calculations
    const [basicStats, distribution, patterns] = await Promise.all([
      Promise.resolve(calculateBasicStats(numbers)),
      Promise.resolve(analyzeDistribution(numbers)),
      analyzePatterns(numbers, drawNo)
    ]);

    // Group 2: Frequency analysis (needs DB)
    const frequency = await analyzeFrequency(numbers);

    // Group 3: Rarity calculation (depends on previous results)
    const rarity = await calculateRarityScore(
      drawNo,
      numbers,
      basicStats,
      distribution,
      patterns,
      frequency
    );

    // Group 4: Similar draws and comparison (parallel)
    const [similarDraws, comparison] = await Promise.all([
      findSimilarDraws(drawNo, numbers),
      compareWithHistory(drawNo, numbers, basicStats)
    ]);

    // Group 5: Generate insights (depends on all previous results)
    const insights = generateStructuredInsights(
      drawNo,
      numbers,
      bonusNumber,
      basicStats,
      distribution,
      patterns,
      frequency,
      rarity,
      similarDraws,
      comparison
    );

    // Step 3: Construct complete response
    const response: LatestDrawAnalysis = {
      drawInfo: {
        drawNo,
        drawDate: drawDate.toISOString().split('T')[0],
        numbers,
        bonusNumber
      },
      basicStats,
      distribution,
      patterns,
      frequency,
      rarity,
      similarDraws,
      comparison,
      insights,
      metadata: {
        analyzedAt: new Date().toISOString(),
        processingTime: Date.now() - startTime,
        version: '1.0.0',
        dataSource: 'PostgreSQL lotto.draws'
      }
    };

    const processingTime = Date.now() - startTime;
    console.log(`[Latest Draw Analysis] Completed in ${processingTime}ms`);

    // Return with 5-minute cache
    return NextResponse.json(
      {
        success: true,
        data: response
      },
      {
        status: 200,
        headers: {
          'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=600',
          'X-Processing-Time': `${processingTime}ms`,
          'X-Draw-Number': drawNo.toString()
        }
      }
    );

  } catch (error) {
    const processingTime = Date.now() - startTime;
    console.error('[Latest Draw Analysis] Error:', error);

    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error',
        message: '분석 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.',
        processingTime
      },
      { status: 500 }
    );
  }
}

/**
 * Export config for Next.js caching
 */
export const revalidate = 300; // 5 minutes
export const dynamic = 'force-dynamic'; // Always execute on request
export const runtime = 'nodejs'; // Use Node.js runtime (not Edge)
