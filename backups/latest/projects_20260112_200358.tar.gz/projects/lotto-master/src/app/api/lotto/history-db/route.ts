import { NextRequest, NextResponse } from 'next/server';
import {
  getDrawByNumber,
  getRecentDraws,
  getTotalDrawsCount,
} from '@/lib/data/db-loader';

/**
 * 로또 당첨 번호 조회 API (PostgreSQL 버전)
 *
 * GET /api/lotto/history-db?drawNo=1145
 * GET /api/lotto/history-db?limit=20
 */
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const drawNoParam = searchParams.get('drawNo');
    const limitParam = searchParams.get('limit');

    // 특정 회차 조회
    if (drawNoParam) {
      const drawNo = parseInt(drawNoParam);
      if (isNaN(drawNo)) {
        return NextResponse.json(
          { success: false, error: '유효하지 않은 회차 번호입니다.' },
          { status: 400 }
        );
      }

      const draw = await getDrawByNumber(drawNo);
      if (!draw) {
        return NextResponse.json(
          { success: false, error: '해당 회차를 찾을 수 없습니다.' },
          { status: 404 }
        );
      }

      return NextResponse.json({ success: true, data: draw });
    }

    // 최근 N회차 조회
    const limit = limitParam ? parseInt(limitParam) : 10;
    const draws = await getRecentDraws(limit);
    const total = await getTotalDrawsCount();

    return NextResponse.json({
      success: true,
      data: {
        results: draws,
        pagination: {
          limit,
          total,
        },
      },
    });
  } catch (error) {
    console.error('[API] 당첨번호 조회 오류:', error);
    return NextResponse.json(
      { success: false, error: '조회 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}
