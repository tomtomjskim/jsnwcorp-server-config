import { NextRequest, NextResponse } from 'next/server';
import { analytics } from '@/lib/analytics';

/**
 * Rate Limiter (In-memory)
 * - IP별 요청 수 추적
 * - 초당 10회 제한
 */
class RateLimiter {
  private requests: Map<string, number[]> = new Map();
  private readonly limit = 10; // 초당 최대 요청 수
  private readonly window = 1000; // 1초 (ms)

  isAllowed(ip: string): boolean {
    const now = Date.now();
    const timestamps = this.requests.get(ip) || [];

    // 윈도우 밖의 오래된 요청 제거
    const recentRequests = timestamps.filter(ts => now - ts < this.window);

    if (recentRequests.length >= this.limit) {
      return false; // Rate limit exceeded
    }

    // 새 요청 추가
    recentRequests.push(now);
    this.requests.set(ip, recentRequests);

    // 메모리 관리: 5분 이상 요청 없는 IP 삭제
    if (this.requests.size > 1000) {
      this.cleanup();
    }

    return true;
  }

  private cleanup() {
    const now = Date.now();
    const fiveMinutes = 5 * 60 * 1000;

    for (const [ip, timestamps] of this.requests.entries()) {
      if (timestamps.length === 0 || now - timestamps[timestamps.length - 1] > fiveMinutes) {
        this.requests.delete(ip);
      }
    }
  }
}

/**
 * Event Batch Processor
 * - 이벤트를 모아서 한 번에 INSERT
 * - DB 부하 감소 및 성능 향상
 */
class EventBatchProcessor {
  private queue: any[] = [];
  private readonly batchSize = 10; // 10개씩 모아서 처리
  private readonly flushInterval = 5000; // 5초마다 자동 flush
  private flushTimer: NodeJS.Timeout | null = null;

  constructor() {
    this.startAutoFlush();
  }

  async add(event: any): Promise<void> {
    this.queue.push(event);

    // 배치 크기 도달 시 즉시 flush
    if (this.queue.length >= this.batchSize) {
      await this.flush();
    }
  }

  async flush(): Promise<void> {
    if (this.queue.length === 0) return;

    const batch = [...this.queue];
    this.queue = [];

    // 배치 처리 (병렬 실행)
    await Promise.allSettled(
      batch.map(event => analytics.trackEvent(event))
    );
  }

  private startAutoFlush() {
    this.flushTimer = setInterval(() => {
      this.flush().catch(err =>
        console.error('[EventBatchProcessor] Auto-flush error:', err)
      );
    }, this.flushInterval);
  }

  destroy() {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
      this.flushTimer = null;
    }
  }
}

// 싱글톤 인스턴스
const rateLimiter = new RateLimiter();
const batchProcessor = new EventBatchProcessor();

/**
 * Extract real IP address from request
 * - nginx proxy를 통한 요청에서 실제 IP 추출
 */
function extractIpAddress(request: NextRequest): string {
  // X-Real-IP (nginx proxy가 설정)
  const realIp = request.headers.get('x-real-ip');
  if (realIp) return realIp;

  // X-Forwarded-For (다중 프록시 경우)
  const forwardedFor = request.headers.get('x-forwarded-for');
  if (forwardedFor) {
    return forwardedFor.split(',')[0].trim();
  }

  // Fallback
  return 'unknown';
}

/**
 * Detect device type from User-Agent
 */
function detectDeviceType(userAgent: string): 'mobile' | 'tablet' | 'desktop' {
  const ua = userAgent.toLowerCase();

  if (/(tablet|ipad|playbook|silk)|(android(?!.*mobile))/i.test(ua)) {
    return 'tablet';
  }

  if (/mobile|android|iphone|ipod|blackberry|iemobile|opera mini/i.test(ua)) {
    return 'mobile';
  }

  return 'desktop';
}

/**
 * Analytics Tracking API
 * POST /api/analytics/track
 *
 * Features:
 * - Rate Limiting (10 req/sec per IP)
 * - Batch Processing (10 events per batch or 5sec interval)
 * - IP & Device detection
 * - Graceful error handling
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Extract IP address
    const ipAddress = extractIpAddress(request);

    // 2. Rate Limiting check
    if (!rateLimiter.isAllowed(ipAddress)) {
      return NextResponse.json(
        { error: 'Rate limit exceeded', limit: '10 requests per second' },
        { status: 429 }
      );
    }

    // 3. Parse request body
    const body = await request.json();

    // 4. Validate required fields
    if (!body.eventType || !body.eventName) {
      return NextResponse.json(
        {
          error: 'Validation failed',
          message: 'Missing required fields: eventType, eventName'
        },
        { status: 400 }
      );
    }

    // 5. Extract additional client information
    const userAgent = request.headers.get('user-agent') || 'unknown';
    const deviceType = detectDeviceType(userAgent);

    // 6. Prepare event data
    const eventData = {
      eventType: body.eventType,
      eventCategory: body.eventCategory,
      eventName: body.eventName,
      eventValue: body.eventValue,
      sessionId: body.sessionId,
      userId: body.userId,
      ipAddress,
      userAgent,
      pageUrl: body.pageUrl,
      referrer: body.referrer || request.headers.get('referer'),
      deviceType: body.deviceType || deviceType,
      metadata: body.metadata
    };

    // 7. Add to batch processor (non-blocking)
    batchProcessor.add(eventData).catch(err =>
      console.error('[Analytics API] Batch add error:', err)
    );

    // 8. Return success immediately (논블로킹)
    return NextResponse.json(
      {
        success: true,
        message: 'Event queued for processing'
      },
      { status: 200 }
    );

  } catch (error) {
    // Log error but return 200 to prevent client retries
    console.error('[Analytics API] Error:', error);

    return NextResponse.json(
      {
        success: false,
        error: 'Internal error',
        message: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 200 } // Graceful degradation
    );
  }
}

/**
 * OPTIONS handler for CORS preflight
 */
export async function OPTIONS() {
  return NextResponse.json({}, {
    status: 200,
    headers: {
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    }
  });
}

/**
 * GET handler for health check
 */
export async function GET() {
  return NextResponse.json({
    service: 'analytics-track',
    status: 'healthy',
    features: {
      rateLimiting: true,
      batchProcessing: true,
      deviceDetection: true
    },
    config: {
      rateLimit: '10 req/sec',
      batchSize: 10,
      flushInterval: '5 seconds'
    }
  });
}

/**
 * Cleanup on module unload (for development)
 */
if (typeof process !== 'undefined') {
  process.on('beforeExit', () => {
    batchProcessor.flush().catch(console.error);
    batchProcessor.destroy();
  });
}
