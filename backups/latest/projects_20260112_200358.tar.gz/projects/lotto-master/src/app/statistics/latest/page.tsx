/**
 * Latest Draw Analysis Page
 *
 * Path: /statistics/latest
 *
 * Displays comprehensive statistical analysis of the most recent lottery draw.
 *
 * Sections:
 * 1. Hero - Draw info and headline insights
 * 2. Stats Cards - Quick metrics overview (4 cards)
 * 3. Distribution Charts - Odd/even, high/low, range visualization
 * 4. Pattern Analysis - Consecutive, arithmetic, repetition
 * 5. Frequency Analysis - Hot/cold numbers with historical context
 * 6. Rarity Score - Uniqueness scoring with factors breakdown
 * 7. Similar Draws - TOP 5 historically similar draws
 * 8. Insights - AI-powered natural language insights
 *
 * @author Claude Code
 * @version 1.0.0
 * @created 2025-11-02
 */

import { Metadata } from 'next';
import Link from 'next/link';
import LatestDrawHero from '@/components/statistics/latest/LatestDrawHero';
import StatsCards from '@/components/statistics/latest/StatsCards';
import DistributionSection from '@/components/statistics/latest/DistributionSection';
import PatternSection from '@/components/statistics/latest/PatternSection';
import FrequencySection from '@/components/statistics/latest/FrequencySection';
import RaritySection from '@/components/statistics/latest/RaritySection';
import SimilarDrawsSection from '@/components/statistics/latest/SimilarDrawsSection';
import InsightsSection from '@/components/statistics/latest/InsightsSection';
import RefreshButton from '@/components/statistics/latest/RefreshButton';
import type { LatestDrawAnalysis } from '@/lib/analysis/latestDrawAnalysis';

/**
 * Page metadata
 */
export const metadata: Metadata = {
  title: '최신 회차 분석 | LottoMaster',
  description: '가장 최근 로또 추첨 결과에 대한 종합 통계 분석. 기본 통계, 분포, 패턴, 빈도, 희귀도, 유사 회차, 인사이트를 확인하세요.',
  keywords: ['로또', '최신 회차', '통계 분석', '추첨 결과', '패턴 분석', '빈도 분석'],
  openGraph: {
    title: '최신 회차 분석 | LottoMaster',
    description: '가장 최근 로또 추첨 결과의 통계적 분석',
    type: 'website'
  }
};

/**
 * Fetch analysis data from API
 */
async function getLatestDrawAnalysis(): Promise<LatestDrawAnalysis | null> {
  try {
    const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000';
    const response = await fetch(`${baseUrl}/api/stats/latest-draw-analysis`, {
      next: { revalidate: 300 } // 5 minutes cache
    });

    if (!response.ok) {
      console.error(`[Latest Draw Analysis Page] API error: ${response.status}`);
      return null;
    }

    const result = await response.json();

    if (!result.success || !result.data) {
      console.error('[Latest Draw Analysis Page] Invalid API response');
      return null;
    }

    return result.data;
  } catch (error) {
    console.error('[Latest Draw Analysis Page] Fetch error:', error);
    return null;
  }
}

/**
 * Main page component
 */
export default async function LatestDrawAnalysisPage() {
  const data = await getLatestDrawAnalysis();

  // Error state
  if (!data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
        <div className="container mx-auto px-4 py-8">
          {/* Back button */}
          <Link
            href="/statistics"
            className="inline-flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 mb-6 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            통계 대시보드로 돌아가기
          </Link>

          {/* Error message */}
          <div className="bg-white rounded-xl shadow-lg p-12 text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                className="w-8 h-8 text-red-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              데이터를 불러올 수 없습니다
            </h1>
            <p className="text-gray-600 mb-6">
              최신 회차 분석 데이터를 가져오는 중 오류가 발생했습니다.
              <br />
              잠시 후 다시 시도해주세요.
            </p>
            <RefreshButton />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Back button */}
        <Link
          href="/statistics"
          className="inline-flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          통계 대시보드로 돌아가기
        </Link>

        {/* Page header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            최신 회차 통계 분석
          </h1>
          <p className="text-gray-600">
            가장 최근 추첨된 로또 번호에 대한 종합적인 통계 분석 결과입니다.
          </p>
        </div>

        {/* Section 1: Hero */}
        <LatestDrawHero
          drawInfo={data.drawInfo}
          rarity={data.rarity}
          insights={data.insights}
        />

        {/* Section 2: Stats Cards */}
        <StatsCards
          basicStats={data.basicStats}
          distribution={data.distribution}
          patterns={data.patterns}
          rarity={data.rarity}
        />

        {/* Section 3: Distribution */}
        <DistributionSection
          distribution={data.distribution}
          comparison={data.comparison}
        />

        {/* Section 4: Pattern Analysis */}
        <PatternSection
          patterns={data.patterns}
          drawInfo={data.drawInfo}
        />

        {/* Section 5: Frequency Analysis */}
        <FrequencySection
          frequency={data.frequency}
          numbers={data.drawInfo.numbers}
        />

        {/* Section 6: Rarity Score */}
        <RaritySection
          rarity={data.rarity}
          drawInfo={data.drawInfo}
        />

        {/* Section 7: Similar Draws */}
        <SimilarDrawsSection
          similarDraws={data.similarDraws}
          currentDraw={data.drawInfo}
        />

        {/* Section 8: Insights */}
        <InsightsSection
          insights={data.insights}
        />

        {/* Footer metadata */}
        <div className="mt-12 pt-6 border-t border-gray-200">
          <div className="flex flex-wrap items-center justify-between gap-4 text-sm text-gray-500">
            <div>
              분석 일시: {new Date(data.metadata.analyzedAt).toLocaleString('ko-KR')}
            </div>
            <div className="flex gap-4">
              <span>처리 시간: {data.metadata.processingTime}ms</span>
              <span>버전: {data.metadata.version}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Enable static generation with revalidation
 */
export const revalidate = 300; // Revalidate every 5 minutes
