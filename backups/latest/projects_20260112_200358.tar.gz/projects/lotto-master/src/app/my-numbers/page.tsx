'use client';

import { useEffect, useState } from 'react';
import Layout from '@/components/layout/Layout';
import { getSavedNumbers, deleteNumberSet, clearAllSavedNumbers, type SavedNumberSet } from '@/lib/storage';
import type { Algorithm } from '@/types/lotto';

export default function MyNumbersPage() {
  const [savedNumbers, setSavedNumbers] = useState<SavedNumberSet[]>([]);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    loadSavedNumbers();
  }, []);

  const loadSavedNumbers = () => {
    const saved = getSavedNumbers();
    setSavedNumbers(saved);
  };

  const handleDelete = (id: string) => {
    setDeletingId(id);
    setTimeout(() => {
      deleteNumberSet(id);
      loadSavedNumbers();
      setDeletingId(null);
    }, 300);
  };

  const handleClearAll = () => {
    if (confirm('저장된 모든 번호를 삭제하시겠습니까?')) {
      clearAllSavedNumbers();
      loadSavedNumbers();
    }
  };

  const handleCopy = async (numbers: number[]) => {
    const text = numbers.join(', ');
    try {
      await navigator.clipboard.writeText(text);
      alert('번호가 복사되었습니다');
    } catch (error) {
      console.error('복사 실패:', error);
      alert('복사 실패');
    }
  };

  const getNumberColor = (num: number) => {
    if (num <= 10) return 'bg-yellow-500';
    if (num <= 20) return 'bg-blue-500';
    if (num <= 30) return 'bg-red-500';
    if (num <= 40) return 'bg-gray-700';
    return 'bg-green-500';
  };

  const algorithmLabels: Record<string, string> = {
    random: '완전 랜덤',
    frequency: '빈도 기반',
    pattern: '패턴 기반',
    'frequency-db': 'DB 빈출 번호',
    'low-frequency-db': 'DB 저빈도 번호',
    'recent-db': 'DB 최근 출현',
    'cold-db': 'DB 콜드 번호',
    'balanced-db': 'DB 균형 조합',
    'ai-mixed-db': 'DB AI 혼합',
  };

  return (
    <Layout>
      <div className="bg-gray-50 min-h-screen py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">
              💾 저장된 번호
            </h1>
            <p className="text-gray-600">
              총 {savedNumbers.length}개의 번호가 저장되어 있습니다
            </p>
          </div>

          {/* Clear All Button */}
          {savedNumbers.length > 0 && (
            <div className="mb-6 flex justify-end">
              <button
                onClick={handleClearAll}
                className="px-4 py-2 text-sm text-red-600 hover:text-red-700 hover:bg-red-50 border border-red-300 rounded-lg transition-colors font-medium"
              >
                전체 삭제
              </button>
            </div>
          )}

          {/* Saved Numbers List */}
          {savedNumbers.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-12 text-center">
              <p className="text-xl text-gray-500 mb-4">저장된 번호가 없습니다</p>
              <a
                href="/"
                className="inline-block px-6 py-3 bg-purple-600 text-white rounded-full font-semibold hover:bg-purple-700 transition-colors"
              >
                번호 생성하러 가기
              </a>
            </div>
          ) : (
            <div className="space-y-4">
              {savedNumbers.map((saved) => (
                <div
                  key={saved.id}
                  className={`bg-white rounded-lg shadow p-6 hover:shadow-md transition-all duration-300 ${
                    deletingId === saved.id ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
                  }`}
                >
                  <div className="flex items-start justify-between mb-4 flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-600 font-medium">
                        {new Date(saved.timestamp).toLocaleString('ko-KR', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                      <span className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded-full">
                        {algorithmLabels[saved.algorithm] || saved.algorithm}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleCopy(saved.numbers)}
                        className="text-sm px-4 py-2 text-gray-700 hover:text-gray-900 hover:bg-gray-100 border border-gray-300 rounded-lg transition-colors font-medium"
                      >
                        복사
                      </button>
                      <button
                        onClick={() => handleDelete(saved.id)}
                        className="text-sm px-4 py-2 text-red-600 hover:text-red-700 hover:bg-red-50 border border-red-300 rounded-lg transition-colors font-medium"
                      >
                        삭제
                      </button>
                    </div>
                  </div>

                  {/* Numbers Display */}
                  <div className="flex gap-2 flex-wrap">
                    {saved.numbers.map((num, idx) => (
                      <div
                        key={idx}
                        className={`w-12 h-12 rounded-full ${getNumberColor(
                          num
                        )} text-white flex items-center justify-center text-lg font-bold shadow`}
                      >
                        {num}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
