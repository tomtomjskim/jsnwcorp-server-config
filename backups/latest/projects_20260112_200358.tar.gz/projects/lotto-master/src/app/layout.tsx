import type { Metadata } from "next";
import "./globals.css";
import AnalyticsProvider from "@/components/AnalyticsProvider";
import { ToastProvider } from "@/components/ui/toast";

export const metadata: Metadata = {
  title: "LottoMaster - 로또 번호 생성기",
  description: "데이터 기반 로또 번호 추천 서비스",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body className="antialiased">
        <ToastProvider>
          <AnalyticsProvider>
            {children}
          </AnalyticsProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
