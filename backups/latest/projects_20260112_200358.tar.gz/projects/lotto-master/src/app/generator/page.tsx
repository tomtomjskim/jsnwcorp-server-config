'use client';

import Layout from '@/components/layout/Layout';
import NumberGenerator from '@/components/lotto/NumberGenerator';

export default function GeneratorPage() {
  return (
    <Layout>
      <div className="bg-gray-50 min-h-screen py-8">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">
              🎲 번호 생성기
            </h1>
            <p className="text-gray-600">
              다양한 알고리즘으로 로또 번호를 생성해보세요
            </p>
          </div>

          <NumberGenerator />
        </div>
      </div>
    </Layout>
  );
}
