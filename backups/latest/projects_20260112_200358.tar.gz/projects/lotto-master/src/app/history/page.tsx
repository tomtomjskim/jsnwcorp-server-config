'use client';

import { useEffect, useState } from 'react';
import Layout from '@/components/layout/Layout';

interface Draw {
  drawNo: number;
  drawDate: string;
  numbers: number[];
  bonusNum: number;
  firstWinAmount: string | number | null;
  firstWinCount: number | null;
}

export default function HistoryPage() {
  const [draws, setDraws] = useState<Draw[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const itemsPerPage = 20;

  useEffect(() => {
    setLoading(true);
    const url = searchTerm
      ? `/api/lotto/history-db?drawNo=${searchTerm}`
      : `/api/lotto/history-db?limit=1000`;

    fetch(url)
      .then((res) => res.json())
      .then((json) => {
        if (json.success) {
          setDraws(json.data.results);
          setTotalCount(json.data.pagination.total);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error('데이터 로드 실패:', err);
        setLoading(false);
      });
  }, [searchTerm]);

  // Pagination
  const totalPages = Math.ceil(draws.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentDraws = draws.slice(startIndex, endIndex);

  const formatAmount = (amount: string | number | null) => {
    if (!amount) return '-';
    const numAmount = typeof amount === 'string' ? parseInt(amount) : amount;
    return new Intl.NumberFormat('ko-KR').format(numAmount) + '원';
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <p className="text-xl text-gray-600">데이터 로딩 중...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (draws.length === 0 && !loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <p className="text-xl text-red-600">데이터를 불러올 수 없습니다</p>
          </div>
        </div>
      </Layout>
    );
  }

  const getNumberColor = (num: number) => {
    if (num <= 10) return 'bg-yellow-500';
    if (num <= 20) return 'bg-blue-500';
    if (num <= 30) return 'bg-red-500';
    if (num <= 40) return 'bg-gray-700';
    return 'bg-green-500';
  };

  return (
    <Layout>
      <div className="bg-gray-50 min-h-screen py-8">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">
              🎯 당첨번호 내역
            </h1>
            <p className="text-gray-600">
              전체 {totalCount}회차 당첨번호 조회
            </p>
          </div>

          {/* Search */}
          <div className="bg-white rounded-lg shadow p-4 mb-6">
            <input
              type="text"
              placeholder="회차 번호 검색..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>

          {/* Latest Draw Highlight */}
          {currentPage === 1 && !searchTerm && draws.length > 0 && (
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg shadow-lg p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">🏆 최신 당첨번호</h2>
                <a
                  href="/statistics/latest"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-white text-purple-600 font-semibold text-sm rounded-lg hover:bg-gray-100 transition-all shadow-lg"
                >
                  <span>💎</span>
                  <span>상세 분석 보기</span>
                  <span className="px-2 py-0.5 bg-purple-600 text-white text-xs rounded-full font-bold">
                    NEW
                  </span>
                </a>
              </div>
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div>
                  <p className="text-sm opacity-90 mb-2">
                    제 {draws[0].drawNo}회 ({new Date(draws[0].drawDate).toLocaleDateString('ko-KR')})
                  </p>
                  <div className="flex items-center gap-2 flex-wrap">
                    {draws[0].numbers.map((num, idx) => (
                      <div
                        key={idx}
                        className="w-12 h-12 rounded-full bg-white text-purple-600 flex items-center justify-center text-lg font-bold shadow-lg"
                      >
                        {num}
                      </div>
                    ))}
                    <span className="text-xl mx-2">+</span>
                    <div className="w-12 h-12 rounded-full bg-yellow-400 text-gray-800 flex items-center justify-center text-lg font-bold shadow-lg">
                      {draws[0].bonusNum}
                    </div>
                  </div>
                </div>
                {draws[0].firstWinAmount && (
                  <div className="text-right">
                    <p className="text-sm opacity-90">1등 당첨금</p>
                    <p className="text-2xl font-bold">
                      {formatAmount(draws[0].firstWinAmount)}
                    </p>
                    <p className="text-xs opacity-75">
                      당첨자: {draws[0].firstWinCount}명
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Draw List */}
          <div className="space-y-4">
            {currentDraws.map((draw) => (
              <div key={draw.drawNo} className="bg-white rounded-lg shadow hover:shadow-md transition-shadow p-6">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <span className="text-lg font-bold text-gray-800">
                        제 {draw.drawNo}회
                      </span>
                      <span className="text-sm text-gray-500">{draw.drawDate}</span>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      {draw.numbers.map((num, idx) => (
                        <div
                          key={idx}
                          className={`w-10 h-10 rounded-full ${getNumberColor(
                            num
                          )} text-white flex items-center justify-center font-bold shadow`}
                        >
                          {num}
                        </div>
                      ))}
                      <span className="text-gray-400 mx-1">+</span>
                      <div className="w-10 h-10 rounded-full bg-yellow-400 text-gray-800 flex items-center justify-center font-bold shadow">
                        {draw.bonusNum}
                      </div>
                    </div>
                  </div>
                  {draw.firstWinAmount && (
                    <div className="text-right">
                      <p className="text-xs text-gray-500">1등 당첨금</p>
                      <p className="text-lg font-bold text-purple-600">
                        {formatAmount(draw.firstWinAmount)}
                      </p>
                      {draw.firstWinCount && (
                        <p className="text-xs text-gray-500">
                          {draw.firstWinCount}명
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-2 mt-8">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-4 py-2 bg-white rounded-lg shadow disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
              >
                이전
              </button>
              <span className="px-4 py-2 bg-white rounded-lg shadow">
                {currentPage} / {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-4 py-2 bg-white rounded-lg shadow disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
              >
                다음
              </button>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
