'use client';

import { useState, useEffect } from 'react';
import Layout from '@/components/layout/Layout';
import { clientAnalytics } from '@/lib/analytics-client';
import { saveNumberSet } from '@/lib/storage';
import type { Algorithm } from '@/types/lotto';

interface NextDraw {
  nextDrawNo: number;
  nextDrawDate: string;
  nextDrawTime: string;
  dayOfWeek: string;
  status: 'waiting' | 'collecting';
  message: string;
}

export default function Home() {
  const [numbers, setNumbers] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);
  const [algorithm, setAlgorithm] = useState<Algorithm>('random');
  const [saveMessage, setSaveMessage] = useState<string>('');
  const [nextDraw, setNextDraw] = useState<NextDraw | null>(null);
  const [countdown, setCountdown] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  // Fetch next draw info
  useEffect(() => {
    fetch('/api/stats/dashboard-db')
      .then((res) => res.json())
      .then((json) => {
        if (json.success && json.data.nextDraw) {
          setNextDraw(json.data.nextDraw);
        }
      })
      .catch((err) => console.error('Failed to load next draw:', err));
  }, []);

  // Countdown timer
  useEffect(() => {
    if (!nextDraw || nextDraw.status !== 'waiting') return;

    const interval = setInterval(() => {
      const now = new Date();
      const target = new Date(`${nextDraw.nextDrawDate} ${nextDraw.nextDrawTime}`);
      const diff = target.getTime() - now.getTime();

      if (diff > 0) {
        setCountdown({
          days: Math.floor(diff / (1000 * 60 * 60 * 24)),
          hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((diff % (1000 * 60)) / 1000),
        });
      } else {
        setCountdown({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [nextDraw]);

  const generateNumbers = async () => {
    setLoading(true);
    const startTime = Date.now();

    try {
      const res = await fetch('/api/lotto/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ algorithm, count: 1 }),
      });

      const data = await res.json();

      if (data.success && data.data.numbers.length > 0) {
        const generatedNumbers = data.data.numbers[0];
        setNumbers(generatedNumbers);

        // Analytics: 번호 생성 성공 이벤트 추적
        await clientAnalytics.trackGeneration(algorithm, generatedNumbers, {
          duration_ms: Date.now() - startTime,
          success: true
        });
      } else {
        // Fallback to random generation
        const generated = new Set<number>();
        while (generated.size < 6) {
          const num = Math.floor(Math.random() * 45) + 1;
          generated.add(num);
        }
        const fallbackNumbers = Array.from(generated).sort((a, b) => a - b);
        setNumbers(fallbackNumbers);

        // Analytics: Fallback 이벤트 추적
        await clientAnalytics.trackGeneration('random', fallbackNumbers, {
          duration_ms: Date.now() - startTime,
          success: true,
          fallback: true
        });
      }
    } catch (error) {
      console.error('생성 오류:', error);

      // Analytics: 에러 추적
      await clientAnalytics.trackError(
        error instanceof Error ? error.message : 'Unknown error',
        'generation',
        {
          algorithm,
          duration_ms: Date.now() - startTime
        }
      );

      // Fallback to random generation
      const generated = new Set<number>();
      while (generated.size < 6) {
        const num = Math.floor(Math.random() * 45) + 1;
        generated.add(num);
      }
      const fallbackNumbers = Array.from(generated).sort((a, b) => a - b);
      setNumbers(fallbackNumbers);

      // Analytics: Fallback 이벤트 추적
      await clientAnalytics.trackGeneration('random', fallbackNumbers, {
        duration_ms: Date.now() - startTime,
        success: true,
        fallback: true,
        error: true
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = () => {
    if (numbers.length === 0) {
      setSaveMessage('저장할 번호가 없습니다');
      setTimeout(() => setSaveMessage(''), 2000);
      return;
    }

    try {
      saveNumberSet(numbers, algorithm);
      setSaveMessage('✓ 번호가 저장되었습니다');
      setTimeout(() => setSaveMessage(''), 2000);
    } catch (error) {
      console.error('저장 실패:', error);
      setSaveMessage('저장 실패');
      setTimeout(() => setSaveMessage(''), 2000);
    }
  };

  const algorithmLabels: Record<Algorithm, string> = {
    random: '완전 랜덤',
    frequency: '빈도 기반',
    pattern: '패턴 기반',
    'frequency-db': 'DB 빈출 번호',
    'low-frequency-db': 'DB 저빈도 번호',
    'recent-db': 'DB 최근 출현',
    'cold-db': 'DB 콜드 번호',
    'balanced-db': 'DB 균형 조합',
    'ai-mixed-db': 'DB AI 혼합',
  };

  const algorithmDescriptions: Record<Algorithm, string> = {
    random: '💫 1~45 중 완전 무작위로 6개 선택',
    frequency: '📊 출현 빈도가 높은 번호 중심으로 선택',
    pattern: '🎯 구간 분산 및 패턴 고려하여 선택',
    'frequency-db': '🔥 실제 당첨 데이터 기반 빈출 번호 (상위 60%)',
    'low-frequency-db': '🧊 실제 당첨 데이터 기반 저빈도 번호 (하위 60%)',
    'recent-db': '⚡ 최근 20회차 이내 출현한 번호 중심',
    'cold-db': '❄️ 최근 20회차 이상 미출현 콜드 번호',
    'balanced-db': '⚖️ 빈출 3개 + 저빈도 3개 균형 조합',
    'ai-mixed-db': '🤖 AI 기반 다중 전략 혼합 (빈출+최근+콜드)',
  };

  return (
    <Layout>
    <div className="min-h-screen bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-2xl w-full">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            🎰 LottoMaster
          </h1>
          <p className="text-gray-600">
            행운의 로또 번호를 생성해드립니다
          </p>
        </div>

        {/* Countdown Section */}
        {nextDraw && (
          <div className={`rounded-xl shadow-lg p-6 mb-8 transition-all ${
            nextDraw.status === 'waiting'
              ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
              : 'bg-gradient-to-r from-orange-500 to-red-500 text-white'
          }`}>
            {nextDraw.status === 'waiting' ? (
              <>
                <div className="text-center mb-4">
                  <h2 className="text-xl font-semibold mb-1">🎯 다음 추첨까지</h2>
                </div>

                <div className="flex justify-center gap-3 mb-4">
                  {/* Days */}
                  <div className="flex flex-col items-center rounded-lg p-3 min-w-[70px]">
                    <div className="text-3xl font-bold mb-1 text-white">{countdown.days}</div>
                    <div className="text-xs text-white">일</div>
                  </div>

                  {/* Hours */}
                  <div className="flex flex-col items-center rounded-lg p-3 min-w-[70px]">
                    <div className="text-3xl font-bold mb-1 text-white">{countdown.hours}</div>
                    <div className="text-xs text-white">시간</div>
                  </div>

                  {/* Minutes */}
                  <div className="flex flex-col items-center rounded-lg p-3 min-w-[70px]">
                    <div className="text-3xl font-bold mb-1 text-white">{countdown.minutes}</div>
                    <div className="text-xs text-white">분</div>
                  </div>

                  {/* Seconds */}
                  <div className="flex flex-col items-center rounded-lg p-3 min-w-[70px]">
                    <div className="text-3xl font-bold mb-1 text-white">{countdown.seconds}</div>
                    <div className="text-xs text-white">초</div>
                  </div>
                </div>

                <div className="text-center text-sm opacity-90">
                  제 {nextDraw.nextDrawNo}회 · {nextDraw.nextDrawDate} ({nextDraw.dayOfWeek}) {nextDraw.nextDrawTime}
                </div>
              </>
            ) : (
              <>
                <div className="text-center">
                  <h2 className="text-xl font-semibold mb-4">⏱️ 당첨번호 발표 대기중</h2>

                  <div className="flex justify-center gap-2 mb-4">
                    <div className="w-3 h-3 bg-white rounded-full animate-pulse"></div>
                    <div className="w-3 h-3 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-3 h-3 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                  </div>

                  <p className="text-sm opacity-90">
                    제 {nextDraw.nextDrawNo}회 당첨번호가 곧 발표됩니다
                  </p>
                </div>
              </>
            )}
          </div>
        )}

        {/* Algorithm Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            생성 알고리즘
          </label>
          <select
            value={algorithm}
            onChange={(e) => setAlgorithm(e.target.value as typeof algorithm)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            disabled={loading}
          >
            {(Object.keys(algorithmLabels) as Array<keyof typeof algorithmLabels>).map((key) => (
              <option key={key} value={key}>
                {algorithmLabels[key]}
              </option>
            ))}
          </select>
          <p className="text-xs text-gray-500 mt-2">
            {algorithmDescriptions[algorithm]}
          </p>
        </div>

        <div className="mb-8">
          {numbers.length > 0 ? (
            <div className="flex justify-center gap-3 flex-wrap">
              {numbers.map((num, idx) => (
                <div
                  key={idx}
                  className={`w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold shadow-lg transition-transform hover:scale-110 ${
                    num <= 10
                      ? 'bg-yellow-500'
                      : num <= 20
                      ? 'bg-blue-500'
                      : num <= 30
                      ? 'bg-red-500'
                      : num <= 40
                      ? 'bg-gray-700'
                      : 'bg-green-500'
                  }`}
                >
                  {num}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-gray-400 py-12">
              <p className="text-lg">번호를 생성해주세요</p>
            </div>
          )}
        </div>

        <div className="text-center space-y-3">
          <button
            onClick={generateNumbers}
            disabled={loading}
            className={`px-8 py-4 rounded-full text-white font-bold text-lg shadow-lg transition-all ${
              loading
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 hover:shadow-xl'
            }`}
          >
            {loading ? '생성 중...' : '🎲 행운의 번호 생성'}
          </button>

          {numbers.length > 0 && (
            <div className="flex flex-col items-center gap-2">
              <button
                onClick={handleSave}
                className="px-6 py-3 rounded-full bg-white text-purple-600 font-semibold border-2 border-purple-600 hover:bg-purple-50 shadow-md transition-all"
              >
                💾 이 번호 저장하기
              </button>
              {saveMessage && (
                <p className={`text-sm font-medium ${saveMessage.includes('✓') ? 'text-green-600' : 'text-red-600'}`}>
                  {saveMessage}
                </p>
              )}
            </div>
          )}
        </div>

        <div className="mt-8 text-center text-sm text-gray-500">
          <p>※ 생성된 번호는 참고용이며 당첨을 보장하지 않습니다</p>
        </div>

        {numbers.length > 0 && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="text-sm font-semibold text-gray-700 mb-2">
              📈 번호 분석
            </h3>
            <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
              <div>
                <span className="font-medium">홀수:</span>{' '}
                {numbers.filter((n) => n % 2 === 1).length}개
              </div>
              <div>
                <span className="font-medium">짝수:</span>{' '}
                {numbers.filter((n) => n % 2 === 0).length}개
              </div>
              <div>
                <span className="font-medium">저번호(1-22):</span>{' '}
                {numbers.filter((n) => n <= 22).length}개
              </div>
              <div>
                <span className="font-medium">고번호(23-45):</span>{' '}
                {numbers.filter((n) => n > 22).length}개
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
    </Layout>
  );
}
