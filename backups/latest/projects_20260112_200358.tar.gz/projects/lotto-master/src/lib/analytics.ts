import { getPool } from './db';

export interface TrackEventParams {
  eventType: string;
  eventCategory?: string;
  eventName: string;
  eventValue?: number;
  sessionId?: string;
  userId?: string;
  ipAddress?: string;
  userAgent?: string;
  pageUrl?: string;
  referrer?: string;
  deviceType?: 'mobile' | 'tablet' | 'desktop';
  metadata?: Record<string, any>;
}

/**
 * Analytics 클라이언트
 * - 논블로킹 방식으로 이벤트 추적
 * - 실패해도 메인 로직에 영향 없음
 */
class AnalyticsClient {
  private projectId: string = 'lotto-master';

  /**
   * 이벤트 추적 (논블로킹)
   * @returns true if successful, false otherwise
   */
  async trackEvent(params: TrackEventParams): Promise<boolean> {
    try {
      const pool = getPool();

      const result = await pool.query(`
        INSERT INTO public.analytics_events (
          project_id, event_type, event_category, event_name, event_value,
          session_id, user_id, ip_address, user_agent, page_url, referrer,
          device_type, metadata
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        RETURNING id
      `, [
        this.projectId,
        params.eventType,
        params.eventCategory || null,
        params.eventName,
        params.eventValue || null,
        params.sessionId || null,
        params.userId || null,
        params.ipAddress || null,
        params.userAgent || null,
        params.pageUrl || null,
        params.referrer || null,
        params.deviceType || null,
        params.metadata ? JSON.stringify(params.metadata) : null
      ]);

      return result.rowCount !== null && result.rowCount > 0;
    } catch (error) {
      // 통계 실패는 에러를 throw하지 않음 (논블로킹)
      console.error('[Analytics] Failed to track event:', error);
      return false;
    }
  }

  /**
   * 페이지뷰 추적
   */
  async trackPageView(pageUrl: string, options?: Partial<TrackEventParams>): Promise<void> {
    await this.trackEvent({
      eventType: 'pageview',
      eventCategory: 'navigation',
      eventName: 'page_view',
      pageUrl,
      ...options
    });
  }

  /**
   * 번호 생성 이벤트 추적
   */
  async trackGeneration(
    algorithm: string,
    numbers: number[],
    sessionId: string,
    options?: Partial<TrackEventParams>
  ): Promise<void> {
    const startTime = Date.now();

    // analytics_events 테이블에 이벤트 기록
    await this.trackEvent({
      eventType: 'generation',
      eventCategory: 'lotto',
      eventName: 'number_generated',
      sessionId,
      metadata: {
        algorithm,
        numbers,
        count: numbers.length,
        duration_ms: Date.now() - startTime,
        success: true
      },
      ...options
    });

    // generation_history 테이블에 상세 기록 저장
    try {
      const pool = getPool();
      await pool.query(`
        INSERT INTO lotto.generation_history (session_id, algorithm, generated_numbers)
        VALUES ($1, $2, $3)
      `, [sessionId, algorithm, numbers]);
    } catch (error) {
      console.error('[Analytics] Failed to save generation history:', error);
    }
  }

  /**
   * API 호출 로깅
   */
  async logApiCall(
    method: string,
    endpoint: string,
    statusCode: number,
    responseTimeMs: number,
    options?: {
      ipAddress?: string;
      userAgent?: string;
      sessionId?: string;
      errorMessage?: string;
    }
  ): Promise<void> {
    try {
      const pool = getPool();

      await pool.query(`
        INSERT INTO public.api_logs (
          project_id, method, endpoint, status_code, response_time_ms,
          ip_address, user_agent, session_id, error_message
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      `, [
        this.projectId,
        method,
        endpoint,
        statusCode,
        responseTimeMs,
        options?.ipAddress || null,
        options?.userAgent || null,
        options?.sessionId || null,
        options?.errorMessage || null
      ]);
    } catch (error) {
      console.error('[Analytics] Failed to log API call:', error);
    }
  }

  /**
   * 에러 추적
   */
  async trackError(
    errorMessage: string,
    errorCategory: string,
    sessionId?: string,
    metadata?: Record<string, any>
  ): Promise<void> {
    await this.trackEvent({
      eventType: 'error',
      eventCategory: errorCategory,
      eventName: 'error_occurred',
      sessionId,
      metadata: {
        ...metadata,
        error: errorMessage
      }
    });
  }
}

// 싱글톤 인스턴스 export
export const analytics = new AnalyticsClient();
