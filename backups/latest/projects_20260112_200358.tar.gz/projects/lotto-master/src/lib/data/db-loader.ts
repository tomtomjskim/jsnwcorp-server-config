/**
 * PostgreSQL 데이터베이스에서 로또 데이터 로드
 */

import { query } from '@/lib/db';
import type { DrawResult, NumberStat } from '@/types/lotto';

/**
 * 특정 회차 조회
 */
export async function getDrawByNumber(drawNo: number): Promise<DrawResult | null> {
  try {
    const result = await query<{
      draw_no: number;
      draw_date: string;
      num1: number;
      num2: number;
      num3: number;
      num4: number;
      num5: number;
      num6: number;
      bonus_num: number;
      first_win_amount: number | null;
      first_win_count: number | null;
    }>(
      `SELECT
        draw_no, draw_date,
        num1, num2, num3, num4, num5, num6,
        bonus_num, first_win_amount, first_win_count
      FROM lotto.draws
      WHERE draw_no = $1`,
      [drawNo]
    );

    if (result.rows.length === 0) {
      return null;
    }

    const row = result.rows[0];
    return {
      drawNo: row.draw_no,
      drawDate: row.draw_date,
      numbers: [row.num1, row.num2, row.num3, row.num4, row.num5, row.num6].sort((a, b) => a - b),
      bonusNum: row.bonus_num,
      firstWinAmount: row.first_win_amount,
      firstWinCount: row.first_win_count,
    };
  } catch (error) {
    console.error('[DB Loader] getDrawByNumber error:', error);
    return null;
  }
}

/**
 * 최근 N회차 조회
 */
export async function getRecentDraws(limit: number = 10): Promise<DrawResult[]> {
  try {
    const result = await query<{
      draw_no: number;
      draw_date: string;
      num1: number;
      num2: number;
      num3: number;
      num4: number;
      num5: number;
      num6: number;
      bonus_num: number;
      first_win_amount: number | null;
      first_win_count: number | null;
    }>(
      `SELECT
        draw_no, draw_date,
        num1, num2, num3, num4, num5, num6,
        bonus_num, first_win_amount, first_win_count
      FROM lotto.draws
      ORDER BY draw_no DESC
      LIMIT $1`,
      [limit]
    );

    return result.rows.map(row => ({
      drawNo: row.draw_no,
      drawDate: row.draw_date,
      numbers: [row.num1, row.num2, row.num3, row.num4, row.num5, row.num6].sort((a, b) => a - b),
      bonusNum: row.bonus_num,
      firstWinAmount: row.first_win_amount,
      firstWinCount: row.first_win_count,
    }));
  } catch (error) {
    console.error('[DB Loader] getRecentDraws error:', error);
    return [];
  }
}

/**
 * 전체 회차 수 조회
 */
export async function getTotalDrawsCount(): Promise<number> {
  try {
    const result = await query<{ count: string }>(
      'SELECT COUNT(*) as count FROM lotto.draws'
    );
    return parseInt(result.rows[0].count);
  } catch (error) {
    console.error('[DB Loader] getTotalDrawsCount error:', error);
    return 0;
  }
}

/**
 * 최신 회차 번호 조회
 */
export async function getLatestDrawNo(): Promise<number> {
  try {
    const result = await query<{ max_draw: number }>(
      'SELECT MAX(draw_no) as max_draw FROM lotto.draws'
    );
    return result.rows[0].max_draw || 0;
  } catch (error) {
    console.error('[DB Loader] getLatestDrawNo error:', error);
    return 0;
  }
}

/**
 * 최신 회차 전체 정보 조회
 */
export async function getLatestDraw(): Promise<DrawResult | null> {
  try {
    const result = await query<{
      draw_no: number;
      draw_date: string;
      num1: number;
      num2: number;
      num3: number;
      num4: number;
      num5: number;
      num6: number;
      bonus_num: number;
      first_win_amount: number | null;
      first_win_count: number | null;
    }>(
      `SELECT
        draw_no, draw_date,
        num1, num2, num3, num4, num5, num6,
        bonus_num, first_win_amount, first_win_count
      FROM lotto.draws
      ORDER BY draw_no DESC
      LIMIT 1`
    );

    if (result.rows.length === 0) {
      return null;
    }

    const row = result.rows[0];
    return {
      drawNo: row.draw_no,
      drawDate: row.draw_date,
      numbers: [row.num1, row.num2, row.num3, row.num4, row.num5, row.num6].sort((a, b) => a - b),
      bonusNum: row.bonus_num,
      firstWinAmount: row.first_win_amount,
      firstWinCount: row.first_win_count,
    };
  } catch (error) {
    console.error('[DB Loader] getLatestDraw error:', error);
    return null;
  }
}

/**
 * 전체 추첨 데이터 조회 (페이지네이션)
 */
export async function getAllDraws(offset: number = 0, limit: number = 100): Promise<DrawResult[]> {
  try {
    const result = await query<{
      draw_no: number;
      draw_date: string;
      num1: number;
      num2: number;
      num3: number;
      num4: number;
      num5: number;
      num6: number;
      bonus_num: number;
      first_win_amount: number | null;
      first_win_count: number | null;
    }>(
      `SELECT
        draw_no, draw_date,
        num1, num2, num3, num4, num5, num6,
        bonus_num, first_win_amount, first_win_count
      FROM lotto.draws
      ORDER BY draw_no DESC
      LIMIT $1 OFFSET $2`,
      [limit, offset]
    );

    return result.rows.map(row => ({
      drawNo: row.draw_no,
      drawDate: row.draw_date,
      numbers: [row.num1, row.num2, row.num3, row.num4, row.num5, row.num6].sort((a, b) => a - b),
      bonusNum: row.bonus_num,
      firstWinAmount: row.first_win_amount,
      firstWinCount: row.first_win_count,
    }));
  } catch (error) {
    console.error('[DB Loader] getAllDraws error:', error);
    return [];
  }
}

/**
 * 번호별 통계 계산
 */
export async function calculateNumberStats(): Promise<NumberStat[]> {
  try {
    // 초기 통계 배열 생성 (1-45번)
    const stats: NumberStat[] = Array.from({ length: 45 }, (_, i) => ({
      number: i + 1,
      totalCount: 0,
      bonusCount: 0,
      lastDrawNo: null,
      lastDrawDate: null,
    }));

    // 일반 번호 통계
    const numberStats = await query<{
      num: number;
      count: string;
      last_draw_no: number;
      last_draw_date: string;
    }>(`
      WITH all_numbers AS (
        SELECT draw_no, draw_date, num1 as num FROM lotto.draws
        UNION ALL
        SELECT draw_no, draw_date, num2 FROM lotto.draws
        UNION ALL
        SELECT draw_no, draw_date, num3 FROM lotto.draws
        UNION ALL
        SELECT draw_no, draw_date, num4 FROM lotto.draws
        UNION ALL
        SELECT draw_no, draw_date, num5 FROM lotto.draws
        UNION ALL
        SELECT draw_no, draw_date, num6 FROM lotto.draws
      )
      SELECT
        num,
        COUNT(*) as count,
        MAX(draw_no) as last_draw_no,
        MAX(draw_date) as last_draw_date
      FROM all_numbers
      GROUP BY num
      ORDER BY num
    `);

    // 일반 번호 통계 적용
    numberStats.rows.forEach(row => {
      const idx = row.num - 1;
      stats[idx].totalCount = parseInt(row.count);
      stats[idx].lastDrawNo = row.last_draw_no;
      stats[idx].lastDrawDate = row.last_draw_date;
    });

    // 보너스 번호 통계
    const bonusStats = await query<{
      bonus_num: number;
      count: string;
    }>(`
      SELECT
        bonus_num,
        COUNT(*) as count
      FROM lotto.draws
      GROUP BY bonus_num
      ORDER BY bonus_num
    `);

    // 보너스 번호 통계 적용
    bonusStats.rows.forEach(row => {
      const idx = row.bonus_num - 1;
      stats[idx].bonusCount = parseInt(row.count);
    });

    return stats;
  } catch (error) {
    console.error('[DB Loader] calculateNumberStats error:', error);
    // 에러 시 빈 통계 반환
    return Array.from({ length: 45 }, (_, i) => ({
      number: i + 1,
      totalCount: 0,
      bonusCount: 0,
      lastDrawNo: null,
      lastDrawDate: null,
    }));
  }
}

/**
 * 홀짝 비율 계산
 */
export async function calculateOddEvenRatio(): Promise<{ odd: number; even: number }> {
  try {
    const stats = await calculateNumberStats();

    const oddCount = stats
      .filter((s) => s.number % 2 === 1)
      .reduce((sum, s) => sum + s.totalCount, 0);

    const evenCount = stats
      .filter((s) => s.number % 2 === 0)
      .reduce((sum, s) => sum + s.totalCount, 0);

    const total = oddCount + evenCount;

    return {
      odd: total > 0 ? (oddCount / total) * 100 : 0,
      even: total > 0 ? (evenCount / total) * 100 : 0,
    };
  } catch (error) {
    console.error('[DB Loader] calculateOddEvenRatio error:', error);
    return { odd: 0, even: 0 };
  }
}

/**
 * 고저 비율 계산 (1-22: 저, 23-45: 고)
 */
export async function calculateHighLowRatio(): Promise<{ low: number; high: number }> {
  try {
    const stats = await calculateNumberStats();

    const lowCount = stats
      .filter((s) => s.number <= 22)
      .reduce((sum, s) => sum + s.totalCount, 0);

    const highCount = stats
      .filter((s) => s.number >= 23)
      .reduce((sum, s) => sum + s.totalCount, 0);

    const total = lowCount + highCount;

    return {
      low: total > 0 ? (lowCount / total) * 100 : 0,
      high: total > 0 ? (highCount / total) * 100 : 0,
    };
  } catch (error) {
    console.error('[DB Loader] calculateHighLowRatio error:', error);
    return { low: 0, high: 0 };
  }
}
