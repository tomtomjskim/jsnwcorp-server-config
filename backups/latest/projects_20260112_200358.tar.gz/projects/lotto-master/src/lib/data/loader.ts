import lottoData from '@/public/data/lotto-data.json'
import type { DrawResult, LottoData, NumberStat } from '@/types/lotto'

// 전체 데이터
export function getLottoData(): LottoData {
  return lottoData as LottoData
}

// 특정 회차 조회
export function getDrawByNumber(drawNo: number): DrawResult | undefined {
  return lottoData.draws.find((d) => d.drawNo === drawNo) as DrawResult | undefined
}

// 최근 N회차 조회
export function getRecentDraws(limit: number = 10): DrawResult[] {
  return lottoData.draws.slice(0, Math.min(limit, lottoData.draws.length)) as DrawResult[]
}

// 번호별 통계 계산
export function calculateNumberStats(): NumberStat[] {
  const stats: NumberStat[] = Array.from({ length: 45 }, (_, i) => ({
    number: i + 1,
    totalCount: 0,
    bonusCount: 0,
    lastDrawNo: null,
    lastDrawDate: null,
  }))

  lottoData.draws.forEach((draw) => {
    // 일반 번호
    draw.numbers.forEach((num) => {
      stats[num - 1].totalCount++
      stats[num - 1].lastDrawNo = draw.drawNo
      stats[num - 1].lastDrawDate = draw.drawDate
    })

    // 보너스 번호
    stats[draw.bonusNum - 1].bonusCount++
  })

  return stats
}

// 홀짝 비율 계산
export function calculateOddEvenRatio(): { odd: number; even: number } {
  const stats = calculateNumberStats()

  const oddCount = stats
    .filter((s) => s.number % 2 === 1)
    .reduce((sum, s) => sum + s.totalCount, 0)

  const evenCount = stats
    .filter((s) => s.number % 2 === 0)
    .reduce((sum, s) => sum + s.totalCount, 0)

  const total = oddCount + evenCount

  return {
    odd: total > 0 ? (oddCount / total) * 100 : 0,
    even: total > 0 ? (evenCount / total) * 100 : 0,
  }
}

// 고저 비율 계산 (1-22: 저, 23-45: 고)
export function calculateHighLowRatio(): { low: number; high: number } {
  const stats = calculateNumberStats()

  const lowCount = stats
    .filter((s) => s.number <= 22)
    .reduce((sum, s) => sum + s.totalCount, 0)

  const highCount = stats
    .filter((s) => s.number >= 23)
    .reduce((sum, s) => sum + s.totalCount, 0)

  const total = lowCount + highCount

  return {
    low: total > 0 ? (lowCount / total) * 100 : 0,
    high: total > 0 ? (highCount / total) * 100 : 0,
  }
}
