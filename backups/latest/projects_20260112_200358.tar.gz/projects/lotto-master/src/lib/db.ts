import { Pool, PoolConfig, QueryResult, QueryResultRow } from 'pg';

const poolConfig: PoolConfig = {
  host: process.env.POSTGRES_HOST || 'postgres',
  port: parseInt(process.env.POSTGRES_PORT || '5432'),
  database: process.env.POSTGRES_DB || 'maindb',
  user: process.env.POSTGRES_USER || 'lotto_user',
  password: process.env.POSTGRES_PASSWORD,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000, // Increased from 2000ms to 10000ms (10 seconds)
  options: `-c search_path=${process.env.POSTGRES_SCHEMA || 'lotto'},public`
};

let pool: Pool | null = null;

/**
 * PostgreSQL Connection Pool 가져오기 (싱글톤)
 */
export function getPool(): Pool {
  if (!pool) {
    pool = new Pool(poolConfig);

    pool.on('error', (err) => {
      console.error('[DB] Unexpected error on idle client:', err);
    });

    console.log('[DB] PostgreSQL pool created');
  }

  return pool;
}

/**
 * 쿼리 실행 (성능 로깅 포함)
 */
export async function query<T extends QueryResultRow = any>(text: string, params?: any[]): Promise<QueryResult<T>> {
  const start = Date.now();
  const client = getPool();

  try {
    const result = await client.query<T>(text, params);
    const duration = Date.now() - start;

    if (process.env.NODE_ENV !== 'production') {
      console.log('[DB]', {
        query: text.substring(0, 100),
        duration: `${duration}ms`,
        rows: result.rowCount
      });
    }

    return result;
  } catch (error) {
    console.error('[DB Error]', { query: text, error });
    throw error;
  }
}

/**
 * 데이터베이스 연결 테스트
 */
export async function testConnection(): Promise<boolean> {
  try {
    const result = await query<{ now: Date; current_database: string; current_user: string }>(
      'SELECT NOW() as now, current_database(), current_user'
    );
    console.log('[DB] ✅ Connection successful:', result.rows[0]);
    return true;
  } catch (error) {
    console.error('[DB] ❌ Connection failed:', error);
    return false;
  }
}

/**
 * Pool 종료 (graceful shutdown용)
 */
export async function closePool(): Promise<void> {
  if (pool) {
    await pool.end();
    pool = null;
    console.log('[DB] Pool closed');
  }
}
