// 기존 동기 알고리즘
export { generateRandomNumbers } from './random'
export { generateFrequencyNumbers } from './frequency'
export { generatePatternNumbers } from './pattern'

// 새로운 DB 기반 비동기 알고리즘
export { generateFrequencyNumbersDB } from './frequency-db'
export { generateLowFrequencyNumbersDB } from './low-frequency-db'
export { generateRecentNumbersDB } from './recent-db'
export { generateColdNumbersDB } from './cold-db'
export { generateBalancedNumbersDB } from './balanced-db'
export { generateAIMixedNumbersDB } from './ai-mixed-db'

import type { Algorithm } from '@/types/lotto'
import { generateRandomNumbers } from './random'
import { generateFrequencyNumbers } from './frequency'
import { generatePatternNumbers } from './pattern'
import { generateFrequencyNumbersDB } from './frequency-db'
import { generateLowFrequencyNumbersDB } from './low-frequency-db'
import { generateRecentNumbersDB } from './recent-db'
import { generateColdNumbersDB } from './cold-db'
import { generateBalancedNumbersDB } from './balanced-db'
import { generateAIMixedNumbersDB } from './ai-mixed-db'

/**
 * 알고리즘 선택하여 번호 생성 (동기)
 * 기존 JSON 기반 알고리즘용
 */
export function generateNumbers(algorithm: Algorithm = 'random'): number[] {
  switch (algorithm) {
    case 'frequency':
      return generateFrequencyNumbers()
    case 'pattern':
      return generatePatternNumbers()
    case 'random':
    default:
      return generateRandomNumbers()
  }
}

/**
 * 알고리즘 선택하여 번호 생성 (비동기)
 * DB 기반 및 모든 알고리즘 지원
 */
export async function generateNumbersAsync(
  algorithm: Algorithm = 'random'
): Promise<number[]> {
  switch (algorithm) {
    // DB 기반 알고리즘
    case 'frequency-db':
      return await generateFrequencyNumbersDB()
    case 'low-frequency-db':
      return await generateLowFrequencyNumbersDB()
    case 'recent-db':
      return await generateRecentNumbersDB()
    case 'cold-db':
      return await generateColdNumbersDB()
    case 'balanced-db':
      return await generateBalancedNumbersDB()
    case 'ai-mixed-db':
      return await generateAIMixedNumbersDB()

    // 기존 동기 알고리즘
    case 'frequency':
      return generateFrequencyNumbers()
    case 'pattern':
      return generatePatternNumbers()
    case 'random':
    default:
      return generateRandomNumbers()
  }
}
