/**
 * 패턴 기반 번호 생성
 * - 홀짝 비율 고려 (3:3 또는 4:2)
 * - 구간 분산 (1-15, 16-30, 31-45)
 * - 연속 번호 제한
 */
export function generatePatternNumbers(): number[] {
  const numbers: number[] = []

  // 1. 구간별 분산 (각 구간에서 2개씩)
  const ranges = [
    { min: 1, max: 15, count: 2 },
    { min: 16, max: 30, count: 2 },
    { min: 31, max: 45, count: 2 },
  ]

  ranges.forEach((range) => {
    const rangeNumbers = new Set<number>()
    while (rangeNumbers.size < range.count) {
      const num =
        Math.floor(Math.random() * (range.max - range.min + 1)) + range.min
      rangeNumbers.add(num)
    }
    numbers.push(...rangeNumbers)
  })

  // 2. 정렬
  const sorted = numbers.sort((a, b) => a - b)

  // 3. 연속 번호 체크 및 조정 (선택적)
  // 현재는 구간 분산만 적용

  return sorted
}
