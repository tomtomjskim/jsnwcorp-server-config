import {
  calculateNumberStats,
  calculateOddEvenRatio,
  getLatestDrawNo,
} from '@/lib/data/db-loader';

/**
 * DB 기반 AI 혼합 번호 생성
 *
 * 다양한 통계를 고려한 종합 전략:
 * - 빈출 번호 (30% 확률)
 * - 저빈도 번호 (20% 확률)
 * - 최근 출현 번호 (25% 확률)
 * - 콜드 번호 (25% 확률)
 * - 홀짝 비율 고려 (3:3 또는 4:2)
 * - 구간 분산 (저/중/고)
 */
export async function generateAIMixedNumbersDB(): Promise<number[]> {
  const [stats, oddEvenRatio, latestDrawNo] = await Promise.all([
    calculateNumberStats(),
    calculateOddEvenRatio(),
    getLatestDrawNo(),
  ]);

  // 출현 빈도순 정렬
  const sortedByFreq = [...stats].sort((a, b) => b.totalCount - a.totalCount);

  // 1. 빈출 풀 (상위 15개)
  const topFrequent = sortedByFreq.slice(0, 15);

  // 2. 저빈도 풀 (하위 15개)
  const lowFrequent = sortedByFreq.slice(-15);

  // 3. 최근 출현 풀 (최근 10회 이내)
  const recentNumbers = stats.filter(
    (s) => s.lastDrawNo && latestDrawNo - s.lastDrawNo <= 10
  );

  // 4. 콜드 풀 (20회 이상 미출현)
  const coldNumbers = stats.filter(
    (s) => s.lastDrawNo && latestDrawNo - s.lastDrawNo >= 20
  );

  const selected = new Set<number>();

  // 전략별 번호 선택
  const strategies = [
    { pool: topFrequent, count: 2, name: '빈출' }, // 2개
    { pool: lowFrequent, count: 1, name: '저빈도' }, // 1개
    { pool: recentNumbers, count: 2, name: '최근' }, // 2개
    { pool: coldNumbers, count: 1, name: '콜드' }, // 1개
  ];

  for (const strategy of strategies) {
    let attempts = 0;
    const maxAttempts = 100;

    while (selected.size < 6 && attempts < maxAttempts) {
      attempts++;

      const availablePool = strategy.pool.filter((s) => !selected.has(s.number));

      if (availablePool.length === 0) {
        // 해당 풀이 비었으면 전체에서 랜덤 선택
        const allAvailable = stats.filter((s) => !selected.has(s.number));
        if (allAvailable.length > 0) {
          const randomIndex = Math.floor(Math.random() * allAvailable.length);
          selected.add(allAvailable[randomIndex].number);
        }
        break;
      }

      const needed = Math.min(strategy.count, 6 - selected.size);

      for (let i = 0; i < needed && selected.size < 6; i++) {
        const randomIndex = Math.floor(Math.random() * availablePool.length);
        selected.add(availablePool[randomIndex].number);
      }

      if (selected.size >= 6) break;
    }

    if (selected.size >= 6) break;
  }

  // 6개 미만이면 랜덤으로 채우기
  while (selected.size < 6) {
    const randomNum = Math.floor(Math.random() * 45) + 1;
    selected.add(randomNum);
  }

  const result = Array.from(selected).sort((a, b) => a - b);

  // 홀짝 비율 체크 (참고용 로그)
  const oddCount = result.filter((n) => n % 2 === 1).length;
  const evenCount = result.filter((n) => n % 2 === 0).length;

  console.log(
    `[AI Mixed] 선택된 번호: ${result.join(', ')} | 홀:${oddCount} 짝:${evenCount}`
  );

  return result;
}
