import { calculateNumberStats } from '@/lib/data/db-loader';

/**
 * DB 기반 빈도 낮은 번호 생성
 * 출현 빈도가 낮은 하위 60% 번호 중에서 랜덤 선택
 *
 * 전략: "언젠가는 나올 것이다" - 평균 회귀 이론
 */
export async function generateLowFrequencyNumbersDB(): Promise<number[]> {
  const stats = await calculateNumberStats();

  // 출현 빈도 역순 정렬 (낮은 것부터)
  const sorted = [...stats].sort((a, b) => a.totalCount - b.totalCount);

  // 하위 60% 저빈도 번호
  const lowCount = Math.ceil(45 * 0.6); // 27개
  const lowNumbers = sorted.slice(0, lowCount);

  // 랜덤 선택 (6개)
  const selected = new Set<number>();
  while (selected.size < 6) {
    const randomIndex = Math.floor(Math.random() * lowNumbers.length);
    selected.add(lowNumbers[randomIndex].number);
  }

  return Array.from(selected).sort((a, b) => a - b);
}
