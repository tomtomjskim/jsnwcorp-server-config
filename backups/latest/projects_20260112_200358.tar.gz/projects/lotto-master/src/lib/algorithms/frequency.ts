import { calculateNumberStats } from '@/lib/data/loader'

/**
 * 빈도 기반 번호 생성
 * 출현 빈도가 높은 상위 60% 번호 중에서 가중 랜덤 선택
 */
export function generateFrequencyNumbers(): number[] {
  const stats = calculateNumberStats()

  // 출현 빈도순 정렬
  const sorted = [...stats].sort((a, b) => b.totalCount - a.totalCount)

  // 상위 60% 빈출 번호
  const topCount = Math.ceil(45 * 0.6) // 27개
  const topNumbers = sorted.slice(0, topCount)

  // 가중 랜덤 선택 (6개)
  const selected = new Set<number>()
  while (selected.size < 6) {
    const randomIndex = Math.floor(Math.random() * topNumbers.length)
    selected.add(topNumbers[randomIndex].number)
  }

  return Array.from(selected).sort((a, b) => a - b)
}
