import { calculateNumberStats } from '@/lib/data/db-loader';

/**
 * DB 기반 균형 번호 생성
 * 빈출 번호 3개 + 저빈도 번호 3개 조합
 *
 * 전략: "밸런스" - 자주 나온 것과 덜 나온 것의 조화
 */
export async function generateBalancedNumbersDB(): Promise<number[]> {
  const stats = await calculateNumberStats();

  // 출현 빈도순 정렬
  const sorted = [...stats].sort((a, b) => b.totalCount - a.totalCount);

  // 상위 15개 (빈출)
  const topNumbers = sorted.slice(0, 15);

  // 하위 15개 (저빈도)
  const lowNumbers = sorted.slice(-15).reverse();

  // 빈출 3개 선택
  const selectedTop = new Set<number>();
  while (selectedTop.size < 3) {
    const randomIndex = Math.floor(Math.random() * topNumbers.length);
    selectedTop.add(topNumbers[randomIndex].number);
  }

  // 저빈도 3개 선택
  const selectedLow = new Set<number>();
  while (selectedLow.size < 3) {
    const randomIndex = Math.floor(Math.random() * lowNumbers.length);
    const num = lowNumbers[randomIndex].number;
    if (!selectedTop.has(num)) {
      selectedLow.add(num);
    }
  }

  // 합치기
  const combined = [...Array.from(selectedTop), ...Array.from(selectedLow)];

  return combined.sort((a, b) => a - b);
}
