import { calculateNumberStats, getLatestDrawNo } from '@/lib/data/db-loader';

/**
 * DB 기반 최근 출현 번호 생성
 * 최근 출현한 번호 중에서 선택
 *
 * 전략: "핫 스트릭" - 최근에 나온 번호가 또 나올 수 있다
 */
export async function generateRecentNumbersDB(): Promise<number[]> {
  const [stats, latestDrawNo] = await Promise.all([
    calculateNumberStats(),
    getLatestDrawNo(),
  ]);

  // lastDrawNo 기준으로 최근 출현 순 정렬
  const sorted = [...stats]
    .filter((s) => s.lastDrawNo !== null)
    .sort((a, b) => (b.lastDrawNo || 0) - (a.lastDrawNo || 0));

  // 최근 20회 이내 출현한 번호들
  const recentNumbers = sorted.filter(
    (s) => latestDrawNo - (s.lastDrawNo || 0) <= 20
  );

  // 선택할 번호 풀 (최소 15개 확보)
  const candidatePool =
    recentNumbers.length >= 15 ? recentNumbers.slice(0, 25) : sorted.slice(0, 30);

  // 랜덤 선택 (6개)
  const selected = new Set<number>();
  while (selected.size < 6) {
    const randomIndex = Math.floor(Math.random() * candidatePool.length);
    selected.add(candidatePool[randomIndex].number);
  }

  return Array.from(selected).sort((a, b) => a - b);
}
