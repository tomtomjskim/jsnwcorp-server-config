/**
 * 완전 랜덤 번호 생성
 * 1~45 범위에서 중복 없이 6개 번호 추출
 */
export function generateRandomNumbers(): number[] {
  const numbers = new Set<number>()

  while (numbers.size < 6) {
    const num = Math.floor(Math.random() * 45) + 1
    numbers.add(num)
  }

  return Array.from(numbers).sort((a, b) => a - b)
}
