import { calculateNumberStats, getLatestDrawNo } from '@/lib/data/db-loader';

/**
 * DB 기반 콜드 번호 생성
 * 오래 출현하지 않은 번호 중에서 선택
 *
 * 전략: "Due Theory" - 오래 안나온 번호가 곧 나올 것이다
 */
export async function generateColdNumbersDB(): Promise<number[]> {
  const [stats, latestDrawNo] = await Promise.all([
    calculateNumberStats(),
    getLatestDrawNo(),
  ]);

  // 미출현 기간이 긴 순서로 정렬
  const sorted = [...stats]
    .filter((s) => s.lastDrawNo !== null)
    .sort((a, b) => {
      const aGap = latestDrawNo - (a.lastDrawNo || 0);
      const bGap = latestDrawNo - (b.lastDrawNo || 0);
      return bGap - aGap; // 내림차순 (오래된 것부터)
    });

  // 상위 30개 콜드 번호
  const coldNumbers = sorted.slice(0, 30);

  // 랜덤 선택 (6개)
  const selected = new Set<number>();
  while (selected.size < 6) {
    const randomIndex = Math.floor(Math.random() * coldNumbers.length);
    selected.add(coldNumbers[randomIndex].number);
  }

  return Array.from(selected).sort((a, b) => a - b);
}
