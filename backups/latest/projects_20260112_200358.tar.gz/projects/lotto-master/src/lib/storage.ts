/**
 * localStorage를 사용한 로또 번호 저장 관리
 */

export interface SavedNumberSet {
  id: string;
  numbers: number[];
  algorithm: string;
  timestamp: number;
  label?: string;
}

const STORAGE_KEY = 'lotto_saved_numbers';

/**
 * 브라우저 환경 확인
 */
function isBrowser(): boolean {
  return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
}

/**
 * 저장된 번호 세트 모두 가져오기
 */
export function getSavedNumbers(): SavedNumberSet[] {
  if (!isBrowser()) return [];

  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return [];

    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error('[Storage] Failed to get saved numbers:', error);
    return [];
  }
}

/**
 * 번호 세트 저장
 */
export function saveNumberSet(numbers: number[], algorithm: string, label?: string): SavedNumberSet {
  if (!isBrowser()) {
    throw new Error('localStorage is not available');
  }

  const newSet: SavedNumberSet = {
    id: `lotto_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    numbers: [...numbers].sort((a, b) => a - b),
    algorithm,
    timestamp: Date.now(),
    label
  };

  try {
    const saved = getSavedNumbers();
    saved.unshift(newSet); // 최신 항목을 앞에 추가

    // 최대 50개까지만 저장
    const trimmed = saved.slice(0, 50);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));

    return newSet;
  } catch (error) {
    console.error('[Storage] Failed to save number set:', error);
    throw error;
  }
}

/**
 * 여러 번호 세트 한번에 저장
 */
export function saveMultipleNumberSets(
  numberSets: number[][],
  algorithm: string
): SavedNumberSet[] {
  if (!isBrowser()) {
    throw new Error('localStorage is not available');
  }

  try {
    const saved = getSavedNumbers();
    const newSets: SavedNumberSet[] = [];

    numberSets.forEach((numbers, index) => {
      const newSet: SavedNumberSet = {
        id: `lotto_${Date.now()}_${index}_${Math.random().toString(36).substr(2, 9)}`,
        numbers: [...numbers].sort((a, b) => a - b),
        algorithm,
        timestamp: Date.now(),
        label: `세트 ${index + 1}`
      };
      newSets.push(newSet);
    });

    // 최신 항목을 앞에 추가
    const updated = [...newSets, ...saved].slice(0, 50);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));

    return newSets;
  } catch (error) {
    console.error('[Storage] Failed to save multiple number sets:', error);
    throw error;
  }
}

/**
 * 특정 번호 세트 삭제
 */
export function deleteNumberSet(id: string): boolean {
  if (!isBrowser()) return false;

  try {
    const saved = getSavedNumbers();
    const filtered = saved.filter(set => set.id !== id);

    if (filtered.length === saved.length) {
      return false; // 삭제할 항목을 찾지 못함
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
    return true;
  } catch (error) {
    console.error('[Storage] Failed to delete number set:', error);
    return false;
  }
}

/**
 * 모든 저장된 번호 삭제
 */
export function clearAllSavedNumbers(): boolean {
  if (!isBrowser()) return false;

  try {
    localStorage.removeItem(STORAGE_KEY);
    return true;
  } catch (error) {
    console.error('[Storage] Failed to clear saved numbers:', error);
    return false;
  }
}

/**
 * 특정 ID의 번호 세트 가져오기
 */
export function getNumberSetById(id: string): SavedNumberSet | null {
  const saved = getSavedNumbers();
  return saved.find(set => set.id === id) || null;
}

/**
 * 저장된 번호 개수
 */
export function getSavedNumbersCount(): number {
  return getSavedNumbers().length;
}
