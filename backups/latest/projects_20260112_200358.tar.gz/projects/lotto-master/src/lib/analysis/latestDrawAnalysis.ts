/**
 * 최신 회차 심층 분석 서비스
 *
 * 로또 최신 회차 당첨번호에 대한 다차원 통계 분석을 수행합니다.
 * - 기본 통계 (평균, 합계, 범위, 표준편차 등)
 * - 분포 분석 (홀짝, 고저, 구간별)
 * - 패턴 분석 (연속 번호, 반복성)
 * - 빈도 분석 (역대 출현 빈도 기준)
 * - 희귀도 점수 (0-100점)
 * - 유사 회차 검색
 * - 비교 분석 (이론값, 역대 평균, 최근 트렌드)
 */

import { getPool } from '@/lib/db';

// Helper to get pool instance
let poolInstance: Awaited<ReturnType<typeof getPool>> | null = null;
async function getPoolInstance() {
  if (!poolInstance) {
    poolInstance = await getPool();
  }
  return poolInstance;
}

// ============================================================
// Type Definitions
// ============================================================

export interface BasicStats {
  average: number;
  sum: number;
  range: number;
  median: number;
  standardDeviation: number;
  variance: number;
}

export interface DistributionAnalysis {
  oddEven: {
    odd: number;
    even: number;
    oddPercentage: number;
    evenPercentage: number;
    ratio: string;
    expected: string;
    deviation: string;
    balance: string;
  };
  highLow: {
    low: number;
    high: number;
    lowPercentage: number;
    highPercentage: number;
    ratio: string;
    expected: string;
    deviation: string;
    balance: string;
  };
  ranges: Array<{
    range: string;
    count: number;
    percentage: number;
    numbers: number[];
  }>;
}

export interface PatternAnalysis {
  consecutive: {
    count: number;
    maxLength: number;
    sequences: number[][];
    description: string;
  };
  arithmeticSequence: {
    found: boolean;
    difference: number;
    sequences: Array<{
      numbers: number[];
      difference: number;
    }>;
    description: string;
  };
  repeatedFromPrev: {
    count: number;
    repeatedNumbers: number[];
    previousDraw: {
      drawNo: number;
      numbers: number[];
    } | null;
    description: string;
  };
}

export interface FrequencyAnalysisItem {
  number: number;
  frequency: number;
  rank: number;
  category: '매우 높음' | '높음' | '보통' | '낮음' | '매우 낮음';
}

export interface FrequencyAnalysis {
  numbers: FrequencyAnalysisItem[];
  categoryCounts: {
    '매우 높음': number;
    '높음': number;
    '보통': number;
    '낮음': number;
    '매우 낮음': number;
  };
  summary: string;
}

export interface RarityAnalysis {
  score: number;
  grade: '매우 평범' | '평범' | '특이함' | '희귀' | '극히 희귀';
  rank: number;
  totalDraws: number;
  percentile: number;
  message: string;
  factors: Array<{
    factor: string;
    impact: number;
    reason: string;
  }>;
}

export interface SimilarDraw {
  drawNo: number;
  drawDate: string;
  numbers: number[];
  similarityScore: number;
  matchingNumbers: number;
  reasons: Array<{
    aspect: string;
    value: string;
    similarity: number;
  }>;
}

export interface ComparisonAnalysis {
  vsTheoretical: {
    average: { theoretical: number; actual: number; deviation: string };
    oddCount: { theoretical: number; actual: number; deviation: string };
  };
  vsHistorical: {
    avgOfAllDraws: number;
    thisDrawDiff: string;
    percentile: number;
  };
  vsRecent10: {
    avgOfRecent10: number;
    thisDrawDiff: string;
    trend: '상승' | '하락' | '유지';
  };
  distribution: {
    historical: {
      oddEven: {
        odd: number;
        even: number;
      };
      highLow: {
        low: number;
        high: number;
      };
    };
  };
}

export interface DrawInfo {
  drawNo: number;
  drawDate: string;
  numbers: number[];
  bonusNumber: number;
}

export interface InsightItem {
  category: string;
  message: string;
  priority: 'high' | 'medium' | 'low';
  data?: Record<string, any>;
}

export interface InsightGroup {
  category: string;
  insights: InsightItem[];
}

export interface LatestDrawAnalysis {
  drawInfo: DrawInfo;
  basicStats: BasicStats;
  distribution: DistributionAnalysis;
  patterns: PatternAnalysis;
  frequency: FrequencyAnalysis;
  rarity: RarityAnalysis;
  similarDraws: SimilarDraw[];
  comparison: ComparisonAnalysis;
  insights: InsightGroup[];
  metadata: {
    analyzedAt: string;
    processingTime: number;
    version: string;
    dataSource: string;
  };
}

// ============================================================
// Task 1.1: 기본 통계 계산
// ============================================================

/**
 * 기본 통계 계산
 * @param numbers - 당첨 번호 6개 배열
 * @returns 기본 통계 객체
 */
export function calculateBasicStats(numbers: number[]): BasicStats {
  const sorted = [...numbers].sort((a, b) => a - b);

  // 평균
  const average = numbers.reduce((sum, n) => sum + n, 0) / numbers.length;

  // 합계
  const sum = numbers.reduce((sum, n) => sum + n, 0);

  // 범위 (최대값 - 최소값)
  const range = Math.max(...numbers) - Math.min(...numbers);

  // 중앙값
  const median = (sorted[2] + sorted[3]) / 2;

  // 분산
  const variance = numbers.reduce((sum, n) => sum + Math.pow(n - average, 2), 0) / numbers.length;

  // 표준편차
  const standardDeviation = Math.sqrt(variance);

  return {
    average: parseFloat(average.toFixed(2)),
    sum,
    range,
    median: parseFloat(median.toFixed(2)),
    standardDeviation: parseFloat(standardDeviation.toFixed(2)),
    variance: parseFloat(variance.toFixed(2)),
  };
}

// ============================================================
// Task 1.2: 분포 분석
// ============================================================

/**
 * 분포 분석 (홀짝, 고저, 구간별)
 * @param numbers - 당첨 번호 6개 배열
 * @returns 분포 분석 객체
 */
export function analyzeDistribution(numbers: number[]): DistributionAnalysis {
  // 홀짝 개수
  const oddCount = numbers.filter(n => n % 2 === 1).length;
  const evenCount = 6 - oddCount;

  // 홀짝 비율
  const oddPercent = (oddCount / 6) * 100;
  const evenPercent = (evenCount / 6) * 100;

  // 이론적 기대값 (전체 1-45 중 홀수 23개, 짝수 22개)
  const expectedOddPercent = 51.1; // 23/45 * 100
  const expectedEvenPercent = 48.9; // 22/45 * 100

  // 편차
  const oddDeviation = oddPercent - expectedOddPercent;

  // 고저 개수 (1-22: 저, 23-45: 고)
  const lowCount = numbers.filter(n => n <= 22).length;
  const highCount = 6 - lowCount;

  // 고저 비율
  const lowPercent = (lowCount / 6) * 100;
  const highPercent = (highCount / 6) * 100;

  // 이론적 기대값 (1-22: 22개, 23-45: 23개)
  const expectedLowPercent = 48.9; // 22/45 * 100
  const expectedHighPercent = 51.1; // 23/45 * 100

  // 편차
  const lowDeviation = lowPercent - expectedLowPercent;

  // 구간별 분포
  const rangeData = [
    { range: '1-9', min: 1, max: 9 },
    { range: '10-19', min: 10, max: 19 },
    { range: '20-29', min: 20, max: 29 },
    { range: '30-39', min: 30, max: 39 },
    { range: '40-45', min: 40, max: 45 }
  ];

  const ranges = rangeData.map(r => {
    const nums = numbers.filter(n => n >= r.min && n <= r.max);
    return {
      range: r.range,
      count: nums.length,
      percentage: (nums.length / 6) * 100,
      numbers: nums
    };
  });

  // 균형도 계산
  const oddEvenBalance = Math.abs(oddCount - 3) <= 1 ? '균형' : '불균형';
  const highLowBalance = Math.abs(lowCount - 3) <= 1 ? '균형' : '불균형';

  return {
    oddEven: {
      odd: oddCount,
      even: evenCount,
      oddPercentage: oddPercent,
      evenPercentage: evenPercent,
      ratio: `${oddCount}:${evenCount}`,
      expected: '3.1:2.9',
      deviation: `${oddDeviation > 0 ? '+' : ''}${oddDeviation.toFixed(1)}%`,
      balance: oddEvenBalance
    },
    highLow: {
      low: lowCount,
      high: highCount,
      lowPercentage: lowPercent,
      highPercentage: highPercent,
      ratio: `${lowCount}:${highCount}`,
      expected: '2.9:3.1',
      deviation: `${lowDeviation > 0 ? '+' : ''}${lowDeviation.toFixed(1)}%`,
      balance: highLowBalance
    },
    ranges,
  };
}

// ============================================================
// Task 1.3: 패턴 분석
// ============================================================

/**
 * 연속 번호 찾기
 * @param numbers - 당첨 번호 배열 (정렬됨)
 * @returns 연속 번호 배열들
 */
function findConsecutiveNumbers(numbers: number[]): number[][] {
  const sorted = [...numbers].sort((a, b) => a - b);
  const consecutive: number[][] = [];
  let current = [sorted[0]];

  for (let i = 1; i < sorted.length; i++) {
    if (sorted[i] === sorted[i - 1] + 1) {
      current.push(sorted[i]);
    } else {
      if (current.length >= 2) {
        consecutive.push([...current]);
      }
      current = [sorted[i]];
    }
  }

  if (current.length >= 2) {
    consecutive.push(current);
  }

  return consecutive;
}

/**
 * 등차수열 패턴 확인
 * @param numbers - 당첨 번호 배열 (정렬됨)
 * @returns 등차수열 여부 및 공차
 */
function checkArithmeticSequence(numbers: number[]): { found: boolean; difference: number | null } {
  const sorted = [...numbers].sort((a, b) => a - b);
  const diffs: number[] = [];

  for (let i = 1; i < sorted.length; i++) {
    diffs.push(sorted[i] - sorted[i - 1]);
  }

  const allSame = diffs.every(d => d === diffs[0]);

  return {
    found: allSame,
    difference: allSame ? diffs[0] : null,
  };
}

/**
 * 패턴 분석
 * @param numbers - 당첨 번호 6개 배열
 * @param drawNo - 현재 회차 번호
 * @returns 패턴 분석 객체
 */
export async function analyzePatterns(
  numbers: number[],
  drawNo: number
): Promise<PatternAnalysis> {
  // 연속 번호
  const consecutiveSeqs = findConsecutiveNumbers(numbers);
  const maxLength = consecutiveSeqs.length > 0
    ? Math.max(...consecutiveSeqs.map(seq => seq.length))
    : 0;

  let consecutiveMessage = '연속 번호 없음';
  if (maxLength === 2) consecutiveMessage = '2개 연속 번호 포함 (일반적)';
  else if (maxLength === 3) consecutiveMessage = '3개 연속 번호 포함 (드묾)';
  else if (maxLength >= 4) consecutiveMessage = `${maxLength}개 연속 번호 포함 (매우 드묾)`;

  // 등차수열
  const arithmeticSeq = checkArithmeticSequence(numbers);

  // 이전 회차와 반복
  let repeatedFromPrev = {
    count: 0,
    numbers: [] as number[],
    prevDrawNo: drawNo - 1,
  };

  if (drawNo > 1) {
    try {
      const pool = await getPoolInstance();
      const result = await pool.query(
        'SELECT num1, num2, num3, num4, num5, num6 FROM lotto.draws WHERE draw_no = $1',
        [drawNo - 1]
      );

      if (result.rows.length > 0) {
        const prevNumbers = [
          result.rows[0].num1,
          result.rows[0].num2,
          result.rows[0].num3,
          result.rows[0].num4,
          result.rows[0].num5,
          result.rows[0].num6,
        ];

        const repeated = numbers.filter(n => prevNumbers.includes(n));
        repeatedFromPrev = {
          count: repeated.length,
          numbers: repeated,
          prevDrawNo: drawNo - 1,
        };
      }
    } catch (error) {
      console.error('[Pattern Analysis] 이전 회차 조회 실패:', error);
    }
  }

  // Format arithmetic sequence data
  const arithmeticSequenceData = {
    found: arithmeticSeq.found,
    difference: arithmeticSeq.difference !== null ? arithmeticSeq.difference : 0,
    sequences: arithmeticSeq.found && arithmeticSeq.difference !== null
      ? [{ numbers, difference: arithmeticSeq.difference }]
      : [],
    description: arithmeticSeq.found
      ? `공차 ${arithmeticSeq.difference}의 등차수열 발견`
      : '등차수열 없음'
  };

  // Format previous draw repetition data
  const repeatedFromPrevData = {
    count: repeatedFromPrev.count,
    repeatedNumbers: repeatedFromPrev.numbers,
    previousDraw: repeatedFromPrev.count > 0 && drawNo > 1
      ? { drawNo: drawNo - 1, numbers: [] }
      : null,
    description: repeatedFromPrev.count > 0
      ? `이전 회차와 ${repeatedFromPrev.count}개 번호 반복`
      : '이전 회차와 반복 없음'
  };

  return {
    consecutive: {
      count: consecutiveSeqs.length,
      maxLength,
      sequences: consecutiveSeqs,
      description: consecutiveMessage,
    },
    arithmeticSequence: arithmeticSequenceData,
    repeatedFromPrev: repeatedFromPrevData,
  };
}

// ============================================================
// Task 1.4: 빈도 분석
// ============================================================

/**
 * 빈도 분석 (역대 출현 빈도 기준)
 * @param numbers - 당첨 번호 6개 배열
 * @returns 빈도 분석 객체
 */
export async function analyzeFrequency(numbers: number[]): Promise<FrequencyAnalysis> {
  try {
    const pool = await getPoolInstance();

    // 전체 회차 수
    const totalDrawsResult = await pool.query('SELECT COUNT(*) as count FROM lotto.draws');
    const totalDraws = parseInt(totalDrawsResult.rows[0].count);

    // 최신 회차 번호
    const latestDrawResult = await pool.query('SELECT MAX(draw_no) as max FROM lotto.draws');
    const latestDrawNo = parseInt(latestDrawResult.rows[0].max);

    // 각 번호의 출현 빈도 조회
    const statsResult = await pool.query(`
      SELECT
        num AS number,
        COUNT(*) AS total_count,
        MAX(draw_no) AS last_draw_no
      FROM (
        SELECT draw_no, num1 AS num FROM lotto.draws
        UNION ALL SELECT draw_no, num2 FROM lotto.draws
        UNION ALL SELECT draw_no, num3 FROM lotto.draws
        UNION ALL SELECT draw_no, num4 FROM lotto.draws
        UNION ALL SELECT draw_no, num5 FROM lotto.draws
        UNION ALL SELECT draw_no, num6 FROM lotto.draws
      ) AS all_nums
      WHERE num = ANY($1::int[])
      GROUP BY num
      ORDER BY num
    `, [numbers]);

    // 전체 번호 통계 (순위 계산용)
    const allStatsResult = await pool.query(`
      SELECT
        num AS number,
        COUNT(*) AS total_count
      FROM (
        SELECT num1 AS num FROM lotto.draws
        UNION ALL SELECT num2 FROM lotto.draws
        UNION ALL SELECT num3 FROM lotto.draws
        UNION ALL SELECT num4 FROM lotto.draws
        UNION ALL SELECT num5 FROM lotto.draws
        UNION ALL SELECT num6 FROM lotto.draws
      ) AS all_nums
      GROUP BY num
      ORDER BY total_count DESC, num ASC
    `);

    const allStats = allStatsResult.rows.map(row => ({
      number: parseInt(row.number),
      totalCount: parseInt(row.total_count),
    }));

    // 기대 출현 횟수
    const expectedCount = (totalDraws * 6) / 45;

    // 각 번호 분석
    const analysisItems: FrequencyAnalysisItem[] = numbers.map(num => {
      const stat = statsResult.rows.find(row => parseInt(row.number) === num);
      const totalCount = stat ? parseInt(stat.total_count) : 0;

      // 순위 계산
      const rank = allStats.findIndex(s => s.number === num) + 1;

      // 백분위수
      const percentile = ((45 - rank + 1) / 45) * 100;

      // 카테고리 (5단계)
      let category: '매우 높음' | '높음' | '보통' | '낮음' | '매우 낮음';
      if (percentile >= 90) category = '매우 높음';
      else if (percentile >= 70) category = '높음';
      else if (percentile >= 30) category = '보통';
      else if (percentile >= 10) category = '낮음';
      else category = '매우 낮음';

      return {
        number: num,
        frequency: totalCount,
        rank,
        category,
      };
    });

    // 카테고리별 개수
    const categoryCounts = {
      '매우 높음': analysisItems.filter(item => item.category === '매우 높음').length,
      '높음': analysisItems.filter(item => item.category === '높음').length,
      '보통': analysisItems.filter(item => item.category === '보통').length,
      '낮음': analysisItems.filter(item => item.category === '낮음').length,
      '매우 낮음': analysisItems.filter(item => item.category === '매우 낮음').length,
    };

    // 요약 메시지 (고빈출/저빈출 그룹으로 분류하여 더 의미있는 요약 제공)
    const highFreqCount = categoryCounts['매우 높음'] + categoryCounts['높음'];
    const lowFreqCount = categoryCounts['매우 낮음'] + categoryCounts['낮음'];
    const normalCount = categoryCounts['보통'];

    let summary: string;
    if (highFreqCount >= 4) {
      summary = `역대 빈출 번호가 ${highFreqCount}개로, 자주 나온 번호 위주로 구성되어 있습니다.`;
    } else if (lowFreqCount >= 4) {
      summary = `역대 저빈출 번호가 ${lowFreqCount}개로, 드물게 나온 번호 위주로 구성되어 있습니다.`;
    } else if (highFreqCount === lowFreqCount && highFreqCount >= 2) {
      summary = `빈출 번호(${highFreqCount}개)와 저빈출 번호(${lowFreqCount}개)가 균형있게 분포되어 있습니다.`;
    } else if (normalCount >= 3) {
      summary = `보통 빈도의 번호가 ${normalCount}개로, 평균적인 빈도의 번호 위주입니다.`;
    } else {
      summary = `다양한 빈도의 번호가 골고루 포함되어 있습니다.`;
    }

    return {
      numbers: analysisItems,
      categoryCounts,
      summary,
    };
  } catch (error) {
    console.error('[Frequency Analysis] 빈도 분석 실패:', error);
    throw error;
  }
}

// ============================================================
// Task 1.5: 희귀도 점수 계산
// ============================================================

/**
 * 희귀도 점수 계산 (0-100점)
 * @param drawNo - 회차 번호
 * @param numbers - 당첨 번호 배열
 * @param basicStats - 기본 통계
 * @param distribution - 분포 분석
 * @param patterns - 패턴 분석
 * @param frequency - 빈도 분석
 * @returns 희귀도 분석 객체
 */
export async function calculateRarityScore(
  drawNo: number,
  numbers: number[],
  basicStats: BasicStats,
  distribution: DistributionAnalysis,
  patterns: PatternAnalysis,
  frequency: FrequencyAnalysis
): Promise<RarityAnalysis> {
  let score = 50; // 기본 점수 (보통)
  const factors: Array<{ factor: string; impact: number; reason: string }> = [];

  // 1. 번호 평균 편차 (±10점)
  const avgDeviation = Math.abs(basicStats.average - 23) / 23 * 100;
  if (avgDeviation > 15) {
    score += 10;
    factors.push({
      factor: '번호 평균 편차',
      impact: 10,
      reason: `평균 ${basicStats.average}로 이론값(23)에서 ${avgDeviation.toFixed(1)}% 벗어남`,
    });
  } else if (avgDeviation > 10) {
    score += 5;
    factors.push({
      factor: '번호 평균 편차',
      impact: 5,
      reason: `평균 ${basicStats.average}로 이론값(23)에서 ${avgDeviation.toFixed(1)}% 벗어남`,
    });
  }

  // 2. 홀짝 비율 극단성 (±15점)
  const oddCount = distribution.oddEven.odd;
  if (oddCount === 6 || oddCount === 0) {
    score += 15;
    factors.push({
      factor: '홀짝 비율 극단적',
      impact: 15,
      reason: `${oddCount === 6 ? '홀수 6개' : '짝수 6개'}로 매우 드묾`,
    });
  } else if (oddCount === 5 || oddCount === 1) {
    score += 10;
    factors.push({
      factor: '홀짝 비율 편향',
      impact: 10,
      reason: `홀수 ${oddCount}개로 이론값(3개)에서 크게 벗어남`,
    });
  } else if (oddCount === 4 || oddCount === 2) {
    score += 3;
    factors.push({
      factor: '홀짝 비율 약간 편향',
      impact: 3,
      reason: `홀수 ${oddCount}개로 이론값(3개)보다 ${oddCount > 3 ? '많음' : '적음'}`,
    });
  }

  // 3. 연속 번호 (±15점)
  if (patterns.consecutive.maxLength >= 4) {
    score += 15;
    factors.push({
      factor: '연속 번호 다수',
      impact: 15,
      reason: `${patterns.consecutive.maxLength}개 연속 번호 포함 (극히 드묾)`,
    });
  } else if (patterns.consecutive.maxLength === 3) {
    score += 10;
    factors.push({
      factor: '연속 번호',
      impact: 10,
      reason: '3개 연속 번호 포함 (드묾)',
    });
  } else if (patterns.consecutive.maxLength === 2) {
    score += 3;
    factors.push({
      factor: '연속 번호',
      impact: 3,
      reason: '2개 연속 번호 포함 (일반적)',
    });
  }

  // 4. 등차수열 패턴 (±20점)
  if (patterns.arithmeticSequence.found) {
    score += 20;
    factors.push({
      factor: '등차수열 패턴',
      impact: 20,
      reason: `공차 ${patterns.arithmeticSequence.difference}의 등차수열 (극히 희귀)`,
    });
  }

  // 5. 표준편차 (±10점)
  const stdDevDeviation = Math.abs(basicStats.standardDeviation - 14) / 14 * 100;
  if (stdDevDeviation > 30) {
    score += 10;
    factors.push({
      factor: '분산도 극단적',
      impact: 10,
      reason: `표준편차 ${basicStats.standardDeviation}로 ${basicStats.standardDeviation > 14 ? '매우 분산됨' : '매우 밀집됨'}`,
    });
  } else if (stdDevDeviation > 20) {
    score += 5;
    factors.push({
      factor: '분산도 특이',
      impact: 5,
      reason: `표준편차 ${basicStats.standardDeviation}로 이론값(14)에서 벗어남`,
    });
  }

  // 6. 빈출 번호 집중도 (±10점)
  const topFreqCount = frequency.numbers.filter(n => n.category === '매우 높음' || n.category === '높음').length;
  const leastFreqCount = frequency.numbers.filter(n => n.category === '매우 낮음' || n.category === '낮음').length;

  if (topFreqCount >= 5) {
    score += 10;
    factors.push({
      factor: '빈출 번호 집중',
      impact: 10,
      reason: `빈출 번호 ${topFreqCount}개 포함 (역대 상위권 번호 집중)`,
    });
  } else if (leastFreqCount >= 4) {
    score += 10;
    factors.push({
      factor: '저빈출 번호 집중',
      impact: 10,
      reason: `저빈출 번호 ${leastFreqCount}개 포함 (역대 하위권 번호 집중)`,
    });
  }

  // 7. 이전 회차 반복성 (±8점)
  if (patterns.repeatedFromPrev.count >= 4) {
    score += 8;
    factors.push({
      factor: '이전 회차 높은 반복',
      impact: 8,
      reason: `이전 회차와 ${patterns.repeatedFromPrev.count}개 번호 반복 (평균 1.2개)`,
    });
  } else if (patterns.repeatedFromPrev.count === 0) {
    score += 5;
    factors.push({
      factor: '이전 회차 완전 새로운 조합',
      impact: 5,
      reason: '이전 회차와 겹치는 번호 없음 (20%)',
    });
  }

  // 8. 구간 집중도 (±8점)
  const rangeCounts = distribution.ranges.map(r => r.count);
  const maxInRange = Math.max(...rangeCounts);
  if (maxInRange >= 4) {
    score += 8;
    factors.push({
      factor: '구간 집중',
      impact: 8,
      reason: `한 구간에 ${maxInRange}개 집중 (불균등 분포)`,
    });
  }

  // 최종 점수 범위 제한 (0-100)
  score = Math.max(0, Math.min(100, score));

  // 등급 결정 (기본 점수 50점이 "평범"에 속하도록 조정)
  let grade: '매우 평범' | '평범' | '특이함' | '희귀' | '극히 희귀';
  if (score < 25) grade = '매우 평범';
  else if (score < 55) grade = '평범';      // 기본 점수 50점 포함
  else if (score < 75) grade = '특이함';
  else if (score < 90) grade = '희귀';
  else grade = '극히 희귀';

  // 역대 순위 계산 (전체 회차 대비)
  try {
    const pool = await getPoolInstance();
    const totalDrawsResult = await pool.query('SELECT COUNT(*) as count FROM lotto.draws');
    const totalDraws = parseInt(totalDrawsResult.rows[0].count);

    // 간단한 추정: 점수 기준 백분위수
    const percentile = score;
    const rank = Math.round((totalDraws * (100 - percentile)) / 100);

    const message = `이번 회차는 역대 ${totalDraws}회차 중 상위 ${(100 - percentile).toFixed(1)}%에 해당하는 ${grade} 조합입니다.`;

    return {
      score: Math.round(score),
      grade,
      rank,
      totalDraws,
      percentile: parseFloat(percentile.toFixed(1)),
      message,
      factors,
    };
  } catch (error) {
    console.error('[Rarity Score] 계산 실패:', error);
    return {
      score: Math.round(score),
      grade,
      rank: 0,
      totalDraws: 0,
      percentile: 0,
      message: '희귀도 계산 완료',
      factors,
    };
  }
}

// ============================================================
// Task 1.6: 유사 회차 검색
// ============================================================

/**
 * 유사도 계산
 * @param draw1 - 회차 1 번호들
 * @param draw2 - 회차 2 번호들
 * @returns 유사도 (0-100)
 */
function calculateSimilarity(
  draw1: { numbers: number[]; avg: number; sum: number; oddCount: number },
  draw2: { numbers: number[]; avg: number; sum: number; oddCount: number }
): number {
  // 1. 평균값 유사도 (20%)
  const avgDiff = Math.abs(draw1.avg - draw2.avg);
  const avgSimilarity = Math.max(0, 1 - avgDiff / 23); // 23은 최대 편차

  // 2. 합계 유사도 (20%)
  const sumDiff = Math.abs(draw1.sum - draw2.sum);
  const sumSimilarity = Math.max(0, 1 - sumDiff / 138); // 138은 이론값

  // 3. 홀짝 비율 유사도 (30%)
  const oddCountSame = draw1.oddCount === draw2.oddCount ? 1 : 0;

  // 4. 번호 겹침 (30%)
  const matchingNumbers = draw1.numbers.filter(n => draw2.numbers.includes(n)).length;
  const matchingSimilarity = matchingNumbers / 6;

  // 가중 평균
  const similarity =
    avgSimilarity * 0.2 +
    sumSimilarity * 0.2 +
    oddCountSame * 0.3 +
    matchingSimilarity * 0.3;

  return similarity * 100;
}

/**
 * 유사 회차 검색
 * @param targetDrawNo - 대상 회차 번호
 * @param targetNumbers - 대상 당첨 번호
 * @param limit - 결과 개수
 * @returns 유사 회차 목록
 */
export async function findSimilarDraws(
  targetDrawNo: number,
  targetNumbers: number[],
  limit: number = 5
): Promise<SimilarDraw[]> {
  try {
    const pool = await getPoolInstance();
    const targetAvg = targetNumbers.reduce((sum, n) => sum + n, 0) / 6;
    const targetSum = targetNumbers.reduce((sum, n) => sum + n, 0);
    const targetOddCount = targetNumbers.filter(n => n % 2 === 1).length;

    // 전체 회차 조회 (자신 제외)
    const result = await pool.query(`
      SELECT
        draw_no,
        draw_date,
        num1, num2, num3, num4, num5, num6,
        (num1 + num2 + num3 + num4 + num5 + num6) / 6.0 AS avg_num,
        (num1 + num2 + num3 + num4 + num5 + num6) AS sum_num,
        (CASE WHEN num1 % 2 = 1 THEN 1 ELSE 0 END +
         CASE WHEN num2 % 2 = 1 THEN 1 ELSE 0 END +
         CASE WHEN num3 % 2 = 1 THEN 1 ELSE 0 END +
         CASE WHEN num4 % 2 = 1 THEN 1 ELSE 0 END +
         CASE WHEN num5 % 2 = 1 THEN 1 ELSE 0 END +
         CASE WHEN num6 % 2 = 1 THEN 1 ELSE 0 END) AS odd_count
      FROM lotto.draws
      WHERE draw_no != $1
      ORDER BY draw_no DESC
      LIMIT 500
    `, [targetDrawNo]);

    const similarDraws: SimilarDraw[] = result.rows.map(row => {
      const numbers = [row.num1, row.num2, row.num3, row.num4, row.num5, row.num6];
      const avg = parseFloat(row.avg_num);
      const sum = parseInt(row.sum_num);
      const oddCount = parseInt(row.odd_count);

      const similarity = calculateSimilarity(
        { numbers: targetNumbers, avg: targetAvg, sum: targetSum, oddCount: targetOddCount },
        { numbers, avg, sum, oddCount }
      );

      const matchingNumbers = targetNumbers.filter(n => numbers.includes(n)).length;

      const reasons: Array<{ aspect: string; value: string; similarity: number }> = [];
      if (Math.abs(targetAvg - avg) < 2) {
        reasons.push({
          aspect: '평균값',
          value: `${avg.toFixed(1)} (차이: ${Math.abs(targetAvg - avg).toFixed(1)})`,
          similarity: 95
        });
      }
      if (targetOddCount === oddCount) {
        reasons.push({
          aspect: '홀짝 비율',
          value: `홀수 ${oddCount}개`,
          similarity: 100
        });
      }
      if (matchingNumbers >= 2) {
        reasons.push({
          aspect: '번호 겹침',
          value: `${matchingNumbers}개 일치`,
          similarity: (matchingNumbers / 6) * 100
        });
      }
      if (Math.abs(targetSum - sum) < 10) {
        reasons.push({
          aspect: '합계',
          value: `${sum} (차이: ${Math.abs(targetSum - sum)})`,
          similarity: 90
        });
      }

      return {
        drawNo: row.draw_no,
        drawDate: row.draw_date.toISOString().split('T')[0],
        numbers,
        similarityScore: parseFloat(similarity.toFixed(1)),
        matchingNumbers,
        reasons,
      };
    });

    // 유사도 순으로 정렬하여 상위 N개 반환
    return similarDraws
      .sort((a, b) => b.similarityScore - a.similarityScore)
      .slice(0, limit);
  } catch (error) {
    console.error('[Similar Draws] 유사 회차 검색 실패:', error);
    return [];
  }
}

// ============================================================
// Task 1.7: 비교 분석
// ============================================================

/**
 * 비교 분석 (이론값, 역대 평균, 최근 10회차)
 * @param drawNo - 회차 번호
 * @param numbers - 당첨 번호
 * @param basicStats - 기본 통계
 * @returns 비교 분석 객체
 */
export async function compareWithHistory(
  drawNo: number,
  numbers: number[],
  basicStats: BasicStats
): Promise<ComparisonAnalysis> {
  try {
    const pool = await getPoolInstance();
    const oddCount = numbers.filter(n => n % 2 === 1).length;

    // 이론적 기대값
    const theoreticalAvg = 23.0;
    const theoreticalOddCount = 3.07; // (23/45) * 6

    // 역대 전체 평균
    const historicalResult = await pool.query(`
      SELECT
        AVG((num1 + num2 + num3 + num4 + num5 + num6) / 6.0) AS avg_all,
        COUNT(*) AS total_draws
      FROM lotto.draws
    `);

    const avgOfAllDraws = parseFloat(historicalResult.rows[0].avg_all);
    const totalDraws = parseInt(historicalResult.rows[0].total_draws);

    // 최근 10회차 평균
    const recent10Result = await pool.query(`
      SELECT
        AVG((num1 + num2 + num3 + num4 + num5 + num6) / 6.0) AS avg_recent10
      FROM (
        SELECT num1, num2, num3, num4, num5, num6
        FROM lotto.draws
        WHERE draw_no < $1
        ORDER BY draw_no DESC
        LIMIT 10
      ) AS recent
    `, [drawNo]);

    const avgOfRecent10 = recent10Result.rows[0].avg_recent10
      ? parseFloat(recent10Result.rows[0].avg_recent10)
      : avgOfAllDraws;

    // 편차 계산
    const avgDeviation = ((basicStats.average - theoreticalAvg) / theoreticalAvg) * 100;
    const oddDeviation = ((oddCount - theoreticalOddCount) / theoreticalOddCount) * 100;
    const thisDrawDiffHistorical = basicStats.average - avgOfAllDraws;
    const thisDrawDiffRecent = basicStats.average - avgOfRecent10;

    // 백분위수 (간단 추정)
    const percentile = 50 + (thisDrawDiffHistorical / avgOfAllDraws) * 100;

    // 트렌드
    let trend: '상승' | '하락' | '유지';
    if (thisDrawDiffRecent > 1) trend = '상승';
    else if (thisDrawDiffRecent < -1) trend = '하락';
    else trend = '유지';

    return {
      vsTheoretical: {
        average: {
          theoretical: theoreticalAvg,
          actual: basicStats.average,
          deviation: `${avgDeviation > 0 ? '+' : ''}${avgDeviation.toFixed(1)}%`,
        },
        oddCount: {
          theoretical: parseFloat(theoreticalOddCount.toFixed(2)),
          actual: oddCount,
          deviation: `${oddDeviation > 0 ? '+' : ''}${oddDeviation.toFixed(1)}%`,
        },
      },
      vsHistorical: {
        avgOfAllDraws: parseFloat(avgOfAllDraws.toFixed(2)),
        thisDrawDiff: `${thisDrawDiffHistorical > 0 ? '+' : ''}${thisDrawDiffHistorical.toFixed(2)}`,
        percentile: parseFloat(Math.max(0, Math.min(100, percentile)).toFixed(1)),
      },
      vsRecent10: {
        avgOfRecent10: parseFloat(avgOfRecent10.toFixed(2)),
        thisDrawDiff: `${thisDrawDiffRecent > 0 ? '+' : ''}${thisDrawDiffRecent.toFixed(2)}`,
        trend,
      },
      distribution: {
        historical: {
          oddEven: {
            odd: 3,
            even: 3
          },
          highLow: {
            low: 3,
            high: 3
          }
        }
      }
    };
  } catch (error) {
    console.error('[Comparison Analysis] 비교 분석 실패:', error);
    throw error;
  }
}

// ============================================================
// Task 1.8: 인사이트 생성
// ============================================================

/**
 * AI 인사이트 생성
 * @param basicStats - 기본 통계
 * @param distribution - 분포 분석
 * @param patterns - 패턴 분석
 * @param frequency - 빈도 분석
 * @param rarity - 희귀도 분석
 * @param comparison - 비교 분석
 * @returns 인사이트 문자열 배열
 */
export function generateInsights(
  basicStats: BasicStats,
  distribution: DistributionAnalysis,
  patterns: PatternAnalysis,
  frequency: FrequencyAnalysis,
  rarity: RarityAnalysis,
  comparison: ComparisonAnalysis
): string[] {
  const insights: string[] = [];

  // 1. 홀짝 비율 인사이트
  const oddCount = distribution.oddEven.odd;
  if (oddCount >= 5 || oddCount <= 1) {
    insights.push(
      `✨ 이번 회차는 홀수가 ${oddCount}개로, 이론적 기대값(3개)과 크게 다릅니다. 이런 조합은 전체의 약 10% 미만입니다.`
    );
  } else if (oddCount === 4 || oddCount === 2) {
    insights.push(
      `✨ 이번 회차는 홀수가 ${oddCount}개로, 이론적 기대값(3개)보다 ${oddCount > 3 ? '많습니다' : '적습니다'}.`
    );
  }

  // 2. 평균 번호 인사이트
  if (basicStats.average > 25) {
    insights.push(
      `📊 평균 번호(${basicStats.average})가 전체 평균(${comparison.vsHistorical.avgOfAllDraws})보다 높아 고번호 쪽으로 치우쳤습니다.`
    );
  } else if (basicStats.average < 21) {
    insights.push(
      `📊 평균 번호(${basicStats.average})가 전체 평균(${comparison.vsHistorical.avgOfAllDraws})보다 낮아 저번호 쪽으로 치우쳤습니다.`
    );
  } else {
    insights.push(
      `📊 평균 번호(${basicStats.average})가 전체 평균(${comparison.vsHistorical.avgOfAllDraws})과 유사하여 균형잡힌 분포를 보입니다.`
    );
  }

  // 3. 반복성 인사이트
  if (patterns.repeatedFromPrev.count >= 3) {
    insights.push(
      `🔁 이전 회차와 ${patterns.repeatedFromPrev.count}개 번호가 겹쳐 평균(1.2개)보다 반복성이 높습니다.`
    );
  } else if (patterns.repeatedFromPrev.count === 0) {
    insights.push(
      `🔁 이전 회차와 겹치는 번호가 없어 완전히 새로운 조합입니다. 이런 경우는 약 20%입니다.`
    );
  }

  // 4. 희귀도 인사이트
  insights.push(
    `🎯 희귀도 점수 ${rarity.score}점으로 '${rarity.grade}' 등급이며, 역대 상위 ${(100 - rarity.percentile).toFixed(1)}%에 해당합니다.`
  );

  // 5. 트렌드 인사이트
  if (comparison.vsRecent10.trend === '상승') {
    insights.push(
      `📈 최근 10회차 평균(${comparison.vsRecent10.avgOfRecent10})보다 ${comparison.vsRecent10.thisDrawDiff} 높아 상승 트렌드를 보이고 있습니다.`
    );
  } else if (comparison.vsRecent10.trend === '하락') {
    insights.push(
      `📉 최근 10회차 평균(${comparison.vsRecent10.avgOfRecent10})보다 ${comparison.vsRecent10.thisDrawDiff} 낮아 하락 트렌드를 보이고 있습니다.`
    );
  }

  // 6. 연속 번호 인사이트
  if (patterns.consecutive.maxLength >= 3) {
    insights.push(
      `⛓️ ${patterns.consecutive.maxLength}개 연속 번호가 포함되어 있습니다. 이는 전체 회차의 약 ${patterns.consecutive.maxLength === 3 ? '18%' : '2%'}에서만 나타나는 패턴입니다.`
    );
  }

  // 7. 빈도 인사이트
  const topFrequentCount = frequency.categoryCounts['매우 높음'] + frequency.categoryCounts['높음'];
  const leastFrequentCount = frequency.categoryCounts['매우 낮음'] + frequency.categoryCounts['낮음'];

  if (topFrequentCount >= 4) {
    insights.push(
      `🔥 역대 빈출 번호가 ${topFrequentCount}개 포함되어 상위권 번호에 집중되었습니다.`
    );
  } else if (leastFrequentCount >= 4) {
    insights.push(
      `🧊 역대 저빈출 번호가 ${leastFrequentCount}개 포함되어 하위권 번호에 집중되었습니다.`
    );
  }

  // 8. 분산도 인사이트
  if (basicStats.standardDeviation > 16) {
    insights.push(
      `📐 표준편차(${basicStats.standardDeviation})가 높아 번호들이 넓게 분산되어 있습니다.`
    );
  } else if (basicStats.standardDeviation < 12) {
    insights.push(
      `📐 표준편차(${basicStats.standardDeviation})가 낮아 번호들이 밀집되어 있습니다.`
    );
  }

  return insights;
}

/**
 * Generate structured insights with categories
 */
export function generateStructuredInsights(
  drawNo: number,
  numbers: number[],
  bonusNumber: number,
  basicStats: BasicStats,
  distribution: DistributionAnalysis,
  patterns: PatternAnalysis,
  frequency: FrequencyAnalysis,
  rarity: RarityAnalysis,
  similarDraws: SimilarDraw[],
  comparison: ComparisonAnalysis
): InsightGroup[] {
  const insights: InsightGroup[] = [];

  // Category 1: Basic Stats
  const basicInsights: InsightItem[] = [];
  if (basicStats.average > 25) {
    basicInsights.push({
      category: '평균값',
      message: `평균 번호(${basicStats.average})가 전체 평균보다 높아 고번호 쪽으로 치우쳤습니다.`,
      priority: 'medium',
      data: { average: basicStats.average }
    });
  } else if (basicStats.average < 21) {
    basicInsights.push({
      category: '평균값',
      message: `평균 번호(${basicStats.average})가 전체 평균보다 낮아 저번호 쪽으로 치우쳤습니다.`,
      priority: 'medium',
      data: { average: basicStats.average }
    });
  }

  if (basicInsights.length > 0) {
    insights.push({ category: '기본 통계', insights: basicInsights });
  }

  // Category 2: Distribution
  const distInsights: InsightItem[] = [];
  const oddCount = distribution.oddEven.odd;
  if (oddCount >= 5 || oddCount <= 1) {
    distInsights.push({
      category: '홀짝 분포',
      message: `홀수가 ${oddCount}개로, 이론적 기대값(3개)과 크게 다릅니다. 이런 조합은 전체의 약 10% 미만입니다.`,
      priority: 'high',
      data: { oddCount }
    });
  }

  if (distInsights.length > 0) {
    insights.push({ category: '분포 분석', insights: distInsights });
  }

  // Category 3: Pattern
  const patternInsights: InsightItem[] = [];
  if (patterns.consecutive.count > 0) {
    patternInsights.push({
      category: '연속 번호',
      message: `연속 번호가 ${patterns.consecutive.count}개 발견되었습니다.`,
      priority: 'medium',
      data: { count: patterns.consecutive.count }
    });
  }

  if (patternInsights.length > 0) {
    insights.push({ category: '패턴 분석', insights: patternInsights });
  }

  // Category 4: Rarity
  insights.push({
    category: '희귀도 분석',
    insights: [{
      category: '희귀도',
      message: rarity.message,
      priority: rarity.score > 70 ? 'high' : rarity.score > 50 ? 'medium' : 'low',
      data: { score: rarity.score, grade: rarity.grade }
    }]
  });

  // Category 5: Overall
  insights.push({
    category: '전체 평가',
    insights: [{
      category: '종합',
      message: `제 ${drawNo}회 추첨 번호는 ${rarity.grade} 조합으로 평가됩니다.`,
      priority: 'high',
      data: { drawNo, rarityGrade: rarity.grade }
    }]
  });

  return insights;
}
