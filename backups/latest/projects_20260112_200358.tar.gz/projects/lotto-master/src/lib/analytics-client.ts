'use client';

/**
 * 클라이언트 사이드 Analytics 라이브러리
 * - 브라우저에서 실행
 * - 자동 세션 관리
 * - 논블로킹 이벤트 전송
 */
class ClientAnalytics {
  private sessionId: string;
  private userId: string;

  constructor() {
    this.sessionId = this.getOrCreateSessionId();
    this.userId = this.getOrCreateUserId();
  }

  /**
   * 세션 ID 가져오기 또는 생성
   */
  private getOrCreateSessionId(): string {
    if (typeof window === 'undefined') return '';

    let sessionId = localStorage.getItem('lotto_session_id');
    if (!sessionId) {
      sessionId = `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('lotto_session_id', sessionId);
    }
    return sessionId;
  }

  /**
   * 세션 ID 반환
   */
  getSessionId(): string {
    return this.sessionId;
  }

  /**
   * 사용자 ID 가져오기 또는 생성
   * - localStorage에 영구 저장하여 재방문 시에도 동일 사용자로 식별
   */
  private getOrCreateUserId(): string {
    if (typeof window === 'undefined') return '';

    let userId = localStorage.getItem('lotto_user_id');
    if (!userId) {
      userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('lotto_user_id', userId);
    }
    return userId;
  }

  /**
   * 사용자 ID 반환
   */
  getUserId(): string {
    return this.userId;
  }

  /**
   * 페이지뷰 추적
   */
  async trackPageView(pageUrl: string) {
    await this.track({
      eventType: 'pageview',
      eventCategory: 'navigation',
      eventName: 'page_view',
      pageUrl
    });
  }

  /**
   * 클릭 이벤트 추적
   */
  async trackClick(elementName: string, metadata?: any) {
    await this.track({
      eventType: 'click',
      eventCategory: 'interaction',
      eventName: elementName,
      metadata
    });
  }

  /**
   * 번호 생성 이벤트 추적 (클라이언트)
   */
  async trackGeneration(algorithm: string, numbers: number[], metadata?: any) {
    await this.track({
      eventType: 'generation',
      eventCategory: 'lotto',
      eventName: 'number_generated',
      metadata: {
        algorithm,
        numbers,
        count: numbers.length,
        ...metadata
      }
    });
  }

  /**
   * 에러 추적
   */
  async trackError(errorMessage: string, errorCategory: string, metadata?: any) {
    await this.track({
      eventType: 'error',
      eventCategory: errorCategory,
      eventName: 'error_occurred',
      metadata: {
        ...metadata,
        error: errorMessage
      }
    });
  }

  /**
   * 커스텀 이벤트 추적
   */
  async trackCustomEvent(eventName: string, metadata?: any) {
    await this.track({
      eventType: 'custom',
      eventCategory: 'user_action',
      eventName,
      metadata
    });
  }

  /**
   * 이벤트 전송 (내부 메서드)
   */
  private async track(data: any) {
    try {
      await fetch('/api/analytics/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          sessionId: this.sessionId,
          userId: this.userId,
          pageUrl: data.pageUrl || (typeof window !== 'undefined' ? window.location.href : '')
        })
      });
    } catch (error) {
      // 실패해도 사용자 경험에 영향 없음 (논블로킹)
      console.error('[ClientAnalytics] Failed to track event:', error);
    }
  }
}

// 싱글톤 인스턴스 export
export const clientAnalytics = new ClientAnalytics();
