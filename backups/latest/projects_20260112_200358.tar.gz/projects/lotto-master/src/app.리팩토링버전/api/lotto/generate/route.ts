import { NextRequest, NextResponse } from 'next/server'
import { generateNumbers } from '@/lib/algorithms'
import type { Algorithm } from '@/types/lotto'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { algorithm = 'random', count = 1 } = body

    // 입력 검증
    if (count < 1 || count > 10) {
      return NextResponse.json(
        { success: false, error: '생성 개수는 1~10 사이여야 합니다.' },
        { status: 400 }
      )
    }

    const validAlgorithms: Algorithm[] = ['random', 'frequency', 'pattern']
    if (!validAlgorithms.includes(algorithm)) {
      return NextResponse.json(
        { success: false, error: '유효하지 않은 알고리즘입니다.' },
        { status: 400 }
      )
    }

    // 번호 생성
    const numbers = Array.from({ length: count }, () =>
      generateNumbers(algorithm as Algorithm)
    )

    return NextResponse.json({
      success: true,
      data: {
        numbers,
        algorithm,
        generatedAt: new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error('번호 생성 오류:', error)
    return NextResponse.json(
      { success: false, error: '번호 생성 중 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}
