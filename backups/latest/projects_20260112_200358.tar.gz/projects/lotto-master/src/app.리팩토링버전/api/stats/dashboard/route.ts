import { NextResponse } from 'next/server'
import {
  getLottoData,
  calculateNumberStats,
  calculateOddEvenRatio,
  calculateHighLowRatio,
} from '@/lib/data/loader'

export const revalidate = 300 // 5분 캐싱

export async function GET() {
  try {
    const data = getLottoData()
    const stats = calculateNumberStats()
    const oddEvenRatio = calculateOddEvenRatio()
    const highLowRatio = calculateHighLowRatio()

    // 빈도순 정렬
    const sorted = [...stats].sort((a, b) => b.totalCount - a.totalCount)

    // 상위 5개
    const topFrequent = sorted.slice(0, 5).map((s) => ({
      number: s.number,
      count: s.totalCount,
    }))

    // 하위 5개
    const leastFrequent = sorted.slice(-5).map((s) => ({
      number: s.number,
      count: s.totalCount,
    }))

    return NextResponse.json({
      success: true,
      data: {
        totalDraws: data.meta.totalDraws,
        lastUpdate: data.meta.lastUpdate,
        topFrequent,
        leastFrequent,
        oddEvenRatio: {
          odd: oddEvenRatio.odd.toFixed(1),
          even: oddEvenRatio.even.toFixed(1),
        },
        highLowRatio: {
          low: highLowRatio.low.toFixed(1),
          high: highLowRatio.high.toFixed(1),
        },
      },
    })
  } catch (error) {
    console.error('통계 조회 오류:', error)
    return NextResponse.json(
      { success: false, error: '통계 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}
