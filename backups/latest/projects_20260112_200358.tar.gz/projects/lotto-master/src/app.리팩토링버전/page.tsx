'use client'

import NumberGenerator from '@/components/lotto/NumberGenerator'

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-gray-900">로또 번호 추천</h1>
        <p className="text-base md:text-lg text-gray-700">
          다양한 알고리즘으로 행운의 번호를 생성해보세요
        </p>
      </div>

      <NumberGenerator />

      <div className="mt-12 max-w-3xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-6 bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow">
            <div className="text-3xl mb-3">🎲</div>
            <h3 className="font-semibold mb-2 text-gray-900 text-lg">완전 랜덤</h3>
            <p className="text-sm text-gray-700">
              1~45 중 완전 무작위 선택
            </p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow">
            <div className="text-3xl mb-3">📊</div>
            <h3 className="font-semibold mb-2 text-gray-900 text-lg">빈도 기반</h3>
            <p className="text-sm text-gray-700">
              자주 나온 번호 중심 선택
            </p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow">
            <div className="text-3xl mb-3">🎯</div>
            <h3 className="font-semibold mb-2 text-gray-900 text-lg">패턴 기반</h3>
            <p className="text-sm text-gray-700">
              구간 분산 패턴 고려
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
