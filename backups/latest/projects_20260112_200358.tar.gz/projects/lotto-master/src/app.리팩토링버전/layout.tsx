'use client'

import type { Metadata } from 'next'
import { useState } from 'react'
import { ToastProvider } from '@/components/ui/toast'
import './globals.css'

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <html lang="ko">
      <head>
        <title>🎰 LottoMaster</title>
        <meta name="description" content="데이터 기반 로또 번호 추천 서비스" />
      </head>
      <body className="antialiased min-h-screen bg-gray-50">
        <ToastProvider>
        <nav className="bg-white border-b sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <a href="/" className="text-xl md:text-2xl font-bold text-gray-900">
                🎰 LottoMaster
              </a>

              {/* Desktop Menu */}
              <div className="hidden md:flex gap-4">
                <a
                  href="/"
                  className="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md font-medium transition-colors"
                >
                  번호 생성
                </a>
                <a
                  href="/history"
                  className="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md font-medium transition-colors"
                >
                  당첨 이력
                </a>
                <a
                  href="/stats"
                  className="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md font-medium transition-colors"
                >
                  통계
                </a>
              </div>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 rounded-md text-gray-700 hover:bg-gray-100 transition-colors"
                aria-label="메뉴"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  {mobileMenuOpen ? (
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  ) : (
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 12h16M4 18h16"
                    />
                  )}
                </svg>
              </button>
            </div>

            {/* Mobile Menu */}
            {mobileMenuOpen && (
              <div className="md:hidden mt-4 pb-4 space-y-2 border-t pt-4">
                <a
                  href="/"
                  className="block text-gray-700 hover:text-gray-900 hover:bg-gray-100 px-3 py-2 rounded-md font-medium transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  번호 생성
                </a>
                <a
                  href="/history"
                  className="block text-gray-700 hover:text-gray-900 hover:bg-gray-100 px-3 py-2 rounded-md font-medium transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  당첨 이력
                </a>
                <a
                  href="/stats"
                  className="block text-gray-700 hover:text-gray-900 hover:bg-gray-100 px-3 py-2 rounded-md font-medium transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  통계
                </a>
              </div>
            )}
          </div>
        </nav>
        <main>{children}</main>
        <footer className="bg-white border-t mt-12">
          <div className="container mx-auto px-4 py-6 text-center text-gray-700 text-sm">
            <p className="font-medium">LottoMaster - 데이터 기반 로또 번호 추천</p>
            <p className="mt-1 text-xs text-gray-600">
              🎰 행운을 빕니다! (결과는 보장하지 않습니다)
            </p>
          </div>
        </footer>
        </ToastProvider>
      </body>
    </html>
  )
}
