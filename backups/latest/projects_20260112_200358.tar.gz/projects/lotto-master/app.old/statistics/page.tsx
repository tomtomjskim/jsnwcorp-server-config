'use client';

import { useEffect, useState } from 'react';
import Layout from '@/components/layout/Layout';
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface LottoData {
  meta: {
    lastUpdate: string;
    totalDraws: number;
    source: string;
  };
  draws: Array<{
    drawNo: number;
    drawDate: string;
    numbers: number[];
    bonusNum: number;
  }>;
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#8dd1e1'];

export default function StatisticsPage() {
  const [data, setData] = useState<LottoData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/data/lotto-data.json')
      .then((res) => res.json())
      .then((json) => {
        setData(json);
        setLoading(false);
      })
      .catch((err) => {
        console.error('데이터 로드 실패:', err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <p className="text-xl text-gray-600">데이터 로딩 중...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!data) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <p className="text-xl text-red-600">데이터를 불러올 수 없습니다</p>
          </div>
        </div>
      </Layout>
    );
  }

  // 번호별 출현 빈도 계산
  const numberFrequency = new Map<number, number>();
  data.draws.forEach((draw) => {
    draw.numbers.forEach((num) => {
      numberFrequency.set(num, (numberFrequency.get(num) || 0) + 1);
    });
  });

  const frequencyData = Array.from(numberFrequency.entries())
    .map(([num, count]) => ({
      number: num,
      count: count,
    }))
    .sort((a, b) => b.count - a.count);

  // 구간별 출현 분포
  const rangeData = [
    { range: '1-10', count: 0, color: '#fbbf24' },
    { range: '11-20', count: 0, color: '#3b82f6' },
    { range: '21-30', count: 0, color: '#ef4444' },
    { range: '31-40', count: 0, color: '#4b5563' },
    { range: '41-45', count: 0, color: '#10b981' },
  ];

  data.draws.forEach((draw) => {
    draw.numbers.forEach((num) => {
      if (num <= 10) rangeData[0].count++;
      else if (num <= 20) rangeData[1].count++;
      else if (num <= 30) rangeData[2].count++;
      else if (num <= 40) rangeData[3].count++;
      else rangeData[4].count++;
    });
  });

  // 최근 10회차 당첨번호 추이
  const recentDraws = data.draws.slice(0, 10).reverse().map((draw) => ({
    drawNo: draw.drawNo,
    min: Math.min(...draw.numbers),
    max: Math.max(...draw.numbers),
    avg: Math.round(draw.numbers.reduce((a, b) => a + b, 0) / 6),
  }));

  // 홀짝 비율
  let oddCount = 0;
  let evenCount = 0;
  data.draws.forEach((draw) => {
    draw.numbers.forEach((num) => {
      if (num % 2 === 0) evenCount++;
      else oddCount++;
    });
  });

  const oddEvenData = [
    { name: '홀수', value: oddCount },
    { name: '짝수', value: evenCount },
  ];

  return (
    <Layout>
      <div className="bg-gray-50 min-h-screen py-8">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">
              📊 로또 통계 분석
            </h1>
            <p className="text-gray-600">
              총 {data.meta.totalDraws}회차 데이터 기준 (최종 업데이트: {data.meta.lastUpdate})
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-sm text-gray-600 mb-2">전체 회차</h3>
              <p className="text-3xl font-bold text-purple-600">{data.meta.totalDraws}</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-sm text-gray-600 mb-2">최다 출현 번호</h3>
              <p className="text-3xl font-bold text-blue-600">{frequencyData[0].number}</p>
              <p className="text-xs text-gray-500 mt-1">{frequencyData[0].count}회</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-sm text-gray-600 mb-2">최근 회차</h3>
              <p className="text-3xl font-bold text-green-600">{data.draws[0].drawNo}</p>
              <p className="text-xs text-gray-500 mt-1">{data.draws[0].drawDate}</p>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-sm text-gray-600 mb-2">평균 당첨번호</h3>
              <p className="text-3xl font-bold text-orange-600">
                {Math.round(
                  data.draws.reduce((sum, draw) => {
                    return sum + draw.numbers.reduce((a, b) => a + b, 0) / 6;
                  }, 0) / data.draws.length
                )}
              </p>
            </div>
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 번호별 출현 빈도 (Top 20) */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">
                🔥 빈출 번호 TOP 20
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={frequencyData.slice(0, 20)}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="number" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#8b5cf6" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* 구간별 분포 */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">
                📈 구간별 출현 분포
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={rangeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="range" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count">
                    {rangeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* 홀짝 비율 */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">
                🎲 홀수 vs 짝수 비율
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={oddEvenData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => `${entry.name}: ${entry.value}`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {oddEvenData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* 최근 추이 */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4">
                📉 최근 10회차 번호 추이
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={recentDraws}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="drawNo" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="min" stroke="#10b981" name="최소값" />
                  <Line type="monotone" dataKey="avg" stroke="#3b82f6" name="평균" />
                  <Line type="monotone" dataKey="max" stroke="#ef4444" name="최대값" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Number Frequency Table */}
          <div className="bg-white rounded-lg shadow p-6 mt-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              🔢 전체 번호 출현 빈도
            </h2>
            <div className="grid grid-cols-5 sm:grid-cols-9 gap-2">
              {frequencyData.map((item) => (
                <div
                  key={item.number}
                  className="text-center p-3 bg-gray-50 rounded-lg hover:bg-purple-50 transition-colors"
                >
                  <div className="text-2xl font-bold text-purple-600">{item.number}</div>
                  <div className="text-xs text-gray-500">{item.count}회</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
