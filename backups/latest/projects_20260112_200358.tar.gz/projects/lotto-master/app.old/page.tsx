'use client';

import { useState } from 'react';
import Layout from '@/components/layout/Layout';
import { clientAnalytics } from '@/lib/analytics-client';

export default function Home() {
  const [numbers, setNumbers] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);
  const [algorithm, setAlgorithm] = useState<'random' | 'frequency' | 'pattern'>('random');

  const generateNumbers = async () => {
    setLoading(true);
    const startTime = Date.now();

    try {
      const res = await fetch('/api/lotto/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ algorithm, count: 1 }),
      });

      const data = await res.json();

      if (data.success && data.data.numbers.length > 0) {
        const generatedNumbers = data.data.numbers[0];
        setNumbers(generatedNumbers);

        // Analytics: 번호 생성 성공 이벤트 추적
        await clientAnalytics.trackGeneration(algorithm, generatedNumbers, {
          duration_ms: Date.now() - startTime,
          success: true
        });
      } else {
        // Fallback to random generation
        const generated = new Set<number>();
        while (generated.size < 6) {
          const num = Math.floor(Math.random() * 45) + 1;
          generated.add(num);
        }
        const fallbackNumbers = Array.from(generated).sort((a, b) => a - b);
        setNumbers(fallbackNumbers);

        // Analytics: Fallback 이벤트 추적
        await clientAnalytics.trackGeneration('random', fallbackNumbers, {
          duration_ms: Date.now() - startTime,
          success: true,
          fallback: true
        });
      }
    } catch (error) {
      console.error('생성 오류:', error);

      // Analytics: 에러 추적
      await clientAnalytics.trackError(
        error instanceof Error ? error.message : 'Unknown error',
        'generation',
        {
          algorithm,
          duration_ms: Date.now() - startTime
        }
      );

      // Fallback to random generation
      const generated = new Set<number>();
      while (generated.size < 6) {
        const num = Math.floor(Math.random() * 45) + 1;
        generated.add(num);
      }
      const fallbackNumbers = Array.from(generated).sort((a, b) => a - b);
      setNumbers(fallbackNumbers);

      // Analytics: Fallback 이벤트 추적
      await clientAnalytics.trackGeneration('random', fallbackNumbers, {
        duration_ms: Date.now() - startTime,
        success: true,
        fallback: true,
        error: true
      });
    } finally {
      setLoading(false);
    }
  };

  const algorithmLabels = {
    random: '완전 랜덤',
    frequency: '빈도 기반',
    pattern: '패턴 기반',
  };

  return (
    <Layout>
    <div className="min-h-screen bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-2xl w-full">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            🎰 LottoMaster
          </h1>
          <p className="text-gray-600">
            행운의 로또 번호를 생성해드립니다
          </p>
        </div>

        {/* Algorithm Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            생성 알고리즘
          </label>
          <select
            value={algorithm}
            onChange={(e) => setAlgorithm(e.target.value as typeof algorithm)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            disabled={loading}
          >
            {(Object.keys(algorithmLabels) as Array<keyof typeof algorithmLabels>).map((key) => (
              <option key={key} value={key}>
                {algorithmLabels[key]}
              </option>
            ))}
          </select>
          <p className="text-xs text-gray-500 mt-2">
            {algorithm === 'random' && '💫 1~45 중 완전 무작위로 6개 선택'}
            {algorithm === 'frequency' && '📊 출현 빈도가 높은 번호 중심으로 선택'}
            {algorithm === 'pattern' && '🎯 구간 분산 및 패턴 고려하여 선택'}
          </p>
        </div>

        <div className="mb-8">
          {numbers.length > 0 ? (
            <div className="flex justify-center gap-3 flex-wrap">
              {numbers.map((num, idx) => (
                <div
                  key={idx}
                  className={`w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold shadow-lg transition-transform hover:scale-110 ${
                    num <= 10
                      ? 'bg-yellow-500'
                      : num <= 20
                      ? 'bg-blue-500'
                      : num <= 30
                      ? 'bg-red-500'
                      : num <= 40
                      ? 'bg-gray-700'
                      : 'bg-green-500'
                  }`}
                >
                  {num}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-gray-400 py-12">
              <p className="text-lg">번호를 생성해주세요</p>
            </div>
          )}
        </div>

        <div className="text-center">
          <button
            onClick={generateNumbers}
            disabled={loading}
            className={`px-8 py-4 rounded-full text-white font-bold text-lg shadow-lg transition-all ${
              loading
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 hover:shadow-xl'
            }`}
          >
            {loading ? '생성 중...' : '🎲 행운의 번호 생성'}
          </button>
        </div>

        <div className="mt-8 text-center text-sm text-gray-500">
          <p>※ 생성된 번호는 참고용이며 당첨을 보장하지 않습니다</p>
        </div>

        {numbers.length > 0 && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="text-sm font-semibold text-gray-700 mb-2">
              📈 번호 분석
            </h3>
            <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
              <div>
                <span className="font-medium">홀수:</span>{' '}
                {numbers.filter((n) => n % 2 === 1).length}개
              </div>
              <div>
                <span className="font-medium">짝수:</span>{' '}
                {numbers.filter((n) => n % 2 === 0).length}개
              </div>
              <div>
                <span className="font-medium">저번호(1-22):</span>{' '}
                {numbers.filter((n) => n <= 22).length}개
              </div>
              <div>
                <span className="font-medium">고번호(23-45):</span>{' '}
                {numbers.filter((n) => n > 22).length}개
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
    </Layout>
  );
}
