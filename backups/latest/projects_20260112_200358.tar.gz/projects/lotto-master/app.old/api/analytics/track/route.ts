import { NextRequest, NextResponse } from 'next/server';
import { analytics } from '@/lib/analytics';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // IP 주소 및 User-Agent 추출
    const ipAddress = request.headers.get('x-forwarded-for') ||
                     request.headers.get('x-real-ip') ||
                     'unknown';
    const userAgent = request.headers.get('user-agent') || undefined;
    const referer = request.headers.get('referer') || undefined;

    // Analytics 이벤트 추적
    await analytics.trackEvent({
      ...body,
      ipAddress,
      userAgent,
      referrer: referer
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('[API] Analytics tracking error:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to track event'
      },
      { status: 500 }
    );
  }
}
