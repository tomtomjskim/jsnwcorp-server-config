# Changelog

All notable changes to the Lotto Master project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.4.3] - 2026-01-11

### Improved
- **UI/UX 개선**
  - Dark mode 제거로 텍스트 가시성 향상 (globals.css)
  - Ghost 버튼 variant에 border 추가하여 시인성 개선 (button.tsx)
  - Footer 4열 그리드로 확장, 문의 섹션 추가
  - 이메일 주소 직접 표시: jsnetwork.corp@gmail.com
  - 하단 영역 "문의하기" 링크 유지

### Added
- **후원 기능 설계 문서** (`docs/donation-feature-design.md`)
  - 플로팅 버튼 + 모달 UI/UX 설계
  - Toss, 카카오페이, Buy Me a Coffee 연동 방안
  - 구현 체크리스트 및 코드 예시

---

## [0.4.2] - 2026-01-05

### Fixed
- **동행복권 API 리뉴얼 대응** (2025년 12월 웹사이트 리뉴얼)
  - 기존 API `/common.do?method=getLottoNumber` 완전 폐기됨
  - 새 API `/lt645/selectPstLt645Info.do`로 마이그레이션
  - User-Agent 헤더 필수 추가
  - 응답 필드명 매핑 변경:
    - `drwtNo1~6` → `tm1WnNo~tm6WnNo`
    - `bnusNo` → `bnsWnNo`
    - `drwNoDate` → `ltRflYmd` (날짜 형식 YYYYMMDD)
  - 날짜 형식 변환 함수 추가 (YYYYMMDD → YYYY-MM-DD)

- **Cron 스크립트 개선**
  - `npm run` 대신 `./node_modules/.bin/tsx` 직접 실행으로 변경
  - Docker 컨테이너 의존성 제거 (호스트에서 직접 실행)

- **Crontab 설정 복구**
  - 누락된 로또 데이터 수집 크론잡 재등록
  - 스케줄: 일요일 00:00/09:00, 월/화 00:00

### Technical Details
- 1205회 데이터 정상 수집 확인 (2026-01-03 추첨)
- 당첨번호: 1, 4, 16, 23, 31, 41 + 보너스 2
- 1등 당첨금: 약 32억원 (10명)

---

## [0.4.1] - 2025-12-17

### Security
- **Next.js 15.5.9 보안 패치** (2025-12-15)
  - Next.js 15.5.5 → 15.5.9 업데이트
  - 보안 취약점 대응

### Fixed
- **최신회차 분석 테이블 불일치 버그 수정**
  - 최신회차 분석 페이지에서 테이블 데이터 불일치 문제 해결
  - 정확한 통계 표시 보장

---

## [0.4.0] - 2025-11-03

### Added
- **최신회차 종합 분석 페이지** (`/statistics/latest`)
  - 10개 분석 섹션: 히어로, 통계 카드, 분포, 빈도, 패턴, 희귀도, 유사 추첨, 인사이트
  - 고급 통계 분석 및 과거 데이터 비교
  - 5분 캐시를 통한 실시간 새로고침 기능

- **신규 API 엔드포인트**
  - `/api/stats/latest-draw-analysis` - 종합 추첨 분석
  - `latestDrawAnalysis.ts` 라이브러리로 데이터베이스 연동 분석

### Changed
- **UI/UX 개선**
  - 분석 링크를 Footer에서 Statistics/History 페이지로 재배치
  - Statistics 페이지 헤더에 그라데이션 CTA 버튼 추가
  - History 페이지 최신 추첨 섹션에 "상세 분석 보기" 버튼 추가
  - DistributionSection 텍스트 대비 개선 (접근성 향상)
  - 색상 체계 최적화 (indigo-800/gray-900)로 가독성 향상

### Technical Details
- 버전 0.4.0으로 업데이트 (package.json)
- Footer 버전 표시 및 설명 업데이트
- 데이터베이스 프로젝트 메타데이터 업데이트

---

## [0.3.0] - 2025-10-30

### Added
- **Manual Save Functionality**
  - Added manual save button on home page for generated numbers
  - Users can now save numbers only when they explicitly choose to
  - Toast-style feedback messages for save confirmation
  - Removed automatic saving behavior for better user control

- **My Numbers Page** (`/my-numbers`)
  - New dedicated page for viewing all saved lottery numbers
  - Display saved numbers with timestamp and algorithm used
  - Individual delete functionality for each saved number set
  - Bulk delete option to clear all saved numbers
  - Copy to clipboard feature for quick number sharing
  - Smooth animations for delete operations
  - Empty state with call-to-action to generate numbers

- **Real-Time Countdown Timer**
  - Live countdown on home page showing time until next lottery draw
  - Four-unit display: days, hours, minutes, seconds
  - Auto-updates every second with precise calculation
  - Glass-morphism design with gradient background
  - Two status modes:
    - "Waiting" mode: Shows countdown with date/time information
    - "Collecting" mode: Animated pulse indicators when draw results are being collected
  - Integrated with `/api/stats/dashboard-db` for next draw information

- **UI/UX Improvements**
  - New navigation menu item for "저장된 번호" (saved numbers)
  - Enhanced visual hierarchy on home page
  - Improved color-coded number display (yellow/blue/red/gray/green by range)
  - Responsive countdown cards with backdrop blur effects
  - Consistent design language across all pages

### Changed
- **Home Page Layout**
  - Repositioned sections for better visual flow
  - Countdown timer now prominently displayed near top
  - Save button appears only when numbers are generated
  - Improved spacing and visual balance

- **Storage Architecture**
  - Migrated from automatic to manual save workflow
  - Enhanced localStorage utility functions usage
  - Better error handling for storage operations

- **Navigation**
  - Updated header component with new menu item
  - Improved hover states and transitions

### Technical Details
- **Components Modified**:
  - `src/app/page.tsx`: Added save button and countdown timer
  - `src/components/layout/Header.tsx`: Added navigation link
- **Components Created**:
  - `src/app/my-numbers/page.tsx`: New page for saved numbers management
- **API Integration**:
  - `/api/stats/dashboard-db`: Now provides nextDraw information
- **Storage**:
  - localStorage with SavedNumberSet interface
- **Performance**:
  - Countdown timer optimized with proper cleanup
  - Minimal re-renders with strategic useEffect dependencies

### User Experience
- Users now have full control over which numbers to save
- Clear visual feedback for all save operations
- Easy access to previously saved numbers
- Real-time awareness of upcoming draws
- Seamless navigation between generation and saved numbers

---

## [0.2.0] - 2025-10-29

### Added
- **PostgreSQL Database Integration**
  - Complete migration from JSON file storage to PostgreSQL
  - New `lotto.draws` table with 1,195 historical records (2002-12-07 to 2025-10-25)
  - Database loader with optimized queries (`src/lib/data/db-loader.ts`)

- **New DB-Based APIs**
  - `/api/stats/dashboard-db` - Enhanced statistics with PostgreSQL data
  - `/api/lotto/history-db` - Database-powered history endpoint
  - Next draw information calculation and status tracking
    - "Waiting" status before draw time
    - "Collecting" status after draw time but before data available

- **6 New Number Generation Algorithms**
  - `frequency-db`: High-frequency numbers (top 60%)
  - `low-frequency-db`: Low-frequency numbers (bottom 60%)
  - `recent-db`: Recently appeared numbers (within 20 draws)
  - `cold-db`: Cold numbers (20+ draws without appearance)
  - `balanced-db`: Balanced mix (3 high-freq + 3 low-freq)
  - `ai-mixed-db`: AI-powered mixed strategy (comprehensive approach)

- **Automated Data Collection**
  - Smart crawler with date-based latest draw detection
  - Bot-blocking prevention (500ms delay + 5s pause per 100 rounds)
  - UPSERT queries for duplicate prevention
  - Cron scheduler with balanced retry strategy:
    - Sunday 00:00, 09:00 (2 attempts)
    - Monday 00:00 (1 retry)
    - Tuesday 00:00 (final safety net)
  - Weekly success flag mechanism to prevent duplicate runs
  - Comprehensive logging to `/var/log/lotto-cron.log`

- **Documentation**
  - `docs/TODO/IMPROVEMENTS.md` - Future improvement roadmap
  - `docs/DATABASE_SETUP.md` - PostgreSQL setup guide
  - `CHANGELOG.md` - Version history tracking

### Changed
- **API Enhancements**
  - History API now uses PostgreSQL instead of JSON files
  - Statistics API includes hot/cold number analysis
  - All DB-based algorithms return `Promise<number[]>` (async)

- **Type System**
  - Extended `Algorithm` type to include 6 new DB-based algorithms
  - Improved type safety across all generation functions

- **Build System**
  - Resolved all TypeScript type errors
  - Optimized production build (55s compile time)
  - 14 pages successfully generated

### Fixed
- PostgreSQL connection issues in crawler scripts
- Latest draw detection algorithm (now uses date-based calculation)
- Missing 45 rounds (1151-1195) data collection
- TypeScript type errors in NumberGenerator component
- Docker container database connectivity

### Technical Details
- **Database**: PostgreSQL 15.14 (Docker: `postgres:15-alpine`)
- **Connection**: Container IP 172.20.0.20:5432
- **Schema**: `lotto.draws` with indexed columns
- **Total Records**: 1,195 draws
- **Data Integrity**: UPSERT operations with ON CONFLICT handling

### Performance
- Build time: ~55 seconds
- API response: Cached for 5 minutes
- Crawler rate limit: 500ms per request
- Database queries: Optimized with UNION ALL for statistics

### Security
- Environment variables properly loaded from `.env`
- PostgreSQL credentials secured
- Docker container isolation maintained
- Cron jobs run with limited permissions

---

## [0.1.0] - 2024-10-16

### Added
- Initial Next.js 15.5.5 project setup
- Basic lotto number generation algorithms:
  - Random generation
  - Frequency-based generation
  - Pattern-based generation
- JSON-based data storage
- Statistics dashboard
- Number history viewing
- User-friendly UI with Tailwind CSS
- Analytics tracking
- Health check endpoint

### Features
- Number generator with multiple algorithms
- Historical draw data viewing
- Basic statistics calculation
- Responsive design
- Dark mode support

---

## Release Notes

### Version 0.2.0 Highlights

This is a major update that transforms the Lotto Master project from a JSON-based system to a fully PostgreSQL-powered application with advanced AI algorithms and automated data collection.

**🎯 Key Improvements:**
- 6x more number generation strategies
- 100% database-backed operations
- Automated weekly data updates
- Smart retry logic for reliable data collection
- Enhanced statistics with hot/cold number analysis
- Next draw countdown and status tracking

**📊 Data Coverage:**
- Complete historical data: 1,195 draws
- Date range: 2002-12-07 to 2025-10-25
- Zero missing records
- Real-time updates via cron scheduler

**🔧 For Developers:**
- All APIs now async-compatible
- Improved type safety
- Better error handling
- Comprehensive logging
- Docker-ready production build

**🚀 Next Steps:**
See `docs/TODO/IMPROVEMENTS.md` for planned enhancements including:
- Frontend UI for next draw status
- Notification system for crawl failures
- Performance optimization with Redis
- User account system
- Machine learning predictions

---

**Upgrade Instructions:**

To deploy version 0.2.0:

1. Pull latest code
2. Rebuild Docker image:
   ```bash
   docker build -f Dockerfile.prod -t deploy-lotto-service:0.2.0 .
   ```
3. Stop and remove old container:
   ```bash
   docker stop lotto-service
   docker rm lotto-service
   ```
4. Start new container with updated image
5. Verify cron scheduler:
   ```bash
   crontab -l | grep lotto
   ```

**Database Migration:** Already completed automatically if you followed previous setup steps.

**Breaking Changes:** None - all legacy APIs remain functional for backward compatibility.
