# 📊 오늘의 운세 - 데이터 구조 가이드

**프로젝트**: 오늘의 운세 (Today Fortune)
**위치**: `/home/deploy/projects/today-fortune`
**작성일**: 2025-10-17

---

## 📂 데이터 디렉토리 위치

```
/home/deploy/projects/today-fortune/public/data/
```

**중요**: 이 디렉토리의 모든 JSON 파일은 **빌드 시 `dist/data/`로 복사**되어 클라이언트에서 fetch로 로드됩니다.

---

## 🗂 데이터 파일 구조

### 1. 만세력 데이터

**파일**: `calendar.json`
**용도**: 1900-2100년 음력/양력 변환 및 24절기
**크기**: 예상 ~500KB

```json
{
  "years": [
    {
      "year": 2025,
      "ganzi": { "gan": "을", "ji": "사" },
      "jieqi": [
        { "name": "입춘", "solar": "2025-02-03" },
        { "name": "경칩", "solar": "2025-03-05" }
      ],
      "months": [
        {
          "lunarMonth": 1,
          "solarStart": "2025-01-29",
          "solarEnd": "2025-02-27",
          "isLeap": false
        }
      ]
    }
  ]
}
```

**AI 작업 필요**: ✅ 200년치 데이터 생성 (알고리즘 활용)

---

### 2. 사주 기초 데이터

#### 2-1. 천간지지 (`saju/ganzi.json`) ✅ 완료

- 10천간, 12지지 기본 속성
- 오행, 음양, 띠 매핑
- **작업 상태**: 완료

#### 2-2. 오행 데이터 (`saju/ohaeng.json`) ✅ 완료

- 목/화/토/금/수 속성 (색상, 계절, 방향)
- 상생상극 관계
- 균형 판단 기준
- **작업 상태**: 완료

#### 2-3. 십신 데이터 (`saju/sipsin.json`) ✅ 완료

- 비견, 겁재, 식신, 상관, 편재, 정재, 편관, 정관, 편인, 정인
- 각 십신의 의미 및 장단점
- **작업 상태**: 완료

---

### 3. 사주 해석 데이터 (AI 생성 필요 ⭐)

#### 3-1. 성격 해석 (`saju/interpretations/personality.json`)

**필요 개수**: 60개 (60갑자)
**현재 진행**: 1/60 (샘플 1개만 작성됨)

```json
{
  "interpretations": [
    {
      "ganzi": "갑자",
      "shortDescription": "강인한 생명력과 창의성을 가진 개척자형",
      "personality": "200-300자 상세 설명",
      "strengths": ["창의력", "리더십", "추진력"],
      "weaknesses": ["고집", "독선"],
      "lifeStyle": "활동적이고 도전적인 삶"
    }
  ]
}
```

**AI 작업**:
- 나머지 59개 갑자 해석 생성
- 각 일주의 특성을 명리학 기반으로 작성
- 60갑자 순서: 갑자 → 을축 → 병인 → ... → 계해

#### 3-2. 직업운 (`saju/interpretations/career.json`)

**필요 개수**: 60개
**현재 진행**: 1/60

```json
{
  "career": [
    {
      "ganzi": "갑자",
      "suitableJobs": ["기업가", "프로젝트 매니저", "교육자"],
      "workStyle": "주도적이고 창의적인 업무 선호",
      "careerAdvice": "독립적인 업무가 적합"
    }
  ]
}
```

#### 3-3. 재물운 (`saju/interpretations/wealth.json`)

**필요 개수**: 60개
**현재 진행**: 1/60

```json
{
  "wealth": [
    {
      "ganzi": "갑자",
      "wealthTendency": "활동을 통한 재물 획득형",
      "moneyManagement": "수입과 지출이 모두 큰 편",
      "investmentStyle": "성장주, 신기술 분야 선호",
      "advice": "장기 저축 계획 필요"
    }
  ]
}
```

---

### 4. 일일 운세 데이터 (AI 생성 필요 ⭐)

#### 4-1. 일일 운세 템플릿 (`fortune/daily.json`)

**필요 개수**: 약 300개 메시지
**현재 진행**: 기본 구조만 작성 (샘플 15개)

**구성**:
- 총운: 5단계 × 3개 = 15개
- 애정운: 5단계 × 12개 = 60개 ⚠️ 필요
- 금전운: 5단계 × 12개 = 60개 ⚠️ 필요
- 건강운: 5단계 × 12개 = 60개 ⚠️ 필요
- 조언: 12띠 × 10개 = 120개 ⚠️ 필요

**점수 구간**:
- 80-100: excellent (매우 좋음)
- 60-79: good (좋음)
- 40-59: normal (보통)
- 20-39: caution (주의)
- 0-19: bad (나쁨)

#### 4-2. 띠별 운세 (`fortune/zodiac.json`)

**필요 개수**: 12띠 기본 정보
**현재 진행**: 3/12 (쥐, 소, 호랑이만 작성)

**추가 필요**:
- 토끼띠, 용띠, 뱀띠, 말띠, 양띠, 원숭이띠, 닭띠, 개띠, 돼지띠 (9개)
- 각 띠별 특성, 행운색, 행운숫자

#### 4-3. 타로 카드 (`fortune/tarot.json`)

**필요 개수**: 22장 (메이저 아르카나)
**현재 진행**: 3/22

**추가 필요**: 19장
- The Empress, The Emperor, The Hierophant, ...
- The World까지

---

### 5. 궁합 데이터 (AI 생성 필요 ⭐)

#### 5-1. 띠별 궁합 (`compatibility/sangsung.json`)

**필요 개수**: 144개 (12 × 12)
**현재 진행**: 2/144

```json
{
  "compatibility": [
    {
      "zodiac1": "쥐띠",
      "zodiac2": "소띠",
      "score": 85,
      "level": "excellent",
      "summary": "서로의 장점을 살리는 최고의 궁합",
      "love": "애정 궁합 설명",
      "work": "업무 궁합 설명",
      "advice": "조언"
    }
  ]
}
```

**AI 작업**: 142개 조합 생성

---

## 📊 데이터 생성 우선순위

### 🔴 Phase 1 (MVP) - 즉시 필요

1. **만세력 데이터** (`calendar.json`)
   - 상태: ⚠️ 빈 파일
   - 우선순위: 최상
   - 방법: 알고리즘 또는 오픈소스 활용

2. **일일 운세 메시지** (`fortune/daily.json`)
   - 상태: ⚠️ 15/300개
   - 우선순위: 최상
   - 최소: 총운 15개 + 애정/금전/건강 각 60개 = 195개

3. **띠별 기본 정보** (`fortune/zodiac.json`)
   - 상태: ⚠️ 3/12개
   - 우선순위: 높음
   - 최소: 12띠 기본 정보

### 🟡 Phase 2 (사주팔자) - 2주 내

4. **60갑자 성격 해석** (`saju/interpretations/personality.json`)
   - 상태: ⚠️ 1/60개
   - 우선순위: 높음
   - 방법: AI 대량 생성 후 검수

5. **직업운 & 재물운** (각 60개)
   - 상태: ⚠️ 각 1/60개
   - 우선순위: 중간

### 🟢 Phase 3 (심화 기능) - 1개월 내

6. **궁합 데이터** (`compatibility/sangsung.json`)
   - 상태: ⚠️ 2/144개
   - 우선순위: 낮음

7. **타로 카드** (`fortune/tarot.json`)
   - 상태: ⚠️ 3/22개
   - 우선순위: 낮음

---

## 🤖 AI에게 데이터 생성 요청 방법

### 예시 프롬프트 (60갑자 성격 해석)

```
다음 60갑자 일주에 대한 성격 해석을 JSON 형식으로 작성해주세요:

갑자, 을축, 병인, 정묘, ... (60개)

각 항목은 다음 형식을 따라주세요:
{
  "ganzi": "갑자",
  "shortDescription": "50자 이내 한 줄 요약",
  "personality": "200-300자 상세 설명",
  "strengths": ["장점1", "장점2", "장점3"],
  "weaknesses": ["단점1", "단점2"],
  "lifeStyle": "삶의 방식 한 줄"
}

명리학 기본 원리를 반영하되, 일반인이 이해하기 쉽게 작성해주세요.
```

---

## 📁 데이터 로드 방법 (프론트엔드)

```javascript
// 예시: 천간지지 데이터 로드
async function loadGanziData() {
  const response = await fetch('/data/saju/ganzi.json');
  const data = await response.json();
  return data;
}

// 예시: 특정 갑자 성격 조회
async function getPersonality(ganzi) {
  const response = await fetch('/data/saju/interpretations/personality.json');
  const data = await response.json();
  return data.interpretations.find(item => item.ganzi === ganzi);
}
```

---

## ✅ 데이터 검증 체크리스트

### 기본 검증
- [ ] 모든 JSON 파일이 유효한 형식인가?
- [ ] 한글 인코딩이 정상인가? (UTF-8)
- [ ] `_description` 필드가 있는가?

### 내용 검증
- [ ] 60갑자 순서가 정확한가?
- [ ] 12띠 매핑이 정확한가?
- [ ] 오행 상생상극 관계가 맞는가?
- [ ] 점수 범위가 0-100 내인가?

### 품질 검증
- [ ] 텍스트 길이가 적절한가? (200-300자)
- [ ] 중복되는 문장이 없는가?
- [ ] 오타나 맞춤법 오류가 없는가?
- [ ] 부정적 표현이 과하지 않은가?

---

## 🔧 데이터 업데이트 프로세스

1. **JSON 파일 수정** (로컬 또는 직접 편집)
2. **빌드 실행**: `npm run build`
3. **Docker 이미지 재생성**: `docker compose build fortune-service`
4. **배포**: `docker compose up -d fortune-service`

---

## 📚 참고 자료

### 명리학 기초
- 천간지지 60갑자 순서표
- 오행 상생상극 이론
- 십신 개념 설명

### 데이터 출처
- 만세력: 한국천문연구원 또는 오픈소스 라이브러리
- 해석 텍스트: AI 생성 후 전문가 검수 권장

---

## 🚨 주의사항

1. **저작권**: 기존 운세 앱의 텍스트를 그대로 복사하지 마세요
2. **책임 고지**: 운세는 오락 목적이며 법적 책임이 없음을 명시
3. **개인정보**: 사용자 생년월일은 LocalStorage에만 저장 (서버 전송 X)
4. **정확성**: 명리학 기본 원리를 최대한 따르되, 100% 정확성은 보장 불가

---

**문서 버전**: 1.0
**최종 수정**: 2025-10-17
**다음 업데이트**: 데이터 생성 완료 시
