/**
 * 만세력 데이터 생성 스크립트
 * lunar-typescript 라이브러리 사용
 * 1900-2100년 음력/양력 변환 및 24절기 데이터 생성
 */

import { Solar, Lunar, LunarMonth } from 'lunar-typescript';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 24절기 한글 이름
const JIEQI_NAMES = {
  '立春': '입춘', '雨水': '우수', '惊蛰': '경칩', '春分': '춘분',
  '清明': '청명', '谷雨': '곡우', '立夏': '입하', '小满': '소만',
  '芒种': '망종', '夏至': '하지', '小暑': '소서', '大暑': '대서',
  '立秋': '입추', '处暑': '처서', '白露': '백로', '秋分': '추분',
  '寒露': '한로', '霜降': '상강', '立冬': '입동', '小雪': '소설',
  '大雪': '대설', '冬至': '동지', '小寒': '소한', '大寒': '대한'
};

// 지지와 띠 매핑
const JI_TO_ANIMAL = {
  '子': '쥐', '丑': '소', '寅': '호랑이', '卯': '토끼',
  '辰': '용', '巳': '뱀', '午': '말', '未': '양',
  '申': '원숭이', '酉': '닭', '戌': '개', '亥': '돼지'
};

/**
 * 특정 연도의 모든 데이터 생성
 */
function generateYearData(year) {
  // Use March 1st to ensure we're after 입춘 (Spring Begins)
  // 입춘 is typically between Feb 3-5, so March 1st is always after it
  const solar = Solar.fromYmd(year, 3, 1);
  const lunar = solar.getLunar();

  const yearData = {
    year: year,
    ganzi: {
      gan: lunar.getYearGanByLiChun(),
      ji: lunar.getYearZhiByLiChun(),
      ganzi: lunar.getYearInGanZhiByLiChun(),
      animal: JI_TO_ANIMAL[lunar.getYearZhiByLiChun()] || ''
    },
    jieqi: [],
    months: []
  };

  // Reset solar to Jan 1 for jieqi extraction
  const solarJan = Solar.fromYmd(year, 1, 1);
  const lunarJan = solarJan.getLunar();

  // 24절기 추출 (해당 연도)
  const jieqiTable = lunarJan.getJieQiTable();
  const jieqiList = [];

  for (const [jieqiName, solarDate] of Object.entries(jieqiTable)) {
    if (solarDate.getYear() === year) {
      jieqiList.push({
        name: JIEQI_NAMES[jieqiName] || jieqiName,
        nameHanja: jieqiName,
        solar: `${solarDate.getYear()}-${String(solarDate.getMonth()).padStart(2, '0')}-${String(solarDate.getDay()).padStart(2, '0')}`,
        solarTime: solarDate.toYmdHms()
      });
    }
  }

  // 절기를 날짜순으로 정렬
  jieqiList.sort((a, b) => a.solar.localeCompare(b.solar));
  yearData.jieqi = jieqiList;

  // 각 월의 음력 정보 생성 (양력 월 기준)
  for (let month = 1; month <= 12; month++) {
    const monthData = {
      solarMonth: month,
      lunarMonths: []
    };

    // 해당 월의 모든 날짜 확인
    const daysInMonth = new Date(year, month, 0).getDate();
    const lunarMonthsInSolarMonth = new Set();

    for (let day = 1; day <= daysInMonth; day++) {
      try {
        const s = Solar.fromYmd(year, month, day);
        const l = s.getLunar();

        const lunarKey = `${l.getYear()}-${l.getMonth()}`;
        if (!lunarMonthsInSolarMonth.has(lunarKey)) {
          lunarMonthsInSolarMonth.add(lunarKey);

          const lunarMonth = l.getMonth();
          const lunarYear = l.getYear();
          const absMonth = Math.abs(lunarMonth);
          const lm = LunarMonth.fromYm(lunarYear, absMonth);

          monthData.lunarMonths.push({
            lunarYear: lunarYear,
            lunarMonth: absMonth,
            isLeap: lunarMonth < 0,
            daysInMonth: lm ? lm.getDayCount() : 30
          });
        }
      } catch (e) {
        console.error(`Error processing ${year}-${month}-${day}:`, e.message);
      }
    }

    yearData.months.push(monthData);
  }

  return yearData;
}

/**
 * 특정 날짜의 음력/양력 변환 샘플 생성
 */
function generateConversionSamples(year) {
  const samples = [];

  // 매월 1일, 15일 샘플
  for (let month = 1; month <= 12; month++) {
    [1, 15].forEach(day => {
      try {
        const solar = Solar.fromYmd(year, month, day);
        const lunar = solar.getLunar();

        samples.push({
          solar: {
            year: solar.getYear(),
            month: solar.getMonth(),
            day: solar.getDay(),
            weekday: solar.getWeek()
          },
          lunar: {
            year: lunar.getYear(),
            month: Math.abs(lunar.getMonth()),
            day: lunar.getDay(),
            isLeap: lunar.getMonth() < 0,
            monthInChinese: lunar.getMonthInChinese(),
            dayInChinese: lunar.getDayInChinese()
          },
          ganzi: {
            year: lunar.getYearInGanZhi(),
            month: lunar.getMonthInGanZhi(),
            day: lunar.getDayInGanZhi()
          }
        });
      } catch (e) {
        // Skip invalid dates
      }
    });
  }

  return samples;
}

/**
 * 전체 만세력 데이터 생성
 */
function generateCalendarData(startYear = 1900, endYear = 2100) {
  console.log(`만세력 데이터 생성 시작: ${startYear}-${endYear}`);

  const calendarData = {
    version: '1.0',
    description: '만세력 데이터 (음력/양력 변환, 24절기)',
    generated: new Date().toISOString(),
    yearRange: {
      start: startYear,
      end: endYear
    },
    years: []
  };

  const progressInterval = 10;

  for (let year = startYear; year <= endYear; year++) {
    try {
      const yearData = generateYearData(year);
      calendarData.years.push(yearData);

      if (year % progressInterval === 0) {
        console.log(`진행 중... ${year}년 (${Math.round((year - startYear) / (endYear - startYear) * 100)}%)`);
      }
    } catch (error) {
      console.error(`${year}년 데이터 생성 실패:`, error.message);
    }
  }

  console.log('만세력 데이터 생성 완료!');
  return calendarData;
}

/**
 * 샘플 데이터 생성 (테스트용)
 */
function generateSampleData() {
  console.log('샘플 데이터 생성 중...');

  const samples = {
    version: '1.0',
    description: '만세력 샘플 데이터 (변환 예제)',
    samples: []
  };

  // 각 10년마다 샘플
  for (let year = 1900; year <= 2100; year += 10) {
    samples.samples.push(...generateConversionSamples(year));
  }

  return samples;
}

/**
 * 메인 실행
 */
async function main() {
  const outputDir = path.join(__dirname, '../public/data');

  // 1. 전체 만세력 데이터 생성 (1900-2100)
  console.log('\n=== 1단계: 전체 만세력 데이터 생성 ===');
  const calendarData = generateCalendarData(1900, 2100);

  const calendarPath = path.join(outputDir, 'calendar.json');
  fs.writeFileSync(calendarPath, JSON.stringify(calendarData, null, 2), 'utf-8');
  console.log(`✅ 저장 완료: ${calendarPath}`);
  console.log(`   크기: ${(fs.statSync(calendarPath).size / 1024).toFixed(2)} KB`);
  console.log(`   연도 개수: ${calendarData.years.length}개`);

  // 2. 샘플 데이터 생성 (빠른 테스트용)
  console.log('\n=== 2단계: 샘플 데이터 생성 ===');
  const sampleData = generateSampleData();

  const samplePath = path.join(outputDir, 'calendar-samples.json');
  fs.writeFileSync(samplePath, JSON.stringify(sampleData, null, 2), 'utf-8');
  console.log(`✅ 저장 완료: ${samplePath}`);
  console.log(`   샘플 개수: ${sampleData.samples.length}개`);

  // 3. 통계 정보
  console.log('\n=== 생성 완료 ===');
  console.log(`총 ${calendarData.years.length}년치 데이터 생성`);

  // 24절기 총 개수 계산
  const totalJieqi = calendarData.years.reduce((sum, year) => sum + year.jieqi.length, 0);
  console.log(`24절기 데이터: ${totalJieqi}개`);

  console.log('\n파일 위치:');
  console.log(`  - ${calendarPath}`);
  console.log(`  - ${samplePath}`);
}

// 실행
main().catch(console.error);
