/**
 * 오행 분석기
 * 사주팔자의 오행 균형을 분석하고 해석
 */

// 천간의 오행
const GAN_OHAENG = {
  '甲': '목', '乙': '목',
  '丙': '화', '丁': '화',
  '戊': '토', '己': '토',
  '庚': '금', '辛': '금',
  '壬': '수', '癸': '수'
};

// 지지의 오행 (본기 기준)
const JI_OHAENG = {
  '子': '수', '丑': '토', '寅': '목', '卯': '목',
  '辰': '토', '巳': '화', '午': '화', '未': '토',
  '申': '금', '酉': '금', '戌': '토', '亥': '수'
};

// 오행 한글-영문 매핑
const OHAENG_EN = {
  '목': 'wood',
  '화': 'fire',
  '토': 'earth',
  '금': 'metal',
  '수': 'water'
};

// 오행 해석 데이터 캐시
let ohaengInterpretationCache = null;

/**
 * 오행 해석 데이터 로드
 */
export async function loadOhaengInterpretation() {
  if (ohaengInterpretationCache) return ohaengInterpretationCache;

  try {
    const response = await fetch('/data/ohaeng-interpretation.json');

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    ohaengInterpretationCache = await response.json();
    return ohaengInterpretationCache;
  } catch (error) {
    console.error('Failed to load ohaeng interpretation:', error);

    // 네트워크 오류 세부 메시지
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error('네트워크 연결을 확인해주세요. 오행 해석 데이터를 불러올 수 없습니다.');
    } else if (error.message.includes('HTTP')) {
      throw new Error(`오행 해석 데이터를 불러올 수 없습니다. (${error.message})`);
    } else {
      throw new Error('오행 해석 데이터를 불러오는 중 오류가 발생했습니다.');
    }
  }
}

/**
 * 사주의 오행 개수 계산
 * @param {Object} saju - 사주팔자 객체
 * @returns {Object} 오행별 개수
 */
export function countOhaeng(saju) {
  const count = {
    목: 0,
    화: 0,
    토: 0,
    금: 0,
    수: 0
  };

  // 연주
  if (saju.year) {
    count[GAN_OHAENG[saju.year.gan] || '목']++;
    count[JI_OHAENG[saju.year.ji] || '목']++;
  }

  // 월주
  if (saju.month) {
    count[GAN_OHAENG[saju.month.gan] || '목']++;
    count[JI_OHAENG[saju.month.ji] || '목']++;
  }

  // 일주
  if (saju.day) {
    count[GAN_OHAENG[saju.day.gan] || '목']++;
    count[JI_OHAENG[saju.day.ji] || '목']++;
  }

  // 시주
  if (saju.hour) {
    count[GAN_OHAENG[saju.hour.gan] || '목']++;
    count[JI_OHAENG[saju.hour.ji] || '목']++;
  }

  return count;
}

/**
 * 오행 균형 상태 분석
 * @param {Object} count - 오행별 개수
 * @returns {Object} 분석 결과
 */
export function analyzeBalance(count) {
  const total = Object.values(count).reduce((sum, val) => sum + val, 0);
  const average = total / 5;

  const balance = {
    total,
    average,
    deficient: [], // 부족한 오행
    excessive: [],  // 과한 오행
    balanced: []    // 균형잡힌 오행
  };

  // 각 오행의 비율 계산
  Object.entries(count).forEach(([ohaeng, cnt]) => {
    const percentage = (cnt / total) * 100;

    if (cnt === 0) {
      balance.deficient.push({
        ohaeng,
        count: cnt,
        percentage: 0,
        level: 'none'
      });
    } else if (cnt < average * 0.6) {
      balance.deficient.push({
        ohaeng,
        count: cnt,
        percentage,
        level: cnt === 1 ? 'very_low' : 'low'
      });
    } else if (cnt > average * 1.6) {
      balance.excessive.push({
        ohaeng,
        count: cnt,
        percentage,
        level: cnt >= 4 ? 'very_high' : 'high'
      });
    } else {
      balance.balanced.push({
        ohaeng,
        count: cnt,
        percentage,
        level: 'balanced'
      });
    }
  });

  return balance;
}

/**
 * 오행 분석 및 해석 생성
 * @param {Object} saju - 사주팔자 객체
 * @returns {Object} 오행 분석 결과 및 해석
 */
export async function analyzeOhaeng(saju) {
  const count = countOhaeng(saju);
  const balance = analyzeBalance(count);
  const interpretation = await loadOhaengInterpretation();

  // 오행별 해석 매칭
  const interpretations = {
    deficient: [],
    excessive: [],
    summary: ''
  };

  // 부족한 오행 해석
  for (const item of balance.deficient) {
    const ohaengData = interpretation.ohaeng_analysis?.[item.ohaeng];

    if (ohaengData && ohaengData.deficiency) {
      // level에 맞는 데이터 찾기 (none -> level_2, very_low/low -> level_1)
      let levelKey = 'level_1';
      if (item.level === 'none') {
        levelKey = 'level_2';
      }

      const levelData = ohaengData.deficiency[levelKey];
      if (levelData) {
        interpretations.deficient.push({
          ohaeng: item.ohaeng,
          level: item.level,
          count: item.count,
          percentage: item.percentage,
          summary: levelData.status,
          symptoms: levelData.symptoms,
          advice: levelData.advice,
          recommended_activity: levelData.recommended_activity,
          food: levelData.food,
          caution: levelData.caution
        });
      }
    }
  }

  // 과한 오행 해석
  for (const item of balance.excessive) {
    const ohaengData = interpretation.ohaeng_analysis?.[item.ohaeng];

    if (ohaengData && ohaengData.excess) {
      // level에 맞는 데이터 찾기 (high -> level_1, very_high -> level_2)
      let levelKey = 'level_1';
      if (item.level === 'very_high') {
        levelKey = 'level_2';
      }

      const levelData = ohaengData.excess[levelKey];
      if (levelData) {
        interpretations.excessive.push({
          ohaeng: item.ohaeng,
          level: item.level,
          count: item.count,
          percentage: item.percentage,
          summary: levelData.status,
          symptoms: levelData.symptoms,
          advice: levelData.advice,
          recommended_activity: levelData.recommended_activity,
          food: levelData.food,
          caution: levelData.caution
        });
      }
    }
  }

  // 전체 요약 생성
  if (balance.deficient.length === 0 && balance.excessive.length === 0) {
    interpretations.summary = '오행의 균형이 매우 잘 잡혀 있습니다. 다방면으로 조화로운 삶을 살아갈 수 있는 사주입니다.';
  } else {
    const summaryParts = [];

    if (balance.deficient.length > 0) {
      const deficientNames = balance.deficient.map(d => d.ohaeng).join(', ');
      summaryParts.push(`${deficientNames}이(가) 부족`);
    }

    if (balance.excessive.length > 0) {
      const excessiveNames = balance.excessive.map(e => e.ohaeng).join(', ');
      summaryParts.push(`${excessiveNames}이(가) 과함`);
    }

    interpretations.summary = `${summaryParts.join('하고 ')}한 사주입니다.`;
  }

  return {
    count,
    balance,
    interpretations,
    chart: {
      labels: ['목', '화', '토', '금', '수'],
      data: [count.목, count.화, count.토, count.금, count.수],
      colors: ['#4CAF50', '#FF5722', '#FFEB3B', '#9E9E9E', '#2196F3']
    }
  };
}

/**
 * 오행 상생상극 관계 분석
 * @param {string} ohaeng1 - 첫 번째 오행
 * @param {string} ohaeng2 - 두 번째 오행
 * @returns {Object} 관계 분석 결과
 */
export function getOhaengRelation(ohaeng1, ohaeng2) {
  // 상생 관계: 목생화, 화생토, 토생금, 금생수, 수생목
  const sangsaeng = {
    '목': '화',
    '화': '토',
    '토': '금',
    '금': '수',
    '수': '목'
  };

  // 상극 관계: 목극토, 토극수, 수극화, 화극금, 금극목
  const sangguk = {
    '목': '토',
    '토': '수',
    '수': '화',
    '화': '금',
    '금': '목'
  };

  if (ohaeng1 === ohaeng2) {
    return { type: 'same', description: '같은 오행' };
  }

  if (sangsaeng[ohaeng1] === ohaeng2) {
    return { type: 'generate', description: `${ohaeng1}이(가) ${ohaeng2}을(를) 생함 (상생)` };
  }

  if (sangsaeng[ohaeng2] === ohaeng1) {
    return { type: 'generated', description: `${ohaeng1}이(가) ${ohaeng2}에게 생을 받음 (상생)` };
  }

  if (sangguk[ohaeng1] === ohaeng2) {
    return { type: 'control', description: `${ohaeng1}이(가) ${ohaeng2}을(를) 극함 (상극)` };
  }

  if (sangguk[ohaeng2] === ohaeng1) {
    return { type: 'controlled', description: `${ohaeng1}이(가) ${ohaeng2}에게 극을 받음 (상극)` };
  }

  return { type: 'neutral', description: '특별한 관계 없음' };
}

/**
 * 일간 오행 기준으로 필요한 오행 추천
 * @param {string} dayGan - 일간 천간
 * @param {Object} count - 오행 개수
 * @returns {Object} 추천 오행
 */
export function getRecommendedOhaeng(dayGan, count) {
  const dayOhaeng = GAN_OHAENG[dayGan];

  // 일간이 약하면 상생하는 오행과 같은 오행 필요
  // 일간이 강하면 설기하는 오행 필요

  const recommendations = {
    favorable: [], // 유리한 오행
    unfavorable: [] // 불리한 오행
  };

  const sangsaeng = {
    '목': { generate: '화', generated: '수', control: '토' },
    '화': { generate: '토', generated: '목', control: '금' },
    '토': { generate: '금', generated: '화', control: '수' },
    '금': { generate: '수', generated: '토', control: '목' },
    '수': { generate: '목', generated: '금', control: '화' }
  };

  const relation = sangsaeng[dayOhaeng];

  // 일간이 약한 경우 (같은 오행 개수가 2개 이하)
  if (count[dayOhaeng] <= 2) {
    recommendations.favorable.push({
      ohaeng: dayOhaeng,
      reason: '일간을 강화'
    });
    recommendations.favorable.push({
      ohaeng: relation.generated,
      reason: '일간을 생해주는 오행'
    });
  } else {
    // 일간이 강한 경우
    recommendations.favorable.push({
      ohaeng: relation.generate,
      reason: '일간을 설기하는 오행'
    });
    recommendations.favorable.push({
      ohaeng: relation.control,
      reason: '일간이 극하는 오행 (재물)'
    });
  }

  return recommendations;
}

export default {
  countOhaeng,
  analyzeBalance,
  analyzeOhaeng,
  getOhaengRelation,
  getRecommendedOhaeng
};
