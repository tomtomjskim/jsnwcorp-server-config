/**
 * 운세 생성 엔진
 * 생년월일 + 오늘 날짜로 일일 운세 생성
 */

// 운세 템플릿 캐시
let fortuneTemplateCache = null;

/**
 * 운세 템플릿 데이터 로드
 */
export async function loadFortuneTemplates() {
  if (fortuneTemplateCache) return fortuneTemplateCache;

  try {
    const response = await fetch('/data/fortune-daily-templates.json');

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    fortuneTemplateCache = await response.json();
    return fortuneTemplateCache;
  } catch (error) {
    console.error('Failed to load fortune templates:', error);

    // 네트워크 오류 세부 메시지
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error('네트워크 연결을 확인해주세요. 인터넷 연결이 불안정합니다.');
    } else if (error.message.includes('HTTP')) {
      throw new Error(`운세 데이터를 불러올 수 없습니다. (${error.message})`);
    } else {
      throw new Error('운세 템플릿을 불러오는 중 오류가 발생했습니다.');
    }
  }
}

/**
 * Seed 기반 난수 생성기 (재현 가능한 랜덤)
 * @param {number} seed - 시드 값
 * @returns {Function} 0-1 사이의 난수를 생성하는 함수
 */
function seededRandom(seed) {
  let state = seed;

  return function() {
    // Linear Congruential Generator
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296;
  };
}

/**
 * 날짜와 프로필 정보로 고유 seed 생성
 * @param {Date} date - 대상 날짜
 * @param {Object} birthInfo - 생년월일 및 프로필 정보
 * @returns {number} seed 값
 */
function generateSeed(date, birthInfo) {
  // 날짜는 연월일만 사용 (시간 무시)
  const dateStr = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`;

  // 프로필 정보: 생년월일시 + 성별 + 음력여부
  const birthStr = `${birthInfo.year}${String(birthInfo.month).padStart(2, '0')}${String(birthInfo.day).padStart(2, '0')}`;
  const hourStr = String(birthInfo.hour || 12).padStart(2, '0');
  const minuteStr = String(birthInfo.minute || 0).padStart(2, '0');
  const genderStr = (birthInfo.gender === 'female' ? 'F' : 'M');
  const lunarStr = (birthInfo.isLunar ? 'L' : 'S');

  // 이름도 포함 (선택사항 - 이름이 있으면 추가)
  const nameStr = birthInfo.name || '';

  // 모든 정보 결합
  const combined = dateStr + birthStr + hourStr + minuteStr + genderStr + lunarStr + nameStr;

  // 문자열을 숫자로 변환
  let seed = 0;
  for (let i = 0; i < combined.length; i++) {
    seed = (seed * 31 + combined.charCodeAt(i)) & 0xffffffff;
  }

  // 음수를 양수로 변환 (unsigned 32bit)
  return seed >>> 0;
}

/**
 * 점수를 등급으로 변환
 * @param {number} score - 0-100 점수
 * @returns {string} 등급 (excellent/good/normal/caution/bad)
 */
function scoreToGrade(score) {
  if (score >= 85) return 'excellent';
  if (score >= 70) return 'good';
  if (score >= 40) return 'normal';
  if (score >= 20) return 'caution';
  return 'bad';
}

/**
 * 타로 카드 데이터 로드
 */
export async function loadTarotCards() {
  try {
    const response = await fetch('/data/fortune/tarot.json');

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    return data.cards || [];
  } catch (error) {
    console.error('Failed to load tarot cards:', error);

    // 타로 카드는 선택적 기능이므로 빈 배열 반환
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.warn('네트워크 오류로 타로 카드를 불러올 수 없습니다.');
    } else if (error.message.includes('HTTP')) {
      console.warn(`타로 카드 데이터를 불러올 수 없습니다. (${error.message})`);
    }

    return [];
  }
}

/**
 * 오늘의 운세 생성
 * @param {Object} birthInfo - 생년월일 정보
 * @param {Date} targetDate - 대상 날짜 (기본값: 오늘)
 * @returns {Object} 운세 결과
 */
export async function generateDailyFortune(birthInfo, targetDate = new Date()) {
  const templates = await loadFortuneTemplates();
  const tarotCards = await loadTarotCards();

  // Seed 생성 및 랜덤 함수 초기화
  const seed = generateSeed(targetDate, birthInfo);
  const random = seededRandom(seed);

  // 운세 점수 생성 (정규분포 근사)
  // 평균 50점 기준으로 자연스러운 분포
  const baseRandom = random();
  const variance = (random() - 0.5) * 2; // -1 ~ +1
  const normalScore = 50 + (baseRandom - 0.5) * 50 + variance * 15;
  const totalScore = Math.max(5, Math.min(100, Math.round(normalScore)));

  // 각 카테고리별 점수도 동일한 방식으로 생성
  const loveBase = random();
  const loveVariance = (random() - 0.5) * 2;
  const loveNormal = 50 + (loveBase - 0.5) * 50 + loveVariance * 15;
  const loveScore = Math.max(5, Math.min(100, Math.round(loveNormal)));

  const moneyBase = random();
  const moneyVariance = (random() - 0.5) * 2;
  const moneyNormal = 50 + (moneyBase - 0.5) * 50 + moneyVariance * 15;
  const moneyScore = Math.max(5, Math.min(100, Math.round(moneyNormal)));

  const healthBase = random();
  const healthVariance = (random() - 0.5) * 2;
  const healthNormal = 50 + (healthBase - 0.5) * 50 + healthVariance * 15;
  const healthScore = Math.max(5, Math.min(100, Math.round(healthNormal)));

  // 등급 결정
  const totalGrade = scoreToGrade(totalScore);
  const loveGrade = scoreToGrade(loveScore);
  const moneyGrade = scoreToGrade(moneyScore);
  const healthGrade = scoreToGrade(healthScore);

  // 직장/커리어 점수 생성
  const careerBase = random();
  const careerVariance = (random() - 0.5) * 2;
  const careerNormal = 50 + (careerBase - 0.5) * 50 + careerVariance * 15;
  const careerScore = Math.max(5, Math.min(100, Math.round(careerNormal)));
  const careerGrade = scoreToGrade(careerScore);

  // 템플릿에서 메시지 선택
  const totalMessages = templates.fortune_templates?.total?.[totalGrade] || [];
  const loveMessages = templates.fortune_templates?.love?.[loveGrade] || [];
  const moneyMessages = templates.fortune_templates?.money?.[moneyGrade] || [];
  const healthMessages = templates.fortune_templates?.health?.[healthGrade] || [];
  const careerMessages = templates.fortune_templates?.career?.[careerGrade] || [];
  const adviceMessages = templates.advice_messages?.[totalGrade] || [];

  // 요일별 하이라이트 메시지
  const dayOfWeekKeys = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const dayKey = dayOfWeekKeys[targetDate.getDay()];
  const dailyHighlights = templates.daily_highlights?.[dayKey] || [];

  // 랜덤하게 하나씩 선택
  const selectRandom = (arr) => arr.length > 0 ? arr[Math.floor(random() * arr.length)] : '오늘도 좋은 하루 되세요!';

  // 타로 카드 선택
  const selectedTarot = tarotCards.length > 0
    ? tarotCards[Math.floor(random() * tarotCards.length)]
    : null;

  const fortune = {
    date: targetDate.toISOString().split('T')[0],
    dayOfWeek: ['일', '월', '화', '수', '목', '금', '토'][targetDate.getDay()],
    total: {
      score: totalScore,
      grade: totalGrade,
      message: selectRandom(totalMessages)
    },
    love: {
      score: loveScore,
      grade: loveGrade,
      message: selectRandom(loveMessages)
    },
    money: {
      score: moneyScore,
      grade: moneyGrade,
      message: selectRandom(moneyMessages)
    },
    health: {
      score: healthScore,
      grade: healthGrade,
      message: selectRandom(healthMessages)
    },
    career: {
      score: careerScore,
      grade: careerGrade,
      message: selectRandom(careerMessages)
    },
    advice: selectRandom(adviceMessages),
    highlight: selectRandom(dailyHighlights),
    lucky: {
      color: selectRandom(templates.lucky_items?.color || ['빨강']),
      number: selectRandom(templates.lucky_items?.number || [7]),
      direction: selectRandom(templates.lucky_items?.direction || ['동쪽']),
      item: selectRandom(templates.lucky_items?.item || ['행운의 물건'])
    },
    tarot: selectedTarot
  };

  return fortune;
}

/**
 * 띠별 운세 가져오기
 * @param {number} year - 태어난 년도
 * @returns {Object} 띠 정보 및 운세
 */
export async function getZodiacFortune(year) {
  // 띠 계산 (12년 주기)
  const zodiacIndex = (year - 4) % 12;
  const zodiacAnimals = ['쥐', '소', '호랑이', '토끼', '용', '뱀', '말', '양', '원숭이', '닭', '개', '돼지'];
  const zodiacAnimal = zodiacAnimals[zodiacIndex];
  const zodiacKey = zodiacAnimal + '띠';

  try {
    const response = await fetch('/data/fortune/zodiac.json');

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const zodiacData = await response.json();

    // 데이터에서 해당 띠 찾기 (zodiac 객체의 키로 접근)
    const zodiacInfo = zodiacData.zodiac?.[zodiacKey];

    if (zodiacInfo) {
      return {
        ...zodiacInfo,
        key: zodiacKey,
        index: zodiacIndex
      };
    }

    // 데이터가 없으면 기본값 반환
    return {
      animal: zodiacAnimal,
      index: zodiacIndex,
      emoji: '',
      characteristics: '띠별 운세 준비 중입니다.',
      years: []
    };
  } catch (error) {
    console.error('Failed to load zodiac fortune:', error);

    // 네트워크 오류 메시지
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.warn('네트워크 오류로 띠별 운세를 불러올 수 없습니다.');
    } else if (error.message.includes('HTTP')) {
      console.warn(`띠별 운세 데이터를 불러올 수 없습니다. (${error.message})`);
    }

    // 기본 띠 정보 반환
    return {
      animal: zodiacAnimal,
      index: zodiacIndex,
      emoji: '',
      characteristics: '띠별 운세를 불러올 수 없습니다. 네트워크 연결을 확인해주세요.',
      years: []
    };
  }
}

/**
 * 모든 12띠 정보 가져오기
 * @returns {Array} 12띠 배열
 */
export async function getAllZodiacs() {
  try {
    const response = await fetch('/data/fortune/zodiac.json');

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const zodiacData = await response.json();
    const zodiacAnimals = ['쥐', '소', '호랑이', '토끼', '용', '뱀', '말', '양', '원숭이', '닭', '개', '돼지'];

    // 12띠 배열 생성 (순서대로)
    return zodiacAnimals.map((animal, index) => {
      const key = animal + '띠';
      const data = zodiacData.zodiac?.[key] || {};

      return {
        key,
        animal,
        index,
        emoji: data.emoji || '',
        characteristics: data.characteristics || '',
        luckyColor: data.luckyColor || '#666',
        luckyNumber: data.luckyNumber || [],
        strengths: data.strengths || [],
        personality: data.personality || '',
        years: data.years || []
      };
    });
  } catch (error) {
    console.error('Failed to load all zodiacs:', error);
    return [];
  }
}

/**
 * 주간 운세 트렌드 생성
 * @param {Object} birthInfo - 생년월일 정보
 * @param {Date} startDate - 시작 날짜
 * @returns {Array} 7일간의 운세 점수
 */
export async function generateWeeklyTrend(birthInfo, startDate = new Date()) {
  const trend = [];

  for (let i = 0; i < 7; i++) {
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);

    const dayFortune = await generateDailyFortune(birthInfo, date);

    trend.push({
      date: date.toISOString().split('T')[0],
      dayOfWeek: ['일', '월', '화', '수', '목', '금', '토'][date.getDay()],
      score: dayFortune.total.score,
      grade: dayFortune.total.grade,
      highlight: dayFortune.highlight,
      career: dayFortune.career
    });
  }

  return trend;
}

/**
 * 월간 운세 요약 생성
 * @param {Object} birthInfo - 생년월일 정보
 * @param {number} year - 연도
 * @param {number} month - 월
 * @returns {Object} 월간 운세 요약
 */
export async function generateMonthlySummary(birthInfo, year, month) {
  const daysInMonth = new Date(year, month, 0).getDate();
  let totalScore = 0;
  const scores = [];

  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month - 1, day);
    const dayFortune = await generateDailyFortune(birthInfo, date);

    totalScore += dayFortune.total.score;
    scores.push(dayFortune.total.score);
  }

  const averageScore = Math.round(totalScore / daysInMonth);
  const maxScore = Math.max(...scores);
  const minScore = Math.min(...scores);

  return {
    year,
    month,
    averageScore,
    maxScore,
    minScore,
    grade: scoreToGrade(averageScore),
    trend: scores
  };
}

/**
 * 특정 날짜의 행운 지수 계산
 * @param {Object} birthInfo - 생년월일 정보
 * @param {Date} targetDate - 대상 날짜
 * @returns {number} 0-100 행운 지수
 */
export function calculateLuckyIndex(birthInfo, targetDate) {
  const seed = generateSeed(targetDate, birthInfo);
  const random = seededRandom(seed);

  // 여러 요소를 조합하여 행운 지수 계산
  const dayScore = random() * 30; // 날짜 영향 (0-30)
  const birthScore = (random() * 30); // 생년월일 영향 (0-30)
  const cosmicScore = random() * 40; // 우주적 영향 (0-40)

  return Math.round(dayScore + birthScore + cosmicScore);
}

/**
 * 궁합 점수 계산 (간단 버전)
 * @param {Object} birthInfo1 - 첫 번째 사람 생년월일
 * @param {Object} birthInfo2 - 두 번째 사람 생년월일
 * @returns {number} 0-100 궁합 점수
 */
export function calculateCompatibility(birthInfo1, birthInfo2) {
  // 두 생년월일을 조합한 고유 seed
  const combinedSeed =
    birthInfo1.year * 10000 + birthInfo1.month * 100 + birthInfo1.day +
    birthInfo2.year * 10000 + birthInfo2.month * 100 + birthInfo2.day;

  const random = seededRandom(combinedSeed);

  // 띠 궁합 고려
  const zodiac1 = (birthInfo1.year - 4) % 12;
  const zodiac2 = (birthInfo2.year - 4) % 12;
  const zodiacDiff = Math.abs(zodiac1 - zodiac2);

  let zodiacBonus = 0;
  if (zodiacDiff === 0) zodiacBonus = 15; // 같은 띠
  else if (zodiacDiff === 4 || zodiacDiff === 8) zodiacBonus = 20; // 삼합
  else if (zodiacDiff === 6) zodiacBonus = -10; // 충

  const baseScore = Math.floor(random() * 70) + 15; // 15-85
  const finalScore = Math.max(0, Math.min(100, baseScore + zodiacBonus));

  return finalScore;
}

export default {
  generateDailyFortune,
  getZodiacFortune,
  getAllZodiacs,
  generateWeeklyTrend,
  generateMonthlySummary,
  calculateLuckyIndex,
  calculateCompatibility
};
