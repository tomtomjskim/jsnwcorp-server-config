/**
 * 운세 캘린더 모듈
 * 월별 운세 점수를 캘린더 형태로 표시
 */

import { generateDailyFortune } from './fortune-generator.js';

/**
 * 특정 월의 일수 계산
 * @param {number} year - 연도
 * @param {number} month - 월 (1-12)
 * @returns {number} 해당 월의 일수
 */
export function getDaysInMonth(year, month) {
  return new Date(year, month, 0).getDate();
}

/**
 * 해당 월 1일의 요일 계산
 * @param {number} year - 연도
 * @param {number} month - 월 (1-12)
 * @returns {number} 요일 (0: 일요일 ~ 6: 토요일)
 */
export function getFirstDayOfMonth(year, month) {
  return new Date(year, month - 1, 1).getDay();
}

/**
 * 점수를 등급으로 변환
 * @param {number} score - 점수 (0-100)
 * @returns {string} 등급
 */
function scoreToGrade(score) {
  if (score >= 85) return 'excellent';
  if (score >= 70) return 'good';
  if (score >= 40) return 'normal';
  if (score >= 20) return 'caution';
  return 'bad';
}

/**
 * 월별 운세 점수 생성
 * @param {Object} birthInfo - 생년월일 정보
 * @param {number} year - 연도
 * @param {number} month - 월 (1-12)
 * @returns {Promise<Array>} 해당 월의 일별 운세 데이터
 */
export async function getMonthScores(birthInfo, year, month) {
  const daysInMonth = getDaysInMonth(year, month);
  const scores = [];

  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month - 1, day);
    const fortune = await generateDailyFortune(birthInfo, date);

    scores.push({
      day,
      date: date.toISOString().split('T')[0],
      dayOfWeek: ['일', '월', '화', '수', '목', '금', '토'][date.getDay()],
      score: fortune.total.score,
      grade: fortune.total.grade,
      highlight: fortune.highlight,
      isToday: isSameDay(date, new Date())
    });
  }

  return scores;
}

/**
 * 두 날짜가 같은 날인지 확인
 * @param {Date} date1 - 첫 번째 날짜
 * @param {Date} date2 - 두 번째 날짜
 * @returns {boolean} 같은 날 여부
 */
function isSameDay(date1, date2) {
  return date1.getFullYear() === date2.getFullYear() &&
         date1.getMonth() === date2.getMonth() &&
         date1.getDate() === date2.getDate();
}

/**
 * 캘린더 데이터 생성 (빈 칸 포함)
 * @param {number} year - 연도
 * @param {number} month - 월 (1-12)
 * @param {Object} birthInfo - 생년월일 정보
 * @returns {Promise<Object>} 캘린더 데이터
 */
export async function generateCalendarData(year, month, birthInfo) {
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);
  const monthScores = await getMonthScores(birthInfo, year, month);

  // 캘린더 그리드 (6주 × 7일 = 42칸)
  const calendarGrid = [];

  // 이전 달 빈 칸
  for (let i = 0; i < firstDay; i++) {
    calendarGrid.push({
      day: null,
      isEmpty: true
    });
  }

  // 현재 달 일자
  monthScores.forEach(dayData => {
    calendarGrid.push({
      ...dayData,
      isEmpty: false
    });
  });

  // 다음 달 빈 칸 (6주를 채우기 위해)
  const remainingSlots = 42 - calendarGrid.length;
  for (let i = 0; i < remainingSlots; i++) {
    calendarGrid.push({
      day: null,
      isEmpty: true
    });
  }

  // 통계 계산
  const validScores = monthScores.map(d => d.score);
  const avgScore = Math.round(validScores.reduce((a, b) => a + b, 0) / validScores.length);
  const maxScore = Math.max(...validScores);
  const minScore = Math.min(...validScores);
  const maxDay = monthScores.find(d => d.score === maxScore);
  const minDay = monthScores.find(d => d.score === minScore);

  // 등급별 일수 카운트
  const gradeCounts = {
    excellent: monthScores.filter(d => d.grade === 'excellent').length,
    good: monthScores.filter(d => d.grade === 'good').length,
    normal: monthScores.filter(d => d.grade === 'normal').length,
    caution: monthScores.filter(d => d.grade === 'caution').length,
    bad: monthScores.filter(d => d.grade === 'bad').length
  };

  return {
    year,
    month,
    monthName: `${year}년 ${month}월`,
    daysInMonth,
    firstDay,
    grid: calendarGrid,
    days: monthScores,
    stats: {
      averageScore: avgScore,
      maxScore,
      minScore,
      bestDay: maxDay,
      worstDay: minDay,
      gradeCounts,
      grade: scoreToGrade(avgScore)
    }
  };
}

/**
 * 월별 운세 상세 분석 생성
 * @param {Object} birthInfo - 생년월일 정보
 * @param {number} year - 연도
 * @param {number} month - 월 (1-12)
 * @returns {Promise<Object>} 상세 월별 운세
 */
export async function generateDetailedMonthlyFortune(birthInfo, year, month) {
  const calendarData = await generateCalendarData(year, month, birthInfo);

  // 카테고리별 월 평균 계산
  const daysInMonth = getDaysInMonth(year, month);
  let loveTotalScore = 0;
  let moneyTotalScore = 0;
  let healthTotalScore = 0;
  let careerTotalScore = 0;

  const luckyDays = [];
  const cautionDays = [];

  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month - 1, day);
    const fortune = await generateDailyFortune(birthInfo, date);

    loveTotalScore += fortune.love.score;
    moneyTotalScore += fortune.money.score;
    healthTotalScore += fortune.health.score;
    careerTotalScore += fortune.career?.score || 50;

    // 행운의 날 (80점 이상)
    if (fortune.total.score >= 80) {
      luckyDays.push({
        day,
        date: date.toISOString().split('T')[0],
        score: fortune.total.score,
        highlight: fortune.highlight
      });
    }

    // 주의할 날 (30점 이하)
    if (fortune.total.score <= 30) {
      cautionDays.push({
        day,
        date: date.toISOString().split('T')[0],
        score: fortune.total.score,
        highlight: fortune.highlight
      });
    }
  }

  const loveAvg = Math.round(loveTotalScore / daysInMonth);
  const moneyAvg = Math.round(moneyTotalScore / daysInMonth);
  const healthAvg = Math.round(healthTotalScore / daysInMonth);
  const careerAvg = Math.round(careerTotalScore / daysInMonth);

  // 이달의 테마 결정
  const categoryScores = {
    love: loveAvg,
    money: moneyAvg,
    health: healthAvg,
    career: careerAvg
  };

  const maxCategory = Object.entries(categoryScores).reduce((a, b) =>
    a[1] > b[1] ? a : b
  )[0];

  const themeMap = {
    love: '사랑과 관계에 집중하는 달',
    money: '재물운이 강한 달',
    health: '건강 관리에 최적인 달',
    career: '커리어 발전의 달'
  };

  return {
    year,
    month,
    monthName: `${year}년 ${month}월`,
    overall: {
      score: calendarData.stats.averageScore,
      grade: calendarData.stats.grade,
      message: getMonthlyMessage(calendarData.stats.averageScore)
    },
    theme: themeMap[maxCategory],
    categories: {
      love: { score: loveAvg, grade: scoreToGrade(loveAvg) },
      money: { score: moneyAvg, grade: scoreToGrade(moneyAvg) },
      health: { score: healthAvg, grade: scoreToGrade(healthAvg) },
      career: { score: careerAvg, grade: scoreToGrade(careerAvg) }
    },
    luckyDays: luckyDays.slice(0, 5), // 상위 5개
    cautionDays: cautionDays.slice(0, 5),
    calendar: calendarData
  };
}

/**
 * 월별 운세 메시지 생성
 * @param {number} score - 평균 점수
 * @returns {string} 운세 메시지
 */
function getMonthlyMessage(score) {
  if (score >= 80) {
    return '이번 달은 전체적으로 매우 좋은 기운이 흐릅니다. 새로운 시도와 도전에 적극적으로 임해보세요.';
  } else if (score >= 65) {
    return '이번 달은 순조로운 흐름이 이어집니다. 계획한 일들을 차근차근 진행하면 좋은 결과를 얻을 수 있습니다.';
  } else if (score >= 45) {
    return '이번 달은 안정적인 흐름입니다. 무리하지 않고 꾸준히 나아가면 됩니다.';
  } else if (score >= 30) {
    return '이번 달은 신중함이 필요합니다. 중요한 결정은 충분히 고민한 후에 내리세요.';
  } else {
    return '이번 달은 휴식과 재충전이 필요한 시기입니다. 무리하지 말고 에너지를 비축하세요.';
  }
}

/**
 * 캘린더 HTML 렌더링
 * @param {Object} calendarData - 캘린더 데이터
 * @param {Function} onDateClick - 날짜 클릭 콜백
 * @returns {string} HTML 문자열
 */
export function renderCalendarHTML(calendarData, onDateClick = null) {
  const { year, month, grid, stats } = calendarData;

  const gradeColorMap = {
    excellent: '#4CAF50',
    good: '#8BC34A',
    normal: '#FFC107',
    caution: '#FF9800',
    bad: '#F44336'
  };

  const gradeEmojiMap = {
    excellent: '🌟',
    good: '😊',
    normal: '😐',
    caution: '😟',
    bad: '😔'
  };

  let html = `
    <div class="fortune-calendar">
      <div class="calendar-header">
        <button class="calendar-nav prev" data-direction="prev">◀</button>
        <h3 class="calendar-title">${year}년 ${month}월</h3>
        <button class="calendar-nav next" data-direction="next">▶</button>
      </div>
      <div class="calendar-stats">
        <span>평균: ${stats.averageScore}점</span>
        <span>최고: ${stats.maxScore}점 (${stats.bestDay?.day}일)</span>
        <span>최저: ${stats.minScore}점 (${stats.worstDay?.day}일)</span>
      </div>
      <div class="calendar-weekdays">
        <div class="weekday sunday">일</div>
        <div class="weekday">월</div>
        <div class="weekday">화</div>
        <div class="weekday">수</div>
        <div class="weekday">목</div>
        <div class="weekday">금</div>
        <div class="weekday saturday">토</div>
      </div>
      <div class="calendar-grid">
  `;

  grid.forEach((cell, index) => {
    const dayOfWeek = index % 7;
    let cellClass = 'calendar-day';

    if (cell.isEmpty) {
      cellClass += ' empty';
    } else {
      cellClass += ` grade-${cell.grade}`;
      if (cell.isToday) cellClass += ' today';
      if (dayOfWeek === 0) cellClass += ' sunday';
      if (dayOfWeek === 6) cellClass += ' saturday';
    }

    if (cell.isEmpty) {
      html += `<div class="${cellClass}"></div>`;
    } else {
      const color = gradeColorMap[cell.grade];
      const emoji = gradeEmojiMap[cell.grade];

      html += `
        <div class="${cellClass}" data-date="${cell.date}" data-score="${cell.score}">
          <span class="day-number">${cell.day}</span>
          <span class="day-score" style="color: ${color}">${cell.score}</span>
          <span class="day-emoji">${emoji}</span>
        </div>
      `;
    }
  });

  html += `
      </div>
      <div class="calendar-legend">
        <span class="legend-item"><span class="legend-color" style="background: #4CAF50"></span>매우 좋음</span>
        <span class="legend-item"><span class="legend-color" style="background: #8BC34A"></span>좋음</span>
        <span class="legend-item"><span class="legend-color" style="background: #FFC107"></span>보통</span>
        <span class="legend-item"><span class="legend-color" style="background: #FF9800"></span>주의</span>
        <span class="legend-item"><span class="legend-color" style="background: #F44336"></span>나쁨</span>
      </div>
    </div>
  `;

  return html;
}

export default {
  getDaysInMonth,
  getFirstDayOfMonth,
  getMonthScores,
  generateCalendarData,
  generateDetailedMonthlyFortune,
  renderCalendarHTML
};
