/**
 * 대운/세운 계산 모듈
 * 사주를 기반으로 10년 단위 대운과 연간 세운을 계산
 */

// 천간 배열
const CHEONGAN = ['갑', '을', '병', '정', '무', '기', '경', '신', '임', '계'];

// 지지 배열
const JIJI = ['자', '축', '인', '묘', '진', '사', '오', '미', '신', '유', '술', '해'];

// 대운 해석 데이터 캐시
let daeunDataCache = null;

/**
 * 대운 해석 데이터 로드
 */
export async function loadDaeunData() {
  if (daeunDataCache) return daeunDataCache;

  try {
    const response = await fetch('/data/daeun/daeun-interpretations.json');
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    daeunDataCache = await response.json();
    return daeunDataCache;
  } catch (error) {
    console.error('Failed to load daeun data:', error);
    return null;
  }
}

/**
 * 대운 방향 결정
 * 남자 양년생, 여자 음년생: 순행 (1)
 * 남자 음년생, 여자 양년생: 역행 (-1)
 */
const DAEUN_DIRECTION = {
  male_yang: 1,    // 남자 양년생: 순행
  male_yin: -1,    // 남자 음년생: 역행
  female_yang: -1, // 여자 양년생: 역행
  female_yin: 1    // 여자 음년생: 순행
};

/**
 * 천간이 양인지 음인지 판단
 * @param {string} gan - 천간
 * @returns {boolean} 양이면 true
 */
function isYangGan(gan) {
  const yangGan = ['갑', '병', '무', '경', '임'];
  return yangGan.includes(gan);
}

/**
 * 대운 방향 계산
 * @param {string} gender - 성별 (male/female)
 * @param {string} yearGan - 년주 천간
 * @returns {number} 1 (순행) 또는 -1 (역행)
 */
export function getDaeunDirection(gender, yearGan) {
  const isYang = isYangGan(yearGan);

  if (gender === 'male') {
    return isYang ? 1 : -1;
  } else {
    return isYang ? -1 : 1;
  }
}

/**
 * 대운 시작 나이 계산 (간략화)
 * 실제로는 절입까지의 일수를 기반으로 계산하지만,
 * 여기서는 간단히 월주를 기반으로 근사치 사용
 * @param {Object} birthInfo - 생년월일 정보
 * @returns {number} 대운 시작 나이
 */
export function calculateDaeunStart(birthInfo) {
  // 간단한 근사: 출생월을 3으로 나눈 값 + 1
  const month = birthInfo.month;
  const startAge = Math.floor(month / 3) + 1;
  return Math.max(1, Math.min(10, startAge));
}

/**
 * 다음/이전 간지 계산
 * @param {string} gan - 현재 천간
 * @param {string} ji - 현재 지지
 * @param {number} direction - 방향 (1: 순행, -1: 역행)
 * @returns {Object} 다음/이전 간지
 */
function getNextGanji(gan, ji, direction) {
  const ganIndex = CHEONGAN.indexOf(gan);
  const jiIndex = JIJI.indexOf(ji);

  const newGanIndex = (ganIndex + direction + 10) % 10;
  const newJiIndex = (jiIndex + direction + 12) % 12;

  return {
    천간: CHEONGAN[newGanIndex],
    지지: JIJI[newJiIndex]
  };
}

/**
 * 천간의 오행 가져오기
 * @param {string} gan - 천간
 * @returns {string} 오행
 */
function getGanElement(gan) {
  const ganElements = {
    '갑': '목', '을': '목',
    '병': '화', '정': '화',
    '무': '토', '기': '토',
    '경': '금', '신': '금',
    '임': '수', '계': '수'
  };
  return ganElements[gan] || '토';
}

/**
 * 지지의 오행 가져오기
 * @param {string} ji - 지지
 * @returns {string} 오행
 */
function getJiElement(ji) {
  const jiElements = {
    '자': '수', '축': '토', '인': '목', '묘': '목',
    '진': '토', '사': '화', '오': '화', '미': '토',
    '신': '금', '유': '금', '술': '토', '해': '수'
  };
  return jiElements[ji] || '토';
}

/**
 * 십신 계산
 * @param {string} dayGan - 일간 (일주 천간)
 * @param {string} targetGan - 대상 천간
 * @returns {string} 십신
 */
export function calculateSipsin(dayGan, targetGan) {
  const dayElement = getGanElement(dayGan);
  const targetElement = getGanElement(targetGan);
  const isDayYang = isYangGan(dayGan);
  const isTargetYang = isYangGan(targetGan);
  const isSameYin = isDayYang === isTargetYang;

  // 오행 관계 매핑
  const elementOrder = ['목', '화', '토', '금', '수'];
  const dayIndex = elementOrder.indexOf(dayElement);
  const targetIndex = elementOrder.indexOf(targetElement);

  // 관계 계산
  const relation = (targetIndex - dayIndex + 5) % 5;

  // 십신 결정
  const sipsinMap = {
    0: isSameYin ? '비견' : '겁재',      // 같은 오행
    1: isSameYin ? '식신' : '상관',      // 내가 생하는 오행
    2: isSameYin ? '편재' : '정재',      // 내가 극하는 오행
    3: isSameYin ? '편관' : '정관',      // 나를 극하는 오행
    4: isSameYin ? '편인' : '정인'       // 나를 생하는 오행
  };

  return sipsinMap[relation] || '비견';
}

/**
 * 십신을 대운 카테고리로 변환
 * @param {string} sipsin - 십신
 * @returns {string} 대운 카테고리
 */
function sipsinToCategory(sipsin) {
  const categories = {
    '비견': '비겁운', '겁재': '비겁운',
    '식신': '식상운', '상관': '식상운',
    '편재': '재성운', '정재': '재성운',
    '편관': '관성운', '정관': '관성운',
    '편인': '인성운', '정인': '인성운'
  };
  return categories[sipsin] || '비겁운';
}

/**
 * 대운 시퀀스 생성 (8개 대운)
 * @param {Object} birthInfo - 생년월일 정보
 * @param {Object} saju - 사주 정보 (fourPillars 포함)
 * @param {number} count - 생성할 대운 수 (기본 8)
 * @returns {Array} 대운 배열
 */
export function generateDaeunSequence(birthInfo, saju, count = 8) {
  const fourPillars = saju.fourPillars;
  const monthPillar = fourPillars.month;
  const dayGan = fourPillars.day.천간;
  const yearGan = fourPillars.year.천간;

  // 대운 방향 결정
  const gender = birthInfo.gender || 'male';
  const direction = getDaeunDirection(gender, yearGan);

  // 대운 시작 나이
  const startAge = calculateDaeunStart(birthInfo);

  // 현재 간지 (월주에서 시작)
  let currentGan = monthPillar.천간;
  let currentJi = monthPillar.지지;

  const daeunList = [];

  for (let i = 0; i < count; i++) {
    // 다음 간지로 이동
    const nextGanji = getNextGanji(currentGan, currentJi, direction);
    currentGan = nextGanji.천간;
    currentJi = nextGanji.지지;

    const periodStart = startAge + (i * 10);
    const periodEnd = periodStart + 9;

    // 십신 계산
    const sipsin = calculateSipsin(dayGan, currentGan);
    const category = sipsinToCategory(sipsin);

    // 오행
    const element = getGanElement(currentGan);

    daeunList.push({
      period: i + 1,
      startAge: periodStart,
      endAge: periodEnd,
      ageRange: `${periodStart}세 ~ ${periodEnd}세`,
      pillar: {
        천간: currentGan,
        지지: currentJi,
        full: currentGan + currentJi
      },
      element,
      sipsin,
      category,
      direction: direction === 1 ? '순행' : '역행'
    });
  }

  return daeunList;
}

/**
 * 현재 대운 찾기
 * @param {Object} birthInfo - 생년월일 정보
 * @param {Array} daeunSequence - 대운 시퀀스
 * @returns {Object|null} 현재 대운
 */
export function getCurrentDaeun(birthInfo, daeunSequence) {
  const birthYear = birthInfo.year;
  const currentYear = new Date().getFullYear();
  const currentAge = currentYear - birthYear + 1; // 한국 나이

  for (const daeun of daeunSequence) {
    if (currentAge >= daeun.startAge && currentAge <= daeun.endAge) {
      return {
        ...daeun,
        currentAge,
        yearsRemaining: daeun.endAge - currentAge + 1
      };
    }
  }

  return null;
}

/**
 * 대운 해석 가져오기
 * @param {Object} daeun - 대운 정보
 * @returns {Promise<Object>} 대운 해석
 */
export async function getDaeunInterpretation(daeun) {
  const data = await loadDaeunData();
  if (!data) return null;

  const interpretation = data.interpretations[daeun.category];
  const elementInfo = data.elements[daeun.element];

  return {
    ...interpretation,
    elementInfo,
    daeun
  };
}

/**
 * 특정 연도의 년주 (세운) 계산
 * @param {number} year - 연도
 * @returns {Object} 년주 정보
 */
export function getYearlyPillar(year) {
  // 년주 계산 (갑자년 기준: 1984년)
  const baseYear = 1984;
  const diff = year - baseYear;

  const ganIndex = ((diff % 10) + 10) % 10;
  const jiIndex = ((diff % 12) + 12) % 12;

  return {
    천간: CHEONGAN[ganIndex],
    지지: JIJI[jiIndex],
    full: CHEONGAN[ganIndex] + JIJI[jiIndex]
  };
}

/**
 * 세운 (연간 운세) 계산
 * @param {Object} birthInfo - 생년월일 정보
 * @param {Object} saju - 사주 정보
 * @param {number} targetYear - 대상 연도
 * @returns {Promise<Object>} 세운 정보
 */
export async function calculateSeun(birthInfo, saju, targetYear = new Date().getFullYear()) {
  const yearPillar = getYearlyPillar(targetYear);
  const dayGan = saju.fourPillars.day.천간;

  // 십신 계산
  const sipsin = calculateSipsin(dayGan, yearPillar.천간);
  const category = sipsinToCategory(sipsin);

  // 대운 해석 데이터 가져오기
  const data = await loadDaeunData();
  const interpretation = data?.interpretations?.[category];

  // 오행
  const element = getGanElement(yearPillar.천간);

  // 점수 계산 (간단한 알고리즘)
  const baseScore = 50;
  const categoryBonus = {
    '비겁운': 5,
    '식상운': 10,
    '재성운': 15,
    '관성운': 10,
    '인성운': 10
  };

  const score = Math.min(100, Math.max(0,
    baseScore + (categoryBonus[category] || 0) + ((targetYear * birthInfo.month) % 30) - 10
  ));

  return {
    year: targetYear,
    pillar: yearPillar,
    element,
    sipsin,
    category,
    score,
    grade: scoreToGrade(score),
    interpretation: interpretation || null
  };
}

/**
 * 점수를 등급으로 변환
 */
function scoreToGrade(score) {
  if (score >= 80) return 'excellent';
  if (score >= 65) return 'good';
  if (score >= 45) return 'normal';
  if (score >= 30) return 'caution';
  return 'bad';
}

/**
 * 세운 십신 관계 계산
 */
export function getSeunSipsin(dayMaster, yearPillar) {
  return calculateSipsin(dayMaster, yearPillar.천간);
}

/**
 * 대운/세운 종합 분석
 * @param {Object} birthInfo - 생년월일 정보
 * @param {Object} saju - 사주 정보
 * @param {number} targetYear - 대상 연도
 * @returns {Promise<Object>} 종합 분석
 */
export async function getComprehensiveAnalysis(birthInfo, saju, targetYear = new Date().getFullYear()) {
  // 대운 시퀀스 생성
  const daeunSequence = generateDaeunSequence(birthInfo, saju);

  // 현재 대운 찾기
  const currentDaeun = getCurrentDaeun(birthInfo, daeunSequence);

  // 대운 해석
  const daeunInterpretation = currentDaeun
    ? await getDaeunInterpretation(currentDaeun)
    : null;

  // 세운 계산
  const seun = await calculateSeun(birthInfo, saju, targetYear);

  // 다음 해 세운
  const nextYearSeun = await calculateSeun(birthInfo, saju, targetYear + 1);

  // 종합 점수 (대운 + 세운)
  const daeunScore = currentDaeun ? getDaeunScore(currentDaeun.category) : 50;
  const totalScore = Math.round((daeunScore + seun.score) / 2);

  return {
    birthInfo,
    targetYear,
    daeun: {
      current: currentDaeun,
      interpretation: daeunInterpretation,
      sequence: daeunSequence
    },
    seun: {
      current: seun,
      nextYear: nextYearSeun
    },
    summary: {
      totalScore,
      grade: scoreToGrade(totalScore),
      message: getSummaryMessage(currentDaeun?.category, seun.category, totalScore)
    }
  };
}

/**
 * 대운 카테고리별 기본 점수
 */
function getDaeunScore(category) {
  const scores = {
    '비겁운': 50,
    '식상운': 60,
    '재성운': 70,
    '관성운': 65,
    '인성운': 60
  };
  return scores[category] || 50;
}

/**
 * 종합 메시지 생성
 */
function getSummaryMessage(daeunCategory, seunCategory, score) {
  const daeunLabels = {
    '비겁운': '자립과 경쟁',
    '식상운': '표현과 창작',
    '재성운': '재물과 관계',
    '관성운': '직장과 명예',
    '인성운': '학습과 성장'
  };

  const daeunLabel = daeunLabels[daeunCategory] || '변화';
  const seunLabel = daeunLabels[seunCategory] || '도전';

  if (score >= 70) {
    return `현재 ${daeunLabel}의 대운과 ${seunLabel}의 세운이 조화롭게 흘러 좋은 기운이 함께합니다.`;
  } else if (score >= 50) {
    return `${daeunLabel}의 시기에 ${seunLabel}의 기운이 더해져 균형잡힌 흐름입니다.`;
  } else {
    return `${daeunLabel}의 시기에 신중함이 필요합니다. 때를 기다리며 준비하세요.`;
  }
}

export default {
  loadDaeunData,
  getDaeunDirection,
  calculateDaeunStart,
  generateDaeunSequence,
  getCurrentDaeun,
  getDaeunInterpretation,
  getYearlyPillar,
  calculateSeun,
  getSeunSipsin,
  calculateSipsin,
  getComprehensiveAnalysis
};
