/**
 * 토정비결 계산 모듈
 * 생년월일을 기반으로 토정비결 144괘 중 해당 괘를 계산
 */

// 토정비결 데이터 캐시
let tojeongDataCache = null;

/**
 * 토정비결 데이터 로드
 * @returns {Promise<Object>} 토정비결 데이터
 */
export async function loadTojeongData() {
  if (tojeongDataCache) return tojeongDataCache;

  try {
    const response = await fetch('/data/tojeong/tojeongbigyeol.json');
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    tojeongDataCache = await response.json();
    return tojeongDataCache;
  } catch (error) {
    console.error('Failed to load tojeong data:', error);
    return null;
  }
}

/**
 * 천간 배열 (갑을병정무기경신임계)
 */
const CHEONGAN = ['갑', '을', '병', '정', '무', '기', '경', '신', '임', '계'];

/**
 * 지지 배열 (자축인묘진사오미신유술해)
 */
const JIJI = ['자', '축', '인', '묘', '진', '사', '오', '미', '신', '유', '술', '해'];

/**
 * 상괘 결정 (출생년도 + 조회년도 기반, 1-8)
 * 전통 토정비결: 생년 천간지지와 조회년도를 조합하여 상괘 결정
 * @param {number} birthYear - 출생년도
 * @param {number} targetYear - 조회년도
 * @returns {number} 상괘 번호 (1-8)
 */
export function getUpperTrigram(birthYear, targetYear) {
  // 생년 천간 인덱스
  const birthGanIndex = (birthYear - 4) % 10;
  // 생년 지지 인덱스
  const birthJiIndex = (birthYear - 4) % 12;
  // 조회년도 천간 인덱스
  const targetGanIndex = (targetYear - 4) % 10;
  // 조회년도 지지 인덱스
  const targetJiIndex = (targetYear - 4) % 12;

  // 생년과 조회년의 천간지지 합으로 상괘 결정
  const sum = birthGanIndex + birthJiIndex + targetGanIndex + targetJiIndex;
  return (sum % 8) + 1;
}

/**
 * 중괘 결정 (월 기반, 1-6)
 * @param {number} month - 출생월 (1-12)
 * @returns {number} 중괘 번호 (1-6)
 */
export function getMiddleTrigram(month) {
  // 월을 6으로 나눈 나머지 + 1
  return ((month - 1) % 6) + 1;
}

/**
 * 하괘 결정 (일 기반, 1-3)
 * @param {number} day - 출생일 (1-31)
 * @returns {number} 하괘 번호 (1-3)
 */
export function getLowerTrigram(day) {
  // 일을 3으로 나눈 나머지 + 1
  return ((day - 1) % 3) + 1;
}

/**
 * 토정비결 괘 번호 계산
 * @param {Object} birthInfo - 생년월일 정보
 * @param {number} targetYear - 대상 연도 (기본: 현재 연도)
 * @returns {Object} 괘 정보
 */
export function calculateTojeongGua(birthInfo, targetYear = new Date().getFullYear()) {
  const { year, month, day } = birthInfo;

  // 상중하 괘 계산 (상괘는 생년+조회년 조합)
  const upper = getUpperTrigram(year, targetYear);
  const middle = getMiddleTrigram(month);
  const lower = getLowerTrigram(day);

  // 괘 번호 계산 (1-144)
  // 공식: (상괘-1)*18 + (중괘-1)*3 + 하괘
  const guaNumber = (upper - 1) * 18 + (middle - 1) * 3 + lower;

  // 괘 이름 생성
  const levelNames = ['상', '중', '하'];
  const guaName = `${levelNames[upper > 4 ? 0 : upper > 2 ? 1 : 2]}${levelNames[middle > 3 ? 0 : middle > 1 ? 1 : 2]}${levelNames[lower > 2 ? 0 : lower > 1 ? 1 : 2]}`;

  return {
    number: guaNumber,
    upper,
    middle,
    lower,
    name: guaName,
    targetYear
  };
}

/**
 * 토정비결 운세 가져오기
 * @param {Object} birthInfo - 생년월일 정보
 * @param {number} targetYear - 대상 연도
 * @returns {Promise<Object>} 토정비결 결과
 */
export async function getTojeongFortune(birthInfo, targetYear = new Date().getFullYear()) {
  const tojeongData = await loadTojeongData();
  const guaInfo = calculateTojeongGua(birthInfo, targetYear);

  // 해당 괘 데이터 찾기
  let guaData = tojeongData?.trigrams?.[guaInfo.number.toString()];

  // 데이터가 없으면 기본 템플릿 사용
  if (!guaData) {
    guaData = generateDefaultGua(guaInfo);
  }

  // 등급 정보
  const gradeInfo = tojeongData?.grades?.[guaData.grade] || {
    label: '보통',
    color: '#FFC107',
    emoji: '😐'
  };

  return {
    gua: guaInfo,
    data: {
      ...guaData,
      gradeInfo
    },
    birthInfo,
    targetYear
  };
}

/**
 * 기본 괘 데이터 생성 (데이터가 없는 경우)
 * @param {Object} guaInfo - 괘 정보
 * @returns {Object} 기본 괘 데이터
 */
function generateDefaultGua(guaInfo) {
  const { number, upper, middle, lower } = guaInfo;

  // 상괘에 따른 기본 등급 결정
  let grade = 'normal';
  if (upper >= 7) grade = 'excellent';
  else if (upper >= 5) grade = 'good';
  else if (upper <= 2) grade = 'caution';

  // 괘 제목 생성
  const titles = [
    '풍조화명', '수류불굴', '지천태평', '산고수심', '뇌동만리',
    '화광동진', '천행건강', '택수곤궁', '중천건괘', '지뢰복괘',
    '산천조화', '수택절괘', '풍지관괘', '화천대유', '천지비괘'
  ];
  const titleIndex = (number - 1) % titles.length;

  // 월별 운세 생성
  const monthlyMessages = generateMonthlyMessages(grade);

  return {
    id: number,
    gua: guaInfo.name,
    title: titles[titleIndex],
    subtitle: `제 ${number}괘`,
    grade,
    yearly: generateYearlyMessage(grade, upper),
    monthly: monthlyMessages,
    advice: generateAdvice(grade)
  };
}

/**
 * 연간 운세 메시지 생성
 * @param {string} grade - 등급
 * @param {number} upper - 상괘
 * @returns {string} 연간 운세
 */
function generateYearlyMessage(grade, upper) {
  const messages = {
    excellent: [
      '올해는 모든 일이 순조롭게 풀리는 대길한 해입니다. 새로운 시작에 적합하며, 적극적으로 움직이면 큰 성과를 거둘 수 있습니다.',
      '운세가 최고조에 달하는 해입니다. 귀인의 도움과 함께 뜻하지 않은 행운도 찾아옵니다. 자신감을 가지고 도전하세요.'
    ],
    good: [
      '전반적으로 순탄한 해입니다. 꾸준히 노력하면 좋은 결과를 얻을 수 있습니다. 특히 인간관계에서 기쁜 일이 생길 수 있습니다.',
      '안정적인 흐름이 이어지는 해입니다. 현재를 유지하며 내실을 다지는 것이 좋습니다. 작은 성취가 모여 큰 행복이 됩니다.'
    ],
    normal: [
      '큰 변화 없이 평온한 해입니다. 무리하지 않고 자신의 페이스를 유지하면 무난하게 보낼 수 있습니다.',
      '보통의 운세가 이어지는 해입니다. 특별한 행운은 없지만 큰 어려움도 없습니다. 현재에 충실하세요.'
    ],
    caution: [
      '신중함이 필요한 해입니다. 큰 변화나 모험은 피하고, 안정을 추구하는 것이 좋습니다.',
      '조심해야 할 일이 있는 해입니다. 중요한 결정은 미루고, 현상 유지에 집중하세요.'
    ],
    bad: [
      '어려움이 있을 수 있는 해입니다. 하지만 이 시기도 지나갈 것입니다. 인내하며 버티세요.',
      '힘든 시기가 될 수 있습니다. 무리한 도전보다는 휴식과 재충전에 집중하세요.'
    ]
  };

  const gradeMessages = messages[grade] || messages.normal;
  return gradeMessages[upper % 2];
}

/**
 * 월별 운세 메시지 생성
 * @param {string} grade - 등급
 * @returns {Object} 월별 메시지
 */
function generateMonthlyMessages(grade) {
  const baseMessages = {
    excellent: {
      '1': '새해 첫 달부터 좋은 기운이 가득합니다. 새로운 계획을 세우세요.',
      '2': '애정운이 상승합니다. 소중한 사람과 시간을 보내세요.',
      '3': '재물운이 좋습니다. 투자나 사업에 좋은 달입니다.',
      '4': '건강과 활력이 넘칩니다. 새로운 도전을 해보세요.',
      '5': '인간관계에서 좋은 일이 생깁니다.',
      '6': '상반기의 성과를 거두는 달입니다.',
      '7': '여행이나 이동에 행운이 따릅니다.',
      '8': '노력의 결실을 맺기 시작합니다.',
      '9': '좋은 소식이 찾아옵니다.',
      '10': '재물운과 직장운 모두 좋습니다.',
      '11': '기쁜 소식이 있을 수 있습니다.',
      '12': '한 해를 아름답게 마무리합니다.'
    },
    good: {
      '1': '차분하게 한 해를 시작하세요.',
      '2': '가정에 좋은 일이 있을 수 있습니다.',
      '3': '작은 이득이 생깁니다.',
      '4': '건강 관리에 신경 쓰세요.',
      '5': '학습과 자기계발에 좋은 달입니다.',
      '6': '인내가 필요한 시기입니다.',
      '7': '휴식을 통해 재충전하세요.',
      '8': '새로운 기회가 찾아올 수 있습니다.',
      '9': '인간관계가 좋아집니다.',
      '10': '안정적인 흐름이 이어집니다.',
      '11': '감사하는 마음을 가지세요.',
      '12': '편안하게 한 해를 마무리합니다.'
    },
    normal: {
      '1': '평범한 시작입니다. 무리하지 마세요.',
      '2': '현상 유지에 집중하세요.',
      '3': '봄의 기운을 느끼며 지내세요.',
      '4': '건강을 챙기세요.',
      '5': '꾸준함이 중요합니다.',
      '6': '중간 점검을 하세요.',
      '7': '쉬어가는 것도 좋습니다.',
      '8': '조용히 준비하세요.',
      '9': '작은 변화를 시도해보세요.',
      '10': '감사한 마음으로 지내세요.',
      '11': '마무리를 준비하세요.',
      '12': '무난하게 한 해를 마무리합니다.'
    },
    caution: {
      '1': '조심스럽게 시작하세요.',
      '2': '무리한 계획은 피하세요.',
      '3': '건강에 주의하세요.',
      '4': '재물 관련 조심하세요.',
      '5': '인간관계에 신경 쓰세요.',
      '6': '휴식이 필요한 달입니다.',
      '7': '여행은 가급적 피하세요.',
      '8': '신중하게 행동하세요.',
      '9': '조금씩 나아지기 시작합니다.',
      '10': '희망을 잃지 마세요.',
      '11': '마무리에 집중하세요.',
      '12': '내년을 기약하세요.'
    },
    bad: {
      '1': '조심스럽게 시작하세요.',
      '2': '무리하지 마세요.',
      '3': '건강 관리가 중요합니다.',
      '4': '휴식을 취하세요.',
      '5': '인내가 필요합니다.',
      '6': '포기하지 마세요.',
      '7': '쉬어가세요.',
      '8': '조금씩 나아집니다.',
      '9': '희망이 보이기 시작합니다.',
      '10': '상황이 개선됩니다.',
      '11': '밝은 미래가 기다립니다.',
      '12': '힘든 해를 버텨냈습니다. 수고하셨습니다.'
    }
  };

  return baseMessages[grade] || baseMessages.normal;
}

/**
 * 조언 메시지 생성
 * @param {string} grade - 등급
 * @returns {string} 조언
 */
function generateAdvice(grade) {
  const advices = {
    excellent: '좋은 기운이 함께하니 적극적으로 움직이세요. 기회를 놓치지 마세요.',
    good: '순리를 따르며 꾸준히 노력하면 좋은 결과가 옵니다.',
    normal: '무리하지 않고 현재에 충실하세요. 때를 기다리는 것도 지혜입니다.',
    caution: '신중하게 행동하고 큰 변화는 피하세요. 인내가 필요한 시기입니다.',
    bad: '힘든 시기도 지나갈 것입니다. 포기하지 말고 버티세요.'
  };

  return advices[grade] || advices.normal;
}

/**
 * 현재 월의 운세 가져오기
 * @param {Object} fortune - 토정비결 결과
 * @returns {string} 현재 월 운세
 */
export function getCurrentMonthFortune(fortune) {
  const currentMonth = new Date().getMonth() + 1;
  return fortune.data.monthly[currentMonth.toString()] || '현재 월 운세를 불러올 수 없습니다.';
}

export default {
  loadTojeongData,
  calculateTojeongGua,
  getTojeongFortune,
  getCurrentMonthFortune,
  getUpperTrigram,
  getMiddleTrigram,
  getLowerTrigram
};
