/**
 * 사주팔자 계산 엔진
 * 생년월일시 → 사주팔자 변환
 * calendar.json 데이터 활용
 */

// 천간 (Heavenly Stems)
const CHEONGAN = ['갑', '을', '병', '정', '무', '기', '경', '신', '임', '계'];
const CHEONGAN_HANJA = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];

// 지지 (Earthly Branches)
const JIJI = ['자', '축', '인', '묘', '진', '사', '오', '미', '신', '유', '술', '해'];
const JIJI_HANJA = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];

// 60갑자 캐시
let ganziCache = null;
let calendarCache = null;

/**
 * 데이터 로드
 */
export async function loadCalendarData() {
  if (calendarCache) return calendarCache;

  try {
    const response = await fetch('/data/calendar.json');

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    calendarCache = await response.json();
    return calendarCache;
  } catch (error) {
    console.error('Failed to load calendar data:', error);

    // 네트워크 오류 세부 메시지
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error('네트워크 연결을 확인해주세요. 만세력 데이터를 불러올 수 없습니다.');
    } else if (error.message.includes('HTTP')) {
      throw new Error(`만세력 데이터를 불러올 수 없습니다. (${error.message})`);
    } else {
      throw new Error('만세력 데이터를 불러오는 중 오류가 발생했습니다.');
    }
  }
}

export async function loadGanziData() {
  if (ganziCache) return ganziCache;

  try {
    const response = await fetch('/data/ganzi.json');

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    ganziCache = await response.json();
    return ganziCache;
  } catch (error) {
    console.error('Failed to load ganzi data:', error);

    // 네트워크 오류 세부 메시지
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error('네트워크 연결을 확인해주세요. 간지 데이터를 불러올 수 없습니다.');
    } else if (error.message.includes('HTTP')) {
      throw new Error(`간지 데이터를 불러올 수 없습니다. (${error.message})`);
    } else {
      throw new Error('간지 데이터를 불러오는 중 오류가 발생했습니다.');
    }
  }
}

/**
 * 음력 날짜를 양력으로 변환
 * @param {number} lunarYear - 음력 연도
 * @param {number} lunarMonth - 음력 월 (1-12)
 * @param {number} lunarDay - 음력 일
 * @param {boolean} isLeapMonth - 윤달 여부
 * @returns {Object} {solarYear, solarMonth, solarDay}
 */
export async function lunarToSolar(lunarYear, lunarMonth, lunarDay, isLeapMonth = false) {
  const calendar = await loadCalendarData();

  // 연도 범위 검증
  if (lunarYear < 1900 || lunarYear > 2100) {
    throw new Error(`음력 생일은 1900년부터 2100년 사이만 지원됩니다. (입력: ${lunarYear}년)`);
  }

  // 해당 연도와 그 전후 연도 데이터 가져오기 (음력 1월이 전년도 양력에 있을 수 있음)
  const yearData = calendar.years.find(y => y.year === lunarYear);
  const prevYearData = calendar.years.find(y => y.year === lunarYear - 1);
  const nextYearData = calendar.years.find(y => y.year === lunarYear + 1);

  if (!yearData) {
    throw new Error(`${lunarYear}년 데이터가 없습니다. (1900-2100년만 지원)`);
  }

  // 모든 연도의 월 데이터를 순회하여 해당 음력 월 찾기
  const allYears = [prevYearData, yearData, nextYearData].filter(y => y !== null && y !== undefined);

  for (const year of allYears) {
    for (const monthData of year.months) {
      for (const lunarMonthInfo of monthData.lunarMonths) {
        // 음력 연월이 일치하는지 확인
        if (
          lunarMonthInfo.lunarYear === lunarYear &&
          lunarMonthInfo.lunarMonth === lunarMonth &&
          lunarMonthInfo.isLeap === isLeapMonth
        ) {
          // 해당 음력 월의 일수 검증
          if (lunarDay < 1 || lunarDay > lunarMonthInfo.daysInMonth) {
            throw new Error(
              `음력 ${lunarYear}년 ${lunarMonth}월${isLeapMonth ? '(윤)' : ''}은 ${lunarMonthInfo.daysInMonth}일까지 있습니다. (입력: ${lunarDay}일)`
            );
          }

          // 이 음력 월의 첫날이 양력 몇월 몇일인지 계산
          // calendar.json에는 월별 시작일이 없으므로, 근사 계산
          // 음력 1일 = 양력 monthData.solarMonth의 중순 근처로 가정
          // 더 정확한 변환을 위해서는 lunar-javascript 라이브러리 필요

          // 간단한 근사: 음력 월의 평균 시작일 추정
          const solarYear = year.year;
          const solarMonth = monthData.solarMonth;

          // 음력 1일은 대략 양력 월의 시작~중순
          // lunarMonthInfo가 solarMonth의 첫 번째인지 두 번째인지에 따라 다름
          const indexInMonth = monthData.lunarMonths.indexOf(lunarMonthInfo);

          // 첫 번째 음력 월이면 전월 말~이번 월 초
          // 두 번째 음력 월이면 이번 월 중순~말
          let estimatedStartDay;
          if (indexInMonth === 0) {
            estimatedStartDay = 1; // 대략 월초
          } else {
            // 전 음력 월의 일수만큼 더함
            const prevLunarMonth = monthData.lunarMonths[indexInMonth - 1];
            estimatedStartDay = prevLunarMonth.daysInMonth - 15; // 대략 중순
          }

          const solarDay = Math.max(1, Math.min(31, estimatedStartDay + lunarDay - 1));

          return {
            solarYear,
            solarMonth,
            solarDay
          };
        }
      }
    }
  }

  throw new Error(
    `음력 ${lunarYear}년 ${lunarMonth}월${isLeapMonth ? '(윤)' : ''} ${lunarDay}일을 찾을 수 없습니다.`
  );
}

/**
 * 양력 날짜를 음력으로 변환 (추후 구현 필요)
 * @param {number} year - 양력 연도
 * @param {number} month - 양력 월 (1-12)
 * @param {number} day - 양력 일
 * @returns {Object} {lunarYear, lunarMonth, lunarDay, isLeap}
 */
export async function solarToLunar(year, month, day) {
  // 양력→음력 변환은 복잡하여 lunar-javascript 라이브러리 권장
  // 현재는 미구현
  return {
    lunarYear: year,
    lunarMonth: month,
    lunarDay: day,
    isLeap: false
  };
}

/**
 * 연주(年柱) 계산 - 입춘 기준
 * @param {number} year - 연도
 * @param {number} month - 월
 * @param {number} day - 일
 * @returns {Object} {gan, ji, ganzi}
 */
export async function getYearPillar(year, month, day) {
  const calendar = await loadCalendarData();
  const yearData = calendar.years.find(y => y.year === year);

  if (!yearData) {
    throw new Error(`${year}년 데이터가 없습니다.`);
  }

  // 입춘 날짜 확인
  const lichun = yearData.jieqi.find(j => j.name === '입춘' || j.nameHanja === '立春');

  if (lichun) {
    const [lichunYear, lichunMonth, lichunDay] = lichun.solar.split('-').map(Number);
    const inputDate = new Date(year, month - 1, day);
    const lichunDate = new Date(lichunYear, lichunMonth - 1, lichunDay);

    // 입춘 이전이면 전년도 간지 사용
    if (inputDate < lichunDate) {
      const prevYearData = calendar.years.find(y => y.year === year - 1);
      if (prevYearData) {
        return {
          gan: prevYearData.ganzi.gan,
          ji: prevYearData.ganzi.ji,
          ganzi: prevYearData.ganzi.ganzi,
          ganHangul: CHEONGAN[CHEONGAN_HANJA.indexOf(prevYearData.ganzi.gan)],
          jiHangul: JIJI[JIJI_HANJA.indexOf(prevYearData.ganzi.ji)]
        };
      }
    }
  }

  return {
    gan: yearData.ganzi.gan,
    ji: yearData.ganzi.ji,
    ganzi: yearData.ganzi.ganzi,
    ganHangul: CHEONGAN[CHEONGAN_HANJA.indexOf(yearData.ganzi.gan)],
    jiHangul: JIJI[JIJI_HANJA.indexOf(yearData.ganzi.ji)]
  };
}

/**
 * 월주(月柱) 계산 - 절입 기준
 * @param {number} year - 연도
 * @param {number} month - 월
 * @param {number} day - 일
 * @returns {Object} {gan, ji, ganzi}
 */
export async function getMonthPillar(year, month, day) {
  const calendar = await loadCalendarData();
  const yearData = calendar.years.find(y => y.year === year);

  if (!yearData) {
    throw new Error(`${year}년 데이터가 없습니다.`);
  }

  // 24절기 중 절(節)만 사용: 입춘, 경칩, 청명, 입하, 망종, 소서, 입추, 백로, 한로, 입동, 대설, 소한
  const monthJieqi = [
    '입춘', '경칩', '청명', '입하', '망종', '소서',
    '입추', '백로', '한로', '입동', '대설', '소한'
  ];

  // 현재 날짜가 어느 절기 이후인지 확인
  const inputDate = new Date(year, month - 1, day);
  let currentMonthIndex = 0;

  for (let i = 0; i < yearData.jieqi.length; i++) {
    const jieqi = yearData.jieqi[i];
    const jieqiIndex = monthJieqi.indexOf(jieqi.name);

    if (jieqiIndex >= 0) {
      const [jYear, jMonth, jDay] = jieqi.solar.split('-').map(Number);
      const jieqiDate = new Date(jYear, jMonth - 1, jDay);

      if (inputDate >= jieqiDate) {
        currentMonthIndex = jieqiIndex;
      }
    }
  }

  // 월주 지지는 고정: 인월(1월)부터 시작
  const monthJi = JIJI[(currentMonthIndex + 2) % 12]; // 인=2부터 시작
  const monthJiHanja = JIJI_HANJA[(currentMonthIndex + 2) % 12];

  // 월주 천간 계산: 연간에 따라 결정
  const yearGanIndex = CHEONGAN_HANJA.indexOf(yearData.ganzi.gan);
  const monthGanOffset = [2, 4, 6, 8, 0]; // 갑/기년, 을/경년, 병/신년, 정/임년, 무/계년
  const monthGanIndex = (monthGanOffset[yearGanIndex % 5] + currentMonthIndex) % 10;

  const monthGan = CHEONGAN[monthGanIndex];
  const monthGanHanja = CHEONGAN_HANJA[monthGanIndex];

  return {
    gan: monthGanHanja,
    ji: monthJiHanja,
    ganzi: monthGanHanja + monthJiHanja,
    ganHangul: monthGan,
    jiHangul: monthJi
  };
}

/**
 * 일주(日柱) 계산
 * @param {number} year - 연도
 * @param {number} month - 월
 * @param {number} day - 일
 * @returns {Object} {gan, ji, ganzi}
 */
export function getDayPillar(year, month, day) {
  // 기준일: 1900년 1월 1일 = 갑술일 (甲戌)
  const baseDate = new Date(1900, 0, 1);
  const baseGanIndex = 0; // 갑
  const baseJiIndex = 10; // 술

  const targetDate = new Date(year, month - 1, day);
  const diffDays = Math.floor((targetDate - baseDate) / (1000 * 60 * 60 * 24));

  const ganIndex = (baseGanIndex + diffDays) % 10;
  const jiIndex = (baseJiIndex + diffDays) % 12;

  // 음수 처리
  const finalGanIndex = ganIndex >= 0 ? ganIndex : ganIndex + 10;
  const finalJiIndex = jiIndex >= 0 ? jiIndex : jiIndex + 12;

  return {
    gan: CHEONGAN_HANJA[finalGanIndex],
    ji: JIJI_HANJA[finalJiIndex],
    ganzi: CHEONGAN_HANJA[finalGanIndex] + JIJI_HANJA[finalJiIndex],
    ganHangul: CHEONGAN[finalGanIndex],
    jiHangul: JIJI[finalJiIndex]
  };
}

/**
 * 시주(時柱) 계산
 * @param {number} hour - 시간 (0-23)
 * @param {string} dayGanHanja - 일간 한자
 * @returns {Object} {gan, ji, ganzi}
 */
export function getHourPillar(hour, dayGanHanja) {
  // 시간을 지지로 변환
  // 자시: 23:00-00:59
  // 축시: 01:00-02:59
  // 인시: 03:00-04:59
  // ...
  let hourJiIndex = 0;

  if (hour >= 23 || hour < 1) {
    hourJiIndex = 0; // 자(子) 23:00-00:59
  } else if (hour >= 1 && hour < 3) {
    hourJiIndex = 1; // 축(丑) 01:00-02:59
  } else if (hour >= 3 && hour < 5) {
    hourJiIndex = 2; // 인(寅) 03:00-04:59
  } else if (hour >= 5 && hour < 7) {
    hourJiIndex = 3; // 묘(卯) 05:00-06:59
  } else if (hour >= 7 && hour < 9) {
    hourJiIndex = 4; // 진(辰) 07:00-08:59
  } else if (hour >= 9 && hour < 11) {
    hourJiIndex = 5; // 사(巳) 09:00-10:59
  } else if (hour >= 11 && hour < 13) {
    hourJiIndex = 6; // 오(午) 11:00-12:59
  } else if (hour >= 13 && hour < 15) {
    hourJiIndex = 7; // 미(未) 13:00-14:59
  } else if (hour >= 15 && hour < 17) {
    hourJiIndex = 8; // 신(申) 15:00-16:59
  } else if (hour >= 17 && hour < 19) {
    hourJiIndex = 9; // 유(酉) 17:00-18:59
  } else if (hour >= 19 && hour < 21) {
    hourJiIndex = 10; // 술(戌) 19:00-20:59
  } else if (hour >= 21 && hour < 23) {
    hourJiIndex = 11; // 해(亥) 21:00-22:59
  }

  // 시주 천간 계산: 일간에 따라 결정
  const dayGanIndex = CHEONGAN_HANJA.indexOf(dayGanHanja);
  const hourGanOffset = [0, 2, 4, 6, 8]; // 갑/기일, 을/경일, 병/신일, 정/임일, 무/계일
  const hourGanIndex = (hourGanOffset[dayGanIndex % 5] + hourJiIndex) % 10;

  return {
    gan: CHEONGAN_HANJA[hourGanIndex],
    ji: JIJI_HANJA[hourJiIndex],
    ganzi: CHEONGAN_HANJA[hourGanIndex] + JIJI_HANJA[hourJiIndex],
    ganHangul: CHEONGAN[hourGanIndex],
    jiHangul: JIJI[hourJiIndex]
  };
}

/**
 * 사주팔자 전체 계산
 * @param {Object} birthInfo - 생년월일시 정보
 * @param {number} birthInfo.year - 연도
 * @param {number} birthInfo.month - 월
 * @param {number} birthInfo.day - 일
 * @param {number} birthInfo.hour - 시 (0-23)
 * @param {boolean} birthInfo.isLunar - 음력 여부
 * @returns {Object} 사주팔자 결과
 */
export async function calculateSaju(birthInfo) {
  const { year, month, day, hour, isLunar = false, isLeapMonth = false } = birthInfo;

  // 음력이면 양력으로 변환
  let solarYear = year;
  let solarMonth = month;
  let solarDay = day;

  if (isLunar) {
    try {
      const solarDate = await lunarToSolar(year, month, day, isLeapMonth);
      solarYear = solarDate.solarYear;
      solarMonth = solarDate.solarMonth;
      solarDay = solarDate.solarDay;

      console.log(
        `음력 ${year}-${month}-${day}${isLeapMonth ? '(윤)' : ''} → 양력 ${solarYear}-${solarMonth}-${solarDay} 변환 완료`
      );
    } catch (error) {
      console.error('음력 변환 실패:', error.message);
      throw new Error(`음력 날짜 변환 중 오류가 발생했습니다: ${error.message}`);
    }
  }

  // 사주 계산
  const yearPillar = await getYearPillar(solarYear, solarMonth, solarDay);
  const monthPillar = await getMonthPillar(solarYear, solarMonth, solarDay);
  const dayPillar = getDayPillar(solarYear, solarMonth, solarDay);

  // 자시(23:00-01:00) 처리: 23시는 다음 날의 시작으로 간주
  let adjustedHour = hour;
  let dayPillarForHour = dayPillar;

  if (hour >= 23) {
    // 23시는 다음 날의 자시이므로 다음 날의 일주를 기준으로 시주 계산
    const nextDay = new Date(solarYear, solarMonth - 1, solarDay);
    nextDay.setDate(nextDay.getDate() + 1);

    dayPillarForHour = getDayPillar(
      nextDay.getFullYear(),
      nextDay.getMonth() + 1,
      nextDay.getDate()
    );
  }

  const hourPillar = getHourPillar(adjustedHour, dayPillarForHour.gan);

  return {
    year: yearPillar,
    month: monthPillar,
    day: dayPillar,
    hour: hourPillar,
    pillars: {
      year: yearPillar.ganzi,
      month: monthPillar.ganzi,
      day: dayPillar.ganzi,
      hour: hourPillar.ganzi
    },
    // 일간을 중심으로 해석
    dayMaster: {
      gan: dayPillar.gan,
      ganHangul: dayPillar.ganHangul,
      ji: dayPillar.ji,
      jiHangul: dayPillar.jiHangul
    }
  };
}

/**
 * 일주(日柱)로 60갑자 ID 찾기
 * @param {string} ilju - 일주 간지 (예: "甲子")
 * @returns {number} 0-59 사이의 ID
 */
export function getIljuId(ilju) {
  const ganIndex = CHEONGAN_HANJA.indexOf(ilju[0]);
  const jiIndex = JIJI_HANJA.indexOf(ilju[1]);

  if (ganIndex === -1 || jiIndex === -1) {
    return -1;
  }

  // 60갑자 순환 계산
  // 갑자(0), 을축(1), 병인(2), ...
  let id = 0;
  for (let i = 0; i < 60; i++) {
    if (ganIndex === (i % 10) && jiIndex === (i % 12)) {
      id = i;
      break;
    }
  }

  return id;
}

/**
 * 간지 정보 가져오기
 * @param {string} ganzi - 간지 (예: "甲子")
 * @returns {Object} 간지 상세 정보
 */
export async function getGanziInfo(ganzi) {
  const ganziData = await loadGanziData();

  const gan = ganziData.cheongan.find(g => g.hanja === ganzi[0]);
  const ji = ganziData.jiji.find(j => j.hanja === ganzi[1]);

  return {
    gan: gan || null,
    ji: ji || null
  };
}

/**
 * 일주 해석 데이터 로드
 * @param {number} iljuId - 일주 ID (0-59)
 * @returns {Object} 일주 해석 정보
 */
export async function getIljuInterpretation(iljuId) {
  try {
    // 일주 데이터는 6개 파일로 분할되어 있음 (각 10개씩)
    const partNumber = Math.floor(iljuId / 10) + 1;
    const response = await fetch(`/data/saju-ilju-part${partNumber}.json`);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();

    // 해당 일주 찾기
    const interpretation = data.interpretations.find(i => i.id === iljuId);
    return interpretation || null;
  } catch (error) {
    console.error('Failed to load ilju interpretation:', error);

    // 일주 해석은 선택적 기능이므로 null 반환
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.warn('네트워크 오류로 일주 해석을 불러올 수 없습니다.');
    } else if (error.message.includes('HTTP')) {
      console.warn(`일주 해석 데이터를 불러올 수 없습니다. (${error.message})`);
    }

    return null;
  }
}
