/**
 * 십신(十神) 분석 모듈
 * 사주 팔자의 천간을 기준으로 십신을 계산하고 해석
 */

// 오행 매핑
const OHAENG_MAP = {
  '갑': '목', '을': '목',
  '병': '화', '정': '화',
  '무': '토', '기': '토',
  '경': '금', '신': '금',
  '임': '수', '계': '수'
};

// 음양 매핑 (양=true, 음=false)
const YINYANG_MAP = {
  '갑': true, '을': false,
  '병': true, '정': false,
  '무': true, '기': false,
  '경': true, '신': false,
  '임': true, '계': false
};

// 오행 상생상극 관계
const OHAENG_RELATION = {
  // 나를 극하는 오행 (나를 제어)
  '극나': {
    '목': '금',
    '화': '수',
    '토': '목',
    '금': '화',
    '수': '토'
  },
  // 내가 극하는 오행 (내가 제어)
  '나극': {
    '목': '토',
    '화': '금',
    '토': '수',
    '금': '목',
    '수': '화'
  },
  // 나를 생하는 오행 (나를 돕는)
  '생나': {
    '목': '수',
    '화': '목',
    '토': '화',
    '금': '토',
    '수': '금'
  },
  // 내가 생하는 오행 (내가 돕는)
  '나생': {
    '목': '화',
    '화': '토',
    '토': '금',
    '금': '수',
    '수': '목'
  }
};

/**
 * 십신 계산
 * @param {string} ilgan - 일간 (예: '갑')
 * @param {string} target - 대상 천간 (예: '을')
 * @returns {string} 십신 이름
 */
export function calculateSipsin(ilgan, target) {
  // 같은 천간이면 비견 또는 겁재
  if (ilgan === target) {
    return '비견';
  }

  const ilganOhaeng = OHAENG_MAP[ilgan];
  const ilganYinyang = YINYANG_MAP[ilgan];
  const targetOhaeng = OHAENG_MAP[target];
  const targetYinyang = YINYANG_MAP[target];

  // 같은 오행 (비겁)
  if (ilganOhaeng === targetOhaeng) {
    return targetYinyang === ilganYinyang ? '비견' : '겁재';
  }

  // 내가 생하는 오행 (식상)
  if (OHAENG_RELATION['나생'][ilganOhaeng] === targetOhaeng) {
    return targetYinyang === ilganYinyang ? '식신' : '상관';
  }

  // 내가 극하는 오행 (재성)
  if (OHAENG_RELATION['나극'][ilganOhaeng] === targetOhaeng) {
    return targetYinyang === ilganYinyang ? '정재' : '편재';
  }

  // 나를 극하는 오행 (관성)
  if (OHAENG_RELATION['극나'][ilganOhaeng] === targetOhaeng) {
    return targetYinyang === ilganYinyang ? '정관' : '편관';
  }

  // 나를 생하는 오행 (인성)
  if (OHAENG_RELATION['생나'][ilganOhaeng] === targetOhaeng) {
    return targetYinyang === ilganYinyang ? '정인' : '편인';
  }

  return '알 수 없음';
}

/**
 * 사주 전체의 십신 분석
 * @param {Object} saju - 사주 팔자 데이터
 * @returns {Object} 십신 분석 결과
 */
export function analyzeSipsin(saju) {
  const ilgan = saju.day.ganHangul; // 일간 (나)

  // 각 주의 천간에 대한 십신 계산
  const sipsinMap = {
    year: {
      gan: calculateSipsin(ilgan, saju.year.ganHangul),
      pillar: '년주'
    },
    month: {
      gan: calculateSipsin(ilgan, saju.month.ganHangul),
      pillar: '월주'
    },
    day: {
      gan: '일간(나)',
      pillar: '일주'
    },
    hour: {
      gan: calculateSipsin(ilgan, saju.hour.ganHangul),
      pillar: '시주'
    }
  };

  // 십신 개수 집계 (일간 제외)
  const sipsinCount = {};
  [sipsinMap.year, sipsinMap.month, sipsinMap.hour].forEach(item => {
    const sipsin = item.gan;
    sipsinCount[sipsin] = (sipsinCount[sipsin] || 0) + 1;
  });

  // 가장 많은 십신 찾기
  let dominantSipsin = null;
  let maxCount = 0;
  Object.entries(sipsinCount).forEach(([sipsin, count]) => {
    if (count > maxCount) {
      maxCount = count;
      dominantSipsin = sipsin;
    }
  });

  // 십신 분류
  const sipsinGroups = {
    '비겁': ['비견', '겁재'],
    '식상': ['식신', '상관'],
    '재성': ['정재', '편재'],
    '관성': ['정관', '편관'],
    '인성': ['정인', '편인']
  };

  // 그룹별 개수
  const groupCount = {};
  Object.entries(sipsinGroups).forEach(([groupName, sipsins]) => {
    groupCount[groupName] = sipsins.reduce((sum, s) => sum + (sipsinCount[s] || 0), 0);
  });

  return {
    map: sipsinMap,
    count: sipsinCount,
    groupCount: groupCount,
    dominant: {
      sipsin: dominantSipsin,
      count: maxCount
    },
    ilgan: ilgan
  };
}

/**
 * 십신 해석 데이터 로드
 */
let sipsinInterpretationCache = null;

export async function loadSipsinInterpretation() {
  if (sipsinInterpretationCache) return sipsinInterpretationCache;

  try {
    const response = await fetch('/data/sipsin-interpretation.json');
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    sipsinInterpretationCache = await response.json();
    return sipsinInterpretationCache;
  } catch (error) {
    console.error('Failed to load sipsin interpretation:', error);

    // 네트워크 오류 세부 메시지
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error('네트워크 연결을 확인해주세요. 십신 해석 데이터를 불러올 수 없습니다.');
    } else if (error.message.includes('HTTP')) {
      throw new Error(`십신 해석 데이터를 불러올 수 없습니다. (${error.message})`);
    } else {
      throw new Error('십신 해석 데이터를 불러오는 중 오류가 발생했습니다.');
    }
  }
}

/**
 * 특정 십신에 대한 해석 가져오기
 * @param {string} sipsinName - 십신 이름
 * @returns {Object} 해석 데이터
 */
export async function getSipsinInterpretation(sipsinName) {
  const data = await loadSipsinInterpretation();
  return data.sipsin[sipsinName] || null;
}

/**
 * 십신 분석 종합 해석
 * @param {Object} sipsinAnalysis - analyzeSipsin() 결과
 * @returns {Object} 종합 해석
 */
export async function interpretSipsin(sipsinAnalysis) {
  const data = await loadSipsinInterpretation();
  const { dominant, groupCount, count } = sipsinAnalysis;

  // 주요 십신 해석
  let mainInterpretation = null;
  if (dominant.sipsin && dominant.count >= 2) {
    mainInterpretation = data.sipsin[dominant.sipsin];
  }

  // 균형 분석
  const hasBalance = Object.values(groupCount).every(c => c <= 2);
  const imbalance = [];

  Object.entries(groupCount).forEach(([group, cnt]) => {
    if (cnt === 0) {
      imbalance.push({ group, type: '부족', count: 0 });
    } else if (cnt >= 3) {
      imbalance.push({ group, type: '과다', count: cnt });
    }
  });

  // 종합 평가
  let summary = '';
  if (hasBalance) {
    summary = '십신이 비교적 균형잡혀 있어 다양한 분야에서 능력을 발휘할 수 있습니다.';
  } else if (dominant.count >= 2) {
    summary = `${dominant.sipsin}의 특성이 강하게 나타나는 사주입니다.`;
  }

  return {
    main: mainInterpretation,
    balance: hasBalance,
    imbalance: imbalance,
    summary: summary,
    count: count
  };
}
