/**
 * LocalStorage 관리 유틸리티
 * 사용자 프로필 및 운세 캐시 관리
 */

import { formatKoreanDate } from './date.js';

const STORAGE_KEYS = {
  PROFILES: 'fortune_profiles',
  CURRENT_PROFILE: 'fortune_current_profile',
  FORTUNE_CACHE: 'fortune_cache',
  SETTINGS: 'fortune_settings'
};

/**
 * LocalStorage에서 데이터 가져오기
 * @param {string} key - 저장소 키
 * @param {*} defaultValue - 기본값
 * @returns {*} 저장된 데이터 또는 기본값
 */
export function getItem(key, defaultValue = null) {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.error(`Failed to get item from localStorage: ${key}`, error);
    return defaultValue;
  }
}

/**
 * LocalStorage에 데이터 저장
 * @param {string} key - 저장소 키
 * @param {*} value - 저장할 데이터
 * @returns {boolean} 성공 여부
 */
export function setItem(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    console.error(`Failed to set item in localStorage: ${key}`, error);
    return false;
  }
}

/**
 * LocalStorage에서 데이터 삭제
 * @param {string} key - 저장소 키
 * @returns {boolean} 성공 여부
 */
export function removeItem(key) {
  try {
    localStorage.removeItem(key);
    return true;
  } catch (error) {
    console.error(`Failed to remove item from localStorage: ${key}`, error);
    return false;
  }
}

/**
 * 모든 프로필 가져오기
 * @returns {Array} 프로필 목록
 */
export function getAllProfiles() {
  return getItem(STORAGE_KEYS.PROFILES, []);
}

/**
 * 현재 활성 프로필 ID 가져오기
 * @returns {string|null} 프로필 ID
 */
export function getCurrentProfileId() {
  return getItem(STORAGE_KEYS.CURRENT_PROFILE, null);
}

/**
 * 현재 활성 프로필 가져오기
 * @returns {Object|null} 프로필 객체
 */
export function getCurrentProfile() {
  const profileId = getCurrentProfileId();
  if (!profileId) return null;

  const profiles = getAllProfiles();
  return profiles.find(p => p.id === profileId) || null;
}

/**
 * 특정 프로필 가져오기
 * @param {string} profileId - 프로필 ID
 * @returns {Object|null} 프로필 객체
 */
export function getProfile(profileId) {
  const profiles = getAllProfiles();
  return profiles.find(p => p.id === profileId) || null;
}

/**
 * 프로필 추가
 * @param {Object} profile - 프로필 정보
 * @returns {Object} 추가된 프로필 (ID 포함)
 */
export function addProfile(profile) {
  const profiles = getAllProfiles();

  // UUID 생성 (간단 버전)
  const id = `profile_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  const newProfile = {
    id,
    ...profile,
    createdAt: formatKoreanDate(new Date(), true),
    updatedAt: formatKoreanDate(new Date(), true)
  };

  profiles.push(newProfile);
  setItem(STORAGE_KEYS.PROFILES, profiles);

  // 첫 프로필이면 자동으로 활성화
  if (profiles.length === 1) {
    setCurrentProfile(id);
  }

  return newProfile;
}

/**
 * 프로필 업데이트
 * @param {string} profileId - 프로필 ID
 * @param {Object} updates - 업데이트할 정보
 * @returns {Object|null} 업데이트된 프로필
 */
export function updateProfile(profileId, updates) {
  const profiles = getAllProfiles();
  const index = profiles.findIndex(p => p.id === profileId);

  if (index === -1) return null;

  profiles[index] = {
    ...profiles[index],
    ...updates,
    updatedAt: formatKoreanDate(new Date(), true)
  };

  setItem(STORAGE_KEYS.PROFILES, profiles);
  return profiles[index];
}

/**
 * 프로필 삭제
 * @param {string} profileId - 프로필 ID
 * @returns {boolean} 성공 여부
 */
export function deleteProfile(profileId) {
  let profiles = getAllProfiles();
  const initialLength = profiles.length;

  profiles = profiles.filter(p => p.id !== profileId);

  if (profiles.length === initialLength) {
    return false; // 삭제할 프로필이 없음
  }

  setItem(STORAGE_KEYS.PROFILES, profiles);

  // 현재 활성 프로필이 삭제되면 첫 번째 프로필로 변경
  const currentId = getCurrentProfileId();
  if (currentId === profileId) {
    if (profiles.length > 0) {
      setCurrentProfile(profiles[0].id);
    } else {
      removeItem(STORAGE_KEYS.CURRENT_PROFILE);
    }
  }

  return true;
}

/**
 * 현재 활성 프로필 설정
 * @param {string} profileId - 프로필 ID
 * @returns {boolean} 성공 여부
 */
export function setCurrentProfile(profileId) {
  const profiles = getAllProfiles();
  const profile = profiles.find(p => p.id === profileId);

  if (!profile) {
    return false;
  }

  setItem(STORAGE_KEYS.CURRENT_PROFILE, profileId);
  return true;
}

/**
 * 운세 캐시 가져오기
 * @param {string} date - 날짜 (YYYY-MM-DD)
 * @param {string} profileId - 프로필 ID
 * @returns {Object|null} 캐시된 운세
 */
export function getFortuneCache(date, profileId) {
  const cache = getItem(STORAGE_KEYS.FORTUNE_CACHE, {});
  const key = `${date}_${profileId}`;
  return cache[key] || null;
}

/**
 * 운세 캐시 저장
 * @param {string} date - 날짜 (YYYY-MM-DD)
 * @param {string} profileId - 프로필 ID
 * @param {Object} fortune - 운세 데이터
 * @returns {boolean} 성공 여부
 */
export function setFortuneCache(date, profileId, fortune) {
  const cache = getItem(STORAGE_KEYS.FORTUNE_CACHE, {});
  const key = `${date}_${profileId}`;

  cache[key] = {
    ...fortune,
    cachedAt: formatKoreanDate(new Date(), true)
  };

  // 오래된 캐시 삭제 (30일 이상)
  const now = new Date();
  Object.keys(cache).forEach(cacheKey => {
    const cachedDate = cache[cacheKey].cachedAt;
    const diff = now - new Date(cachedDate);
    const daysDiff = diff / (1000 * 60 * 60 * 24);

    if (daysDiff > 30) {
      delete cache[cacheKey];
    }
  });

  return setItem(STORAGE_KEYS.FORTUNE_CACHE, cache);
}

/**
 * 설정 가져오기
 * @returns {Object} 설정 객체
 */
export function getSettings() {
  return getItem(STORAGE_KEYS.SETTINGS, {
    theme: 'light',
    notifications: true,
    language: 'ko'
  });
}

/**
 * 설정 저장
 * @param {Object} settings - 설정 객체
 * @returns {boolean} 성공 여부
 */
export function setSettings(settings) {
  return setItem(STORAGE_KEYS.SETTINGS, settings);
}

/**
 * 모든 데이터 초기화
 * @returns {boolean} 성공 여부
 */
export function clearAll() {
  try {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
    return true;
  } catch (error) {
    console.error('Failed to clear all data:', error);
    return false;
  }
}

/**
 * 저장소 사용량 확인
 * @returns {Object} 사용량 정보
 */
export function getStorageInfo() {
  let total = 0;
  const details = {};

  Object.entries(STORAGE_KEYS).forEach(([name, key]) => {
    const item = localStorage.getItem(key);
    const size = item ? new Blob([item]).size : 0;
    details[name] = size;
    total += size;
  });

  return {
    total,
    totalKB: (total / 1024).toFixed(2),
    details,
    limit: 5 * 1024 * 1024, // 5MB (일반적인 한계)
    percentage: ((total / (5 * 1024 * 1024)) * 100).toFixed(2)
  };
}

export default {
  getItem,
  setItem,
  removeItem,
  getAllProfiles,
  getCurrentProfileId,
  getCurrentProfile,
  getProfile,
  addProfile,
  updateProfile,
  deleteProfile,
  setCurrentProfile,
  getFortuneCache,
  setFortuneCache,
  getSettings,
  setSettings,
  clearAll,
  getStorageInfo
};
