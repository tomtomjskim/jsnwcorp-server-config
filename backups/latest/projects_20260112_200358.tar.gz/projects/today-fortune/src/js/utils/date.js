/**
 * 날짜 관련 유틸리티 함수
 */

/**
 * 날짜를 YYYY-MM-DD 형식으로 변환
 * @param {Date} date - Date 객체
 * @returns {string} YYYY-MM-DD 형식의 문자열
 */
export function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * 날짜를 한글 형식으로 변환
 * @param {Date} date - Date 객체
 * @param {boolean} includeDay - 요일 포함 여부
 * @returns {string} "2025년 10월 20일 (월)" 형식의 문자열
 */
export function formatKoreanDate(date, includeDay = true) {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();

  let result = `${year}년 ${month}월 ${day}일`;

  if (includeDay) {
    const dayNames = ['일', '월', '화', '수', '목', '금', '토'];
    const dayName = dayNames[date.getDay()];
    result += ` (${dayName})`;
  }

  return result;
}

/**
 * 시간을 한글 형식으로 변환
 * @param {number} hour - 시 (0-23)
 * @param {number} minute - 분 (0-59)
 * @returns {string} "오전 10시 30분" 형식의 문자열
 */
export function formatKoreanTime(hour, minute = 0) {
  const period = hour < 12 ? '오전' : '오후';
  const hour12 = hour === 0 ? 12 : (hour > 12 ? hour - 12 : hour);
  const minuteStr = minute > 0 ? ` ${minute}분` : '';

  return `${period} ${hour12}시${minuteStr}`;
}

/**
 * 문자열을 Date 객체로 변환
 * @param {string} dateStr - YYYY-MM-DD 형식의 문자열
 * @returns {Date} Date 객체
 */
export function parseDate(dateStr) {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(year, month - 1, day);
}

/**
 * 두 날짜 사이의 일수 계산
 * @param {Date} date1 - 첫 번째 날짜
 * @param {Date} date2 - 두 번째 날짜
 * @returns {number} 일수
 */
export function daysBetween(date1, date2) {
  const oneDay = 24 * 60 * 60 * 1000;
  return Math.round(Math.abs((date1 - date2) / oneDay));
}

/**
 * 오늘인지 확인
 * @param {Date} date - 확인할 날짜
 * @returns {boolean} 오늘 여부
 */
export function isToday(date) {
  const today = new Date();
  return (
    date.getFullYear() === today.getFullYear() &&
    date.getMonth() === today.getMonth() &&
    date.getDate() === today.getDate()
  );
}

/**
 * 어제인지 확인
 * @param {Date} date - 확인할 날짜
 * @returns {boolean} 어제 여부
 */
export function isYesterday(date) {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);

  return (
    date.getFullYear() === yesterday.getFullYear() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getDate() === yesterday.getDate()
  );
}

/**
 * 내일인지 확인
 * @param {Date} date - 확인할 날짜
 * @returns {boolean} 내일 여부
 */
export function isTomorrow(date) {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);

  return (
    date.getFullYear() === tomorrow.getFullYear() &&
    date.getMonth() === tomorrow.getMonth() &&
    date.getDate() === tomorrow.getDate()
  );
}

/**
 * 상대적인 날짜 표현
 * @param {Date} date - 날짜
 * @returns {string} "오늘", "어제", "내일", "3일 전" 등
 */
export function getRelativeDate(date) {
  if (isToday(date)) return '오늘';
  if (isYesterday(date)) return '어제';
  if (isTomorrow(date)) return '내일';

  const today = new Date();
  const diffDays = daysBetween(date, today);

  if (date < today) {
    return `${diffDays}일 전`;
  } else {
    return `${diffDays}일 후`;
  }
}

/**
 * 나이 계산
 * @param {number} birthYear - 출생년도
 * @param {number} birthMonth - 출생월
 * @param {number} birthDay - 출생일
 * @returns {number} 만 나이
 */
export function calculateAge(birthYear, birthMonth, birthDay) {
  const today = new Date();
  let age = today.getFullYear() - birthYear;

  const birthDateThisYear = new Date(today.getFullYear(), birthMonth - 1, birthDay);

  if (today < birthDateThisYear) {
    age--;
  }

  return age;
}

/**
 * 윤년 확인
 * @param {number} year - 연도
 * @returns {boolean} 윤년 여부
 */
export function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

/**
 * 해당 월의 일수
 * @param {number} year - 연도
 * @param {number} month - 월 (1-12)
 * @returns {number} 일수
 */
export function getDaysInMonth(year, month) {
  return new Date(year, month, 0).getDate();
}

/**
 * 월 이름 가져오기
 * @param {number} month - 월 (1-12)
 * @param {boolean} short - 짧은 형식 여부
 * @returns {string} 월 이름
 */
export function getMonthName(month, short = false) {
  const longNames = [
    '1월', '2월', '3월', '4월', '5월', '6월',
    '7월', '8월', '9월', '10월', '11월', '12월'
  ];

  return longNames[month - 1];
}

/**
 * 요일 이름 가져오기
 * @param {number} day - 요일 (0: 일요일 ~ 6: 토요일)
 * @param {boolean} short - 짧은 형식 여부
 * @returns {string} 요일 이름
 */
export function getDayName(day, short = false) {
  const longNames = ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'];
  const shortNames = ['일', '월', '화', '수', '목', '금', '토'];

  return short ? shortNames[day] : longNames[day];
}

/**
 * 날짜 배열 생성
 * @param {Date} startDate - 시작 날짜
 * @param {number} days - 일수
 * @returns {Array<Date>} 날짜 배열
 */
export function generateDateRange(startDate, days) {
  const dates = [];

  for (let i = 0; i < days; i++) {
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);
    dates.push(date);
  }

  return dates;
}

/**
 * 현재 년도의 시작/끝 날짜
 * @param {number} year - 연도 (기본값: 현재 년도)
 * @returns {Object} {start: Date, end: Date}
 */
export function getYearRange(year = new Date().getFullYear()) {
  return {
    start: new Date(year, 0, 1),
    end: new Date(year, 11, 31)
  };
}

/**
 * 현재 월의 시작/끝 날짜
 * @param {number} year - 연도
 * @param {number} month - 월 (1-12)
 * @returns {Object} {start: Date, end: Date}
 */
export function getMonthRange(year, month) {
  return {
    start: new Date(year, month - 1, 1),
    end: new Date(year, month, 0)
  };
}

/**
 * 오늘부터 N일 후 날짜
 * @param {number} days - 일수
 * @returns {Date} 날짜
 */
export function addDays(days) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date;
}

/**
 * 유효한 날짜인지 확인
 * @param {number} year - 연도
 * @param {number} month - 월 (1-12)
 * @param {number} day - 일
 * @returns {boolean} 유효성 여부
 */
export function isValidDate(year, month, day) {
  if (month < 1 || month > 12) return false;

  const daysInMonth = getDaysInMonth(year, month);
  return day >= 1 && day <= daysInMonth;
}

/**
 * 생년월일 객체를 Date로 변환
 * @param {Object} birthInfo - {year, month, day, hour, minute}
 * @returns {Date} Date 객체
 */
export function birthInfoToDate(birthInfo) {
  return new Date(
    birthInfo.year,
    birthInfo.month - 1,
    birthInfo.day,
    birthInfo.hour || 0,
    birthInfo.minute || 0
  );
}

export default {
  formatDate,
  formatKoreanDate,
  formatKoreanTime,
  parseDate,
  daysBetween,
  isToday,
  isYesterday,
  isTomorrow,
  getRelativeDate,
  calculateAge,
  isLeapYear,
  getDaysInMonth,
  getMonthName,
  getDayName,
  generateDateRange,
  getYearRange,
  getMonthRange,
  addDays,
  isValidDate,
  birthInfoToDate
};
