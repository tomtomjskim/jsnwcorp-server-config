/**
 * 운세 공유 유틸리티
 * 운세 결과를 텍스트로 변환하고 클립보드에 복사
 */

/**
 * 등급을 한글 텍스트로 변환
 * @param {string} grade - 등급 (excellent/good/normal/caution/bad)
 * @returns {string} 한글 등급
 */
function gradeToText(grade) {
  const gradeMap = {
    excellent: '매우 좋음',
    good: '좋음',
    normal: '보통',
    caution: '주의',
    bad: '나쁨'
  };
  return gradeMap[grade] || '보통';
}

/**
 * 등급별 이모지
 * @param {string} grade - 등급
 * @returns {string} 이모지
 */
function gradeToEmoji(grade) {
  const emojiMap = {
    excellent: '🌟',
    good: '😊',
    normal: '😐',
    caution: '😟',
    bad: '😔'
  };
  return emojiMap[grade] || '😐';
}

/**
 * 일일 운세 공유 텍스트 생성
 * @param {Object} fortune - 운세 결과 객체
 * @param {string} name - 사용자 이름 (선택)
 * @returns {string} 공유용 텍스트
 */
export function generateDailyShareText(fortune, name = '') {
  const date = fortune.date || new Date().toISOString().split('T')[0];
  const dayOfWeek = fortune.dayOfWeek || '';
  const nameStr = name ? `${name}님의 ` : '';

  let text = `${gradeToEmoji(fortune.total.grade)} ${nameStr}오늘의 운세 (${date} ${dayOfWeek})\n`;
  text += `━━━━━━━━━━━━━━━━━━\n\n`;

  // 총운
  text += `📊 총운: ${fortune.total.score}점 (${gradeToText(fortune.total.grade)})\n`;
  text += `${fortune.total.message}\n\n`;

  // 카테고리별 운세
  text += `💕 애정운: ${fortune.love.score}점 (${gradeToText(fortune.love.grade)})\n`;
  text += `💰 금전운: ${fortune.money.score}점 (${gradeToText(fortune.money.grade)})\n`;
  text += `💪 건강운: ${fortune.health.score}점 (${gradeToText(fortune.health.grade)})\n`;

  if (fortune.career) {
    text += `💼 직장운: ${fortune.career.score}점 (${gradeToText(fortune.career.grade)})\n`;
  }

  text += `\n`;

  // 오늘의 조언
  if (fortune.advice) {
    text += `💡 오늘의 조언\n`;
    text += `${fortune.advice}\n\n`;
  }

  // 하이라이트
  if (fortune.highlight) {
    text += `✨ ${fortune.highlight}\n\n`;
  }

  // 행운 정보
  text += `🍀 행운 정보\n`;
  text += `색상: ${fortune.lucky.color} | 숫자: ${fortune.lucky.number} | 방향: ${fortune.lucky.direction}\n`;

  // 타로 카드
  if (fortune.tarot) {
    text += `\n🎴 오늘의 타로: ${fortune.tarot.nameKo} (${fortune.tarot.name})\n`;
    text += `"${fortune.tarot.keyword}" - ${fortune.tarot.advice}\n`;
  }

  text += `\n━━━━━━━━━━━━━━━━━━\n`;
  text += `오늘의 운세에서 확인하세요!`;

  return text;
}

/**
 * 주간 운세 공유 텍스트 생성
 * @param {Array} weeklyTrend - 주간 운세 배열
 * @param {string} name - 사용자 이름 (선택)
 * @returns {string} 공유용 텍스트
 */
export function generateWeeklyShareText(weeklyTrend, name = '') {
  const nameStr = name ? `${name}님의 ` : '';
  const startDate = weeklyTrend[0]?.date || '';
  const endDate = weeklyTrend[weeklyTrend.length - 1]?.date || '';

  let text = `📅 ${nameStr}주간 운세\n`;
  text += `${startDate} ~ ${endDate}\n`;
  text += `━━━━━━━━━━━━━━━━━━\n\n`;

  weeklyTrend.forEach((day) => {
    const emoji = gradeToEmoji(day.grade);
    const bar = '█'.repeat(Math.floor(day.score / 10)) + '░'.repeat(10 - Math.floor(day.score / 10));
    text += `${day.dayOfWeek} ${emoji} ${bar} ${day.score}점\n`;
    if (day.highlight) {
      text += `   └ ${day.highlight}\n`;
    }
  });

  // 평균 점수 계산
  const avgScore = Math.round(weeklyTrend.reduce((sum, d) => sum + d.score, 0) / weeklyTrend.length);
  const bestDay = weeklyTrend.reduce((best, d) => d.score > best.score ? d : best, weeklyTrend[0]);
  const worstDay = weeklyTrend.reduce((worst, d) => d.score < worst.score ? d : worst, weeklyTrend[0]);

  text += `\n📈 주간 분석\n`;
  text += `평균 점수: ${avgScore}점\n`;
  text += `최고의 날: ${bestDay.dayOfWeek}요일 (${bestDay.score}점)\n`;
  text += `주의할 날: ${worstDay.dayOfWeek}요일 (${worstDay.score}점)\n`;

  text += `\n━━━━━━━━━━━━━━━━━━\n`;
  text += `오늘의 운세에서 확인하세요!`;

  return text;
}

/**
 * 궁합 결과 공유 텍스트 생성
 * @param {Object} compatibility - 궁합 결과
 * @param {string} name1 - 첫 번째 사람 이름
 * @param {string} name2 - 두 번째 사람 이름
 * @returns {string} 공유용 텍스트
 */
export function generateCompatibilityShareText(compatibility, name1 = '나', name2 = '상대방') {
  const score = compatibility.score || compatibility;

  let gradeText = '';
  let emoji = '';

  if (score >= 85) {
    gradeText = '천생연분';
    emoji = '💕💕💕';
  } else if (score >= 70) {
    gradeText = '좋은 궁합';
    emoji = '💕💕';
  } else if (score >= 50) {
    gradeText = '무난한 궁합';
    emoji = '💕';
  } else if (score >= 30) {
    gradeText = '노력 필요';
    emoji = '🤝';
  } else {
    gradeText = '조심스러운 관계';
    emoji = '🙏';
  }

  let text = `${emoji} ${name1} ❤️ ${name2} 궁합 결과\n`;
  text += `━━━━━━━━━━━━━━━━━━\n\n`;
  text += `💯 궁합 점수: ${score}점\n`;
  text += `📝 평가: ${gradeText}\n\n`;

  // 점수 바 시각화
  const bar = '❤️'.repeat(Math.floor(score / 20)) + '🤍'.repeat(5 - Math.floor(score / 20));
  text += `${bar}\n\n`;

  if (compatibility.analysis) {
    text += `💡 분석\n${compatibility.analysis}\n\n`;
  }

  text += `━━━━━━━━━━━━━━━━━━\n`;
  text += `오늘의 운세에서 확인하세요!`;

  return text;
}

/**
 * 사주 결과 공유 텍스트 생성
 * @param {Object} saju - 사주 결과
 * @param {string} name - 사용자 이름 (선택)
 * @returns {string} 공유용 텍스트
 */
export function generateSajuShareText(saju, name = '') {
  const nameStr = name ? `${name}님의 ` : '';

  let text = `🔮 ${nameStr}사주팔자\n`;
  text += `━━━━━━━━━━━━━━━━━━\n\n`;

  // 사주 표시
  text += `📜 사주 명식\n`;
  text += `┌───┬───┬───┬───┐\n`;
  text += `│시주│일주│월주│년주│\n`;
  text += `├───┼───┼───┼───┤\n`;

  if (saju.fourPillars) {
    const { year, month, day, hour } = saju.fourPillars;
    text += `│${hour?.천간 || '?'}${hour?.지지 || '?'}│${day?.천간 || '?'}${day?.지지 || '?'}│${month?.천간 || '?'}${month?.지지 || '?'}│${year?.천간 || '?'}${year?.지지 || '?'}│\n`;
  }

  text += `└───┴───┴───┴───┘\n\n`;

  // 일간 (일주천간)
  if (saju.dayMaster) {
    text += `🌟 일간: ${saju.dayMaster.name} (${saju.dayMaster.element})\n`;
    text += `${saju.dayMaster.description || ''}\n\n`;
  }

  // 오행 분석
  if (saju.ohaeng) {
    text += `🌈 오행 분포\n`;
    const elements = ['목', '화', '토', '금', '수'];
    elements.forEach(el => {
      const count = saju.ohaeng[el] || 0;
      text += `${el}: ${'■'.repeat(count)}${'□'.repeat(4-count)} (${count})\n`;
    });
  }

  text += `\n━━━━━━━━━━━━━━━━━━\n`;
  text += `오늘의 운세에서 확인하세요!`;

  return text;
}

/**
 * 클립보드에 텍스트 복사
 * @param {string} text - 복사할 텍스트
 * @returns {Promise<boolean>} 성공 여부
 */
export async function copyToClipboard(text) {
  try {
    // 최신 Clipboard API 사용
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }

    // Fallback: 구형 브라우저 지원
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    textarea.style.top = '-9999px';
    document.body.appendChild(textarea);
    textarea.select();

    const success = document.execCommand('copy');
    document.body.removeChild(textarea);

    return success;
  } catch (error) {
    console.error('Failed to copy to clipboard:', error);
    return false;
  }
}

/**
 * 공유 기능 (클립보드 복사 + 토스트 메시지)
 * @param {string} text - 공유할 텍스트
 * @param {Function} showToast - 토스트 메시지 표시 함수 (선택)
 * @returns {Promise<boolean>} 성공 여부
 */
export async function shareText(text, showToast = null) {
  // Web Share API 지원 확인 (모바일 등)
  if (navigator.share) {
    try {
      await navigator.share({
        title: '오늘의 운세',
        text: text
      });
      return true;
    } catch (error) {
      // 사용자가 공유 취소한 경우
      if (error.name !== 'AbortError') {
        console.error('Share failed:', error);
      }
    }
  }

  // Fallback: 클립보드 복사
  const success = await copyToClipboard(text);

  if (showToast) {
    if (success) {
      showToast('클립보드에 복사되었습니다!', 'success');
    } else {
      showToast('복사에 실패했습니다. 다시 시도해주세요.', 'error');
    }
  }

  return success;
}

export default {
  generateDailyShareText,
  generateWeeklyShareText,
  generateCompatibilityShareText,
  generateSajuShareText,
  copyToClipboard,
  shareText
};
