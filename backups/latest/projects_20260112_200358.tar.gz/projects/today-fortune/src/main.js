/**
 * Main App Entry Point
 * 라우팅 및 앱 초기화
 */

import { getCurrentProfile, getAllProfiles } from './js/utils/storage.js';
import { formatKoreanDate } from './js/utils/date.js';
import { generateDailyFortune, generateWeeklyTrend, getAllZodiacs, calculateCompatibility } from './js/core/fortune-generator.js';
import { calculateSaju, getIljuId, getIljuInterpretation } from './js/core/saju-calculator.js';
import { analyzeOhaeng } from './js/core/ohaeng-analyzer.js';
import { analyzeSipsin, interpretSipsin, getSipsinInterpretation } from './js/core/sipsin-analyzer.js';
import { generateDaeunSequence, getCurrentDaeun, getDaeunInterpretation, calculateSeun, getComprehensiveAnalysis } from './js/core/daeun-calculator.js';
import { getTojeongFortune, getCurrentMonthFortune } from './js/core/tojeong-calculator.js';
import { generateCalendarData } from './js/core/fortune-calendar.js';
import { generateDailyShareText, generateWeeklyShareText, shareText } from './js/utils/share.js';
import { initAnalytics, trackPageView, trackFortuneGenerated, trackTarotDrawn, trackSajuViewed, trackCompatibilityChecked, trackProfileCreated, trackProfileSwitched } from './lib/analytics.js';

// 현재 페이지 상태
let currentPage = 'home';
let currentProfile = null;
let isDarkMode = false;

// 캘린더 상태
let calendarYear = new Date().getFullYear();
let calendarMonth = new Date().getMonth() + 1;

// 토정비결 상태
let tojeongYear = new Date().getFullYear();
let selectedTojeongMonth = null;
let tojeongFortuneCache = null;

// 홈 페이지 운세 캐시 (공유 기능용)
let currentFortuneCache = null;
let currentWeeklyTrendCache = null;

/**
 * Custom Alert 함수
 */
function showAlert(message, type = 'info', title = null) {
  return new Promise((resolve) => {
    const icons = {
      success: '✅',
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️'
    };

    const titles = {
      success: '성공',
      error: '오류',
      warning: '경고',
      info: '알림'
    };

    const overlay = document.createElement('div');
    overlay.className = 'alert-dialog-overlay';
    overlay.innerHTML = `
      <div class="alert-dialog ${type}">
        <div class="alert-dialog-icon">${icons[type] || icons.info}</div>
        <h3 class="alert-dialog-title">${title || titles[type] || titles.info}</h3>
        <p class="alert-dialog-message">${message}</p>
        <div class="alert-dialog-buttons">
          <button class="button button-primary" id="alert-ok">확인</button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    const closeAlert = () => {
      overlay.remove();
      resolve(true);
    };

    document.getElementById('alert-ok').addEventListener('click', closeAlert);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeAlert();
    });
  });
}

function showConfirm(message, title = '확인') {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'alert-dialog-overlay';
    overlay.innerHTML = `
      <div class="alert-dialog warning">
        <div class="alert-dialog-icon">❓</div>
        <h3 class="alert-dialog-title">${title}</h3>
        <p class="alert-dialog-message">${message}</p>
        <div class="alert-dialog-buttons">
          <button class="button button-secondary" id="confirm-cancel">취소</button>
          <button class="button button-primary" id="confirm-ok">확인</button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    const closeWithResult = (result) => {
      overlay.remove();
      resolve(result);
    };

    document.getElementById('confirm-ok').addEventListener('click', () => closeWithResult(true));
    document.getElementById('confirm-cancel').addEventListener('click', () => closeWithResult(false));
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeWithResult(false);
    });
  });
}

/**
 * 다크모드 초기화
 */
function initDarkMode() {
  // LocalStorage에서 다크모드 설정 불러오기
  const savedTheme = localStorage.getItem('theme');

  // 저장된 설정이 있으면 적용, 없으면 시스템 설정 따름
  if (savedTheme === 'dark') {
    isDarkMode = true;
    document.documentElement.classList.add('dark-mode');
  } else if (savedTheme === 'light') {
    isDarkMode = false;
    document.documentElement.classList.remove('dark-mode');
  } else {
    // 시스템 다크모드 설정 확인
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    isDarkMode = prefersDark;
    if (prefersDark) {
      document.documentElement.classList.add('dark-mode');
    }
  }
}

/**
 * 다크모드 토글
 */
function toggleDarkMode() {
  isDarkMode = !isDarkMode;

  if (isDarkMode) {
    document.documentElement.classList.add('dark-mode');
    localStorage.setItem('theme', 'dark');
  } else {
    document.documentElement.classList.remove('dark-mode');
    localStorage.setItem('theme', 'light');
  }

  // 토글 버튼 아이콘 업데이트
  updateDarkModeButton();
}

/**
 * 다크모드 버튼 업데이트
 */
function updateDarkModeButton() {
  const darkModeIcon = document.getElementById('dark-mode-icon');
  const darkModeSwitch = document.getElementById('dark-mode-switch');

  if (darkModeIcon) {
    darkModeIcon.textContent = isDarkMode ? '🌙' : '☀️';
  }

  if (darkModeSwitch) {
    if (isDarkMode) {
      darkModeSwitch.classList.add('active');
    } else {
      darkModeSwitch.classList.remove('active');
    }
  }
}

/**
 * 다크모드 토글 핸들러
 */
function handleDarkModeToggle() {
  toggleDarkMode();
}

/**
 * 앱 초기화
 */
async function initApp() {
  console.log('🔮 오늘의 운세 앱 초기화...');

  // Analytics 초기화
  initAnalytics();

  // 다크모드 초기화
  initDarkMode();

  // 프로필 체크
  currentProfile = getCurrentProfile();

  if (!currentProfile) {
    // 프로필이 없으면 프로필 생성 페이지로
    showPage('profile');
  } else {
    // 프로필이 있으면 홈 화면
    showPage('home');
  }

  // 네비게이션 이벤트 리스너
  setupNavigation();

  // 로딩 화면 제거
  setTimeout(() => {
    document.getElementById('loading')?.remove();
    document.getElementById('bottom-nav').style.display = 'flex';
  }, 500);
}

/**
 * 네비게이션 설정
 */
function setupNavigation() {
  const navItems = document.querySelectorAll('.nav-item:not(.nav-more-btn)');
  const moreBtn = document.getElementById('nav-more-btn');
  const moreMenu = document.getElementById('more-menu');
  const moreMenuClose = document.getElementById('more-menu-close');
  const moreMenuOverlay = document.getElementById('more-menu-overlay');
  const moreMenuItems = document.querySelectorAll('.more-menu-item');

  // 일반 네비게이션 아이템 클릭
  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const page = item.dataset.page;
      showPage(page);

      // 활성 상태 업데이트
      navItems.forEach(nav => nav.classList.remove('active'));
      moreBtn?.classList.remove('active');
      item.classList.add('active');

      // 더보기 메뉴 닫기
      closeMoreMenu();
    });
  });

  // 더보기 버튼 클릭
  moreBtn?.addEventListener('click', () => {
    toggleMoreMenu();
  });

  // 더보기 메뉴 닫기 버튼
  moreMenuClose?.addEventListener('click', () => {
    closeMoreMenu();
  });

  // 오버레이 클릭시 닫기
  moreMenuOverlay?.addEventListener('click', () => {
    closeMoreMenu();
  });

  // 더보기 메뉴 아이템 클릭
  moreMenuItems.forEach(item => {
    item.addEventListener('click', () => {
      const page = item.dataset.page;
      showPage(page);

      // 활성 상태 업데이트
      navItems.forEach(nav => nav.classList.remove('active'));
      moreBtn?.classList.add('active');

      // 더보기 메뉴 닫기
      closeMoreMenu();
    });
  });
}

/**
 * 더보기 메뉴 토글
 */
function toggleMoreMenu() {
  const moreMenu = document.getElementById('more-menu');
  const moreBtn = document.getElementById('nav-more-btn');

  if (moreMenu?.classList.contains('hidden')) {
    moreMenu.classList.remove('hidden');
    moreBtn?.classList.add('active');
  } else {
    closeMoreMenu();
  }
}

/**
 * 더보기 메뉴 닫기
 */
function closeMoreMenu() {
  const moreMenu = document.getElementById('more-menu');
  const moreBtn = document.getElementById('nav-more-btn');

  moreMenu?.classList.add('hidden');
  // 현재 페이지가 더보기 메뉴에 있는 페이지인 경우 active 유지
  if (!['calendar', 'tojeong', 'profile'].includes(currentPage)) {
    moreBtn?.classList.remove('active');
  }
}

/**
 * 페이지 표시
 */
async function showPage(pageName) {
  currentPage = pageName;
  const appContainer = document.getElementById('app');

  // 페이지뷰 추적
  trackPageView(pageName);

  let content = '';

  switch (pageName) {
    case 'home':
      content = await renderHomePage();
      break;
    case 'zodiac':
      content = await renderZodiacPage();
      break;
    case 'saju':
      content = await renderSajuPage();
      break;
    case 'compatibility':
      content = renderCompatibilityPage();
      break;
    case 'profile':
      content = renderProfilePage();
      break;
    case 'calendar':
      content = await renderCalendarPage();
      break;
    case 'tojeong':
      content = await renderTojeongPage();
      break;
    default:
      content = '<div class="container"><h2>페이지를 찾을 수 없습니다</h2></div>';
  }

  appContainer.innerHTML = `<div class="page">${content}</div>`;

  // 페이지별 이벤트 리스너 설정
  setupPageEvents(pageName);
}

/**
 * 홈 페이지 렌더링
 */
async function renderHomePage() {
  if (!currentProfile) {
    return `
      <!-- Header -->
      <div class="header">
        <h1 class="header-title">오늘의 운세</h1>
      </div>

      <div class="container">
        <div class="empty-state">
          <div class="empty-state-icon">🔮</div>
          <h2 class="empty-state-title">프로필을 생성해주세요</h2>
          <p class="empty-state-description">생년월일 정보를 입력하면 운세를 확인할 수 있습니다.</p>
          <button class="button button-primary" onclick="showPage('profile')">프로필 만들기</button>
        </div>
      </div>

      ${renderFooter()}
    `;
  }

  const today = new Date();
  const todayStr = formatKoreanDate(today);

  // 오늘의 운세 생성 (전체 프로필 정보 전달)
  const fortune = await generateDailyFortune({
    name: currentProfile.name,
    year: currentProfile.birthDate.year,
    month: currentProfile.birthDate.month,
    day: currentProfile.birthDate.day,
    hour: currentProfile.birthDate.hour,
    minute: currentProfile.birthDate.minute,
    gender: currentProfile.gender,
    isLunar: currentProfile.birthDate.isLunar
  }, today);

  // 공유 기능용 캐시 저장
  currentFortuneCache = {
    ...fortune,
    date: todayStr,
    dayOfWeek: ['일', '월', '화', '수', '목', '금', '토'][today.getDay()] + '요일'
  };

  // Analytics: 운세 생성 추적
  trackFortuneGenerated('daily', {
    totalScore: fortune.total.score,
    grade: fortune.total.grade,
    hasTarot: !!fortune.tarot
  });

  // 주간 운세 트렌드 생성 (전체 프로필 정보 전달)
  const weeklyTrend = await generateWeeklyTrend({
    name: currentProfile.name,
    year: currentProfile.birthDate.year,
    month: currentProfile.birthDate.month,
    day: currentProfile.birthDate.day,
    hour: currentProfile.birthDate.hour,
    minute: currentProfile.birthDate.minute,
    gender: currentProfile.gender,
    isLunar: currentProfile.birthDate.isLunar
  }, today);

  // 주간 운세 캐시 저장
  currentWeeklyTrendCache = weeklyTrend;

  return `
    <!-- Header -->
    <div class="header">
      <h1 class="header-title">오늘의 운세</h1>
    </div>

    <div class="container">
      <!-- Hero Section -->
      <div class="home-hero">
        <div class="home-date">${todayStr}</div>
        <h1 class="home-greeting">👋 ${currentProfile.name}님의</h1>
        <p class="home-subtitle">오늘의 운세</p>
      </div>

      <!-- Fortune Score Card -->
      <div class="card fortune-card">
        <div class="card-header">
          <h2 class="card-title">총운</h2>
          <span class="badge badge-${fortune.total.grade}">${getGradeText(fortune.total.grade)}</span>
        </div>

        <div class="fortune-score-container">
          <div class="score-circle">${fortune.total.score}</div>
        </div>

        <div class="fortune-message">
          ${fortune.total.message}
        </div>

        <!-- Categories -->
        <div class="fortune-categories">
          <div class="fortune-category">
            <div class="fortune-category-icon">💕</div>
            <div class="fortune-category-content">
              <div class="fortune-category-score">${fortune.love.score}</div>
              <div class="fortune-category-label">애정운</div>
            </div>
          </div>
          <div class="fortune-category">
            <div class="fortune-category-icon">💰</div>
            <div class="fortune-category-content">
              <div class="fortune-category-score">${fortune.money.score}</div>
              <div class="fortune-category-label">금전운</div>
            </div>
          </div>
          <div class="fortune-category">
            <div class="fortune-category-icon">🏥</div>
            <div class="fortune-category-content">
              <div class="fortune-category-score">${fortune.health.score}</div>
              <div class="fortune-category-label">건강운</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Lucky Items -->
      <div class="card">
        <h2 class="card-title mb-4">오늘의 행운 아이템</h2>
        <div class="lucky-items">
          <div class="lucky-item">
            <div class="lucky-item-icon">🎨</div>
            <div class="lucky-item-content">
              <div class="lucky-item-label">행운의 색</div>
              <div style="display: flex; align-items: center; gap: var(--space-2);">
                <div style="width: 24px; height: 24px; border-radius: 50%; background: ${getColorHex(fortune.lucky.color)}; border: 2px solid var(--color-border); box-shadow: 0 2px 4px rgba(0,0,0,0.1);"></div>
                <div class="lucky-item-value">${fortune.lucky.color}</div>
              </div>
            </div>
          </div>
          <div class="lucky-item">
            <div class="lucky-item-icon">🔢</div>
            <div class="lucky-item-content">
              <div class="lucky-item-label">행운의 숫자</div>
              <div class="lucky-item-value">${fortune.lucky.number}</div>
            </div>
          </div>
          <div class="lucky-item">
            <div class="lucky-item-icon">🧭</div>
            <div class="lucky-item-content">
              <div class="lucky-item-label">행운의 방향</div>
              <div class="lucky-item-value">${fortune.lucky.direction}</div>
            </div>
          </div>
          <div class="lucky-item">
            <div class="lucky-item-icon">✨</div>
            <div class="lucky-item-content">
              <div class="lucky-item-label">행운의 물건</div>
              <div class="lucky-item-value">${fortune.lucky.item}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Tarot Card Section -->
      <div class="card tarot-section">
        <div class="card-header mb-4">
          <h2 class="card-title">🔮 오늘의 타로 카드</h2>
        </div>

        <div id="tarot-container">
          ${getTodayTarotCard() ? `
            <!-- 이미 뽑은 타로 카드 -->
            <div class="tarot-card-revealed">
              <div class="tarot-card-front">
                <div class="tarot-card-icon">🔮</div>
                <h3 class="tarot-card-name">${fortune.tarot.nameKo}</h3>
                <p class="tarot-card-name-en">${fortune.tarot.name}</p>
                <p class="tarot-card-keyword">🌟 ${fortune.tarot.keyword}</p>
                <p class="tarot-card-meaning">${fortune.tarot.meaning}</p>
                <div class="tarot-card-advice">💡 ${fortune.tarot.advice}</div>
              </div>
            </div>
          ` : `
            <!-- 타로 카드 뽑기 전 -->
            <div class="tarot-draw-area">
              <div class="tarot-card-back" id="tarot-back">
                <div class="tarot-card-pattern">🌙✨🔮✨🌙</div>
              </div>
              <p class="tarot-instruction">카드를 탭하여 오늘의 타로를 뽑아보세요</p>
            </div>
          `}
        </div>
      </div>

      <!-- Advice -->
      <div class="card mt-4">
        <h2 class="card-title mb-4">오늘의 조언</h2>
        <div class="card-body">
          ${fortune.advice}
        </div>
      </div>

      <!-- Weekly Trend -->
      <div class="card weekly-trend">
        <h2 class="card-title mb-4">주간 운세 흐름</h2>
        <div class="trend-chart">
          ${weeklyTrend.map((day, index) => {
            const height = Math.max(5, (day.score / 100) * 150); // 5-150px
            const isToday = index === 0;
            return `
              <div class="trend-bar">
                <div class="trend-bar-fill" style="height: ${height}px" data-score="${day.score}"></div>
                <div class="trend-day ${isToday ? 'today' : ''}">${day.dayOfWeek}</div>
              </div>
            `;
          }).join('')}
        </div>
        <div class="mt-4 text-center">
          <p class="text-sm color-text-light">
            ${(() => {
              const startDate = new Date(today);
              const endDate = new Date(today);
              endDate.setDate(endDate.getDate() + 6);
              const startMonth = startDate.getMonth() + 1;
              const startDay = startDate.getDate();
              const endMonth = endDate.getMonth() + 1;
              const endDay = endDate.getDate();
              return `${startMonth}월 ${startDay}일 ~ ${endMonth}월 ${endDay}일 (향후 7일)`;
            })()}
          </p>
        </div>
      </div>

      <!-- 공유 버튼 -->
      <div class="card mt-4">
        <div style="display: flex; gap: var(--space-3); justify-content: center;">
          <button class="button button-secondary" id="share-daily-btn" style="flex: 1; max-width: 200px;">
            📤 오늘 운세 공유
          </button>
          <button class="button button-secondary" id="share-weekly-btn" style="flex: 1; max-width: 200px;">
            📅 주간 운세 공유
          </button>
        </div>
      </div>
    </div>

    ${renderFooter()}
  `;
}

/**
 * 사주 페이지 렌더링
 */
async function renderSajuPage() {
  if (!currentProfile) {
    return `
      <!-- Header -->
      <div class="header">
        <h1 class="header-title">사주팔자</h1>
      </div>

      <div class="container">
        <div class="empty-state">
          <div class="empty-state-icon">🔮</div>
          <h2 class="empty-state-title">프로필이 필요합니다</h2>
          <p class="empty-state-description">생년월일 정보를 입력하면 사주를 확인할 수 있습니다.</p>
          <button class="button button-primary" onclick="showPage('profile')">프로필 만들기</button>
        </div>
      </div>

      ${renderFooter()}
    `;
  }

  try {
    // 사주 계산
    const saju = await calculateSaju({
      year: currentProfile.birthDate.year,
      month: currentProfile.birthDate.month,
      day: currentProfile.birthDate.day,
      hour: currentProfile.birthDate.hour || 12,
      isLunar: currentProfile.birthDate.isLunar || false
    });

    // 오행 분석
    const ohaeng = await analyzeOhaeng(saju);

    // 십신 분석
    const sipsinAnalysis = analyzeSipsin(saju);
    const sipsinInterpret = await interpretSipsin(sipsinAnalysis);

    // 일주 해석 가져오기
    const iljuId = getIljuId(saju.day.ganzi);
    const iljuInterpretation = await getIljuInterpretation(iljuId);

    // Analytics: 사주 조회 추적
    trackSajuViewed(saju.day.ganzi);

    return `
      <!-- Header -->
      <div class="header">
        <h1 class="header-title">사주팔자</h1>
      </div>

      <div class="container">
        <!-- Saju Display -->
        <div class="saju-display">
          <div class="saju-title">사주원국</div>
          <div class="saju-pillars">
            <div class="saju-pillar">
              <div class="saju-pillar-label">시</div>
              <div class="saju-pillar-hanja">${saju.hour.gan}</div>
              <div class="saju-pillar-hanja">${saju.hour.ji}</div>
              <div class="saju-pillar-hangul">${saju.hour.ganHangul}${saju.hour.jiHangul}</div>
            </div>
            <div class="saju-pillar">
              <div class="saju-pillar-label">일</div>
              <div class="saju-pillar-hanja">${saju.day.gan}</div>
              <div class="saju-pillar-hanja">${saju.day.ji}</div>
              <div class="saju-pillar-hangul">${saju.day.ganHangul}${saju.day.jiHangul}</div>
            </div>
            <div class="saju-pillar">
              <div class="saju-pillar-label">월</div>
              <div class="saju-pillar-hanja">${saju.month.gan}</div>
              <div class="saju-pillar-hanja">${saju.month.ji}</div>
              <div class="saju-pillar-hangul">${saju.month.ganHangul}${saju.month.jiHangul}</div>
            </div>
            <div class="saju-pillar">
              <div class="saju-pillar-label">년</div>
              <div class="saju-pillar-hanja">${saju.year.gan}</div>
              <div class="saju-pillar-hanja">${saju.year.ji}</div>
              <div class="saju-pillar-hangul">${saju.year.ganHangul}${saju.year.jiHangul}</div>
            </div>
          </div>
        </div>

        <!-- Ohaeng Chart -->
        <div class="ohaeng-chart">
          <h2 class="card-title mb-4">오행 분포</h2>
          <div class="ohaeng-bars">
            ${renderOhaengBars(ohaeng.count)}
          </div>
          <div class="divider"></div>
          <p class="card-body">${ohaeng.interpretations.summary}</p>
        </div>

        <!-- Interpretations -->
        ${ohaeng.interpretations.deficient.length > 0 ? `
          <div class="card mt-4">
            <h2 class="card-title mb-4">부족한 오행</h2>
            ${ohaeng.interpretations.deficient.map(item => `
              <div class="alert alert-warning mb-3">
                <strong>${item.ohaeng}</strong> (${item.count}개) - ${item.summary}
              </div>
            `).join('')}
          </div>
        ` : ''}

        ${ohaeng.interpretations.excessive.length > 0 ? `
          <div class="card mt-4">
            <h2 class="card-title mb-4">과한 오행</h2>
            ${ohaeng.interpretations.excessive.map(item => `
              <div class="alert alert-info mb-3">
                <strong>${item.ohaeng}</strong> (${item.count}개) - ${item.summary}
              </div>
            `).join('')}
          </div>
        ` : ''}

        <!-- 십신 분석 -->
        <div class="card mt-4">
          <h2 class="card-title mb-4">십신 분석</h2>

          <!-- 십신 매핑 -->
          <div class="mb-6">
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-3); margin-bottom: var(--space-4);">
              <div style="text-align: center;">
                <div style="font-size: var(--text-xs); color: var(--color-text-light); margin-bottom: var(--space-1);">년주</div>
                <div class="badge badge-secondary">${sipsinAnalysis.map.year.gan}</div>
              </div>
              <div style="text-align: center;">
                <div style="font-size: var(--text-xs); color: var(--color-text-light); margin-bottom: var(--space-1);">월주</div>
                <div class="badge badge-secondary">${sipsinAnalysis.map.month.gan}</div>
              </div>
              <div style="text-align: center;">
                <div style="font-size: var(--text-xs); color: var(--color-text-light); margin-bottom: var(--space-1);">일주</div>
                <div class="badge badge-primary">${sipsinAnalysis.map.day.gan}</div>
              </div>
              <div style="text-align: center;">
                <div style="font-size: var(--text-xs); color: var(--color-text-light); margin-bottom: var(--space-1);">시주</div>
                <div class="badge badge-secondary">${sipsinAnalysis.map.hour.gan}</div>
              </div>
            </div>
          </div>

          <!-- 십신 개수 -->
          ${Object.keys(sipsinInterpret.count).length > 0 ? `
            <div class="mb-6">
              <h3 class="text-base font-weight-semibold mb-3">십신 분포</h3>
              <div style="display: flex; flex-wrap: wrap; gap: var(--space-2);">
                ${Object.entries(sipsinInterpret.count).map(([sipsin, count]) => `
                  <span class="badge badge-info">${sipsin} × ${count}</span>
                `).join('')}
              </div>
            </div>
          ` : ''}

          <!-- 종합 해석 -->
          ${sipsinInterpret.summary ? `
            <div class="alert alert-info mb-4">
              ${sipsinInterpret.summary}
            </div>
          ` : ''}

          <!-- 주요 십신 해석 -->
          ${sipsinInterpret.main ? `
            <div class="divider"></div>
            <div class="mt-6">
              <h3 class="text-lg font-weight-semibold mb-3">
                ${sipsinInterpret.main.name} (${sipsinInterpret.main.hanja})
              </h3>
              <p class="mb-4 color-text-light">${sipsinInterpret.main.basic_meaning}</p>

              <div class="mb-4">
                <strong>장점:</strong>
                <ul class="mt-2" style="padding-left: 1.5rem; font-size: var(--text-sm);">
                  ${sipsinInterpret.main.personality.positive.slice(0, 4).map(p => `<li>${p}</li>`).join('')}
                </ul>
              </div>

              <div class="mb-4">
                <strong>주의사항:</strong>
                <ul class="mt-2" style="padding-left: 1.5rem; font-size: var(--text-sm);">
                  ${sipsinInterpret.main.personality.negative.slice(0, 4).map(n => `<li>${n}</li>`).join('')}
                </ul>
              </div>

              <div class="mb-4">
                <strong>적합한 직업:</strong>
                <div style="display: flex; flex-wrap: wrap; gap: var(--space-2); margin-top: var(--space-2);">
                  ${sipsinInterpret.main.career.suitable.slice(0, 6).map(job => `
                    <span class="badge badge-secondary">${job}</span>
                  `).join('')}
                </div>
              </div>

              <div class="alert alert-success">
                <strong>조언:</strong> ${sipsinInterpret.main.development.key_lesson}
              </div>
            </div>
          ` : ''}
        </div>

        <!-- 일주 해석 -->
        ${iljuInterpretation ? `
          <div class="card mt-4">
            <h2 class="card-title mb-4">
              ${iljuInterpretation.ilju}일주 (${iljuInterpretation.title})
            </h2>

            <div class="mb-6">
              <h3 class="text-lg font-weight-semibold mb-3">성격</h3>
              <p class="mb-4">${iljuInterpretation.personality.summary}</p>

              <div class="mb-3">
                <strong>장점:</strong>
                <ul class="mt-2" style="padding-left: 1.5rem;">
                  ${iljuInterpretation.personality.strengths.map(s => `<li>${s}</li>`).join('')}
                </ul>
              </div>

              <div>
                <strong>단점:</strong>
                <ul class="mt-2" style="padding-left: 1.5rem;">
                  ${iljuInterpretation.personality.weaknesses.map(w => `<li>${w}</li>`).join('')}
                </ul>
              </div>
            </div>

            <div class="divider"></div>

            <div class="mb-6 mt-6">
              <h3 class="text-lg font-weight-semibold mb-3">직업운</h3>
              <p class="mb-3">${iljuInterpretation.career.summary}</p>
              <div class="mb-2"><strong>적합한 직업:</strong></div>
              <div style="display: flex; flex-wrap: wrap; gap: var(--space-2);">
                ${iljuInterpretation.career.suitable_jobs.map(job => `
                  <span class="badge badge-secondary">${job}</span>
                `).join('')}
              </div>
            </div>

            <div class="divider"></div>

            <div class="mb-6 mt-6">
              <h3 class="text-lg font-weight-semibold mb-3">재물운</h3>
              <div class="mb-2">
                <span class="badge badge-${iljuInterpretation.wealth.tendency === '강함' ? 'excellent' : 'good'}">
                  ${iljuInterpretation.wealth.tendency}
                </span>
              </div>
              <p>${iljuInterpretation.wealth.description}</p>
            </div>

            <div class="divider"></div>

            <div class="mt-6">
              <h3 class="text-lg font-weight-semibold mb-3">애정운</h3>
              <div class="mb-2">
                <span class="badge badge-info">${iljuInterpretation.love.tendency}</span>
              </div>
              <p>${iljuInterpretation.love.description}</p>
            </div>
          </div>
        ` : ''}

        ${await renderDaeunSeunSection(currentProfile, saju)}
      </div>

      ${renderFooter()}
    `;
  } catch (error) {
    console.error('사주 계산 오류:', error);
    return `
      <div class="container">
        <div class="alert alert-error">
          사주 계산 중 오류가 발생했습니다: ${error.message}
        </div>
      </div>
    `;
  }
}

/**
 * 대운/세운 타임라인 섹션 렌더링
 */
async function renderDaeunSeunSection(profile, saju) {
  try {
    const birthInfo = {
      year: profile.birthDate.year,
      month: profile.birthDate.month,
      day: profile.birthDate.day,
      gender: profile.gender
    };

    const currentYear = new Date().getFullYear();
    const koreanAge = currentYear - birthInfo.year + 1;

    // 대운 시퀀스 생성
    const daeunSequence = generateDaeunSequence(birthInfo, {
      fourPillars: {
        year: { 천간: saju.year.ganHangul },
        month: { 천간: saju.month.ganHangul, 지지: saju.month.jiHangul },
        day: { 천간: saju.day.ganHangul }
      }
    });

    // 현재 대운 찾기
    const currentDaeun = getCurrentDaeun(birthInfo, daeunSequence);

    // 대운 해석
    const daeunInterpretation = currentDaeun ? await getDaeunInterpretation(currentDaeun) : null;

    // 세운 계산
    const seun = await calculateSeun(birthInfo, {
      fourPillars: {
        day: { 천간: saju.day.ganHangul }
      }
    }, currentYear);

    // 내년 세운
    const nextYearSeun = await calculateSeun(birthInfo, {
      fourPillars: {
        day: { 천간: saju.day.ganHangul }
      }
    }, currentYear + 1);

    // 오행 이모지 매핑
    const elementEmoji = {
      '목': '🌳',
      '화': '🔥',
      '토': '🏔️',
      '금': '⚪',
      '수': '💧'
    };

    // 등급 텍스트
    const gradeTextMap = {
      'excellent': '최고',
      'good': '좋음',
      'normal': '보통',
      'caution': '주의',
      'bad': '나쁨'
    };

    return `
      <!-- 대운/세운 타임라인 -->
      <div class="card mt-4">
        <div class="timeline-container">
          <h2 class="timeline-title">🌊 대운 (10년 주기)</h2>
          <p class="timeline-subtitle">
            현재 나이: ${koreanAge}세 |
            ${currentDaeun ? `${currentDaeun.category} 진행 중 (${currentDaeun.yearsRemaining}년 남음)` : '대운 정보 없음'}
          </p>

          <!-- 대운 카드 그리드 -->
          <div class="daeun-grid">
            ${daeunSequence.map((daeun, index) => {
              const isCurrent = currentDaeun && daeun.period === currentDaeun.period;
              const isPast = koreanAge > daeun.endAge;
              const isFuture = koreanAge < daeun.startAge;

              return `
                <div class="daeun-card ${isCurrent ? 'current' : ''} ${isPast ? 'past' : ''} ${isFuture ? 'future' : ''}"
                     style="position: relative;">
                  <div class="daeun-period">${daeun.ageRange}</div>
                  <div class="daeun-pillar">${daeun.pillar.full}</div>
                  <div class="daeun-category">${daeun.category}</div>
                  <div class="daeun-element">
                    ${elementEmoji[daeun.element] || '🔮'} ${daeun.element}
                  </div>
                </div>
              `;
            }).join('')}
          </div>

          <!-- 현재 대운 해석 -->
          ${daeunInterpretation ? `
            <div class="daeun-interpretation">
              <div class="daeun-interpretation-title">${daeunInterpretation.title || currentDaeun.category}</div>
              <div class="daeun-interpretation-subtitle">${currentDaeun.pillar.full} (${currentDaeun.ageRange})</div>

              ${daeunInterpretation.keywords ? `
                <div class="daeun-keywords">
                  ${daeunInterpretation.keywords.map(kw => `<span class="daeun-keyword">${kw}</span>`).join('')}
                </div>
              ` : ''}

              ${daeunInterpretation.description ? `
                <p class="daeun-description">${daeunInterpretation.description}</p>
              ` : ''}

              ${daeunInterpretation.positive ? `
                <div class="daeun-points">
                  <div class="daeun-points-title positive">✅ 긍정적 요소</div>
                  <ul class="daeun-points-list">
                    ${daeunInterpretation.positive.slice(0, 3).map(p => `<li>${p}</li>`).join('')}
                  </ul>
                </div>
              ` : ''}

              ${daeunInterpretation.negative ? `
                <div class="daeun-points">
                  <div class="daeun-points-title negative">⚠️ 주의할 점</div>
                  <ul class="daeun-points-list">
                    ${daeunInterpretation.negative.slice(0, 3).map(n => `<li>${n}</li>`).join('')}
                  </ul>
                </div>
              ` : ''}

              ${daeunInterpretation.advice ? `
                <div class="daeun-advice">
                  💡 <strong>조언:</strong> ${daeunInterpretation.advice}
                </div>
              ` : ''}
            </div>
          ` : ''}

          <!-- 세운 섹션 -->
          <div class="seun-section">
            <h3 class="timeline-title">📅 ${currentYear}년 세운</h3>

            <div class="seun-card">
              <div class="seun-header">
                <div class="seun-year">${currentYear}년</div>
                <div class="seun-pillar">
                  <div class="seun-pillar-label">년주</div>
                  <div class="seun-pillar-value">${seun.pillar.full}</div>
                </div>
              </div>

              <div class="seun-score-container">
                <div class="seun-score-circle">
                  <div class="seun-score-value">${seun.score}</div>
                  <div class="seun-score-label">점</div>
                </div>
              </div>

              <div class="seun-info">
                <div class="seun-info-item">
                  <div class="seun-info-label">운세 유형</div>
                  <div class="seun-info-value">${seun.category}</div>
                </div>
                <div class="seun-info-item">
                  <div class="seun-info-label">십신</div>
                  <div class="seun-info-value">${seun.sipsin}</div>
                </div>
                <div class="seun-info-item">
                  <div class="seun-info-label">오행</div>
                  <div class="seun-info-value">${elementEmoji[seun.element]} ${seun.element}</div>
                </div>
                <div class="seun-info-item">
                  <div class="seun-info-label">등급</div>
                  <div class="seun-info-value">${gradeTextMap[seun.grade] || seun.grade}</div>
                </div>
              </div>

              ${seun.interpretation ? `
                <div class="mt-4 p-4" style="background: var(--color-bg); border-radius: var(--radius-lg);">
                  <p style="font-size: var(--text-sm); color: var(--color-text-light); line-height: var(--leading-relaxed);">
                    ${seun.interpretation.description || ''}
                  </p>
                </div>
              ` : ''}
            </div>

            <!-- 내년 세운 미리보기 -->
            <div class="mt-4 p-4" style="background: var(--color-bg); border-radius: var(--radius-lg); border: 1px dashed var(--color-border);">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                  <div style="font-size: var(--text-sm); color: var(--color-text-light);">내년 (${currentYear + 1}년)</div>
                  <div style="font-weight: var(--font-weight-semibold);">${nextYearSeun.pillar.full} - ${nextYearSeun.category}</div>
                </div>
                <div style="text-align: right;">
                  <div style="font-size: var(--text-2xl); font-weight: var(--font-weight-bold); color: var(--color-primary);">${nextYearSeun.score}점</div>
                  <span class="badge badge-${nextYearSeun.grade}">${gradeTextMap[nextYearSeun.grade]}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  } catch (error) {
    console.error('대운/세운 렌더링 오류:', error);
    return `
      <div class="card mt-4">
        <div class="alert alert-warning">
          대운/세운 정보를 불러오는 중 오류가 발생했습니다.
        </div>
      </div>
    `;
  }
}

/**
 * 캘린더 페이지 렌더링
 */
async function renderCalendarPage() {
  if (!currentProfile) {
    return `
      <!-- Header -->
      <div class="header">
        <h1 class="header-title">운세 캘린더</h1>
      </div>

      <div class="container">
        <div class="empty-state">
          <div class="empty-state-icon">📅</div>
          <h2 class="empty-state-title">프로필이 필요합니다</h2>
          <p class="empty-state-description">생년월일 정보를 입력하면 월별 운세를 확인할 수 있습니다.</p>
          <button class="button button-primary" onclick="showPage('profile')">프로필 만들기</button>
        </div>
      </div>

      ${renderFooter()}
    `;
  }

  try {
    const today = new Date();
    const year = calendarYear;
    const month = calendarMonth;
    const isCurrentMonth = year === today.getFullYear() && month === today.getMonth() + 1;

    const birthInfo = {
      year: currentProfile.birthDate.year,
      month: currentProfile.birthDate.month,
      day: currentProfile.birthDate.day,
      gender: currentProfile.gender
    };

    const calendarData = await generateCalendarData(year, month, birthInfo);

    const gradeColorMap = {
      excellent: '#4CAF50',
      good: '#8BC34A',
      normal: '#FFC107',
      caution: '#FF9800',
      bad: '#F44336'
    };

    const gradeEmojiMap = {
      excellent: '🌟',
      good: '😊',
      normal: '😐',
      caution: '😟',
      bad: '😔'
    };

    return `
      <!-- Header -->
      <div class="header">
        <h1 class="header-title">운세 캘린더</h1>
      </div>

      <div class="container">
        <!-- Calendar Card -->
        <div class="card mb-6">
          <div class="fortune-calendar" id="fortune-calendar">
            <div class="calendar-header">
              <button class="calendar-nav prev" id="calendar-prev">◀</button>
              <h3 class="calendar-title">${year}년 ${month}월</h3>
              <button class="calendar-nav next" id="calendar-next">▶</button>
            </div>

            ${!isCurrentMonth ? `
            <div style="text-align: center; margin-bottom: var(--space-3);">
              <button class="button button-secondary" id="calendar-today" style="font-size: var(--text-sm); padding: var(--space-2) var(--space-4);">
                오늘로 이동
              </button>
            </div>
            ` : ''}

            <div class="calendar-stats">
              <span>평균: ${calendarData.stats.averageScore}점</span>
              <span>최고: ${calendarData.stats.maxScore}점</span>
              <span>최저: ${calendarData.stats.minScore}점</span>
            </div>

            <div class="calendar-weekdays">
              <div class="weekday sunday">일</div>
              <div class="weekday">월</div>
              <div class="weekday">화</div>
              <div class="weekday">수</div>
              <div class="weekday">목</div>
              <div class="weekday">금</div>
              <div class="weekday saturday">토</div>
            </div>

            <div class="calendar-grid">
              ${calendarData.grid.map((cell, index) => {
                const dayOfWeek = index % 7;
                let cellClass = 'calendar-day';

                if (cell.isEmpty) {
                  cellClass += ' empty';
                } else {
                  cellClass += ` grade-${cell.grade}`;
                  if (cell.isToday) cellClass += ' today';
                  if (dayOfWeek === 0) cellClass += ' sunday';
                  if (dayOfWeek === 6) cellClass += ' saturday';
                }

                if (cell.isEmpty) {
                  return `<div class="${cellClass}"></div>`;
                }

                const color = gradeColorMap[cell.grade];
                const emoji = gradeEmojiMap[cell.grade];

                return `
                  <div class="${cellClass}" data-date="${cell.date}" data-score="${cell.score}">
                    <span class="day-number">${cell.day}</span>
                    <span class="day-score" style="color: ${color}">${cell.score}</span>
                    <span class="day-emoji">${emoji}</span>
                  </div>
                `;
              }).join('')}
            </div>

            <div class="calendar-legend">
              <span class="legend-item"><span class="legend-color" style="background: #4CAF50"></span>매우 좋음</span>
              <span class="legend-item"><span class="legend-color" style="background: #8BC34A"></span>좋음</span>
              <span class="legend-item"><span class="legend-color" style="background: #FFC107"></span>보통</span>
              <span class="legend-item"><span class="legend-color" style="background: #FF9800"></span>주의</span>
              <span class="legend-item"><span class="legend-color" style="background: #F44336"></span>나쁨</span>
            </div>
          </div>
        </div>

        <!-- Monthly Summary -->
        <div class="card mb-6">
          <h2 class="card-title mb-4">이달의 운세 요약</h2>

          <div class="fortune-summary" style="background: ${gradeColorMap[calendarData.stats.grade]};">
            <div class="fortune-summary-score">${calendarData.stats.averageScore}점</div>
            <div class="fortune-summary-grade">${getGradeText(calendarData.stats.grade)}</div>
          </div>

          <div class="mt-4">
            <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: var(--space-2); text-align: center;">
              <div>
                <div style="font-size: var(--text-2xl); font-weight: var(--font-weight-bold); color: #4CAF50;">
                  ${calendarData.stats.gradeCounts.excellent}
                </div>
                <div style="font-size: var(--text-xs); color: var(--color-text-light);">최고</div>
              </div>
              <div>
                <div style="font-size: var(--text-2xl); font-weight: var(--font-weight-bold); color: #8BC34A;">
                  ${calendarData.stats.gradeCounts.good}
                </div>
                <div style="font-size: var(--text-xs); color: var(--color-text-light);">좋음</div>
              </div>
              <div>
                <div style="font-size: var(--text-2xl); font-weight: var(--font-weight-bold); color: #FFC107;">
                  ${calendarData.stats.gradeCounts.normal}
                </div>
                <div style="font-size: var(--text-xs); color: var(--color-text-light);">보통</div>
              </div>
              <div>
                <div style="font-size: var(--text-2xl); font-weight: var(--font-weight-bold); color: #FF9800;">
                  ${calendarData.stats.gradeCounts.caution}
                </div>
                <div style="font-size: var(--text-xs); color: var(--color-text-light);">주의</div>
              </div>
              <div>
                <div style="font-size: var(--text-2xl); font-weight: var(--font-weight-bold); color: #F44336;">
                  ${calendarData.stats.gradeCounts.bad}
                </div>
                <div style="font-size: var(--text-xs); color: var(--color-text-light);">나쁨</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Best & Worst Days -->
        <div class="card">
          <h2 class="card-title mb-4">이달의 특별한 날</h2>

          <div style="display: grid; gap: var(--space-4);">
            <div style="padding: var(--space-4); background: rgba(76, 175, 80, 0.1); border-radius: var(--radius-lg); border-left: 4px solid #4CAF50;">
              <div style="font-size: var(--text-sm); color: #4CAF50; margin-bottom: var(--space-1);">🌟 최고의 날</div>
              <div style="font-weight: var(--font-weight-bold);">
                ${calendarData.stats.bestDay?.day}일 (${calendarData.stats.bestDay?.dayOfWeek}) - ${calendarData.stats.maxScore}점
              </div>
            </div>
            <div style="padding: var(--space-4); background: rgba(244, 67, 54, 0.1); border-radius: var(--radius-lg); border-left: 4px solid #F44336;">
              <div style="font-size: var(--text-sm); color: #F44336; margin-bottom: var(--space-1);">⚠️ 주의할 날</div>
              <div style="font-weight: var(--font-weight-bold);">
                ${calendarData.stats.worstDay?.day}일 (${calendarData.stats.worstDay?.dayOfWeek}) - ${calendarData.stats.minScore}점
              </div>
            </div>
          </div>
        </div>
      </div>

      ${renderFooter()}
    `;
  } catch (error) {
    console.error('캘린더 렌더링 오류:', error);
    return `
      <div class="container">
        <div class="alert alert-error">
          캘린더를 불러오는 중 오류가 발생했습니다: ${error.message}
        </div>
      </div>
    `;
  }
}

/**
 * 토정비결 페이지 렌더링
 */
async function renderTojeongPage() {
  if (!currentProfile) {
    return `
      <!-- Header -->
      <div class="header">
        <h1 class="header-title">토정비결</h1>
      </div>

      <div class="container">
        <div class="empty-state">
          <div class="empty-state-icon">📜</div>
          <h2 class="empty-state-title">프로필이 필요합니다</h2>
          <p class="empty-state-description">생년월일 정보를 입력하면 토정비결 운세를 확인할 수 있습니다.</p>
          <button class="button button-primary" onclick="showPage('profile')">프로필 만들기</button>
        </div>
      </div>

      ${renderFooter()}
    `;
  }

  try {
    const thisYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;
    const targetYear = tojeongYear;

    const birthInfo = {
      year: currentProfile.birthDate.year,
      month: currentProfile.birthDate.month,
      day: currentProfile.birthDate.day
    };

    const fortune = await getTojeongFortune(birthInfo, targetYear);
    tojeongFortuneCache = fortune; // 모달에서 사용하기 위해 캐시

    const gradeLabels = {
      excellent: '대길(大吉)',
      good: '길(吉)',
      normal: '평(平)',
      caution: '소흉(小凶)',
      bad: '흉(凶)'
    };

    const gradeColors = {
      excellent: '#4CAF50',
      good: '#8BC34A',
      normal: '#FFC107',
      caution: '#FF9800',
      bad: '#F44336'
    };

    const isCurrentYear = targetYear === thisYear;

    return `
      <!-- Header -->
      <div class="header">
        <h1 class="header-title">토정비결</h1>
      </div>

      <div class="container">
        <!-- Year Selector -->
        <div class="card mb-4" style="padding: var(--space-3);">
          <div class="year-selector">
            <button class="year-nav-btn" id="tojeong-year-prev">◀</button>
            <span class="year-display">${targetYear}년</span>
            <button class="year-nav-btn" id="tojeong-year-next">▶</button>
          </div>
        </div>

        <!-- Tojeong Header Card -->
        <div class="card mb-6" style="text-align: center; background: linear-gradient(135deg, rgba(139, 90, 43, 0.1) 0%, rgba(139, 90, 43, 0.05) 100%); border: 2px solid rgba(139, 90, 43, 0.2);">
          <div style="font-size: var(--text-sm); color: var(--color-text-light); margin-bottom: var(--space-2);">
            ${currentProfile.name}님의 ${targetYear}년 토정비결
          </div>
          <div class="tojeong-gua-number">제 ${fortune.gua.number}괘</div>
          <div class="tojeong-gua-title">${fortune.data.title}</div>
          <div class="tojeong-gua-subtitle">${fortune.data.subtitle || `상괘 ${fortune.gua.upper} · 중괘 ${fortune.gua.middle} · 하괘 ${fortune.gua.lower}`}</div>

          <div style="margin-top: var(--space-4);">
            <span class="badge" style="background: ${gradeColors[fortune.data.grade]}; color: white; padding: var(--space-2) var(--space-4); font-size: var(--text-base);">
              ${fortune.data.gradeInfo.emoji} ${gradeLabels[fortune.data.grade]}
            </span>
          </div>
        </div>

        <!-- Yearly Fortune -->
        <div class="card mb-6">
          <h2 class="card-title mb-4">📖 ${targetYear}년 운세</h2>
          <div class="tojeong-yearly">
            <p class="tojeong-yearly-text">${fortune.data.yearly}</p>
          </div>
        </div>

        <!-- Monthly Fortune Grid -->
        <div class="card mb-6">
          <h2 class="card-title mb-4">📅 월별 운세 <span style="font-size: var(--text-xs); color: var(--color-text-light);">(클릭하여 상세보기)</span></h2>

          <div class="tojeong-monthly-grid">
            ${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(m => {
              const isCurrent = isCurrentYear && m === currentMonth;
              const monthText = fortune.data.monthly?.[m.toString()] || '월별 운세 정보가 없습니다.';

              return `
                <div class="tojeong-month ${isCurrent ? 'current' : ''}" data-month="${m}" title="클릭하여 상세보기">
                  <div class="tojeong-month-number">${m}월</div>
                  <div class="tojeong-month-text">${monthText.substring(0, 8)}...</div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Advice -->
        <div class="card">
          <h2 class="card-title mb-4">💡 ${targetYear}년 조언</h2>
          <div class="alert alert-info">
            ${fortune.data.advice}
          </div>
        </div>

        <!-- Disclaimer -->
        <div style="margin-top: var(--space-6); padding: var(--space-4); background: var(--color-bg); border-radius: var(--radius-lg); text-align: center;">
          <p style="font-size: var(--text-xs); color: var(--color-text-light);">
            토정비결은 조선시대 토정 이지함 선생이 만든 점서로,<br>
            144괘를 통해 한 해의 운세를 풀이합니다.<br>
            본 서비스는 오락 목적으로 제공됩니다.
          </p>
        </div>
      </div>

      <!-- Month Detail Modal -->
      <div class="tojeong-modal-overlay" id="tojeong-month-modal">
        <div class="tojeong-modal">
          <div class="tojeong-modal-header">
            <h3 id="tojeong-modal-month">1월</h3>
            <button class="tojeong-modal-close" id="tojeong-modal-close">✕</button>
          </div>
          <div class="tojeong-modal-body">
            <p id="tojeong-modal-content"></p>
          </div>
        </div>
      </div>

      ${renderFooter()}
    `;
  } catch (error) {
    console.error('토정비결 렌더링 오류:', error);
    return `
      <div class="container">
        <div class="alert alert-error">
          토정비결을 불러오는 중 오류가 발생했습니다: ${error.message}
        </div>
      </div>
    `;
  }
}

/**
 * 궁합 페이지 렌더링
 */
function renderCompatibilityPage() {
  const profiles = getAllProfiles();

  return `
    <!-- Header -->
    <div class="header">
      <h1 class="header-title">궁합 보기</h1>
    </div>

    <div class="container">
      ${currentProfile ? `
        <!-- 궁합 계산 폼 -->
        <div class="card mb-6">
          <h2 class="card-title mb-4">궁합 상대 선택</h2>

          <div class="mb-4">
            <strong>나:</strong> ${currentProfile.name}
            (${currentProfile.birthDate.year}년 ${currentProfile.birthDate.month}월 ${currentProfile.birthDate.day}일)
          </div>

          ${profiles.length > 1 ? `
            <div class="mb-4">
              <label class="input-label">저장된 프로필에서 선택</label>
              <select class="input" id="partner-select">
                <option value="">선택하세요</option>
                ${profiles.filter(p => p.id !== currentProfile.id).map(p => `
                  <option value="${p.id}">
                    ${p.name} (${p.birthDate.year}.${p.birthDate.month}.${p.birthDate.day})
                  </option>
                `).join('')}
              </select>
            </div>
            <div class="text-center mb-4 color-text-light">또는</div>
          ` : ''}

          <div class="input-group">
            <label class="input-label">상대방 정보 직접 입력</label>
            <input type="text" class="input mb-2" id="partner-name" placeholder="이름">
            <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: var(--space-2);">
              <input type="number" class="input" id="partner-year" placeholder="년 (예: 1995)" min="1900" max="2100">
              <input type="number" class="input" id="partner-month" placeholder="월" min="1" max="12">
              <input type="number" class="input" id="partner-day" placeholder="일" min="1" max="31">
            </div>
          </div>

          <button class="button button-primary mt-4" style="width: 100%;" id="calc-compatibility-btn">
            궁합 계산하기
          </button>
        </div>

        <!-- 궁합 결과 (초기에는 숨김) -->
        <div id="compatibility-result" class="hidden">
          <!-- 결과가 여기에 렌더링됨 -->
        </div>
      ` : `
        <div class="empty-state">
          <div class="empty-state-icon">💕</div>
          <h2 class="empty-state-title">프로필이 필요합니다</h2>
          <p class="empty-state-description">생년월일 정보를 입력하면 궁합을 확인할 수 있습니다.</p>
          <button class="button button-primary" onclick="showPage('profile')">프로필 만들기</button>
        </div>
      `}
    </div>

    ${renderFooter()}
  `;
}

/**
 * 띠별 운세 페이지 렌더링
 */
async function renderZodiacPage() {
  const zodiacs = await getAllZodiacs();

  return `
    <!-- Header -->
    <div class="header">
      <h1 class="header-title">띠별 운세</h1>
    </div>

    <div class="container">
      <div class="card mb-6" style="text-align: center;">
        <h2 class="card-title mb-2">12띠 성격 & 운세</h2>
        <p style="font-size: var(--text-sm); color: var(--color-text-light);">
          12가지 띠별 성격과 특징을 확인해보세요
        </p>
      </div>

      <!-- 12띠 목록 -->
      ${zodiacs.map((zodiac, index) => `
        <div class="card mb-4" style="background: linear-gradient(135deg, ${zodiac.luckyColor}15 0%, ${zodiac.luckyColor}05 100%); border: 2px solid ${zodiac.luckyColor}30;">
          <div style="display: flex; align-items: flex-start; gap: var(--space-4);">
            <!-- 띠 아이콘 -->
            <div style="font-size: 4rem; flex-shrink: 0;">${zodiac.emoji}</div>

            <!-- 띠 정보 -->
            <div style="flex: 1;">
              <h2 class="card-title mb-2" style="color: ${zodiac.luckyColor};">${zodiac.key}</h2>

              <!-- 해당 연도 -->
              <div class="mb-3">
                <div style="font-size: var(--text-xs); color: var(--color-text-light); margin-bottom: var(--space-1);">
                  출생연도
                </div>
                <div style="display: flex; flex-wrap: wrap; gap: var(--space-1);">
                  ${zodiac.years.map(y => `
                    <span class="badge badge-secondary" style="font-size: var(--text-xs); background: ${zodiac.luckyColor}20; color: ${zodiac.luckyColor};">
                      ${y}년
                    </span>
                  `).join('')}
                </div>
              </div>

              <!-- 특징 -->
              <div class="mb-3">
                <p style="line-height: var(--leading-relaxed);">${zodiac.characteristics}</p>
              </div>

              ${zodiac.personality ? `
                <div class="mb-3">
                  <p style="font-size: var(--text-sm); color: var(--color-text-light);">${zodiac.personality}</p>
                </div>
              ` : ''}

              <!-- 강점 -->
              ${zodiac.strengths && zodiac.strengths.length > 0 ? `
                <div class="mb-3">
                  <div style="font-size: var(--text-xs); color: var(--color-text-light); margin-bottom: var(--space-2);">
                    주요 강점
                  </div>
                  <div style="display: flex; flex-wrap: wrap; gap: var(--space-2);">
                    ${zodiac.strengths.map(strength => `
                      <span class="badge badge-success" style="font-size: var(--text-xs);">${strength}</span>
                    `).join('')}
                  </div>
                </div>
              ` : ''}

              <!-- 행운 정보 -->
              <div class="divider mb-3"></div>
              <div style="display: flex; gap: var(--space-4); flex-wrap: wrap;">
                <div>
                  <div style="font-size: var(--text-xs); color: var(--color-text-light); margin-bottom: var(--space-1);">
                    행운의 색
                  </div>
                  <div style="display: flex; align-items: center; gap: var(--space-2);">
                    <div style="width: 20px; height: 20px; border-radius: 50%; background: ${zodiac.luckyColor}; border: 2px solid var(--color-border);"></div>
                  </div>
                </div>
                <div>
                  <div style="font-size: var(--text-xs); color: var(--color-text-light); margin-bottom: var(--space-1);">
                    행운의 숫자
                  </div>
                  <div style="font-weight: var(--font-weight-semibold); color: ${zodiac.luckyColor};">
                    ${zodiac.luckyNumber.join(', ')}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      `).join('')}
    </div>

    ${renderFooter()}
  `;
}

/**
 * 프로필 페이지 렌더링
 */
function renderProfilePage() {
  const profiles = getAllProfiles();

  return `
    <!-- Header -->
    <div class="header">
      <h1 class="header-title">내 프로필</h1>
    </div>

    <div class="container">

      ${profiles.length === 0 ? `
        <div class="profile-form">
          <div class="profile-avatar">👤</div>
          <h2 class="text-center mb-6">프로필 생성</h2>

          <div class="input-group">
            <label class="input-label">이름</label>
            <input type="text" class="input" id="profile-name" placeholder="이름을 입력하세요">
          </div>

          <div class="input-group">
            <label class="input-label">생년월일</label>
            <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: var(--space-2);">
              <input type="number" class="input" id="birth-year" placeholder="년 (예: 1995)" min="1900" max="2100">
              <input type="number" class="input" id="birth-month" placeholder="월" min="1" max="12">
              <input type="number" class="input" id="birth-day" placeholder="일" min="1" max="31">
            </div>
          </div>

          <div class="input-group">
            <label class="input-label">태어난 시간</label>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-2);">
              <input type="number" class="input" id="birth-hour" placeholder="시 (0-23)" min="0" max="23">
              <input type="number" class="input" id="birth-minute" placeholder="분 (0-59)" min="0" max="59" value="0">
            </div>
          </div>

          <div class="radio-group">
            <label class="radio-label">
              <input type="radio" name="calendar-type" value="solar" checked>
              양력
            </label>
            <label class="radio-label">
              <input type="radio" name="calendar-type" value="lunar">
              음력
            </label>
          </div>

          <div class="radio-group">
            <label class="radio-label">
              <input type="radio" name="gender" value="male" checked>
              남성
            </label>
            <label class="radio-label">
              <input type="radio" name="gender" value="female">
              여성
            </label>
          </div>

          <button class="button button-primary" style="width: 100%;" id="save-profile-btn">
            저장하기
          </button>
        </div>
      ` : `
        <!-- 현재 프로필 -->
        <div class="card mb-6">
          <h2 class="card-title mb-4">현재 프로필</h2>
          <div class="profile-avatar">${currentProfile?.name?.[0] || '👤'}</div>
          <h3 class="text-center mb-2">${currentProfile?.name}</h3>
          <p class="text-center text-sm color-text-light mb-2">
            ${currentProfile?.birthDate.year}년 ${currentProfile?.birthDate.month}월 ${currentProfile?.birthDate.day}일
          </p>
          <p class="text-center text-xs color-text-light mb-6">
            ${currentProfile?.birthDate.hour}시 ${currentProfile?.birthDate.minute}분 (${currentProfile?.birthDate.isLunar ? '음력' : '양력'})
          </p>
        </div>

        <!-- 프로필 목록 -->
        ${profiles.length > 1 ? `
          <div class="card mb-6">
            <h2 class="card-title mb-4">저장된 프로필 (${profiles.length}개)</h2>
            <div class="profile-list">
              ${profiles.map(profile => `
                <div class="profile-list-item ${profile.id === currentProfile?.id ? 'active' : ''}"
                     style="display: flex; align-items: center; gap: var(--space-3); padding: var(--space-4); border: 2px solid var(--color-border); border-radius: var(--radius-lg); margin-bottom: var(--space-3); cursor: pointer; transition: all var(--transition-base);"
                     data-profile-id="${profile.id}">
                  <div style="display: flex; align-items: center; gap: var(--space-3); flex: 1;">
                    <div style="width: 40px; height: 40px; border-radius: var(--radius-full);
                                background: var(--gradient-main); display: flex;
                                align-items: center; justify-content: center; color: white;">
                      ${profile.name[0]}
                    </div>
                    <div style="flex: 1;">
                      <div style="font-weight: var(--font-weight-semibold);">${profile.name}</div>
                      <div style="font-size: var(--text-xs); opacity: 0.7;">
                        ${profile.birthDate.year}.${profile.birthDate.month}.${profile.birthDate.day}
                      </div>
                    </div>
                  </div>
                  <div style="display: flex; align-items: center; gap: var(--space-2);">
                    ${profile.id === currentProfile?.id ?
                      '<span class="badge badge-primary">선택됨</span>' :
                      '<button class="button button-sm button-ghost profile-select-btn" data-profile-id="' + profile.id + '" onclick="event.stopPropagation();">선택</button>'
                    }
                    <button class="button button-sm button-ghost profile-edit-btn" data-profile-id="${profile.id}" onclick="event.stopPropagation();" title="수정">✏️</button>
                    <button class="button button-sm button-ghost profile-delete-btn" data-profile-id="${profile.id}" onclick="event.stopPropagation();" title="삭제">🗑️</button>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        <!-- 추가 옵션 -->
        <div class="card">
          <h2 class="card-title mb-4">설정</h2>

          <!-- 다크모드 토글 -->
          <div class="dark-mode-toggle-container" id="dark-mode-container">
            <div class="dark-mode-toggle-label">
              <span class="dark-mode-toggle-icon" id="dark-mode-icon">${isDarkMode ? '🌙' : '☀️'}</span>
              <span class="dark-mode-toggle-text">다크 모드</span>
            </div>
            <div class="dark-mode-switch ${isDarkMode ? 'active' : ''}" id="dark-mode-switch">
              <div class="dark-mode-switch-handle"></div>
            </div>
          </div>

          <button class="button button-primary mb-3" style="width: 100%;" id="add-profile-btn">
            ➕ 새 프로필 추가
          </button>
          <button class="button button-secondary" style="width: 100%;" id="clear-data-btn">
            🗑️ 모든 데이터 삭제
          </button>
        </div>
      `}
    </div>

    ${renderFooter()}
  `;
}

/**
 * 오행 바 렌더링
 */
function renderOhaengBars(count) {
  const ohaengList = [
    { key: '목', name: '목', class: 'wood' },
    { key: '화', name: '화', class: 'fire' },
    { key: '토', name: '토', class: 'earth' },
    { key: '금', name: '금', class: 'metal' },
    { key: '수', name: '수', class: 'water' }
  ];

  const max = Math.max(...Object.values(count), 1);

  return ohaengList.map(oh => {
    const cnt = count[oh.key] || 0;
    const percentage = (cnt / max) * 100;

    return `
      <div class="ohaeng-bar-row">
        <div class="ohaeng-label">${oh.name}</div>
        <div class="ohaeng-bar-container">
          <div class="ohaeng-bar ${oh.class}" style="width: ${percentage}%"></div>
        </div>
        <div class="ohaeng-count">${cnt}</div>
      </div>
    `;
  }).join('');
}

/**
 * 등급 텍스트 변환
 */
function getGradeText(grade) {
  const gradeMap = {
    excellent: '최고',
    good: '좋음',
    normal: '보통',
    caution: '주의',
    bad: '나쁨'
  };
  return gradeMap[grade] || '보통';
}

/**
 * 색상 이름 → HEX 코드 변환
 */
function getColorHex(colorName) {
  const colorMap = {
    '빨강': '#FF0000',
    '주황': '#FF8800',
    '노랑': '#FFD700',
    '연두': '#9ACD32',
    '초록': '#00CC00',
    '청록': '#00CED1',
    '파랑': '#0066FF',
    '남색': '#4B0082',
    '보라': '#8B00FF',
    '분홍': '#FFB6C1',
    '흰색': '#FFFFFF',
    '검정': '#000000',
    '회색': '#808080',
    '갈색': '#A0522D',
    '베이지': '#F5F5DC',
    '금색': '#FFD700',
    '은색': '#C0C0C0',
    '청색': '#0000CD',
    '자주': '#8B008B',
    '하늘색': '#87CEEB'
  };
  return colorMap[colorName] || '#6B4FE0'; // 기본 색상
}

/**
 * 푸터 렌더링
 */
function renderFooter() {
  const currentYear = new Date().getFullYear();

  return `
    <footer class="footer">
      <div class="footer-content">
        <div class="footer-logo">🔮</div>
        <h3 class="footer-title">오늘의 운세</h3>
        <p class="footer-description">매일 아침 가볍게 확인하는 나만의 운세 다이어리</p>

        <div class="footer-disclaimer">
          본 서비스의 운세 결과는 오락 목적으로 제공되며, 실제 결과를 보장하지 않습니다.<br>
          <strong>🔒 모든 데이터는 브라우저에만 저장되며, 서버에 전송되지 않습니다.</strong>
        </div>

        <div class="footer-copyright">
          © ${currentYear} 오늘의 운세. Made with ❤️ by Tom
        </div>
      </div>
    </footer>
  `;
}

/**
 * 오늘의 타로 카드 LocalStorage 관리
 */
function getTodayTarotCard() {
  const today = new Date().toISOString().split('T')[0];
  const stored = localStorage.getItem('tarot_draw');

  if (stored) {
    const data = JSON.parse(stored);
    if (data.date === today && data.profileId === currentProfile?.id) {
      return data.card;
    }
  }
  return null;
}

function saveTodayTarotCard(card) {
  const today = new Date().toISOString().split('T')[0];
  const data = {
    date: today,
    profileId: currentProfile?.id,
    card: card
  };
  localStorage.setItem('tarot_draw', JSON.stringify(data));

  // Analytics: 타로 카드 뽑기 추적
  trackTarotDrawn(card);
}

/**
 * 페이지별 이벤트 설정
 */
function setupPageEvents(pageName) {
  if (pageName === 'home') {
    // 타로 카드 뽑기 이벤트
    const tarotBack = document.getElementById('tarot-back');
    if (tarotBack) {
      tarotBack.addEventListener('click', handleDrawTarot);
    }

    // 공유 버튼 이벤트
    const shareDailyBtn = document.getElementById('share-daily-btn');
    if (shareDailyBtn) {
      shareDailyBtn.addEventListener('click', handleShareDaily);
    }

    const shareWeeklyBtn = document.getElementById('share-weekly-btn');
    if (shareWeeklyBtn) {
      shareWeeklyBtn.addEventListener('click', handleShareWeekly);
    }
  } else if (pageName === 'profile') {
    // 프로필 저장 버튼
    const saveBtn = document.getElementById('save-profile-btn');
    if (saveBtn) {
      saveBtn.addEventListener('click', handleSaveProfile);
    }

    // 다크모드 토글 버튼
    const darkModeContainer = document.getElementById('dark-mode-container');
    if (darkModeContainer) {
      darkModeContainer.addEventListener('click', handleDarkModeToggle);
    }

    // 프로필 추가 버튼
    const addBtn = document.getElementById('add-profile-btn');
    if (addBtn) {
      addBtn.addEventListener('click', handleAddProfile);
    }

    // 데이터 초기화 버튼
    const clearBtn = document.getElementById('clear-data-btn');
    if (clearBtn) {
      clearBtn.addEventListener('click', handleClearData);
    }

    // 프로필 선택 버튼
    const selectBtns = document.querySelectorAll('.profile-select-btn');
    selectBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const profileId = btn.dataset.profileId;
        if (profileId) {
          handleSelectProfile(profileId);
        }
      });
    });

    // 프로필 수정 버튼
    const editBtns = document.querySelectorAll('.profile-edit-btn');
    editBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const profileId = btn.dataset.profileId;
        if (profileId) {
          handleEditProfile(profileId);
        }
      });
    });

    // 프로필 삭제 버튼
    const deleteBtns = document.querySelectorAll('.profile-delete-btn');
    deleteBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const profileId = btn.dataset.profileId;
        if (profileId) {
          handleDeleteProfile(profileId);
        }
      });
    });
  } else if (pageName === 'compatibility') {
    // 궁합 계산 버튼
    const calcBtn = document.getElementById('calc-compatibility-btn');
    if (calcBtn) {
      calcBtn.addEventListener('click', handleCalculateCompatibility);
    }

    // 저장된 프로필 선택 시 자동 입력
    const partnerSelect = document.getElementById('partner-select');
    if (partnerSelect) {
      partnerSelect.addEventListener('change', async (e) => {
        const { getProfile } = await import('./js/utils/storage.js');
        const partner = getProfile(e.target.value);
        if (partner) {
          document.getElementById('partner-name').value = partner.name;
          document.getElementById('partner-year').value = partner.birthDate.year;
          document.getElementById('partner-month').value = partner.birthDate.month;
          document.getElementById('partner-day').value = partner.birthDate.day;
        }
      });
    }
  } else if (pageName === 'calendar') {
    // 캘린더 네비게이션
    const prevBtn = document.getElementById('calendar-prev');
    const nextBtn = document.getElementById('calendar-next');

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        calendarMonth--;
        if (calendarMonth < 1) {
          calendarMonth = 12;
          calendarYear--;
        }
        showPage('calendar');
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        calendarMonth++;
        if (calendarMonth > 12) {
          calendarMonth = 1;
          calendarYear++;
        }
        showPage('calendar');
      });
    }

    // 오늘로 이동 버튼
    const todayBtn = document.getElementById('calendar-today');
    if (todayBtn) {
      todayBtn.addEventListener('click', () => {
        const now = new Date();
        calendarYear = now.getFullYear();
        calendarMonth = now.getMonth() + 1;
        showPage('calendar');
      });
    }

    // 날짜 클릭 이벤트
    const dayElements = document.querySelectorAll('.calendar-day:not(.empty)');
    dayElements.forEach(el => {
      el.addEventListener('click', () => {
        const date = el.dataset.date;
        const score = el.dataset.score;
        if (date && score) {
          showDayFortuneModal(date, score);
        }
      });
    });
  } else if (pageName === 'tojeong') {
    // 토정비결 연도 선택
    const yearPrev = document.getElementById('tojeong-year-prev');
    const yearNext = document.getElementById('tojeong-year-next');

    if (yearPrev) {
      yearPrev.addEventListener('click', () => {
        tojeongYear--;
        tojeongFortuneCache = null;
        showPage('tojeong');
      });
    }

    if (yearNext) {
      yearNext.addEventListener('click', () => {
        tojeongYear++;
        tojeongFortuneCache = null;
        showPage('tojeong');
      });
    }

    // 월별 운세 클릭 이벤트
    const monthElements = document.querySelectorAll('.tojeong-month');
    monthElements.forEach(el => {
      el.addEventListener('click', () => {
        const monthNum = parseInt(el.dataset.month);
        if (monthNum) {
          showTojeongMonthModal(monthNum);
        }
      });
    });

    // 모달 닫기 버튼
    const closeModalBtn = document.getElementById('tojeong-modal-close');
    if (closeModalBtn) {
      closeModalBtn.addEventListener('click', closeTojeongModal);
    }

    // 오버레이 클릭으로 닫기
    const modalOverlay = document.getElementById('tojeong-month-modal');
    if (modalOverlay) {
      modalOverlay.addEventListener('click', (e) => {
        if (e.target === modalOverlay) {
          closeTojeongModal();
        }
      });
    }
  }
}

/**
 * 생년월일 유효성 검증
 */
function validateBirthDate(year, month, day) {
  const errors = [];

  // 년도 범위 검증
  if (year < 1900 || year > 2100) {
    errors.push('년도는 1900년부터 2100년 사이여야 합니다.');
  }

  // 월 범위 검증
  if (month < 1 || month > 12) {
    errors.push('월은 1부터 12 사이여야 합니다.');
  }

  // 일 범위 검증
  if (day < 1 || day > 31) {
    errors.push('일은 1부터 31 사이여야 합니다.');
  }

  // 월별 일수 검증
  if (month && day) {
    const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    // 윤년 계산
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (isLeapYear) {
      daysInMonth[1] = 29;
    }

    if (day > daysInMonth[month - 1]) {
      errors.push(`${month}월은 최대 ${daysInMonth[month - 1]}일까지만 있습니다.`);
    }
  }

  return errors;
}

/**
 * 시간 유효성 검증
 */
function validateTime(hour, minute) {
  const errors = [];

  if (hour !== null && hour !== undefined && hour !== '') {
    if (hour < 0 || hour > 23) {
      errors.push('시는 0부터 23 사이여야 합니다.');
    }
  }

  if (minute !== null && minute !== undefined && minute !== '') {
    if (minute < 0 || minute > 59) {
      errors.push('분은 0부터 59 사이여야 합니다.');
    }
  }

  return errors;
}

/**
 * 프로필 저장 핸들러
 */
async function handleSaveProfile() {
  const { addProfile, setCurrentProfile } = await import('./js/utils/storage.js');

  const name = document.getElementById('profile-name').value;
  const year = parseInt(document.getElementById('birth-year').value);
  const month = parseInt(document.getElementById('birth-month').value);
  const day = parseInt(document.getElementById('birth-day').value);
  const hour = parseInt(document.getElementById('birth-hour').value) || 12;
  const minute = parseInt(document.getElementById('birth-minute').value) || 0;
  const isLunar = document.querySelector('input[name="calendar-type"]:checked').value === 'lunar';
  const gender = document.querySelector('input[name="gender"]:checked').value;

  // 필수 항목 검사
  if (!name || !year || !month || !day) {
    await showAlert('모든 필수 항목을 입력해주세요.', 'warning');
    return;
  }

  // 생년월일 유효성 검사
  const dateErrors = validateBirthDate(year, month, day);
  if (dateErrors.length > 0) {
    await showAlert(dateErrors.join('\n'), 'warning', '입력 오류');
    return;
  }

  // 시간 유효성 검사
  const timeErrors = validateTime(hour, minute);
  if (timeErrors.length > 0) {
    await showAlert(timeErrors.join('\n'), 'warning', '입력 오류');
    return;
  }

  const profile = {
    name,
    birthDate: {
      year,
      month,
      day,
      hour,
      minute,
      isLunar
    },
    gender
  };

  const newProfile = addProfile(profile);
  setCurrentProfile(newProfile.id);
  currentProfile = newProfile;

  await showAlert('프로필이 저장되었습니다!', 'success');
  showPage('home');
}

/**
 * 프로필 추가 핸들러
 */
async function handleAddProfile() {
  // 모달 생성
  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal">
      <div class="modal-header">
        <h2 class="modal-title">새 프로필 추가</h2>
        <button class="modal-close" id="close-modal">✕</button>
      </div>

      <div class="modal-body">
        <div class="input-group">
          <label class="input-label">이름</label>
          <input type="text" class="input" id="modal-name" placeholder="이름을 입력하세요">
        </div>

        <div class="input-group">
          <label class="input-label">생년월일</label>
          <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: var(--space-2);">
            <input type="number" class="input" id="modal-year" placeholder="년 (예: 1995)" min="1900" max="2100">
            <input type="number" class="input" id="modal-month" placeholder="월" min="1" max="12">
            <input type="number" class="input" id="modal-day" placeholder="일" min="1" max="31">
          </div>
        </div>

        <div class="input-group">
          <label class="input-label">태어난 시간</label>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-2);">
            <input type="number" class="input" id="modal-hour" placeholder="시 (0-23)" min="0" max="23" value="12">
            <input type="number" class="input" id="modal-minute" placeholder="분 (0-59)" min="0" max="59" value="0">
          </div>
        </div>

        <div class="radio-group">
          <label class="radio-label">
            <input type="radio" name="modal-calendar" value="solar" checked>
            양력
          </label>
          <label class="radio-label">
            <input type="radio" name="modal-calendar" value="lunar">
            음력
          </label>
        </div>

        <div class="radio-group">
          <label class="radio-label">
            <input type="radio" name="modal-gender" value="male" checked>
            남성
          </label>
          <label class="radio-label">
            <input type="radio" name="modal-gender" value="female">
            여성
          </label>
        </div>

        <button class="button button-primary" style="width: 100%;" id="modal-save">
          저장하기
        </button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  // 모달 닫기
  const closeModal = () => {
    modal.remove();
  };

  document.getElementById('close-modal').addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // 저장 버튼
  document.getElementById('modal-save').addEventListener('click', async () => {
    const name = document.getElementById('modal-name').value;
    const year = parseInt(document.getElementById('modal-year').value);
    const month = parseInt(document.getElementById('modal-month').value);
    const day = parseInt(document.getElementById('modal-day').value);
    const hour = parseInt(document.getElementById('modal-hour').value);
    const minute = parseInt(document.getElementById('modal-minute').value);
    const isLunar = document.querySelector('input[name="modal-calendar"]:checked').value === 'lunar';
    const gender = document.querySelector('input[name="modal-gender"]:checked').value;

    // 필수 항목 검사
    if (!name || !year || !month || !day) {
      await showAlert('모든 필수 항목을 입력해주세요.', 'warning');
      return;
    }

    // 생년월일 유효성 검사
    const dateErrors = validateBirthDate(year, month, day);
    if (dateErrors.length > 0) {
      await showAlert(dateErrors.join('\n'), 'warning', '입력 오류');
      return;
    }

    // 시간 유효성 검사
    const timeErrors = validateTime(hour, minute);
    if (timeErrors.length > 0) {
      await showAlert(timeErrors.join('\n'), 'warning', '입력 오류');
      return;
    }

    const { addProfile } = await import('./js/utils/storage.js');

    const profile = {
      name,
      birthDate: {
        year,
        month,
        day,
        hour,
        minute,
        isLunar
      },
      gender
    };

    try {
      const newProfile = addProfile(profile);
      await showAlert(`${name}님의 프로필이 추가되었습니다!`, 'success');
      closeModal();
      showPage('profile');
    } catch (error) {
      await showAlert('프로필 추가에 실패했습니다: ' + error.message, 'error');
    }
  });
}

/**
 * 프로필 선택 핸들러
 */
async function handleSelectProfile(profileId) {
  const { setCurrentProfile, getProfile } = await import('./js/utils/storage.js');

  setCurrentProfile(profileId);
  currentProfile = getProfile(profileId);

  await showAlert(`${currentProfile.name}님의 프로필로 전환되었습니다.`, 'success');
  showPage('home');
}

/**
 * 프로필 수정 핸들러
 */
async function handleEditProfile(profileId) {
  const { getProfile, updateProfile } = await import('./js/utils/storage.js');
  const profile = getProfile(profileId);

  if (!profile) {
    await showAlert('프로필을 찾을 수 없습니다.', 'error');
    return;
  }

  // 수정 모달 생성
  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal">
      <div class="modal-header">
        <h2 class="modal-title">프로필 수정</h2>
        <button class="modal-close" id="close-edit-modal">✕</button>
      </div>

      <div class="modal-body">
        <div class="input-group">
          <label class="input-label">이름</label>
          <input type="text" class="input" id="edit-name" placeholder="이름을 입력하세요" value="${profile.name}">
        </div>

        <div class="input-group">
          <label class="input-label">생년월일</label>
          <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: var(--space-2);">
            <input type="number" class="input" id="edit-year" placeholder="년 (예: 1995)" min="1900" max="2100" value="${profile.birthDate.year}">
            <input type="number" class="input" id="edit-month" placeholder="월" min="1" max="12" value="${profile.birthDate.month}">
            <input type="number" class="input" id="edit-day" placeholder="일" min="1" max="31" value="${profile.birthDate.day}">
          </div>
        </div>

        <div class="input-group">
          <label class="input-label">태어난 시간</label>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-2);">
            <input type="number" class="input" id="edit-hour" placeholder="시 (0-23)" min="0" max="23" value="${profile.birthDate.hour}">
            <input type="number" class="input" id="edit-minute" placeholder="분 (0-59)" min="0" max="59" value="${profile.birthDate.minute}">
          </div>
        </div>

        <div class="radio-group">
          <label class="radio-label">
            <input type="radio" name="edit-calendar" value="solar" ${!profile.birthDate.isLunar ? 'checked' : ''}>
            양력
          </label>
          <label class="radio-label">
            <input type="radio" name="edit-calendar" value="lunar" ${profile.birthDate.isLunar ? 'checked' : ''}>
            음력
          </label>
        </div>

        <div class="radio-group">
          <label class="radio-label">
            <input type="radio" name="edit-gender" value="male" ${profile.gender === 'male' ? 'checked' : ''}>
            남성
          </label>
          <label class="radio-label">
            <input type="radio" name="edit-gender" value="female" ${profile.gender === 'female' ? 'checked' : ''}>
            여성
          </label>
        </div>

        <button class="button button-primary" style="width: 100%;" id="edit-save">
          저장하기
        </button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  // 모달 닫기
  const closeModal = () => {
    modal.remove();
  };

  document.getElementById('close-edit-modal').addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // 저장 버튼
  document.getElementById('edit-save').addEventListener('click', async () => {
    const name = document.getElementById('edit-name').value;
    const year = parseInt(document.getElementById('edit-year').value);
    const month = parseInt(document.getElementById('edit-month').value);
    const day = parseInt(document.getElementById('edit-day').value);
    const hour = parseInt(document.getElementById('edit-hour').value);
    const minute = parseInt(document.getElementById('edit-minute').value);
    const isLunar = document.querySelector('input[name="edit-calendar"]:checked').value === 'lunar';
    const gender = document.querySelector('input[name="edit-gender"]:checked').value;

    // 필수 항목 검사
    if (!name || !year || !month || !day) {
      await showAlert('모든 필수 항목을 입력해주세요.', 'warning');
      return;
    }

    // 생년월일 유효성 검사
    const dateErrors = validateBirthDate(year, month, day);
    if (dateErrors.length > 0) {
      await showAlert(dateErrors.join('\\n'), 'warning', '입력 오류');
      return;
    }

    // 시간 유효성 검사
    const timeErrors = validateTime(hour, minute);
    if (timeErrors.length > 0) {
      await showAlert(timeErrors.join('\\n'), 'warning', '입력 오류');
      return;
    }

    const updates = {
      name,
      birthDate: {
        year,
        month,
        day,
        hour,
        minute,
        isLunar
      },
      gender
    };

    try {
      updateProfile(profileId, updates);

      // 현재 프로필이 수정된 경우 currentProfile 업데이트
      if (currentProfile?.id === profileId) {
        currentProfile = getProfile(profileId);
      }

      await showAlert('프로필이 수정되었습니다!', 'success');
      closeModal();
      showPage('profile');
    } catch (error) {
      await showAlert('프로필 수정에 실패했습니다: ' + error.message, 'error');
    }
  });
}

/**
 * 프로필 삭제 핸들러
 */
async function handleDeleteProfile(profileId) {
  const { getProfile, deleteProfile, getCurrentProfile: getCurrent } = await import('./js/utils/storage.js');
  const profile = getProfile(profileId);

  if (!profile) {
    await showAlert('프로필을 찾을 수 없습니다.', 'error');
    return;
  }

  // 삭제 확인
  const confirmed = await showConfirm(
    `"${profile.name}"님의 프로필을 삭제하시겠습니까?\n이 작업은 되돌릴 수 없습니다.`,
    '프로필 삭제'
  );

  if (!confirmed) {
    return;
  }

  try {
    deleteProfile(profileId);

    // 현재 프로필이 삭제된 경우 업데이트
    currentProfile = getCurrent();

    await showAlert('프로필이 삭제되었습니다.', 'success');

    // 프로필이 없으면 홈으로, 있으면 프로필 페이지 새로고침
    if (!currentProfile) {
      showPage('home');
    } else {
      showPage('profile');
    }
  } catch (error) {
    await showAlert('프로필 삭제에 실패했습니다: ' + error.message, 'error');
  }
}

/**
 * 궁합 계산 핸들러
 */
async function handleCalculateCompatibility() {
  const partnerName = document.getElementById('partner-name').value;
  const partnerYear = parseInt(document.getElementById('partner-year').value);
  const partnerMonth = parseInt(document.getElementById('partner-month').value);
  const partnerDay = parseInt(document.getElementById('partner-day').value);

  // 필수 항목 검사
  if (!partnerName || !partnerYear || !partnerMonth || !partnerDay) {
    await showAlert('상대방 정보를 모두 입력해주세요.', 'warning');
    return;
  }

  // 생년월일 유효성 검사
  const dateErrors = validateBirthDate(partnerYear, partnerMonth, partnerDay);
  if (dateErrors.length > 0) {
    await showAlert(dateErrors.join('\n'), 'warning', '입력 오류');
    return;
  }

  // 궁합 점수 계산
  const score = calculateCompatibility(
    currentProfile.birthDate,
    { year: partnerYear, month: partnerMonth, day: partnerDay }
  );

  // 등급 결정
  let grade, gradeText, gradeColor;
  if (score >= 90) {
    grade = 'excellent';
    gradeText = '천생연분';
    gradeColor = '#FF7B9C';
  } else if (score >= 75) {
    grade = 'good';
    gradeText = '좋은 궁합';
    gradeColor = '#6B4FE0';
  } else if (score >= 60) {
    grade = 'normal';
    gradeText = '평범한 궁합';
    gradeColor = '#FDCB6E';
  } else if (score >= 40) {
    grade = 'caution';
    gradeText = '노력 필요';
    gradeColor = '#FF6B6B';
  } else {
    grade = 'bad';
    gradeText = '어려운 궁합';
    gradeColor = '#A0AEC0';
  }

  // Analytics: 궁합 계산 추적
  trackCompatibilityChecked(score, grade);

  // 결과 메시지 생성
  let message;
  if (score >= 80) {
    message = '두 분은 서로에게 큰 행운을 가져다 주는 관계입니다. 서로를 이해하고 배려하는 마음이 있다면 아름다운 인연을 이어갈 수 있습니다.';
  } else if (score >= 60) {
    message = '두 분은 조화로운 관계를 형성할 수 있습니다. 서로의 차이를 인정하고 존중한다면 좋은 관계를 유지할 수 있습니다.';
  } else if (score >= 40) {
    message = '두 분은 서로 다른 성향을 가지고 있어 노력이 필요합니다. 소통과 이해를 통해 관계를 개선해 나가세요.';
  } else {
    message = '두 분은 성향이 많이 다를 수 있습니다. 하지만 사주는 참고일 뿐, 진심과 노력이 더 중요합니다.';
  }

  // 결과 표시
  const resultDiv = document.getElementById('compatibility-result');
  resultDiv.innerHTML = `
    <div class="card" style="background: linear-gradient(135deg, ${gradeColor}15 0%, ${gradeColor}05 100%); border: 2px solid ${gradeColor}30;">
      <h2 class="card-title mb-4 text-center">궁합 결과</h2>

      <div class="text-center mb-6">
        <div style="font-size: 4rem; margin-bottom: 1rem;">💕</div>
        <h3 style="font-size: var(--text-2xl); font-weight: var(--font-weight-bold); margin-bottom: var(--space-2);">
          ${currentProfile.name} ❤️ ${partnerName}
        </h3>
        <div style="font-size: var(--text-sm); color: var(--color-text-light);">
          ${currentProfile.birthDate.year}.${currentProfile.birthDate.month}.${currentProfile.birthDate.day} &
          ${partnerYear}.${partnerMonth}.${partnerDay}
        </div>
      </div>

      <div class="text-center mb-6">
        <div style="font-size: 5rem; font-weight: var(--font-weight-bold); color: ${gradeColor};">
          ${score}점
        </div>
        <div class="badge badge-${grade}" style="font-size: var(--text-lg); padding: var(--space-3) var(--space-6); background: ${gradeColor}; color: white;">
          ${gradeText}
        </div>
      </div>

      <div class="divider"></div>

      <p class="mt-6" style="line-height: var(--leading-relaxed); text-align: center;">
        ${message}
      </p>

      <div class="mt-6 text-center">
        <p style="font-size: var(--text-xs); color: var(--color-text-light); opacity: 0.7;">
          ※ 궁합은 참고용이며, 실제 관계는 서로의 노력과 이해가 가장 중요합니다.
        </p>
      </div>
    </div>
  `;
  resultDiv.classList.remove('hidden');

  // 결과로 스크롤
  resultDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/**
 * 일일 운세 공유 핸들러
 */
async function handleShareDaily() {
  if (!currentFortuneCache || !currentProfile) {
    await showAlert('공유할 운세 정보가 없습니다.', 'warning');
    return;
  }

  const shareTextContent = generateDailyShareText(currentFortuneCache, currentProfile.name);
  const success = await shareText(shareTextContent, showToast);

  if (success) {
    showToast('운세가 클립보드에 복사되었습니다!', 'success');
  }
}

/**
 * 주간 운세 공유 핸들러
 */
async function handleShareWeekly() {
  if (!currentWeeklyTrendCache || !currentProfile) {
    await showAlert('공유할 운세 정보가 없습니다.', 'warning');
    return;
  }

  const shareTextContent = generateWeeklyShareText(currentWeeklyTrendCache, currentProfile.name);
  const success = await shareText(shareTextContent, showToast);

  if (success) {
    showToast('주간 운세가 클립보드에 복사되었습니다!', 'success');
  }
}

/**
 * 토스트 메시지 표시
 */
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = message;
  toast.style.cssText = `
    position: fixed;
    bottom: 80px;
    left: 50%;
    transform: translateX(-50%);
    padding: 12px 24px;
    background: ${type === 'success' ? '#4CAF50' : type === 'error' ? '#F44336' : '#6B4FE0'};
    color: white;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    z-index: 9999;
    font-size: 14px;
    animation: toastSlideUp 0.3s ease;
  `;

  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'toastSlideDown 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 2000);
}

/**
 * 타로 카드 뽑기 핸들러
 */
async function handleDrawTarot() {
  const tarotBack = document.getElementById('tarot-back');
  if (!tarotBack) return;

  // 이미 뽑았는지 확인
  if (getTodayTarotCard()) return;

  // 뒤집기 애니메이션 시작
  tarotBack.classList.add('flipping');

  // 타로 카드 생성 (운세와 동일한 로직 사용)
  const today = new Date();
  const { generateDailyFortune } = await import('./js/core/fortune-generator.js');

  const fortune = await generateDailyFortune({
    year: currentProfile.birthDate.year,
    month: currentProfile.birthDate.month,
    day: currentProfile.birthDate.day
  }, today);

  if (!fortune.tarot) {
    await showAlert('타로 카드를 불러올 수 없습니다.', 'error');
    tarotBack.classList.remove('flipping');
    return;
  }

  // LocalStorage에 저장
  saveTodayTarotCard(fortune.tarot);

  // 애니메이션 후 카드 표시
  setTimeout(() => {
    const container = document.getElementById('tarot-container');
    container.innerHTML = `
      <div class="tarot-card-revealed animate-flip-in">
        <div class="tarot-card-front">
          <div class="tarot-card-icon">🔮</div>
          <h3 class="tarot-card-name">${fortune.tarot.nameKo}</h3>
          <p class="tarot-card-name-en">${fortune.tarot.name}</p>
          <p class="tarot-card-keyword">🌟 ${fortune.tarot.keyword}</p>
          <p class="tarot-card-meaning">${fortune.tarot.meaning}</p>
          <div class="tarot-card-advice">💡 ${fortune.tarot.advice}</div>
        </div>
      </div>
    `;
  }, 600);
}

/**
 * 데이터 초기화 핸들러
 */
async function handleClearData() {
  const confirmed = await showConfirm('모든 데이터를 삭제하시겠습니까?', '데이터 초기화');

  if (confirmed) {
    const { clearAll } = await import('./js/utils/storage.js');
    clearAll();
    currentProfile = null;
    await showAlert('데이터가 초기화되었습니다.', 'success');
    location.reload();
  }
}

/**
 * 토정비결 월별 운세 모달 표시
 */
function showTojeongMonthModal(monthNum) {
  if (!tojeongFortuneCache || !tojeongFortuneCache.data.monthly) return;

  const monthText = tojeongFortuneCache.data.monthly[monthNum.toString()];
  if (!monthText) return;

  const modal = document.getElementById('tojeong-month-modal');
  const modalMonth = document.getElementById('tojeong-modal-month');
  const modalContent = document.getElementById('tojeong-modal-content');

  if (modal && modalMonth && modalContent) {
    modalMonth.textContent = `${monthNum}월`;
    modalContent.textContent = monthText;
    modal.classList.add('active');
  }
}

/**
 * 토정비결 모달 닫기
 */
function closeTojeongModal() {
  const modal = document.getElementById('tojeong-month-modal');
  if (modal) {
    modal.classList.remove('active');
  }
}

/**
 * 캘린더 날짜 운세 모달 표시
 */
function showDayFortuneModal(date, score) {
  const parts = date.split('-');
  const month = parseInt(parts[1]);
  const day = parseInt(parts[2]);
  const dayOfWeek = ['일', '월', '화', '수', '목', '금', '토'][new Date(date).getDay()];

  const scoreNum = parseInt(score);
  let grade, gradeText, color;

  if (scoreNum >= 85) {
    grade = 'excellent';
    gradeText = '매우 좋음';
    color = '#4CAF50';
  } else if (scoreNum >= 70) {
    grade = 'good';
    gradeText = '좋음';
    color = '#8BC34A';
  } else if (scoreNum >= 40) {
    grade = 'normal';
    gradeText = '보통';
    color = '#FFC107';
  } else if (scoreNum >= 20) {
    grade = 'caution';
    gradeText = '주의';
    color = '#FF9800';
  } else {
    grade = 'bad';
    gradeText = '나쁨';
    color = '#F44336';
  }

  const modal = document.createElement('div');
  modal.className = 'modal-overlay active';
  modal.id = 'day-fortune-modal';
  modal.innerHTML = `
    <div class="modal" style="max-width: 320px;">
      <div class="modal-header">
        <h2 class="modal-title">${month}월 ${day}일 (${dayOfWeek})</h2>
        <button class="modal-close" id="day-modal-close">✕</button>
      </div>
      <div class="modal-body" style="text-align: center; padding: var(--space-6);">
        <div style="font-size: 3rem; font-weight: bold; color: ${color}; margin-bottom: var(--space-2);">
          ${score}점
        </div>
        <div style="font-size: var(--text-lg); color: ${color}; margin-bottom: var(--space-4);">
          ${gradeText}
        </div>
        <p style="font-size: var(--text-sm); color: var(--color-text-light);">
          이 날의 전체적인 운세 점수입니다.<br>
          홈 화면에서 해당 날짜의 상세 운세를 확인하세요.
        </p>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  const closeBtn = document.getElementById('day-modal-close');
  closeBtn.addEventListener('click', () => modal.remove());
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.remove();
  });
}

// Export for global access
window.showPage = showPage;

// 앱 시작
initApp();
