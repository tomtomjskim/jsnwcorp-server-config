# 🔧 오늘의 운세 - 기술 문서

## 목차
1. [아키텍처 개요](#아키텍처-개요)
2. [핵심 알고리즘](#핵심-알고리즘)
3. [데이터 구조](#데이터-구조)
4. [API 레퍼런스](#api-레퍼런스)
5. [파일 구조](#파일-구조)
6. [개발 가이드](#개발-가이드)
7. [배포 가이드](#배포-가이드)
8. [성능 최적화](#성능-최적화)

---

## 아키텍처 개요

### 기술 스택

```
┌─────────────────────────────────────┐
│      Frontend (Vanilla JS)          │
├─────────────────────────────────────┤
│  - ES6 Modules                      │
│  - Async/Await                      │
│  - DOM Manipulation                 │
│  - LocalStorage API                 │
└─────────────────────────────────────┘
          ↓
┌─────────────────────────────────────┐
│      Build Tool (Vite 7.1.10)       │
├─────────────────────────────────────┤
│  - Hot Module Replacement (HMR)     │
│  - ES Module bundling               │
│  - CSS preprocessing                │
│  - Development server               │
└─────────────────────────────────────┘
          ↓
┌─────────────────────────────────────┐
│      Browser Runtime                │
├─────────────────────────────────────┤
│  - LocalStorage (max 5-10MB)        │
│  - CSS Variables                    │
│  - CSS Grid / Flexbox               │
│  - Responsive Design                │
└─────────────────────────────────────┘
```

### 모듈 구조

```
src/
├── main.js                    # 앱 엔트리 포인트 + 라우팅
├── js/
│   ├── core/                  # 핵심 로직
│   │   ├── fortune-generator.js   # 운세 생성 엔진
│   │   ├── saju-calculator.js     # 사주 계산 엔진
│   │   ├── ohaeng-analyzer.js     # 오행 분석
│   │   └── sipsin-analyzer.js     # 십신 분석
│   └── utils/                 # 유틸리티
│       ├── storage.js             # LocalStorage CRUD
│       └── date.js                # 날짜 포맷팅
└── styles/
    ├── variables.css          # CSS 변수
    ├── components.css         # 재사용 컴포넌트
    └── main.css               # 레이아웃 + 페이지 스타일
```

---

## 핵심 알고리즘

### 1. 시드 기반 운세 생성

#### Seeded Random Generator (LCG)

**Linear Congruential Generator** 알고리즘 사용:

```javascript
function seededRandom(seed) {
  let state = seed;

  return function() {
    // LCG formula: X(n+1) = (a * X(n) + c) mod m
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296; // 0-1 사이 반환
  };
}
```

**파라미터**:
- `a = 1664525` (multiplier)
- `c = 1013904223` (increment)
- `m = 2^32 = 4294967296` (modulus)

**특징**:
- ✅ 재현 가능: 같은 seed → 같은 난수 시퀀스
- ✅ 빠른 속도: O(1) 시간복잡도
- ✅ 균등 분포: 0-1 사이 균등 분포

#### Seed 생성

```javascript
function generateSeed(date, birthInfo) {
  // 1. 날짜 문자열 (YYYYMMDD)
  const dateStr = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`;

  // 2. 생년월일 (YYYYMMDD)
  const birthStr = `${birthInfo.year}${String(birthInfo.month).padStart(2, '0')}${String(birthInfo.day).padStart(2, '0')}`;

  // 3. 시간 (HHMM)
  const hourStr = String(birthInfo.hour || 12).padStart(2, '0');
  const minuteStr = String(birthInfo.minute || 0).padStart(2, '0');

  // 4. 성별 (M/F)
  const genderStr = (birthInfo.gender === 'female' ? 'F' : 'M');

  // 5. 음력/양력 (L/S)
  const lunarStr = (birthInfo.isLunar ? 'L' : 'S');

  // 6. 이름
  const nameStr = birthInfo.name || '';

  // 7. 모든 정보 결합
  const combined = dateStr + birthStr + hourStr + minuteStr + genderStr + lunarStr + nameStr;

  // 8. 문자열 → 숫자 해시 (Java hashCode 방식)
  let seed = 0;
  for (let i = 0; i < combined.length; i++) {
    seed = (seed * 31 + combined.charCodeAt(i)) & 0xffffffff;
  }

  // 9. Unsigned 변환 (음수 방지)
  return seed >>> 0;
}
```

**왜 모든 정보를 포함하는가?**
- 같은 생일이어도 다른 사람은 다른 운세
- 이름, 시간, 성별, 음력/양력까지 모두 고유성 보장

### 2. 정규분포 근사 점수 생성

기존 방식 (문제):
```javascript
// ❌ 0점이 나올 수 있음
const score = Math.floor(random() * 100);
```

개선된 방식 (현재):
```javascript
// ✅ 정규분포 근사, 최소 5점 보장
const baseRandom = random();
const variance = (random() - 0.5) * 2; // -1 ~ +1
const normalScore = 50 + (baseRandom - 0.5) * 50 + variance * 15;
const totalScore = Math.max(5, Math.min(100, Math.round(normalScore)));
```

**효과**:
- 평균 50점 기준 자연스러운 분포
- 극단값(0, 100) 희소
- 최소 5점 보장

### 3. 사주 계산 알고리즘

#### 입춘 기준 년주 계산

```javascript
// 입춘(立春)은 매년 2월 3-5일 사이
// 입춘 이전 출생자는 전년도 간지 사용

const lichun = getLichunDate(year);
if (month < 2 || (month === 2 && day < lichun.day)) {
  // 입춘 이전 → 전년도 간지
  ganziYear = getGanzi(year - 1);
}
```

#### 24절기 기준 월주 계산

```javascript
// 절입시간 (節入時間)을 기준으로 월주 결정
const monthGanzi = getMonthGanzi(year, month, day, hour);
```

#### 60갑자 순환

```javascript
const HEAVENLY_STEMS = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸']; // 10개
const EARTHLY_BRANCHES = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥']; // 12개

// LCM(10, 12) = 60 → 60갑자
function getGanzi(index) {
  const ganIndex = (index - 4) % 10; // 甲子년 기준
  const jiIndex = (index - 4) % 12;

  return {
    gan: HEAVENLY_STEMS[ganIndex],
    ji: EARTHLY_BRANCHES[jiIndex]
  };
}
```

### 4. 오행 분석 알고리즘

#### 오행 개수 계산

```javascript
function countOhaeng(saju) {
  const count = { 목: 0, 화: 0, 토: 0, 금: 0, 수: 0 };

  // 년/월/일/시 각 주의 천간(天干), 지지(地支) 오행 합산
  count[GAN_OHAENG[saju.year.gan]]++;
  count[JI_OHAENG[saju.year.ji]]++;
  // ... 월/일/시 동일

  return count; // { 목: 3, 화: 1, 토: 2, 금: 1, 수: 1 }
}
```

#### 균형 분석

```javascript
function analyzeBalance(count) {
  const total = Object.values(count).reduce((sum, val) => sum + val, 0); // 8
  const average = total / 5; // 1.6

  const balance = {
    deficient: [], // 부족 (< average * 0.6)
    excessive: [],  // 과다 (> average * 1.6)
    balanced: []    // 균형
  };

  Object.entries(count).forEach(([ohaeng, cnt]) => {
    if (cnt === 0) {
      balance.deficient.push({ ohaeng, level: 'none' });
    } else if (cnt < average * 0.6) {
      balance.deficient.push({ ohaeng, level: 'low' });
    } else if (cnt > average * 1.6) {
      balance.excessive.push({ ohaeng, level: 'high' });
    } else {
      balance.balanced.push({ ohaeng, level: 'balanced' });
    }
  });

  return balance;
}
```

### 5. 십신 계산 알고리즘

```javascript
function calculateSipsin(ilgan, target) {
  // 일간(日干) 기준으로 대상 천간의 십신 결정

  const ilganOhaeng = OHAENG_MAP[ilgan]; // 예: '갑' → '목'
  const targetOhaeng = OHAENG_MAP[target]; // 예: '병' → '화'
  const sameYinyang = YINYANG_MAP[ilgan] === YINYANG_MAP[target];

  // 1. 같은 오행 → 비겁
  if (ilganOhaeng === targetOhaeng) {
    return sameYinyang ? '비견' : '겁재';
  }

  // 2. 내가 생하는 오행 → 식상
  if (OHAENG_RELATION['나생'][ilganOhaeng] === targetOhaeng) {
    return sameYinyang ? '식신' : '상관';
  }

  // 3. 내가 극하는 오행 → 재성
  if (OHAENG_RELATION['나극'][ilganOhaeng] === targetOhaeng) {
    return sameYinyang ? '정재' : '편재';
  }

  // 4. 나를 극하는 오행 → 관성
  if (OHAENG_RELATION['극나'][ilganOhaeng] === targetOhaeng) {
    return sameYinyang ? '정관' : '편관';
  }

  // 5. 나를 생하는 오행 → 인성
  if (OHAENG_RELATION['생나'][ilganOhaeng] === targetOhaeng) {
    return sameYinyang ? '정인' : '편인';
  }
}
```

### 6. 궁합 계산 알고리즘

```javascript
function calculateCompatibility(birthInfo1, birthInfo2) {
  // 1. 기본 시드 생성
  const combinedSeed =
    birthInfo1.year * 10000 + birthInfo1.month * 100 + birthInfo1.day +
    birthInfo2.year * 10000 + birthInfo2.month * 100 + birthInfo2.day;

  const random = seededRandom(combinedSeed);

  // 2. 띠 궁합 계산
  const zodiac1 = (birthInfo1.year - 4) % 12;
  const zodiac2 = (birthInfo2.year - 4) % 12;
  const zodiacDiff = Math.abs(zodiac1 - zodiac2);

  let zodiacBonus = 0;
  if (zodiacDiff === 0) zodiacBonus = 15; // 같은 띠
  else if (zodiacDiff === 4 || zodiacDiff === 8) zodiacBonus = 20; // 삼합
  else if (zodiacDiff === 6) zodiacBonus = -10; // 충(沖)

  // 3. 최종 점수
  const baseScore = Math.floor(random() * 70) + 15; // 15-85
  const finalScore = Math.max(0, Math.min(100, baseScore + zodiacBonus));

  return finalScore;
}
```

---

## 데이터 구조

### LocalStorage 구조

```javascript
// Key: 'profiles'
{
  "profiles": [
    {
      "id": "1729413600000",  // Unix timestamp
      "name": "홍길동",
      "birthDate": {
        "year": 1990,
        "month": 5,
        "day": 15,
        "hour": 14,
        "minute": 30,
        "isLunar": false
      },
      "gender": "male",
      "createdAt": "2025-10-20T12:00:00.000Z"
    }
  ],
  "currentProfileId": "1729413600000"
}

// Key: 'theme'
"dark" | "light"

// Key: 'tarot_draw'
{
  "date": "2025-10-20",
  "profileId": "1729413600000",
  "card": {
    "id": 0,
    "name": "The Fool",
    "nameKo": "바보",
    "keyword": "새로운 시작",
    "meaning": "...",
    "advice": "..."
  }
}
```

### JSON 데이터 스키마

#### fortune-daily-templates.json

```json
{
  "fortune_templates": {
    "total": {
      "excellent": ["...", "..."],
      "good": ["...", "..."],
      "normal": ["...", "..."],
      "caution": ["...", "..."],
      "bad": ["...", "..."]
    },
    "love": { /* 동일 구조 */ },
    "money": { /* 동일 구조 */ },
    "health": { /* 동일 구조 */ }
  },
  "advice_messages": {
    "excellent": ["...", "..."],
    "good": ["...", "..."],
    "normal": ["...", "..."],
    "caution": ["...", "..."],
    "bad": ["...", "..."]
  },
  "lucky_items": {
    "color": ["빨강", "주황", "..."],
    "number": [1, 2, 3, "..."],
    "direction": ["동쪽", "서쪽", "..."],
    "item": ["열쇠", "지갑", "..."]
  }
}
```

#### ohaeng-interpretation.json

```json
{
  "ohaeng_analysis": {
    "목": {
      "deficiency": {
        "level_1": {
          "status": "목 기운이 약간 부족합니다",
          "symptoms": ["인간관계가 소극적", "..."],
          "advice": ["나무가 많은 공원 산책", "..."],
          "recommended_activity": ["등산", "정원 가꾸기", "..."],
          "food": ["채소", "과일", "..."],
          "caution": ["과도한 금 기운 조심", "..."]
        },
        "level_2": { /* 더 심각한 부족 */ }
      },
      "excess": {
        "level_1": { /* 과다 */ },
        "level_2": { /* 매우 과다 */ }
      }
    },
    "화": { /* 동일 구조 */ },
    // ... 토, 금, 수
  }
}
```

#### sipsin-interpretation.json

```json
{
  "sipsin": {
    "비견": {
      "name": "비견",
      "hanja": "比肩",
      "basic_meaning": "나와 같은 오행, 같은 음양의 천간",
      "personality": {
        "positive": ["독립적", "자존심 강함", "..."],
        "negative": ["고집", "경쟁심", "..."]
      },
      "career": {
        "suitable": ["자영업", "프리랜서", "..."],
        "unsuitable": ["대기업", "..."]
      },
      "development": {
        "key_lesson": "협력과 타협의 중요성 배우기",
        "advice": ["..."]
      }
    },
    // ... 겁재, 식신, 상관, 정재, 편재, 정관, 편관, 정인, 편인
  }
}
```

#### saju-ilju-part1.json (1-10일주)

```json
{
  "ilju_interpretations": [
    {
      "id": 1,
      "ilju": "갑자",
      "ganzi": "甲子",
      "title": "물 위의 나무",
      "personality": {
        "summary": "창의적이고 독립적인 성향",
        "strengths": ["리더십", "추진력", "창의성"],
        "weaknesses": ["고집", "성급함"]
      },
      "career": {
        "summary": "독창적인 아이디어로 승부하는 직업에 적합",
        "suitable_jobs": ["사업가", "예술가", "기획자"]
      },
      "wealth": {
        "tendency": "강함",
        "description": "수완이 좋아 재물을 모으는 능력이 뛰어남"
      },
      "love": {
        "tendency": "적극적",
        "description": "먼저 다가가는 스타일"
      }
    }
    // ... 10일주까지
  ]
}
```

---

## API 레퍼런스

### fortune-generator.js

#### `generateDailyFortune(birthInfo, targetDate)`

**설명**: 특정 날짜의 일일 운세 생성

**파라미터**:
```typescript
interface BirthInfo {
  name: string;
  year: number;       // 1900-2100
  month: number;      // 1-12
  day: number;        // 1-31
  hour: number;       // 0-23 (optional, default: 12)
  minute: number;     // 0-59 (optional, default: 0)
  gender: 'male' | 'female';
  isLunar: boolean;
}

targetDate: Date  // 대상 날짜
```

**반환값**:
```typescript
interface Fortune {
  date: string;  // "2025-10-20"
  total: {
    score: number;  // 0-100
    grade: 'excellent' | 'good' | 'normal' | 'caution' | 'bad';
    message: string;
  };
  love: { score: number; grade: string; message: string };
  money: { score: number; grade: string; message: string };
  health: { score: number; grade: string; message: string };
  advice: string;
  lucky: {
    color: string;
    number: number;
    direction: string;
    item: string;
  };
  tarot: {
    id: number;
    name: string;
    nameKo: string;
    keyword: string;
    meaning: string;
    advice: string;
  } | null;
}
```

**사용 예시**:
```javascript
import { generateDailyFortune } from './js/core/fortune-generator.js';

const fortune = await generateDailyFortune({
  name: '홍길동',
  year: 1990,
  month: 5,
  day: 15,
  hour: 14,
  minute: 30,
  gender: 'male',
  isLunar: false
}, new Date());

console.log(fortune.total.score); // 82
console.log(fortune.advice); // "오늘은 새로운 도전을 시작하기 좋은 날입니다."
```

---

#### `generateWeeklyTrend(birthInfo, startDate)`

**설명**: 7일간의 운세 트렌드 생성

**반환값**:
```typescript
interface WeeklyTrend {
  date: string;      // "2025-10-20"
  dayOfWeek: string; // "월"
  score: number;     // 0-100
  grade: string;     // 'excellent' | 'good' | ...
}[]
```

---

#### `calculateCompatibility(birthInfo1, birthInfo2)`

**설명**: 두 사람의 궁합 점수 계산

**반환값**: `number` (0-100)

---

### saju-calculator.js

#### `calculateSaju(birthInfo)`

**설명**: 사주팔자 계산

**파라미터**:
```typescript
interface SajuInput {
  year: number;
  month: number;
  day: number;
  hour: number;      // optional, default: 12
  isLunar: boolean;  // optional, default: false
}
```

**반환값**:
```typescript
interface Saju {
  year: {
    gan: string;       // 천간 한자 (예: '甲')
    ji: string;        // 지지 한자 (예: '子')
    ganHangul: string; // 천간 한글 (예: '갑')
    jiHangul: string;  // 지지 한글 (예: '자')
    ganzi: string;     // 간지 (예: '甲子')
  };
  month: { /* 동일 구조 */ };
  day: { /* 동일 구조 */ };
  hour: { /* 동일 구조 */ };
}
```

---

### ohaeng-analyzer.js

#### `analyzeOhaeng(saju)`

**설명**: 오행 분석

**반환값**:
```typescript
interface OhaengAnalysis {
  count: {
    목: number;
    화: number;
    토: number;
    금: number;
    수: number;
  };
  balance: {
    total: number;
    average: number;
    deficient: Array<{ ohaeng: string; level: string; count: number }>;
    excessive: Array<{ ohaeng: string; level: string; count: number }>;
    balanced: Array<{ ohaeng: string; level: string; count: number }>;
  };
  interpretations: {
    deficient: Array<{
      ohaeng: string;
      summary: string;
      symptoms: string[];
      advice: string[];
      recommended_activity: string[];
      food: string[];
      caution: string[];
    }>;
    excessive: Array<{ /* 동일 구조 */ }>;
    summary: string;
  };
  chart: {
    labels: string[];
    data: number[];
    colors: string[];
  };
}
```

---

### sipsin-analyzer.js

#### `analyzeSipsin(saju)`

**설명**: 십신 분석

**반환값**:
```typescript
interface SipsinAnalysis {
  map: {
    year: { gan: string; pillar: string };
    month: { gan: string; pillar: string };
    day: { gan: string; pillar: string };
    hour: { gan: string; pillar: string };
  };
  count: {
    [sipsin: string]: number;
  };
  groupCount: {
    비겁: number;
    식상: number;
    재성: number;
    관성: number;
    인성: number;
  };
  dominant: {
    sipsin: string | null;
    count: number;
  };
  ilgan: string;
}
```

---

### storage.js

#### `getCurrentProfile()`
**설명**: 현재 선택된 프로필 가져오기
**반환값**: `Profile | null`

#### `getAllProfiles()`
**설명**: 모든 프로필 가져오기
**반환값**: `Profile[]`

#### `addProfile(profile)`
**설명**: 새 프로필 추가
**파라미터**: `Profile` (id 제외)
**반환값**: `Profile` (생성된 프로필)

#### `updateProfile(profileId, updates)`
**설명**: 프로필 수정
**파라미터**: `profileId: string`, `updates: Partial<Profile>`

#### `deleteProfile(profileId)`
**설명**: 프로필 삭제
**파라미터**: `profileId: string`

#### `setCurrentProfile(profileId)`
**설명**: 현재 프로필 설정
**파라미터**: `profileId: string`

#### `clearAll()`
**설명**: 모든 데이터 삭제

---

## 파일 구조

```
/home/deploy/projects/today-fortune/
├── public/
│   ├── favicon.svg
│   └── data/
│       ├── calendar.json              # 1.7MB 만세력
│       ├── ganzi.json
│       ├── fortune-daily-templates.json
│       ├── ohaeng-interpretation.json
│       ├── sipsin-interpretation.json
│       ├── saju-ilju-part1.json       # 일주 1-10
│       ├── saju-ilju-part2.json       # 일주 11-20
│       ├── saju-ilju-part3.json       # 일주 21-30
│       ├── saju-ilju-part4.json       # 일주 31-40
│       ├── saju-ilju-part5.json       # 일주 41-50
│       ├── saju-ilju-part6.json       # 일주 51-60
│       ├── compatibility.json
│       └── fortune/
│           ├── daily.json
│           ├── zodiac.json
│           └── tarot.json
├── src/
│   ├── main.js                        # 540+ lines
│   ├── js/
│   │   ├── core/
│   │   │   ├── fortune-generator.js  # 383 lines
│   │   │   ├── saju-calculator.js    # 파일 확인 필요
│   │   │   ├── ohaeng-analyzer.js    # 372 lines
│   │   │   └── sipsin-analyzer.js    # 259 lines
│   │   └── utils/
│   │       ├── storage.js
│   │       └── date.js
│   └── styles/
│       ├── variables.css
│       ├── components.css
│       └── main.css
├── index.html
├── vite.config.js
├── package.json
├── RELEASE_NOTES.md
├── USER_GUIDE.md
├── TECHNICAL_DOCS.md
└── UNIMPLEMENTED_FEATURES.md
```

---

## 개발 가이드

### 개발 환경 설정

```bash
# 1. 저장소 클론 (또는 프로젝트 다운로드)
cd /home/deploy/projects/today-fortune

# 2. 의존성 설치
npm install

# 3. 개발 서버 실행
npm run dev
# → http://localhost:5173

# 4. 프로덕션 빌드
npm run build

# 5. 빌드 미리보기
npm run preview
```

### 코드 스타일

**Naming Convention**:
- 변수/함수: camelCase (예: `generateDailyFortune`)
- 상수: UPPER_SNAKE_CASE (예: `HEAVENLY_STEMS`)
- 클래스: PascalCase (사용하지 않음)

**File Convention**:
- kebab-case (예: `fortune-generator.js`)

**주석**:
- JSDoc 스타일 사용
```javascript
/**
 * 일일 운세 생성
 * @param {Object} birthInfo - 생년월일 정보
 * @param {Date} targetDate - 대상 날짜
 * @returns {Object} 운세 결과
 */
export async function generateDailyFortune(birthInfo, targetDate = new Date()) {
  // ...
}
```

### 새 기능 추가 절차

1. **기획**: `UNIMPLEMENTED_FEATURES.md` 업데이트
2. **데이터**: `public/data/` 에 JSON 파일 추가 (필요 시)
3. **로직**: `src/js/core/` 에 핵심 함수 작성
4. **UI**: `src/main.js` 에 렌더링 함수 추가
5. **스타일**: `src/styles/` 에 CSS 추가
6. **테스트**: 브라우저에서 동작 확인
7. **문서화**: `RELEASE_NOTES.md`, `USER_GUIDE.md` 업데이트

### 디버깅 팁

**콘솔 로그 활용**:
```javascript
console.log('🔮 운세 생성 시작:', birthInfo);
console.log('📊 오행 분석 결과:', ohaengAnalysis);
console.error('❌ 에러 발생:', error);
```

**Vite DevTools**:
- HMR로 즉시 변경사항 반영
- 소스맵으로 디버깅 용이

**브라우저 DevTools**:
- Application 탭 → LocalStorage 확인
- Network 탭 → JSON 파일 로딩 확인

---

## 배포 가이드

### 빌드

```bash
npm run build
```

**출력 디렉토리**: `dist/`

**빌드 결과**:
```
dist/
├── index.html
├── assets/
│   ├── index-xxxxx.js       # Main bundle
│   ├── index-xxxxx.css      # Styles
│   └── ...
├── data/                     # JSON 파일 복사
└── favicon.svg
```

### 배포 플랫폼

#### 1. Vercel

```bash
# vercel.json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite"
}
```

#### 2. Netlify

```bash
# netlify.toml
[build]
  command = "npm run build"
  publish = "dist"
```

#### 3. GitHub Pages

```bash
# vite.config.js
export default {
  base: '/repository-name/'  # GitHub Pages 경로
}
```

### 환경 변수 (옵션)

```bash
# .env
VITE_API_URL=https://api.example.com
```

```javascript
// 코드에서 사용
const apiUrl = import.meta.env.VITE_API_URL;
```

---

## 성능 최적화

### 현재 최적화 사항

✅ **번들 사이즈 최적화**:
- Vite의 Tree Shaking 활용
- 불필요한 의존성 제거
- 현재 크기: ~45KB (gzipped)

✅ **데이터 로딩 최적화**:
- 캐시 활용 (`fortuneTemplateCache`)
- 필요 시에만 데이터 로드 (Lazy Loading)

✅ **렌더링 최적화**:
- Virtual DOM 없음 → 빠른 렌더링
- CSS Transitions 활용 → GPU 가속

✅ **이미지 최적화**:
- SVG 파비콘 사용 (벡터 → 확장성 좋음)

### 향후 최적화 계획

- [ ] **Code Splitting**: 라우트별 번들 분리
- [ ] **Service Worker**: 오프라인 캐시
- [ ] **IndexedDB**: 대용량 데이터 저장
- [ ] **WebP 이미지**: 이미지 추가 시 WebP 사용
- [ ] **Critical CSS**: 초기 로딩 CSS 인라인

### 성능 측정

```bash
# Lighthouse 실행 (Chrome DevTools)
1. F12 → Lighthouse 탭
2. "Generate report" 클릭
3. 점수 확인: Performance, Accessibility, Best Practices, SEO
```

**목표 점수**:
- Performance: 90+
- Accessibility: 90+
- Best Practices: 90+
- SEO: 90+

---

## 보안 고려사항

### XSS 방어

✅ **사용자 입력 검증**:
```javascript
// 이름 입력 시 특수문자 제한
const name = input.value.replace(/<|>|&|"/g, '');
```

✅ **innerHTML 사용 최소화**:
- 템플릿 리터럴 사용
- 필요 시 DOMPurify 사용 검토

### CSRF 방어

✅ **서버 통신 없음**: CSRF 위험 없음 (LocalStorage만 사용)

### 개인정보 보호

✅ **로컬 저장만**: 서버 전송 없음
✅ **HTTPS 사용 권장**: 배포 시 HTTPS 필수
✅ **쿠키 없음**: 추적 쿠키 미사용

---

## 문제 해결 (Troubleshooting)

### 빌드 실패

**에러**: `Cannot find module 'vite'`

**해결**:
```bash
rm -rf node_modules package-lock.json
npm install
```

### HMR 작동 안 함

**해결**:
```bash
# Vite 서버 재시작
npm run dev
```

### LocalStorage 용량 초과

**에러**: `QuotaExceededError`

**해결**:
- 프로필 개수 줄이기
- 브라우저 설정에서 LocalStorage 비우기
- IndexedDB로 마이그레이션 검토

---

## 라이선스

MIT License (또는 프로젝트에 맞는 라이선스 명시)

---

**마지막 업데이트**: 2025-10-20
**작성자**: Tom + Claude Code
**버전**: 1.0.0
