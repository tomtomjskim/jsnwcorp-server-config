const express = require('express');
const session = require('express-session');
const FileStore = require('session-file-store')(session);
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Import middleware and routes
const { optionalAuth, requireAdmin } = require('./middleware/auth');
const authRoutes = require('./routes/auth');
const analyticsRoutes = require('./routes/analytics');
const aiRoutes = require('./routes/ai');

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Session configuration
app.use(session({
  store: new FileStore({
    path: './data/sessions',
    ttl: parseInt(process.env.SESSION_MAX_AGE) / 1000 || 43200, // 12 hours
    retries: 0
  }),
  secret: process.env.SESSION_SECRET || 'dashboard-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: parseInt(process.env.SESSION_MAX_AGE) || 43200000, // 12 hours
    httpOnly: true,
    sameSite: 'strict',
    secure: process.env.NODE_ENV === 'production' && process.env.HTTPS === 'true'
  },
  name: 'dashboard.sid'
}));

// Authentication routes
app.use('/api/auth', authRoutes);

// Analytics routes (PostgreSQL-backed)
app.use('/api/analytics', analyticsRoutes);

// AI Chatbot status routes
app.use('/api/ai', aiRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).send('OK');
});

// AI Chatbot proxy endpoint
app.post('/api/chatbot/ask', async (req, res) => {
  try {
    const { question } = req.body;

    if (!question || question.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Question is required'
      });
    }

    // Forward to AI chatbot service
    const chatbotUrl = process.env.CHATBOT_URL || 'http://172.20.0.14:8000';

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 120000); // 120 seconds timeout

    const response = await fetch(`${chatbotUrl}/api/chatbot/ask`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ question }),
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    const data = await response.json();
    res.json(data);

  } catch (error) {
    console.error('Chatbot API error:', error);

    if (error.name === 'AbortError') {
      return res.status(504).json({
        success: false,
        answer: 'AI 챗봇 응답 시간이 초과되었습니다. 다시 시도해주세요.',
        error: 'Request timeout'
      });
    }

    res.status(500).json({
      success: false,
      answer: 'AI 챗봇 서비스에 연결할 수 없습니다.',
      error: error.message
    });
  }
});

// Get quick questions
app.get('/api/chatbot/quick-questions', async (req, res) => {
  try {
    const chatbotUrl = process.env.CHATBOT_URL || 'http://172.20.0.14:8000';
    const response = await fetch(`${chatbotUrl}/api/chatbot/quick-questions`);
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.json({
      questions: [
        { id: 'projects', text: '현재 운영 중인 프로젝트는?', emoji: '📊' },
        { id: 'health', text: '서비스 헬스 상태는?', emoji: '💚' },
      ]
    });
  }
});

// ==========================================
// Data Models & Database Functions
// ==========================================

// Import database connection
const db = require('./lib/db');

// Developers/Teams (keeping as static for now)
const DEVELOPERS = [
  {
    id: 'tom',
    name: 'Tom',
    avatar: '👨‍💻',
    role: 'Full-stack Developer',
    color: '#667eea'
  }
];

// ✅ NEW: Load projects from PostgreSQL (replaces hardcoded PROJECTS array)
async function getProjects() {
  try {
    const result = await db.query(`
      SELECT
        id,
        name,
        display_name,
        emoji,
        description,
        category,
        status,
        version,
        url,
        port,
        tags,
        developer,
        TO_CHAR(deployed_at, 'YYYY-MM-DD') as deployed_date,
        deployed_at,
        repository,
        health_status,
        avg_response_time_ms
      FROM public.projects
      ORDER BY
        CASE
          WHEN status = 'active' AND id NOT IN ('ai-chatbot', 'dashboard') THEN 0
          WHEN status = 'active' AND id IN ('ai-chatbot', 'dashboard') THEN 1
          WHEN status = 'development' THEN 2
          WHEN status = 'maintenance' THEN 3
          ELSE 4
        END,
        deployed_at DESC NULLS LAST
    `);

    console.log('[DEBUG] First row deployed_date:', result.rows[0]?.deployed_date, typeof result.rows[0]?.deployed_date);
    console.log('[DEBUG] First row deployed_at:', result.rows[0]?.deployed_at, typeof result.rows[0]?.deployed_at);

    const projects = result.rows.map(p => {
      // Use deployed_date (TO_CHAR result) which is always a string
      const deployedAt = p.deployed_date || new Date().toISOString().split('T')[0];

      return {
        id: p.id,
        name: p.display_name || p.name,
        emoji: p.emoji || '📦',
        description: p.description || '',
        url: p.url,
        port: p.port,
        status: p.status,
        category: p.category || 'full-stack',
        tags: p.tags || [],
        developer: p.developer || 'team-a',
        version: p.version || '1.0.0',
        deployedAt: deployedAt,
        repository: p.repository,
        docs: null,  // Not in database schema yet
        healthStatus: p.health_status,
        avgResponseTimeMs: p.avg_response_time_ms
      };
    });

    return projects;
  } catch (error) {
    console.error('[Dashboard] Failed to load projects from DB:', error);
    // Fallback to empty array if DB fails
    return [];
  }
}

// Release Notes
const RELEASE_NOTES = [
  // === 2026년 릴리즈 ===
  {
    id: 21,
    projectId: 'lotto-master',
    version: '0.4.2',
    date: '2026-01-05',
    type: 'patch',
    developer: 'tom',
    title: '동행복권 API 리뉴얼 대응',
    changes: [
      { type: 'fix', description: '동행복권 신규 API 마이그레이션 (2025년 12월 웹사이트 리뉴얼)' },
      { type: 'fix', description: '기존 API 폐기 대응 (/common.do → /lt645/selectPstLt645Info.do)' },
      { type: 'fix', description: '응답 필드명 매핑 변경 (drwtNo → tm1WnNo 등)' },
      { type: 'tech', description: 'User-Agent 헤더 필수 추가' },
      { type: 'tech', description: 'Cron 스크립트 Docker 의존성 제거' }
    ]
  },
  {
    id: 20,
    projectId: 'dashboard',
    version: '2.5.0',
    date: '2026-01-10',
    type: 'minor',
    developer: 'tom',
    title: '블로그 자동화 프로젝트 등록 및 릴리즈 노트 최신화',
    changes: [
      { type: 'feature', description: 'blog-automation 프로젝트 PostgreSQL 등록' },
      { type: 'feature', description: '누락된 릴리즈 노트 전체 추가 (20개+)' },
      { type: 'tech', description: '모든 프로젝트 버전 정보 최신화' }
    ]
  },
  {
    id: 19,
    projectId: 'blog-automation',
    version: '1.0.0',
    date: '2026-01-07',
    type: 'major',
    developer: 'tom',
    title: '블로그 자동화 MVP 릴리즈',
    changes: [
      { type: 'feature', description: 'Multi-LLM 지원 (Claude, GPT, Gemini, Groq)' },
      { type: 'feature', description: 'AI 이미지 생성 (DALL-E 3, Stable Diffusion)' },
      { type: 'feature', description: '네이버 블로그 API 연동 (자동 포스팅)' },
      { type: 'feature', description: 'SEO 분석 (키워드 밀도, 글자 수, 가독성)' },
      { type: 'feature', description: '이미지 업로드 (드래그&드롭, 클립보드, 자동 리사이징)' },
      { type: 'feature', description: 'SSE 스트리밍 실시간 글 생성' },
      { type: 'tech', description: 'Vanilla JS SPA (No Build Required)' },
      { type: 'tech', description: 'AES-GCM 256-bit API 키 암호화' }
    ]
  },
  // === 2025년 12월 릴리즈 ===
  {
    id: 18,
    projectId: 'today-fortune',
    version: '1.1.1',
    date: '2025-12-18',
    type: 'patch',
    developer: 'tom',
    title: '인터랙션 개선 및 공유 기능',
    changes: [
      { type: 'feature', description: '일일/주간 운세 공유 기능 (Web Share API)' },
      { type: 'feature', description: '토정비결 연도 선택기 및 월별 모달' },
      { type: 'feature', description: '운세 캘린더 네비게이션 및 날짜 클릭 인터랙션' },
      { type: 'fix', description: 'ESM 호환성 수정 (require → import)' }
    ]
  },
  {
    id: 17,
    projectId: 'today-fortune',
    version: '1.1.0',
    date: '2025-12-17',
    type: 'minor',
    developer: 'tom',
    title: '고도화 업데이트 - 토정비결, 대운, 캘린더',
    changes: [
      { type: 'feature', description: '토정비결 144괘 시스템 (연간/월별 운세)' },
      { type: 'feature', description: '대운/세운 타임라인 (10년 주기)' },
      { type: 'feature', description: '운세 캘린더 뷰 (일별 점수, 월간 통계)' },
      { type: 'feature', description: '더보기 메뉴 네비게이션 (바텀시트)' },
      { type: 'tech', description: '타로 카드 22장 완성, 운세 템플릿 360개+' }
    ]
  },
  {
    id: 16,
    projectId: 'lotto-master',
    version: '0.4.1',
    date: '2025-12-17',
    type: 'patch',
    developer: 'tom',
    title: '보안 패치 및 버그 수정',
    changes: [
      { type: 'fix', description: 'Next.js 15.5.9 보안 패치 적용' },
      { type: 'fix', description: '최신회차 분석 테이블 데이터 불일치 버그 수정' }
    ]
  },
  // === 2025년 11월 릴리즈 ===
  {
    id: 15,
    projectId: 'lotto-master',
    version: '0.4.0',
    date: '2025-11-03',
    type: 'minor',
    developer: 'tom',
    title: '최신회차 종합 분석 페이지',
    changes: [
      { type: 'feature', description: '최신회차 종합 분석 페이지 (/statistics/latest)' },
      { type: 'feature', description: '10개 분석 섹션 (히어로, 통계, 분포, 빈도, 패턴 등)' },
      { type: 'feature', description: '고급 통계 분석 및 과거 데이터 비교' },
      { type: 'tech', description: 'latestDrawAnalysis.ts 라이브러리 추가' },
      { type: 'tech', description: 'UI 개선 (그라데이션 CTA, 접근성 향상)' }
    ]
  },
  {
    id: 14,
    projectId: 'dashboard',
    version: '2.4.0',
    date: '2025-11-01',
    type: 'minor',
    developer: 'tom',
    title: 'Author Clock 소셜 기능 및 버그 수정',
    changes: [
      { type: 'feature', description: '북마크 기능 (저장/제거, 통계, 페이지네이션)' },
      { type: 'feature', description: '좋아요한 명언 패널 신규 추가' },
      { type: 'fix', description: 'crypto.randomUUID() 브라우저 호환성 문제 해결' },
      { type: 'fix', description: 'views_count 컬럼 참조 오류 수정' },
      { type: 'fix', description: 'API 라우트 매칭 순서 문제 해결' },
      { type: 'tech', description: 'user_bookmarks, user_likes 테이블 추가' }
    ]
  },
  // === 2025년 10월 릴리즈 ===
  {
    id: 13,
    projectId: 'author-clock',
    version: '2.0.2',
    date: '2025-10-31',
    type: 'patch',
    developer: 'tom',
    title: 'Quote 표시 버그 수정',
    changes: [
      { type: 'fix', description: '명언 변경 주기 설정 시 즉시 표시되지 않는 버그 수정' },
      { type: 'fix', description: '설정 변경 즉시 적용 (페이지 새로고침 불필요)' },
      { type: 'tech', description: 'useEffect 훅 통합으로 리렌더링 최적화' }
    ]
  },
  {
    id: 12,
    projectId: 'author-clock',
    version: '2.0.1',
    date: '2025-10-31',
    type: 'patch',
    developer: 'tom',
    title: 'Settings 패널 버그 수정',
    changes: [
      { type: 'fix', description: '설정 패널 클릭 시 전체화면 전환 버그 수정' },
      { type: 'fix', description: '무한 리렌더링 루프 방지' },
      { type: 'tech', description: 'ARIA 속성 추가 (접근성 향상)' }
    ]
  },
  {
    id: 11,
    projectId: 'author-clock',
    version: '2.0.0',
    date: '2025-10-31',
    type: 'major',
    developer: 'tom',
    title: 'Author Clock 메이저 UX 개선 및 커스터마이징 강화',
    changes: [
      { type: 'feature', description: '텍스트 드래그 방지 기능' },
      { type: 'feature', description: '더블클릭/더블탭 전체화면 토글' },
      { type: 'feature', description: '자동 숨김 바텀 컨트롤 (3초 idle)' },
      { type: 'feature', description: '날짜 표시 커스터마이징 (6가지 포맷)' },
      { type: 'feature', description: '날짜 위치 설정 (4가지 위치)' },
      { type: 'tech', description: 'useDoubleClick, useIdleDetection 커스텀 훅' }
    ]
  },
  {
    id: 10,
    projectId: 'author-clock',
    version: '1.1.0',
    date: '2025-10-31',
    type: 'minor',
    developer: 'tom',
    title: 'Author Clock 사용자 설정 기능 추가',
    changes: [
      { type: 'feature', description: '시간 표기법 설정 (24시간/12시간 AM-PM)' },
      { type: 'feature', description: '명언 변경 주기 설정 (1분~24시간)' },
      { type: 'feature', description: '설정 패널 UI (슬라이드 방식)' },
      { type: 'tech', description: 'useSettings custom hook, localStorage 저장' }
    ]
  },
  {
    id: 9,
    projectId: 'author-clock',
    version: '1.0.0',
    date: '2025-10-31',
    type: 'major',
    developer: 'tom',
    title: 'Author Clock 초기 릴리즈',
    changes: [
      { type: 'feature', description: '실시간 시계 표시 (초 단위)' },
      { type: 'feature', description: '일일 명언 로테이션 시스템' },
      { type: 'feature', description: '한국어/영어 언어 지원' },
      { type: 'feature', description: '라이트/다크 테마 토글' },
      { type: 'feature', description: '전체화면 모드' },
      { type: 'tech', description: 'Vite + React + TypeScript' },
      { type: 'tech', description: 'PostgreSQL + Redis, Docker 배포' }
    ]
  },
  {
    id: 8,
    projectId: 'dashboard',
    version: '2.3.0',
    date: '2025-10-30',
    type: 'minor',
    developer: 'tom',
    title: 'PostgreSQL 기반 동적 프로젝트 관리 시스템',
    changes: [
      { type: 'feature', description: 'PostgreSQL 기반 동적 프로젝트 등록' },
      { type: 'feature', description: 'SQL INSERT만으로 프로젝트 추가' },
      { type: 'feature', description: 'Configuration over Code 아키텍처' },
      { type: 'tech', description: 'Database Connection Pool (pg library)' }
    ]
  },
  {
    id: 7,
    projectId: 'lotto-master',
    version: '0.3.0',
    date: '2025-10-30',
    type: 'minor',
    developer: 'tom',
    title: '사용자 경험 개선 업데이트',
    changes: [
      { type: 'feature', description: '수동 저장 기능 (사용자 선택)' },
      { type: 'feature', description: '저장된 번호 관리 페이지 (/my-numbers)' },
      { type: 'feature', description: '실시간 추첨 카운트다운 타이머' },
      { type: 'feature', description: '추첨 대기/진행 상태 표시' },
      { type: 'fix', description: '저장 UX 개선 (Toast, 복사 기능)' }
    ]
  },
  {
    id: 6,
    projectId: 'lotto-master',
    version: '0.2.0',
    date: '2025-10-29',
    type: 'minor',
    developer: 'tom',
    title: 'PostgreSQL 통합 및 6개 신규 알고리즘',
    changes: [
      { type: 'feature', description: 'PostgreSQL 데이터베이스 통합 (JSON → DB)' },
      { type: 'feature', description: '6개 신규 번호 생성 알고리즘 (frequency-db, cold-db 등)' },
      { type: 'feature', description: '자동 데이터 수집 크론 스케줄러' },
      { type: 'tech', description: '1,195회차 역대 당첨번호 수집 완료' },
      { type: 'tech', description: 'Next draw 상태 추적 (Waiting/Collecting)' }
    ]
  },
  {
    id: 5,
    projectId: 'ai-chatbot',
    version: '1.0.0',
    date: '2025-10-22',
    type: 'major',
    developer: 'tom',
    title: 'AI 챗봇 RAG 시스템 초기 릴리즈',
    changes: [
      { type: 'feature', description: 'FastAPI 기반 RAG 챗봇 서비스' },
      { type: 'feature', description: 'BM25 검색 엔진 (문서 기반)' },
      { type: 'feature', description: 'Groq API 통합 (llama-3.3-70b)' },
      { type: 'feature', description: '빠른 응답 시스템 (FAQ 패턴 매칭)' },
      { type: 'tech', description: 'Python FastAPI + Pydantic' }
    ]
  },
  {
    id: 4,
    projectId: 'today-fortune',
    version: '1.0.1',
    date: '2025-10-20',
    type: 'patch',
    developer: 'tom',
    title: '음력/자시 버그 수정',
    changes: [
      { type: 'fix', description: '음력 생일 계산 완전 구현 (1900-2100년)' },
      { type: 'fix', description: '자시(23:00-01:00) 시주 계산 수정' },
      { type: 'fix', description: '윤달 지원 추가' },
      { type: 'tech', description: '테스트 파일 추가 (test-bug-fixes.html)' }
    ]
  },
  {
    id: 3,
    projectId: 'today-fortune',
    version: '1.0.0',
    date: '2025-10-20',
    type: 'major',
    developer: 'tom',
    title: '오늘의 운세 MVP 릴리즈',
    changes: [
      { type: 'feature', description: '사주팔자 계산 (201년치 만세력)' },
      { type: 'feature', description: '오행 분석 및 십신 해석' },
      { type: 'feature', description: '일일/주간 운세 생성' },
      { type: 'feature', description: '궁합 점수 계산' },
      { type: 'feature', description: '타로 카드 뽑기' },
      { type: 'tech', description: 'Vite + Vanilla JS SPA' }
    ]
  },
  {
    id: 2,
    projectId: 'lotto-master',
    version: '0.1.0',
    date: '2025-10-16',
    type: 'major',
    developer: 'tom',
    title: 'LottoMaster 초기 릴리즈',
    changes: [
      { type: 'feature', description: '3가지 알고리즘 기반 번호 생성 (랜덤, 빈도, 패턴)' },
      { type: 'feature', description: '당첨 이력 조회 기능' },
      { type: 'feature', description: '번호별 출현 빈도 통계' },
      { type: 'tech', description: 'Next.js 15 + TypeScript 기반 구축' },
      { type: 'tech', description: 'Docker 멀티스테이지 빌드 최적화' }
    ]
  },
  {
    id: 1,
    projectId: 'dashboard',
    version: '2.0.0',
    date: '2025-10-16',
    type: 'major',
    developer: 'tom',
    title: 'Dashboard 2.0 전면 개편',
    changes: [
      { type: 'feature', description: '왼쪽 사이드바 네비게이션' },
      { type: 'feature', description: '프로젝트 상태별/카테고리별 필터링' },
      { type: 'feature', description: '릴리즈 노트 뷰, 타임라인 뷰' },
      { type: 'feature', description: '관리자 인증 시스템' },
      { type: 'tech', description: 'Express.js + Server-side Rendering' }
    ]
  }
];

// System notes
const SYSTEM_NOTES = [
  {
    id: 1,
    date: '2025-10-16',
    author: 'System',
    type: 'info',
    title: '프로젝트 대시보드 업그레이드',
    content: '사이드바 메뉴, 검색, 개발자 노트 시스템 추가'
  }
];

// ==========================================
// Menu Configuration (Whitelist-based)
// ==========================================

const MENU_CONFIG = [
  {
    section: '프로젝트',
    role: 'public', // public = 모두 접근 가능
    items: [
      { id: 'all', icon: '📦', label: '전체 프로젝트', badge: 'stats.total', action: "showView('all')" },
      { id: 'active', icon: '✅', label: '운영중', badge: 'stats.active', action: "filterByStatus('active')" },
      { id: 'development', icon: '🔨', label: '개발중', badge: 'stats.development', action: "filterByStatus('development')" }
    ]
  },
  {
    section: '카테고리',
    role: 'public',
    items: [
      { id: 'full-stack', icon: '🌐', label: 'Full-stack', badge: "stats.byCategory['full-stack']", action: "filterByCategory('full-stack')" },
      { id: 'frontend', icon: '🎨', label: 'Frontend', badge: 'stats.byCategory.frontend', action: "filterByCategory('frontend')" },
      { id: 'backend', icon: '⚙️', label: 'Backend', badge: 'stats.byCategory.backend', action: "filterByCategory('backend')" },
      { id: 'ai-application', icon: '🤖', label: 'AI Application', badge: "stats.byCategory['ai-application']", action: "filterByCategory('ai-application')" },
      { id: 'tools', icon: '🛠️', label: 'Tools', badge: 'stats.byCategory.tools', action: "filterByCategory('tools')" }
    ]
  },
  {
    section: '개발자 노트',
    role: 'public',
    items: [
      { id: 'releases', icon: '📝', label: '릴리즈 노트', action: "showView('releases')" },
      { id: 'timeline', icon: '📅', label: '타임라인', action: "showView('timeline')" }
    ]
  },
  {
    section: '⭐ 관리자 전용',
    role: 'admin', // admin = 관리자만 접근 가능
    items: [
      { id: 'analytics', icon: '📊', label: 'Analytics', action: "showView('analytics')" },
      { id: 'stats', icon: '📈', label: '통계', action: "showView('stats')" },
      { id: 'developers', icon: '👥', label: '개발자 정보', action: "showView('developers')" },
      { id: 'system', icon: '⚙️', label: '시스템 상태', action: "showView('system')" }
    ]
  }
];

// ==========================================
// Helper Functions
// ==========================================

function getCategoryInfo(category) {
  const categories = {
    'full-stack': { label: 'Full-stack', icon: '🌐', color: 'full-stack' },
    'frontend': { label: 'Frontend', icon: '🎨', color: 'frontend' },
    'backend': { label: 'Backend', icon: '⚙️', color: 'backend' },
    'ai-application': { label: 'AI Application', icon: '🤖', color: 'ai-application' },
    'tools': { label: 'Tools', icon: '🛠️', color: 'tools' }
  };
  return categories[category] || { label: category, icon: '📦', color: 'default' };
}

function getProjectsByDeveloper(projects, developerId) {
  return projects.filter(p => p.developer === developerId);
}

function getProjectsByCategory(projects, category) {
  return projects.filter(p => p.category === category);
}

function getProjectsByStatus(projects, status) {
  return projects.filter(p => p.status === status);
}

function searchProjects(projects, query) {
  const lowerQuery = query.toLowerCase();
  return projects.filter(p =>
    p.name.toLowerCase().includes(lowerQuery) ||
    p.description.toLowerCase().includes(lowerQuery) ||
    p.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
  );
}

function getReleaseNotesByProject(projectId) {
  return RELEASE_NOTES.filter(rn => rn.projectId === projectId)
    .sort((a, b) => new Date(b.date) - new Date(a.date));
}

function getProjectStats(projects) {
  return {
    total: projects.length,
    active: projects.filter(p => p.status === 'active').length,
    development: projects.filter(p => p.status === 'development').length,
    byCategory: {
      'full-stack': projects.filter(p => p.category === 'full-stack').length,
      'frontend': projects.filter(p => p.category === 'frontend').length,
      'backend': projects.filter(p => p.category === 'backend').length,
      'ai-application': projects.filter(p => p.category === 'ai-application').length,
      'tools': projects.filter(p => p.category === 'tools').length
    }
  };
}

// Render menu based on user role (Whitelist-based)
function renderMenu(isAdmin, stats) {
  return MENU_CONFIG
    .filter(section => section.role === 'public' || (section.role === 'admin' && isAdmin))
    .map((section, sectionIdx) => {
      const items = section.items.map((item, idx) => {
        const badge = item.badge ? eval(item.badge) : null;
        // Only first item of first public section is active by default
        const activeClass = (sectionIdx === 0 && idx === 0) ? ' active' : '';
        return `
                    <div class="menu-item${activeClass}" onclick="${item.action}">
                        <span class="menu-icon">${item.icon}</span>
                        <span>${item.label}</span>
                        ${badge !== null ? `<span class="menu-badge">${badge}</span>` : ''}
                    </div>`;
      }).join('');

      return `
                <div class="menu-section">
                    <div class="menu-title">${section.section}</div>
                    ${items}
                </div>`;
    }).join('');
}

// ==========================================
// Main Dashboard HTML
// ==========================================

app.get('/', optionalAuth, async (req, res) => {
  try {
    const PROJECTS = await getProjects();
    const stats = getProjectStats(PROJECTS);
    const recentReleases = RELEASE_NOTES.slice(0, 5);
    const isAdmin = req.user && req.user.role === 'admin';

  const html = `
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Dashboard - jsnwcorp.com</title>
    <link rel="icon" type="image/svg+xml" href="/favicon.svg">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #667eea;
            --primary-dark: #5568d3;
            --secondary: #764ba2;
            --success: #4caf50;
            --warning: #ff9800;
            --danger: #f44336;
            --bg-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --sidebar-width: 280px;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: var(--bg-gradient);
            min-height: 100vh;
            color: #333;
        }

        /* Layout */
        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 2px 0 20px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 25px 20px;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.3em;
            font-weight: bold;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .sidebar-logo-icon {
            font-size: 1.5em;
        }

        .auth-section {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 15px;
            background: rgba(102, 126, 234, 0.08);
            border-radius: 10px;
            font-size: 0.9em;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--primary);
            font-weight: 600;
        }

        .auth-btn {
            padding: 6px 15px;
            border: none;
            border-radius: 20px;
            background: var(--primary);
            color: white;
            font-size: 0.85em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-block;
        }

        .auth-btn:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
        }

        .auth-btn.secondary {
            background: white;
            color: var(--primary);
            border: 2px solid var(--primary);
        }

        .auth-btn.secondary:hover {
            background: rgba(102, 126, 234, 0.1);
        }

        /* Search Box */
        .search-box {
            padding: 15px 20px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .search-input {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 25px;
            font-size: 0.9em;
            transition: all 0.3s;
            outline: none;
        }

        .search-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        /* Sidebar Menu */
        .sidebar-menu {
            flex: 1;
            padding: 15px 0;
        }

        .menu-section {
            margin-bottom: 25px;
        }

        .menu-title {
            padding: 8px 20px;
            font-size: 0.75em;
            font-weight: 600;
            text-transform: uppercase;
            color: #999;
            letter-spacing: 0.5px;
        }

        .menu-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #555;
            text-decoration: none;
            transition: all 0.2s;
            cursor: pointer;
            border-left: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(102, 126, 234, 0.08);
            border-left-color: var(--primary);
            color: var(--primary);
        }

        .menu-item.active {
            background: rgba(102, 126, 234, 0.12);
            border-left-color: var(--primary);
            color: var(--primary);
            font-weight: 600;
        }

        .menu-icon {
            font-size: 1.2em;
            width: 24px;
            text-align: center;
        }

        .menu-badge {
            margin-left: auto;
            background: var(--primary);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.75em;
            font-weight: 600;
        }

        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            flex: 1;
            padding: 40px;
        }

        .content-header {
            margin-bottom: 40px;
        }

        .content-title {
            font-size: 2em;
            color: white;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }

        .content-subtitle {
            color: rgba(255,255,255,0.9);
            font-size: 1.1em;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .stat-card-clickable:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .stat-value {
            font-size: 2.5em;
            font-weight: bold;
            color: var(--primary);
            line-height: 1;
        }

        .stat-label {
            margin-top: 8px;
            color: #666;
            font-size: 0.9em;
        }

        /* Project Cards */
        .projects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .project-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            transition: transform 0.3s, box-shadow 0.3s;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .project-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.25);
        }

        .project-header {
            display: flex;
            gap: 15px;
            align-items: flex-start;
        }

        .project-emoji {
            font-size: 3em;
            line-height: 1;
        }

        .project-title-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 8px;
            flex-wrap: wrap;
        }

        .project-info h3 {
            font-size: 1.5em;
            color: #333;
            margin: 0;
        }

        .project-version {
            display: inline-block;
            background: #f0f0f0;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 0.75em;
            color: #666;
            margin-left: 8px;
        }

        .category-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 0.75em;
            font-weight: 600;
            white-space: nowrap;
            transition: transform 0.2s;
        }

        .category-badge:hover {
            transform: scale(1.05);
        }

        .category-badge.full-stack {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
        }

        .category-badge.frontend {
            background: #fff3e0;
            color: #f57c00;
            border: 1px solid #ffb74d;
        }

        .category-badge.backend {
            background: #e3f2fd;
            color: #1976d2;
            border: 1px solid #64b5f6;
        }

        .category-badge.ai-application {
            background: #f3e5f5;
            color: #7b1fa2;
            border: 1px solid #ba68c8;
        }

        .category-badge.tools {
            background: #e8f5e9;
            color: #388e3c;
            border: 1px solid #81c784;
        }

        .category-badge.default {
            background: #f5f5f5;
            color: #666;
            border: 1px solid #ddd;
        }

        .project-desc {
            color: #666;
            line-height: 1.5;
            font-size: 0.95em;
        }

        .project-meta {
            display: flex;
            gap: 15px;
            font-size: 0.85em;
            color: #999;
        }

        .project-meta-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .project-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .tag {
            background: #f0f0f0;
            color: #666;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 0.85em;
            font-weight: 500;
        }

        .project-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }

        .project-status {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9em;
            color: #666;
        }

        .status-indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #ccc;
        }

        .status-indicator.active {
            background: var(--success);
            box-shadow: 0 0 8px rgba(76, 175, 80, 0.5);
            animation: pulse-dot 2s infinite;
        }

        .status-indicator.development {
            background: var(--warning);
        }

        @keyframes pulse-dot {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .visit-btn {
            background: var(--bg-gradient);
            color: white;
            text-decoration: none;
            padding: 10px 25px;
            border-radius: 25px;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
            border: none;
            cursor: pointer;
            font-size: 0.95em;
        }

        .visit-btn:hover:not(.disabled) {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .visit-btn.disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        /* Release Notes */
        .release-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .release-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .release-title {
            font-size: 1.3em;
            font-weight: 600;
            color: #333;
        }

        .release-badge {
            padding: 5px 12px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: 600;
        }

        .release-badge.major {
            background: #e3f2fd;
            color: #1976d2;
        }

        .release-badge.minor {
            background: #f3e5f5;
            color: #7b1fa2;
        }

        .release-badge.patch {
            background: #e8f5e9;
            color: #388e3c;
        }

        .release-meta {
            display: flex;
            gap: 15px;
            font-size: 0.9em;
            color: #999;
            margin-bottom: 15px;
        }

        .change-list {
            list-style: none;
        }

        .change-item {
            padding: 8px 0;
            padding-left: 30px;
            position: relative;
            color: #555;
            line-height: 1.6;
        }

        .change-item::before {
            content: '';
            position: absolute;
            left: 8px;
            top: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--primary);
        }

        .change-type {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 8px;
            font-size: 0.75em;
            font-weight: 600;
            margin-right: 8px;
        }

        .change-type.feature {
            background: #e3f2fd;
            color: #1976d2;
        }

        .change-type.tech {
            background: #f3e5f5;
            color: #7b1fa2;
        }

        .change-type.fix {
            background: #fff3e0;
            color: #f57c00;
        }

        /* Mobile Menu Toggle Button */
        .mobile-menu-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 900;
            width: 48px;
            height: 48px;
            background: var(--bg-gradient);
            border: none;
            border-radius: 12px;
            cursor: pointer;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            gap: 6px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: transform 0.2s;
        }

        .mobile-menu-toggle:active {
            transform: scale(0.95);
        }

        .mobile-menu-toggle span {
            display: block;
            width: 24px;
            height: 3px;
            background: white;
            border-radius: 2px;
            transition: all 0.3s;
        }

        /* Sidebar Overlay */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .sidebar-overlay.active {
            display: block;
            opacity: 1;
        }

        /* Mobile Close Button */
        .mobile-close-btn {
            display: none;
            position: absolute;
            top: 15px;
            right: 15px;
            width: 36px;
            height: 36px;
            background: rgba(0,0,0,0.1);
            border: none;
            border-radius: 50%;
            font-size: 24px;
            line-height: 1;
            color: #666;
            cursor: pointer;
            z-index: 10;
            transition: all 0.2s;
        }

        .mobile-close-btn:active {
            background: rgba(0,0,0,0.2);
            transform: scale(0.95);
        }

        /* Mobile Bottom Navigation - 기본 스타일 먼저 선언 */
        .mobile-bottom-nav {
            display: none;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: 60px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
            z-index: 100;
            padding-bottom: env(safe-area-inset-bottom, 0);
        }

        .bottom-nav-container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            height: 100%;
            max-width: 600px;
            margin: 0 auto;
        }

        .nav-item {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 4px;
            padding: 8px;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            background: none;
            color: #999;
            text-decoration: none;
        }

        .nav-item:active {
            transform: scale(0.95);
        }

        .nav-item.active {
            color: var(--primary);
        }

        .nav-item.disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }

        .nav-icon {
            font-size: 24px;
            line-height: 1;
        }

        .nav-label {
            font-size: 10px;
            font-weight: 500;
            white-space: nowrap;
        }

        .nav-item.active .nav-label {
            font-weight: 700;
        }

        /* Mobile - 미디어 쿼리는 마지막에 */
        @media (max-width: 768px) {
            .mobile-menu-toggle {
                display: none; /* 하단 네비로 대체 */
            }

            .mobile-bottom-nav {
                display: block; /* 하단 네비 표시 */
            }

            .mobile-close-btn {
                display: block;
            }

            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease-in-out;
                z-index: 1001;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 20px 20px calc(60px + 20px) 20px; /* 하단 네비 공간 확보 */
            }

            .projects-grid {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        /* Utility */
        .hidden {
            display: none;
        }

        /* AI Chatbot Styles */
        .chat-fab {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
            z-index: 999;
            transition: all 0.3s ease;
        }

        .chat-fab:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(102, 126, 234, 0.5);
        }

        /* AI Service Status Indicators */
        .chat-fab.status-active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .chat-fab.status-paused {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            animation: pulse 2s infinite;
        }

        .chat-fab.status-stopped {
            background: linear-gradient(135deg, #868f96 0%, #596164 100%);
            opacity: 0.6;
            cursor: not-allowed;
        }

        .chat-fab.status-unknown {
            background: linear-gradient(135deg, #89f7fe 0%, #66a6ff 100%);
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        .chat-modal {
            position: fixed;
            bottom: 90px;
            right: 20px;
            width: 400px;
            max-width: calc(100vw - 40px);
            max-height: 600px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            display: none;
            flex-direction: column;
            z-index: 1000;
        }

        .chat-modal.active {
            display: flex;
        }

        .chat-header {
            padding: 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px 12px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .chat-header h3 {
            margin: 0;
            font-size: 18px;
        }

        .chat-close {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 16px;
            max-height: 400px;
        }

        .message-bubble {
            background: #f5f5f5;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 12px;
            max-width: 85%;
            word-wrap: break-word;
        }

        .user-message .message-bubble {
            background: #667eea;
            color: white;
            margin-left: auto;
        }

        .bot-message .message-bubble {
            background: #f5f5f5;
            color: #333;
        }

        .message-bubble.loading {
            animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .quick-questions {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-top: 12px;
        }

        .quick-question-btn {
            padding: 8px 12px;
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            cursor: pointer;
            text-align: left;
            font-size: 14px;
            transition: all 0.2s;
        }

        .quick-question-btn:hover {
            background: #f9f9f9;
            border-color: #667eea;
        }

        .chat-input {
            padding: 16px;
            border-top: 1px solid #e0e0e0;
            display: flex;
            gap: 8px;
        }

        .chat-input input {
            flex: 1;
            padding: 10px;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
        }

        .chat-input button {
            padding: 10px 20px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        }

        .chat-input button:hover {
            background: #5568d3;
        }

        .chat-input button:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        @media (max-width: 768px) {
            .chat-modal {
                width: calc(100vw - 40px);
                bottom: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" onclick="closeMobileSidebar()"></div>

    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <!-- Mobile Close Button -->
            <button class="mobile-close-btn" onclick="closeMobileSidebar()" aria-label="메뉴 닫기">✕</button>

            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <span class="sidebar-logo-icon">🚀</span>
                    <span>Dashboard</span>
                </div>
                ${isAdmin ? `
                <div class="auth-section">
                    <div class="user-info">
                        <span>👑</span>
                        <span>관리자</span>
                    </div>
                    <button class="auth-btn secondary" onclick="logout()">로그아웃</button>
                </div>
                ` : `
                <div class="auth-section">
                    <span style="color: #999; font-size: 0.85em;">비로그인 상태</span>
                    <a href="/login" class="auth-btn">로그인</a>
                </div>
                `}
            </div>

            <div class="search-box">
                <input type="text" class="search-input" placeholder="🔍 프로젝트 검색..." onkeyup="searchProjects(this.value)">
            </div>

                        <nav class="sidebar-menu">
                ${renderMenu(isAdmin, stats)}
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div id="all-view">
                <div class="content-header">
                    <h1 class="content-title">전체 프로젝트</h1>
                    <p class="content-subtitle">배포된 모든 프로젝트를 한눈에 확인하세요</p>
                </div>

                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-value">${stats.total}</div>
                        <div class="stat-label">전체 프로젝트</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">${stats.active}</div>
                        <div class="stat-label">운영중</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">${stats.development}</div>
                        <div class="stat-label">개발중</div>
                    </div>
                    <div class="stat-card stat-card-clickable" onclick="showView('developers')" style="cursor: pointer;">
                        <div class="stat-value">${DEVELOPERS.length}</div>
                        <div class="stat-label">개발팀 <span style="font-size: 0.8em; color: #999;">→ 상세보기</span></div>
                    </div>
                </div>

                <div class="projects-grid" id="projects-container">
                    ${PROJECTS.map(project => {
                      const developer = DEVELOPERS.find(d => d.id === project.developer);
                      return `
                        <div class="project-card" data-id="${project.id}" data-status="${project.status}" data-category="${project.category}">
                            <div class="project-header">
                                <div class="project-emoji">${project.emoji}</div>
                                <div class="project-info">
                                    <div class="project-title-row">
                                        <h3>
                                            ${project.name}
                                            <span class="project-version">v${project.version}</span>
                                        </h3>
                                        <span class="category-badge ${getCategoryInfo(project.category).color}">
                                            ${getCategoryInfo(project.category).icon} ${getCategoryInfo(project.category).label}
                                        </span>
                                    </div>
                                    <p class="project-desc">${project.description}</p>
                                    <div class="project-meta">
                                        <span class="project-meta-item">
                                            <span>${developer ? developer.avatar : '👤'}</span>
                                            <span>${developer ? developer.name : 'Unknown'}</span>
                                        </span>
                                        <span class="project-meta-item">
                                            <span>📅</span>
                                            <span>${project.deployedAt}</span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="project-tags">
                                ${project.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                            </div>
                            <div class="project-footer">
                                <div class="project-status">
                                    ${project.healthStatus ? `
                                      <span class="health-indicator ${project.healthStatus}" title="Health: ${project.healthStatus} | Response: ${project.avgResponseTimeMs}ms">
                                        ${project.healthStatus === 'healthy' ? '🟢' : project.healthStatus === 'degraded' ? '🟡' : project.healthStatus === 'unhealthy' ? '🔴' : '⚪'}
                                      </span>
                                    ` : ''}
                                    <span class="status-indicator ${project.status}"></span>
                                    <span>${project.status === 'active' ? '운영중' : project.status === 'development' ? '개발중' : '준비중'}</span>
                                </div>
                                ${!['ai-chatbot', 'dashboard'].includes(project.id) ? (
                                  project.status === 'active' ?
                                    `<a href="${project.url}" target="_blank" class="visit-btn">방문하기 →</a>` :
                                    `<button class="visit-btn disabled" disabled>준비중</button>`
                                ) : ''}
                            </div>
                        </div>
                      `;
                    }).join('')}
                </div>
            </div>

            <div id="releases-view" class="hidden">
                <div class="content-header">
                    <h1 class="content-title">📝 릴리즈 노트</h1>
                    <p class="content-subtitle">프로젝트 업데이트 히스토리</p>
                </div>

                ${recentReleases.map(release => {
                  const project = PROJECTS.find(p => p.id === release.projectId);
                  const developer = DEVELOPERS.find(d => d.id === release.developer);
                  return `
                    <div class="release-card">
                        <div class="release-header">
                            <div>
                                <div class="release-title">
                                    ${project ? project.emoji : '📦'} ${release.title}
                                </div>
                            </div>
                            <span class="release-badge ${release.type}">${release.type.toUpperCase()}</span>
                        </div>
                        <div class="release-meta">
                            <span>버전 ${release.version}</span>
                            <span>•</span>
                            <span>${release.date}</span>
                            <span>•</span>
                            <span>${developer ? developer.avatar + ' ' + developer.name : 'Unknown'}</span>
                        </div>
                        <ul class="change-list">
                            ${release.changes.map(change => `
                                <li class="change-item">
                                    <span class="change-type ${change.type}">${change.type}</span>
                                    ${change.description}
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                  `;
                }).join('')}
            </div>

            <div id="developers-view" class="hidden">
                <div class="content-header">
                    <h1 class="content-title">👥 개발자별 프로젝트</h1>
                    <p class="content-subtitle">팀별 프로젝트 현황</p>
                </div>

                ${DEVELOPERS.map(dev => {
                  const devProjects = getProjectsByDeveloper(PROJECTS, dev.id);
                  return `
                    <div class="release-card" style="border-left: 4px solid ${dev.color}">
                        <div class="release-header">
                            <div class="release-title">
                                ${dev.avatar} ${dev.name}
                                <span class="project-version">${dev.role}</span>
                            </div>
                            <span class="menu-badge">${devProjects.length} 프로젝트</span>
                        </div>
                        <div class="project-tags" style="margin-top: 15px;">
                            ${devProjects.map(p => `<span class="tag">${p.emoji} ${p.name}</span>`).join('')}
                        </div>
                    </div>
                  `;
                }).join('')}
            </div>

            <div id="timeline-view" class="hidden">
                <div class="content-header">
                    <h1 class="content-title">📅 타임라인</h1>
                    <p class="content-subtitle">전체 릴리즈 히스토리 (${RELEASE_NOTES.length}개)</p>
                </div>

                ${[...RELEASE_NOTES].sort((a, b) => new Date(b.date) - new Date(a.date)).map(release => {
                    const project = PROJECTS.find(p => p.id === release.projectId) || {};
                    const badgeClass = release.type === 'major' ? 'major' : release.type === 'minor' ? 'minor' : 'patch';
                    return `
                    <div class="release-card">
                        <div class="release-header">
                            <div class="release-title">${project.emoji || '📦'} ${release.title}</div>
                            <span class="release-badge ${badgeClass}">${release.type}</span>
                        </div>
                        <div class="release-meta">
                            <span>${release.date}</span>
                            <span>•</span>
                            <span>${project.name || release.projectId}</span>
                            <span>•</span>
                            <span>v${release.version}</span>
                            <span>•</span>
                            <span>by ${DEVELOPERS.find(d => d.id === release.developer)?.name || release.developer}</span>
                        </div>
                        <div class="changes-list" style="margin-top: 12px;">
                            ${release.changes.slice(0, 4).map(change => `
                                <div class="change-item ${change.type}" style="display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px;">
                                    <span style="font-size: 0.75em; padding: 2px 6px; border-radius: 4px; background: ${change.type === 'feature' ? '#e8f5e9' : change.type === 'fix' ? '#fff3e0' : '#e3f2fd'}; color: ${change.type === 'feature' ? '#2e7d32' : change.type === 'fix' ? '#ef6c00' : '#1565c0'};">${change.type}</span>
                                    <span style="color: #555; font-size: 0.9em;">${change.description}</span>
                                </div>
                            `).join('')}
                            ${release.changes.length > 4 ? `<div style="color: #999; font-size: 0.85em; margin-top: 4px;">+${release.changes.length - 4}개 더...</div>` : ''}
                        </div>
                    </div>
                `}).join('')}
            </div>

            ${isAdmin ? `
            <div id="stats-view" class="hidden">
                <div class="content-header">
                    <h1 class="content-title">📈 통계</h1>
                    <p class="content-subtitle">프로젝트 및 개발자 통계 현황</p>
                </div>

                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-value">${stats.total}</div>
                        <div class="stat-label">전체 프로젝트</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">${stats.active}</div>
                        <div class="stat-label">운영중 프로젝트</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">${stats.development}</div>
                        <div class="stat-label">개발중 프로젝트</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">${DEVELOPERS.length}</div>
                        <div class="stat-label">개발팀</div>
                    </div>
                </div>

                <div class="release-card">
                    <div class="release-title">카테고리별 프로젝트</div>
                    <div class="project-tags" style="margin-top: 15px;">
                        <span class="tag">Full-stack: ${stats.byCategory['full-stack']}</span>
                        <span class="tag">Frontend: ${stats.byCategory.frontend}</span>
                        <span class="tag">Backend: ${stats.byCategory.backend}</span>
                        <span class="tag">AI Application: ${stats.byCategory['ai-application']}</span>
                        <span class="tag">Tools: ${stats.byCategory.tools}</span>
                    </div>
                </div>

                <div class="release-card">
                    <div class="release-title">팀별 프로젝트 분포</div>
                    ${DEVELOPERS.map(dev => {
                      const devProjects = getProjectsByDeveloper(PROJECTS, dev.id);
                      return `
                        <div style="padding: 15px 0; border-bottom: 1px solid #eee;">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <span style="font-size: 1.5em;">${dev.avatar}</span>
                                    <div>
                                        <div style="font-weight: 600; color: #333;">${dev.name}</div>
                                        <div style="font-size: 0.85em; color: #999;">${dev.role}</div>
                                    </div>
                                </div>
                                <div style="font-size: 1.5em; font-weight: bold; color: var(--primary);">
                                    ${devProjects.length}
                                </div>
                            </div>
                        </div>
                      `;
                    }).join('')}
                </div>
            </div>

            <div id="system-view" class="hidden">
                <div class="content-header">
                    <h1 class="content-title">📊 시스템 상태</h1>
                    <p class="content-subtitle">서버 환경 및 리소스 정보</p>
                </div>

                <div class="release-card">
                    <div class="release-title">서버 정보</div>
                    <div class="change-list" style="margin-top: 15px;">
                        <div class="change-item">서버 IP: 203.245.30.6</div>
                        <div class="change-item">환경: Docker + Docker Compose</div>
                        <div class="change-item">프록시: nginx (Port-based routing)</div>
                        <div class="change-item">데이터베이스: PostgreSQL 15</div>
                        <div class="change-item">캐시: Redis 7</div>
                    </div>
                </div>

                <div class="release-card">
                    <div class="release-title">활성 서비스</div>
                    <div class="project-tags" style="margin-top: 15px;">
                        <span class="tag">nginx (Port 80)</span>
                        <span class="tag">Dashboard (Port 80)</span>
                        ${PROJECTS.filter(p => p.status === 'active').map(p =>
                          `<span class="tag">${p.name} (Port ${p.port})</span>`
                        ).join('')}
                        <span class="tag">PostgreSQL (Internal)</span>
                        <span class="tag">Redis (Internal)</span>
                    </div>
                </div>
            </div>

            <div id="analytics-view" class="hidden">
                <div class="content-header">
                    <h1 class="content-title">📊 실시간 Analytics</h1>
                    <p class="content-subtitle">프로젝트별 실시간 통계 및 사용자 활동</p>
                </div>

                <div class="stats-grid" id="realtime-summary">
                    <div class="stat-card">
                        <div class="stat-label">
                            <span class="realtime-indicator"></span>
                            실시간 활성 사용자
                        </div>
                        <div class="stat-value" id="total-active-users">-</div>
                        <div style="font-size: 0.85em; color: #999; margin-top: 5px;">최근 5분</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">오늘 총 이벤트</div>
                        <div class="stat-value" id="total-today-events">-</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">최근 24시간 이벤트</div>
                        <div class="stat-value" id="events-24h">-</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">활성 프로젝트</div>
                        <div class="stat-value" id="active-projects-count">-</div>
                    </div>
                </div>

                <div class="projects-stats-grid" id="projects-stats">
                    <div style="text-align: center; padding: 40px; color: #999;">
                        데이터를 불러오는 중...
                    </div>
                </div>

                <!-- Project Detail Modal -->
                <div id="project-detail-modal" class="modal-overlay" style="display: none;">
                    <div class="modal-container">
                        <div class="modal-header">
                            <div class="modal-title-section">
                                <span id="modal-project-emoji" class="modal-project-emoji"></span>
                                <div>
                                    <h2 id="modal-project-name" class="modal-project-name"></h2>
                                    <p id="modal-project-description" class="modal-project-description"></p>
                                </div>
                            </div>
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <button id="modal-refresh-btn" class="modal-refresh-btn" title="새로고침">
                                    🔄
                                </button>
                                <span style="font-size: 12px; color: #999;">
                                    마지막 업데이트: <span id="last-refresh-time">-</span>
                                </span>
                            </div>
                            <button class="modal-close-btn" onclick="closeProjectDetailModal()">✕</button>
                        </div>

                        <div class="modal-body">
                            <!-- Summary Cards -->
                            <div class="modal-stats-grid">
                                <div class="modal-stat-card">
                                    <div class="modal-stat-label">총 사용자</div>
                                    <div class="modal-stat-value" id="modal-total-users">-</div>
                                </div>
                                <div class="modal-stat-card">
                                    <div class="modal-stat-label">총 페이지뷰</div>
                                    <div class="modal-stat-value" id="modal-total-pageviews">-</div>
                                </div>
                                <div class="modal-stat-card">
                                    <div class="modal-stat-label">총 이벤트</div>
                                    <div class="modal-stat-value" id="modal-total-events">-</div>
                                </div>
                                <div class="modal-stat-card">
                                    <div class="modal-stat-label">일일 활성 사용자</div>
                                    <div class="modal-stat-value highlight" id="modal-daily-active">-</div>
                                </div>
                            </div>

                            <!-- 7 Days Chart -->
                            <div class="modal-section">
                                <h3 class="modal-section-title">📊 최근 7일 활동 추이</h3>
                                <div id="daily-stats-chart-container">
                                    <canvas id="daily-stats-chart" style="max-height: 250px;"></canvas>
                                </div>
                            </div>

                            <!-- Event Type Distribution -->
                            <div class="modal-section">
                                <h3 class="modal-section-title">📈 이벤트 타입별 분포 (최근 7일)</h3>
                                <div id="event-distribution-chart-container">
                                    <canvas id="event-distribution-chart" style="max-height: 200px;"></canvas>
                                </div>
                            </div>

                            <!-- Recent Events -->
                            <div class="modal-section">
                                <h3 class="modal-section-title">📝 최근 이벤트 (최근 50개)</h3>
                                <div id="recent-events-list" class="events-list">
                                    <p style="text-align: center; color: #999; padding: 20px;">로딩 중...</p>
                                </div>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-secondary" onclick="closeProjectDetailModal()">닫기</button>
                            <button class="btn btn-primary" id="visit-project-btn" onclick="">프로젝트 방문 →</button>
                        </div>
                    </div>
                </div>

                <style>
                    .realtime-indicator {
                        display: inline-block;
                        width: 8px;
                        height: 8px;
                        background: #10b981;
                        border-radius: 50%;
                        animation: pulse-dot 2s infinite;
                        margin-right: 8px;
                    }

                    @keyframes pulse-dot {
                        0%, 100% { opacity: 1; }
                        50% { opacity: 0.5; }
                    }

                    .projects-stats-grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
                        gap: 20px;
                        margin-top: 30px;
                    }

                    .project-stat-card {
                        background: white;
                        border-radius: 15px;
                        padding: 25px;
                        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
                        cursor: pointer;
                        transition: transform 0.2s, box-shadow 0.2s;
                    }

                    .project-stat-card:hover {
                        transform: translateY(-5px);
                        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
                    }

                    .project-stat-header {
                        display: flex;
                        align-items: center;
                        gap: 12px;
                        margin-bottom: 20px;
                        padding-bottom: 15px;
                        border-bottom: 2px solid #f0f0f0;
                    }

                    .project-stat-emoji {
                        font-size: 36px;
                    }

                    .project-stat-info h3 {
                        margin: 0 0 5px 0;
                        font-size: 20px;
                        color: #333;
                    }

                    .project-stat-status {
                        font-size: 12px;
                        color: #10b981;
                        font-weight: 600;
                    }

                    .project-stat-metrics {
                        display: grid;
                        grid-template-columns: repeat(2, 1fr);
                        gap: 15px;
                        margin-bottom: 15px;
                    }

                    .metric-item {
                        display: flex;
                        flex-direction: column;
                    }

                    .metric-label {
                        font-size: 12px;
                        color: #666;
                        margin-bottom: 5px;
                    }

                    .metric-value {
                        font-size: 24px;
                        font-weight: bold;
                        color: #333;
                    }

                    .metric-value.highlight {
                        color: #667eea;
                    }

                    .project-stat-footer {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        padding-top: 15px;
                        border-top: 1px solid #f0f0f0;
                        font-size: 12px;
                        color: #999;
                    }

                    /* Modal Styles */
                    .modal-overlay {
                        position: fixed;
                        top: 0;
                        left: 0;
                        right: 0;
                        bottom: 0;
                        background: rgba(0, 0, 0, 0.6);
                        z-index: 10000;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        padding: 20px;
                        animation: fadeIn 0.2s ease;
                    }

                    @keyframes fadeIn {
                        from { opacity: 0; }
                        to { opacity: 1; }
                    }

                    .modal-container {
                        background: white;
                        border-radius: 20px;
                        max-width: 900px;
                        width: 100%;
                        max-height: 90vh;
                        overflow: hidden;
                        display: flex;
                        flex-direction: column;
                        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                        animation: slideUp 0.3s ease;
                    }

                    @keyframes slideUp {
                        from { transform: translateY(50px); opacity: 0; }
                        to { transform: translateY(0); opacity: 1; }
                    }

                    .modal-header {
                        display: flex;
                        justify-content: space-between;
                        align-items: flex-start;
                        padding: 30px;
                        border-bottom: 2px solid #f0f0f0;
                    }

                    .modal-title-section {
                        display: flex;
                        align-items: center;
                        gap: 15px;
                    }

                    .modal-project-emoji {
                        font-size: 48px;
                    }

                    .modal-project-name {
                        margin: 0;
                        font-size: 24px;
                        color: #333;
                    }

                    .modal-project-description {
                        margin: 5px 0 0 0;
                        color: #666;
                        font-size: 14px;
                    }

                    .modal-close-btn {
                        background: #f0f0f0;
                        border: none;
                        width: 36px;
                        height: 36px;
                        border-radius: 50%;
                        font-size: 20px;
                        cursor: pointer;
                        transition: background 0.2s;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }

                    .modal-close-btn:hover {
                        background: #e0e0e0;
                    }

                    .modal-refresh-btn {
                        background: #667eea;
                        color: white;
                        border: none;
                        width: 32px;
                        height: 32px;
                        border-radius: 50%;
                        font-size: 16px;
                        cursor: pointer;
                        transition: all 0.2s;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }

                    .modal-refresh-btn:hover {
                        background: #5568d3;
                        transform: rotate(180deg);
                    }

                    .modal-body {
                        flex: 1;
                        overflow-y: auto;
                        padding: 30px;
                    }

                    .modal-stats-grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                        gap: 15px;
                        margin-bottom: 30px;
                    }

                    .modal-stat-card {
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        padding: 20px;
                        border-radius: 12px;
                        color: white;
                    }

                    .modal-stat-label {
                        font-size: 13px;
                        opacity: 0.9;
                        margin-bottom: 8px;
                    }

                    .modal-stat-value {
                        font-size: 28px;
                        font-weight: bold;
                    }

                    .modal-stat-value.highlight {
                        color: #fbbf24;
                    }

                    .modal-section {
                        background: #f9fafb;
                        border-radius: 12px;
                        padding: 20px;
                        margin-bottom: 20px;
                    }

                    .modal-section-title {
                        margin: 0 0 20px 0;
                        font-size: 16px;
                        color: #333;
                    }

                    #daily-stats-chart-container {
                        background: white;
                        border-radius: 8px;
                        padding: 15px;
                    }

                    .events-list {
                        max-height: 300px;
                        overflow-y: auto;
                        background: white;
                        border-radius: 8px;
                        padding: 10px;
                    }

                    .event-item {
                        padding: 12px;
                        border-bottom: 1px solid #f0f0f0;
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        transition: background 0.2s;
                    }

                    .event-item:last-child {
                        border-bottom: none;
                    }

                    .event-item:hover {
                        background: #f9fafb;
                    }

                    .event-info {
                        flex: 1;
                    }

                    .event-type {
                        font-weight: 600;
                        color: #667eea;
                        font-size: 14px;
                    }

                    .event-name {
                        color: #666;
                        font-size: 13px;
                        margin-top: 2px;
                    }

                    .event-time {
                        font-size: 12px;
                        color: #999;
                        white-space: nowrap;
                    }

                    .modal-footer {
                        padding: 20px 30px;
                        border-top: 2px solid #f0f0f0;
                        display: flex;
                        gap: 10px;
                        justify-content: flex-end;
                    }

                    .btn {
                        padding: 10px 24px;
                        border-radius: 8px;
                        border: none;
                        font-size: 14px;
                        font-weight: 600;
                        cursor: pointer;
                        transition: all 0.2s;
                    }

                    .btn-secondary {
                        background: #f0f0f0;
                        color: #333;
                    }

                    .btn-secondary:hover {
                        background: #e0e0e0;
                    }

                    .btn-primary {
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: white;
                    }

                    .btn-primary:hover {
                        transform: translateY(-2px);
                        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
                    }

                    @media (max-width: 768px) {
                        .modal-container {
                            max-height: 95vh;
                            border-radius: 20px 20px 0 0;
                        }

                        .modal-header {
                            padding: 20px;
                        }

                        .modal-project-emoji {
                            font-size: 36px;
                        }

                        .modal-project-name {
                            font-size: 20px;
                        }

                        .modal-body {
                            padding: 20px;
                        }

                        .modal-stats-grid {
                            grid-template-columns: repeat(2, 1fr);
                        }
                    }
                </style>
            </div>
            ` : ''}

        <!-- Analytics Modal Script -->
        <script src="/js/analytics-modal.js"></script>
        </main>
    </div>

    <script>
        let currentView = 'all';
        let currentFilter = { type: null, value: null }; // Track active filter
        let allProjects = ${JSON.stringify(PROJECTS)};
        let isAdmin = ${isAdmin};
        let analyticsEventSource = null;

        // Content header configurations
        const headerConfigs = {
            all: { title: '전체 프로젝트', subtitle: '배포된 모든 프로젝트를 한눈에 확인하세요' },
            active: { title: '운영중인 프로젝트', subtitle: '현재 운영중인 프로젝트 목록' },
            development: { title: '개발중인 프로젝트', subtitle: '개발 진행중인 프로젝트 목록' },
            'full-stack': { title: 'Full-stack 프로젝트', subtitle: '풀스택 프로젝트 모음' },
            frontend: { title: 'Frontend 프로젝트', subtitle: '프론트엔드 프로젝트 모음' },
            backend: { title: 'Backend 프로젝트', subtitle: '백엔드 프로젝트 모음' },
            tools: { title: 'Tools 프로젝트', subtitle: '도구 및 유틸리티 프로젝트' }
        };

        // Update content header dynamically
        function updateContentHeader(filterKey) {
            const config = headerConfigs[filterKey] || headerConfigs.all;
            const titleEl = document.querySelector('.content-title');
            const subtitleEl = document.querySelector('.content-subtitle');

            if (titleEl) titleEl.textContent = config.title;
            if (subtitleEl) subtitleEl.textContent = config.subtitle;
        }

        async function logout() {
            if (!confirm('로그아웃하시겠습니까?')) {
                return;
            }

            try {
                const response = await fetch('/api/auth/logout', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                if (response.ok) {
                    window.location.reload();
                } else {
                    alert('로그아웃에 실패했습니다.');
                }
            } catch (error) {
                console.error('Logout error:', error);
                alert('로그아웃 중 오류가 발생했습니다.');
            }
        }

        function filterByStatus(status) {
            currentView = 'all';
            currentFilter = { type: 'status', value: status };

            // Show all-view
            document.querySelectorAll('[id$="-view"]').forEach(el => el.classList.add('hidden'));
            document.getElementById('all-view').classList.remove('hidden');

            // Filter cards
            const cards = document.querySelectorAll('.project-card');
            cards.forEach(card => {
                if (card.dataset.status === status) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });

            // Update header
            updateContentHeader(status);

            // Update menu active state
            document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
            event.currentTarget.classList.add('active');
        }

        function filterByCategory(category) {
            currentView = 'all';
            currentFilter = { type: 'category', value: category };

            // Show all-view
            document.querySelectorAll('[id$="-view"]').forEach(el => el.classList.add('hidden'));
            document.getElementById('all-view').classList.remove('hidden');

            // Filter cards
            const cards = document.querySelectorAll('.project-card');
            cards.forEach(card => {
                if (card.dataset.category === category) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });

            // Update header
            updateContentHeader(category);

            // Update menu active state
            document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
            event.currentTarget.classList.add('active');
        }

        function searchProjects(query) {
            if (!query) {
                document.querySelectorAll('.project-card').forEach(card => {
                    card.style.display = 'flex';
                });
                return;
            }

            const lowerQuery = query.toLowerCase();
            const cards = document.querySelectorAll('.project-card');

            cards.forEach(card => {
                const project = allProjects.find(p => p.id === card.dataset.id);
                const matches = project.name.toLowerCase().includes(lowerQuery) ||
                               project.description.toLowerCase().includes(lowerQuery) ||
                               project.tags.some(tag => tag.toLowerCase().includes(lowerQuery));

                card.style.display = matches ? 'flex' : 'none';
            });
        }

        // Analytics functions
        async function loadAnalyticsSummary() {
            try {
                const response = await fetch('/api/analytics/summary');
                const result = await response.json();

                if (result.success) {
                    updateSummaryCards(result.data);
                }
            } catch (error) {
                console.error('Failed to load analytics summary:', error);
            }

            try {
                const response = await fetch('/api/analytics/projects');
                const result = await response.json();

                if (result.success) {
                    renderProjectsStats(result.data);
                }
            } catch (error) {
                console.error('Failed to load projects stats:', error);
            }
        }

        function updateSummaryCards(data) {
            document.getElementById('total-active-users').textContent = data.daily_active_users || 0;
            document.getElementById('total-today-events').textContent = (data.total_requests || 0).toLocaleString();
            document.getElementById('events-24h').textContent = (data.events_last_24h || 0).toLocaleString();
            document.getElementById('active-projects-count').textContent = data.active_projects_24h || 0;
        }

        function renderProjectsStats(projects) {
            const container = document.getElementById('projects-stats');

            if (!projects || projects.length === 0) {
                container.innerHTML = '<p style="color: #999; text-align: center; padding: 40px;">통계 데이터가 없습니다.</p>';
                return;
            }

            container.innerHTML = projects.map(p => \`
                <div class="project-stat-card" onclick="showProjectDetail('\${p.id}', '\${p.url}')" data-project-id="\${p.id}">
                    <div class="project-stat-header">
                        <span class="project-stat-emoji">\${p.emoji || '📦'}</span>
                        <div class="project-stat-info">
                            <h3>\${p.display_name || p.name}</h3>
                            <div class="project-stat-status">● \${p.status === 'active' ? '운영중' : p.status}</div>
                        </div>
                    </div>

                    <div class="project-stat-metrics">
                        <div class="metric-item">
                            <span class="metric-label">일일 활성 사용자</span>
                            <span class="metric-value highlight" data-project-id="\${p.id}" data-metric="active">\${p.daily_active_users || 0}</span>
                        </div>
                        <div class="metric-item">
                            <span class="metric-label">총 페이지뷰</span>
                            <span class="metric-value">\${(p.total_page_views || 0).toLocaleString()}</span>
                        </div>
                        <div class="metric-item">
                            <span class="metric-label">총 이벤트</span>
                            <span class="metric-value">\${(p.total_events || 0).toLocaleString()}</span>
                        </div>
                        <div class="metric-item">
                            <span class="metric-label">평균 응답시간</span>
                            <span class="metric-value" style="font-size: 14px; color: #666;">
                                \${p.avg_response_time_ms ? Math.round(p.avg_response_time_ms) + 'ms' : '-'}
                            </span>
                        </div>
                    </div>

                    <div class="project-stat-footer">
                        <span>\${p.last_health_check ? '최근 확인: ' + new Date(p.last_health_check).toLocaleTimeString('ko-KR', {hour: '2-digit', minute: '2-digit'}) : '데이터 없음'}</span>
                        <span>상세 보기 →</span>
                    </div>
                </div>
            \`).join('');
        }

        // Analytics 뷰가 열릴 때 호출되도록 showView 함수
        function showView(viewName) {
            // Hide all views
            document.querySelectorAll('[id$="-view"]').forEach(el => el.classList.add('hidden'));

            // Show selected view
            document.getElementById(viewName + '-view').classList.remove('hidden');

            // Update active menu item
            document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
            event.currentTarget.classList.add('active');

            currentView = viewName;
            currentFilter = { type: null, value: null }; // Reset filter

            // Reset filters when showing 'all' view
            if (viewName === 'all') {
                document.querySelectorAll('.project-card').forEach(card => {
                    card.style.display = 'flex';
                });
                updateContentHeader('all');
            }

            // Load Analytics data when showing analytics view
            if (viewName === 'analytics' && isAdmin) {
                loadAnalyticsSummary();
            }

            // Auto-close sidebar on mobile after menu click
            if (window.innerWidth <= 768) {
                closeMobileSidebar();
            }
        }

        // Mobile sidebar toggle functions
        function toggleMobileSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.querySelector('.sidebar-overlay');

            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');

            // Prevent body scroll when sidebar is open
            if (sidebar.classList.contains('active')) {
                document.body.style.overflow = 'hidden';
            } else {
                document.body.style.overflow = '';
            }
        }

        function closeMobileSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.querySelector('.sidebar-overlay');

            sidebar.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
        }

        // Close sidebar on ESC key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && window.innerWidth <= 768) {
                closeMobileSidebar();
            }
        });

        // Close sidebar when resizing from mobile to desktop
        let resizeTimer;
        window.addEventListener('resize', function() {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function() {
                // 768px 넘어가면 무조건 닫기 (햄버거 버튼이 사라지므로)
                if (window.innerWidth > 768) {
                    const sidebar = document.getElementById('sidebar');
                    const overlay = document.querySelector('.sidebar-overlay');

                    // 강제로 active 클래스 제거 및 display none 처리
                    sidebar.classList.remove('active');
                    overlay.classList.remove('active');
                    document.body.style.overflow = '';
                }
            }, 250);
        });

        // Bottom navigation functions
        function handleBottomNav(viewName) {
            // Show view
            showBottomNavView(viewName);

            // Update active state
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
            });
            event.currentTarget.classList.add('active');
        }

        function showBottomNavView(viewName) {
            // Hide all views
            document.querySelectorAll('[id$="-view"]').forEach(el => el.classList.add('hidden'));

            // Show selected view
            document.getElementById(viewName + '-view').classList.remove('hidden');

            // Update sidebar menu items
            document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));

            currentView = viewName;

            // Reset filters when showing 'all' view
            if (viewName === 'all') {
                document.querySelectorAll('.project-card').forEach(card => {
                    card.style.display = 'flex';
                });
            }

            // Load Analytics data when showing analytics view
            if (viewName === 'analytics' && isAdmin) {
                loadAnalyticsSummary();
            }

            // Close sidebar if open
            closeMobileSidebar();
        }
    </script>

    <!-- Mobile Bottom Navigation -->
    <nav class="mobile-bottom-nav">
        <div class="bottom-nav-container">
            <button class="nav-item active" onclick="handleBottomNav('all')" aria-label="홈">
                <span class="nav-icon">🏠</span>
                <span class="nav-label">홈</span>
            </button>
            <button class="nav-item" onclick="handleBottomNav('releases')" aria-label="릴리즈 노트">
                <span class="nav-icon">📝</span>
                <span class="nav-label">노트</span>
            </button>
            ${isAdmin ? `
            <button class="nav-item" onclick="handleBottomNav('analytics')" aria-label="통계">
                <span class="nav-icon">📊</span>
                <span class="nav-label">통계</span>
            </button>
            ` : `
            <button class="nav-item disabled" onclick="alert('관리자 로그인이 필요합니다')" aria-label="통계">
                <span class="nav-icon">📊</span>
                <span class="nav-label">통계</span>
            </button>
            `}
            <button class="nav-item" onclick="toggleMobileSidebar()" aria-label="메뉴">
                <span class="nav-icon">☰</span>
                <span class="nav-label">메뉴</span>
            </button>
        </div>
    </nav>

    <!-- AI Chatbot -->
    <div class="chat-fab" id="chatFab" onclick="toggleChatModal()">
        <span style="font-size: 28px;">💬</span>
    </div>

    <div class="chat-modal" id="chatModal">
        <div class="chat-header">
            <h3>🤖 프로젝트 도우미</h3>
            <button class="chat-close" onclick="toggleChatModal()">×</button>
        </div>
        <div class="chat-messages" id="chatMessages">
            <div class="bot-message">
                <div class="message-bubble">
                    안녕하세요! 프로젝트 정보에 대해 무엇이든 물어보세요.
                    <div class="quick-questions" id="quickQuestions">
                        <!-- Quick questions will be loaded here -->
                    </div>
                </div>
            </div>
        </div>
        <div class="chat-input">
            <input
                type="text"
                id="chatInput"
                placeholder="질문을 입력하세요..."
                onkeypress="handleChatEnter(event)"
            />
            <button id="chatSendBtn" onclick="sendMessage()">전송</button>
        </div>
    </div>

    <script>
    // Chatbot functionality
    let isChatLoading = false;

    async function loadQuickQuestions() {
        try {
            const response = await fetch('/api/chatbot/quick-questions');
            const data = await response.json();

            const quickQuestionsDiv = document.getElementById('quickQuestions');
            if (data.questions && data.questions.length > 0) {
                quickQuestionsDiv.innerHTML = data.questions.map(q =>
                    \`<button class="quick-question-btn" onclick="askQuestion('\${q.text}')">\${q.emoji} \${q.text}</button>\`
                ).join('');
            }
        } catch (error) {
            console.error('Failed to load quick questions:', error);
        }
    }

    function toggleChatModal() {
        const modal = document.getElementById('chatModal');
        modal.classList.toggle('active');

        // Load quick questions on first open
        if (modal.classList.contains('active') && document.getElementById('quickQuestions').children.length === 0) {
            loadQuickQuestions();
        }
    }

    function handleChatEnter(event) {
        if (event.key === 'Enter' && !isChatLoading) {
            sendMessage();
        }
    }

    function askQuestion(question) {
        document.getElementById('chatInput').value = question;
        sendMessage();
    }

    async function sendMessage() {
        const input = document.getElementById('chatInput');
        const sendBtn = document.getElementById('chatSendBtn');
        const question = input.value.trim();

        if (!question || isChatLoading) return;

        // Add user message
        addMessage(question, 'user');
        input.value = '';

        // Disable input
        isChatLoading = true;
        sendBtn.disabled = true;

        // Add loading message
        const loadingId = addMessage('답변을 생성하는 중...', 'bot', true);

        try {
            const response = await fetch('/api/chatbot/ask', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ question })
            });

            const data = await response.json();

            // Remove loading message
            document.getElementById(loadingId).remove();

            // Add bot response
            if (data.success) {
                addMessage(data.answer, 'bot');
            } else {
                addMessage(data.answer || 'AI 챗봇 서비스에 연결할 수 없습니다.', 'bot');
            }

        } catch (error) {
            console.error('Chat error:', error);
            document.getElementById(loadingId).remove();
            addMessage('죄송합니다. 오류가 발생했습니다.', 'bot');
        } finally {
            isChatLoading = false;
            sendBtn.disabled = false;
        }
    }

    function addMessage(text, type, isLoading = false) {
        const messagesDiv = document.getElementById('chatMessages');
        const messageDiv = document.createElement('div');
        const id = \`msg-\${Date.now()}\`;

        messageDiv.id = id;
        messageDiv.className = \`\${type}-message\`;
        messageDiv.innerHTML = \`
            <div class="message-bubble \${isLoading ? 'loading' : ''}">
                \${text}
            </div>
        \`;

        messagesDiv.appendChild(messageDiv);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;

        return id;
    }

    // AI Service Status Monitoring
    let aiServiceStatus = { status: 'unknown', reason: '', health: {} };

    async function checkAIServiceStatus() {
        try {
            const response = await fetch('/api/ai/status');
            const data = await response.json();

            if (data.success) {
                aiServiceStatus = data.data;
                updateFABStatus(data.data);
            }
        } catch (error) {
            console.error('Failed to check AI status:', error);
            aiServiceStatus = { status: 'unknown', reason: 'Connection failed' };
            updateFABStatus(aiServiceStatus);
        }
    }

    function updateFABStatus(status) {
        const fab = document.getElementById('chatFab');
        if (!fab) return;

        // Remove all status classes
        fab.classList.remove('status-active', 'status-paused', 'status-stopped', 'status-unknown');

        // Add current status class
        fab.classList.add(\`status-\${status.status}\`);

        // Update tooltip/title
        const statusMessages = {
            'active': '✅ AI 챗봇 사용 가능',
            'paused': '⚠️ 챗봇 일시정지 (메모리 부족)',
            'stopped': '🔴 챗봇 사용 불가',
            'unknown': '❓ 상태 확인 중'
        };

        fab.title = statusMessages[status.status] || '챗봇 상태 확인 중';

        // Update FAB icon based on status
        const fabIcon = fab.querySelector('span');
        if (fabIcon) {
            if (status.status === 'active') {
                fabIcon.textContent = '💬';
            } else if (status.status === 'paused') {
                fabIcon.textContent = '⏸️';
            } else if (status.status === 'stopped') {
                fabIcon.textContent = '🔴';
            } else {
                fabIcon.textContent = '❓';
            }
        }
    }

    // Check AI status on page load
    checkAIServiceStatus();

    // Check AI status every 30 seconds
    setInterval(checkAIServiceStatus, 30000);

    // Override toggleChatModal to check AI status
    const originalToggleChatModal = toggleChatModal;
    toggleChatModal = function() {
        // Check if AI is available
        if (aiServiceStatus.status === 'paused' || aiServiceStatus.status === 'stopped') {
            const message = aiServiceStatus.status === 'paused'
                ? \`AI 챗봇이 일시적으로 사용 중지되었습니다.\\n\\n사유: \${aiServiceStatus.reason || '메모리 부족'}\\n\\n메모리 확보 후 자동으로 재시작됩니다.\`
                : \`AI 챗봇을 사용할 수 없습니다.\\n\\n사유: \${aiServiceStatus.reason || '서비스 중지'}\`;

            alert(message);
            return;
        }

        // If active, proceed with original function
        originalToggleChatModal();
    };
    </script>

</body>
</html>
  `;

    res.send(html);
  } catch (error) {
    console.error('[Dashboard] Error rendering dashboard:', error);
    res.status(500).send('Internal Server Error');
  }
});

// ==========================================
// API Endpoints
// ==========================================

app.get('/api/projects', async (req, res) => {
  try {
    const { status, category, developer, search } = req.query;

    const PROJECTS = await getProjects();
    let filtered = [...PROJECTS];

    if (status) {
      filtered = filtered.filter(p => p.status === status);
    }

    if (category) {
      filtered = filtered.filter(p => p.category === category);
    }

    if (developer) {
      filtered = filtered.filter(p => p.developer === developer);
    }

    if (search) {
      filtered = searchProjects(PROJECTS, search);
    }

    res.json({
      success: true,
      data: filtered,
      count: filtered.length,
      total: PROJECTS.length
    });
  } catch (error) {
    console.error('[API] /api/projects error:', error);
    res.status(500).json({ success: false, error: 'Failed to load projects' });
  }
});

app.get('/api/projects/:id', async (req, res) => {
  try {
    const PROJECTS = await getProjects();
    const project = PROJECTS.find(p => p.id === req.params.id);

    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }

    const releaseNotes = getReleaseNotesByProject(project.id);
    const developer = DEVELOPERS.find(d => d.id === project.developer);

    res.json({
      success: true,
      data: {
        ...project,
        developer: developer,
        releaseNotes: releaseNotes
      }
    });
  } catch (error) {
    console.error('[API] /api/projects/:id error:', error);
    res.status(500).json({ success: false, error: 'Failed to load project' });
  }
});

// Admin-only API: Developers information
app.get('/api/developers', requireAdmin, async (req, res) => {
  try {
    const PROJECTS = await getProjects();
    const developersWithProjects = DEVELOPERS.map(dev => ({
      ...dev,
      projects: getProjectsByDeveloper(PROJECTS, dev.id),
      projectCount: getProjectsByDeveloper(PROJECTS, dev.id).length
    }));

    res.json({
      success: true,
      data: developersWithProjects,
      count: DEVELOPERS.length
    });
  } catch (error) {
    console.error('[API] /api/developers error:', error);
    res.status(500).json({ success: false, error: 'Failed to load developers' });
  }
});

app.get('/api/releases', (req, res) => {
  const { projectId, type } = req.query;

  let filtered = [...RELEASE_NOTES];

  if (projectId) {
    filtered = getReleaseNotesByProject(projectId);
  }

  if (type) {
    filtered = filtered.filter(rn => rn.type === type);
  }

  res.json({
    success: true,
    data: filtered.sort((a, b) => new Date(b.date) - new Date(a.date)),
    count: filtered.length
  });
});

// Admin-only API: Statistics
app.get('/api/stats', requireAdmin, async (req, res) => {
  try {
    const PROJECTS = await getProjects();
    const stats = getProjectStats(PROJECTS);

    res.json({
      success: true,
      data: {
        ...stats,
        developers: DEVELOPERS.length,
        releases: RELEASE_NOTES.length,
        categories: Object.keys(stats.byCategory)
      }
    });
  } catch (error) {
    console.error('[API] /api/stats error:', error);
    res.status(500).json({ success: false, error: 'Failed to load stats' });
  }
});

app.get('/api/info', (req, res) => {
  res.json({
    name: 'Dashboard API',
    version: '2.1.0',
    environment: process.env.NODE_ENV || 'development',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    stats: getProjectStats()
  });
});

// Login page
app.get('/login', (req, res) => {
  // Redirect if already logged in
  if (req.session && req.session.userId) {
    return res.redirect('/');
  }

  const html = require('./views/login.js');
  res.send(html);
});

// Admin-only API: System status
app.get('/api/system/status', requireAdmin, (req, res) => {
  res.json({
    success: true,
    data: {
      server: {
        ip: '203.245.30.6',
        environment: 'Docker + Docker Compose',
        proxy: 'nginx (Port-based routing)',
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        nodeVersion: process.version
      },
      services: {
        database: 'PostgreSQL 15',
        cache: 'Redis 7',
        nginx: 'Port 80',
        dashboard: 'Port 3000'
      },
      activeProjects: PROJECTS.filter(p => p.status === 'active').map(p => ({
        name: p.name,
        port: p.port,
        status: p.status
      }))
    }
  });
});

// Database connection test
db.testConnection().then(connected => {
  if (connected) {
    console.log('[DB] PostgreSQL connection established');
  } else {
    console.error('[DB] Failed to connect to PostgreSQL');
  }
}).catch(err => {
  console.error('[DB] Database connection error:', err.message);
});

// Start server
app.listen(PORT, '0.0.0.0', async () => {
  console.log(`Dashboard server is running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);

  try {
    const projects = await getProjects();
    console.log(`Projects: ${projects.length}`);
  } catch (error) {
    console.error(`Failed to load projects count:`, error.message);
  }

  console.log(`Developers: ${DEVELOPERS.length}`);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM signal received: closing HTTP server');
  await db.close();
  process.exit(0);
});
