# Dashboard v2.0 - 프로젝트 관리 대시보드

## 📋 개요

다중 프로젝트 배포 환경을 관리하는 통합 대시보드입니다. 포트 기반 라우팅으로 배포된 여러 프로젝트를 한 곳에서 관리하고, 개발자별/카테고리별로 프로젝트를 분류하며, 릴리즈 히스토리를 추적할 수 있습니다.

**접속 URL**: http://203.245.30.6:80

## 🚀 주요 기능

### 1. 왼쪽 사이드바 네비게이션
- **고정 사이드바** (280px): 스크롤 가능한 메뉴
- **실시간 검색**: 프로젝트명, 설명, 태그로 즉시 필터링
- **Badge 카운터**: 각 카테고리별 프로젝트 개수 표시
- **Active 상태**: 현재 보고 있는 뷰 하이라이트

### 2. 프로젝트 관리
- **전체 프로젝트**: 모든 프로젝트 카드 뷰
- **상태별 필터**: 운영중 / 개발중 / 유지보수 / 아카이브
- **카테고리별 필터**: Full-stack / Frontend / Backend / Tools
- **프로젝트 카드**: 상태, 기술 스택, 개발자, 배포일, 방문 버튼

### 3. 개발자 노트
- **릴리즈 노트**: 버전별 변경사항 (major/minor/patch)
- **개발자별 뷰**: 팀별로 그룹화된 프로젝트 목록
- **타임라인**: 배포 날짜순 히스토리

### 4. 시스템 모니터링
- **통계 대시보드**: 프로젝트 현황, 카테고리 분포
- **시스템 상태**: 전체 서비스 상태 확인

## 🏗️ 데이터 구조

### DEVELOPERS 배열
개발자/팀 정보를 관리합니다.

```javascript
const DEVELOPERS = [
  {
    id: 'team-a',              // 개발자/팀 ID (고유값)
    name: 'Team A',            // 표시 이름
    avatar: '👨‍💻',            // 아바타 이모지
    role: 'Full-stack',        // 역할/전문분야
    color: '#667eea'           // 테마 색상 (헥스코드)
  }
];
```

**필드 설명**:
- `id`: 다른 데이터와 연결할 고유 식별자
- `name`: UI에 표시될 개발자/팀 이름
- `avatar`: 이모지 아바타 (선택사항)
- `role`: 역할 또는 전문 분야
- `color`: 개발자별 색상 테마

### PROJECTS 배열
배포된 프로젝트 정보를 관리합니다.

```javascript
const PROJECTS = [
  {
    id: 'lotto-master',                    // 프로젝트 ID (고유값)
    name: 'LottoMaster',                   // 프로젝트명
    emoji: '🎰',                           // 아이콘 이모지
    description: '데이터 기반 로또 번호 추천',  // 간단한 설명
    url: 'http://203.245.30.6:3001',       // 접속 URL
    port: 3001,                            // 포트 번호
    status: 'active',                      // 상태: active, development, maintenance, archived
    category: 'full-stack',                // 카테고리: full-stack, frontend, backend, tools
    tags: ['Next.js', 'TypeScript'],       // 기술 스택 태그
    developer: 'team-a',                   // 개발자 ID (DEVELOPERS 참조)
    version: '1.0.0',                      // 현재 버전
    deployedAt: '2025-10-16',             // 배포일 (YYYY-MM-DD)
    repository: null,                      // GitHub URL (선택)
    docs: null                             // 문서 URL (선택)
  }
];
```

**필드 설명**:
- `id`: 프로젝트 고유 식별자 (kebab-case 권장)
- `name`: UI에 표시될 프로젝트명
- `emoji`: 프로젝트 아이콘 (이모지)
- `description`: 한 줄 설명 (검색에 사용됨)
- `url`: 실제 서비스 접속 URL
- `port`: nginx 프록시 포트 번호
- `status`: 프로젝트 상태
  - `active`: 운영중
  - `development`: 개발중
  - `maintenance`: 유지보수
  - `archived`: 아카이브됨
- `category`: 프로젝트 유형
  - `full-stack`: 풀스택 애플리케이션
  - `frontend`: 프론트엔드 앱
  - `backend`: 백엔드 API
  - `tools`: 개발 도구/유틸리티
- `tags`: 기술 스택 배열 (검색에 사용됨)
- `developer`: 담당 개발자 ID (DEVELOPERS.id 참조)
- `version`: 시맨틱 버저닝 (major.minor.patch)
- `deployedAt`: 최초 배포일
- `repository`: GitHub 등 저장소 URL (선택)
- `docs`: 문서 링크 (선택)

### RELEASE_NOTES 배열
프로젝트별 릴리즈 히스토리를 관리합니다.

```javascript
const RELEASE_NOTES = [
  {
    id: 1,                                  // 릴리즈 노트 ID
    projectId: 'lotto-master',              // 프로젝트 ID (PROJECTS 참조)
    version: '1.0.0',                       // 릴리즈 버전
    date: '2025-10-16',                     // 릴리즈 날짜
    type: 'major',                          // 릴리즈 타입: major, minor, patch
    developer: 'team-a',                    // 릴리즈 담당자
    title: 'LottoMaster 초기 릴리즈',         // 릴리즈 제목
    changes: [                              // 변경사항 목록
      {
        type: 'feature',                    // 변경 타입: feature, tech, fix
        description: '번호 생성 기능'         // 변경 내용
      }
    ]
  }
];
```

**필드 설명**:
- `id`: 릴리즈 노트 고유 번호
- `projectId`: 해당 프로젝트 ID (PROJECTS.id 참조)
- `version`: 릴리즈 버전 (시맨틱 버저닝)
- `date`: 릴리즈 날짜 (YYYY-MM-DD)
- `type`: 릴리즈 타입
  - `major`: 주요 버전 (1.0.0, 2.0.0)
  - `minor`: 마이너 버전 (1.1.0, 1.2.0)
  - `patch`: 패치 버전 (1.0.1, 1.0.2)
- `developer`: 릴리즈 담당자 ID
- `title`: 릴리즈 제목 (한 줄 요약)
- `changes`: 변경사항 배열
  - `type`: 변경 타입
    - `feature`: 새 기능 추가
    - `tech`: 기술적 개선
    - `fix`: 버그 수정
  - `description`: 변경 내용 설명

### SYSTEM_NOTES 배열
시스템 전체 공지사항을 관리합니다.

```javascript
const SYSTEM_NOTES = [
  {
    id: 1,
    date: '2025-10-16',
    type: 'info',                          // info, warning, success
    title: '대시보드 v2.0 릴리즈',
    description: '사이드바 메뉴 추가'
  }
];
```

## 🔌 API 엔드포인트

### GET /api/projects
모든 프로젝트 또는 필터링된 프로젝트 목록

**Query Parameters**:
- `status`: 상태 필터 (active, development, maintenance, archived)
- `category`: 카테고리 필터 (full-stack, frontend, backend, tools)
- `developer`: 개발자 ID 필터
- `search`: 검색어 (프로젝트명, 설명, 태그에서 검색)

**예시**:
```bash
# 모든 프로젝트
curl http://203.245.30.6/api/projects

# 운영중인 프로젝트만
curl http://203.245.30.6/api/projects?status=active

# Full-stack 카테고리
curl http://203.245.30.6/api/projects?category=full-stack

# Team A의 프로젝트
curl http://203.245.30.6/api/projects?developer=team-a

# Next.js 검색
curl http://203.245.30.6/api/projects?search=next.js
```

**응답**:
```json
{
  "success": true,
  "data": [...],
  "count": 1,
  "total": 1
}
```

### GET /api/projects/:id
특정 프로젝트 상세 정보 (릴리즈 노트 포함)

**예시**:
```bash
curl http://203.245.30.6/api/projects/lotto-master
```

**응답**:
```json
{
  "success": true,
  "data": {
    "project": {...},
    "releases": [...]
  }
}
```

### GET /api/developers
개발자 목록 (담당 프로젝트 포함)

**예시**:
```bash
curl http://203.245.30.6/api/developers
```

**응답**:
```json
{
  "success": true,
  "data": [
    {
      "id": "team-a",
      "name": "Team A",
      "projects": [...],
      "projectCount": 1
    }
  ],
  "count": 2
}
```

### GET /api/releases
릴리즈 노트 목록

**Query Parameters**:
- `projectId`: 특정 프로젝트의 릴리즈만
- `type`: 릴리즈 타입 필터 (major, minor, patch)

**예시**:
```bash
# 모든 릴리즈
curl http://203.245.30.6/api/releases

# LottoMaster 릴리즈만
curl http://203.245.30.6/api/releases?projectId=lotto-master

# Major 릴리즈만
curl http://203.245.30.6/api/releases?type=major
```

### GET /api/stats
통계 정보

**예시**:
```bash
curl http://203.245.30.6/api/stats
```

**응답**:
```json
{
  "success": true,
  "data": {
    "total": 1,
    "active": 1,
    "development": 0,
    "byCategory": {
      "full-stack": 1,
      "frontend": 0,
      "backend": 0,
      "tools": 0
    },
    "developers": 2,
    "releases": 1,
    "categories": ["full-stack", "frontend", "backend", "tools"]
  }
}
```

### GET /api/info
대시보드 정보

**예시**:
```bash
curl http://203.245.30.6/api/info
```

## 📝 새 프로젝트 추가 가이드

### 1단계: 개발자 등록 (신규 팀인 경우)

`server.js`의 `DEVELOPERS` 배열에 추가:

```javascript
const DEVELOPERS = [
  // ... 기존 개발자들
  {
    id: 'team-c',              // 고유 ID (kebab-case)
    name: 'Team C',            // 팀명
    avatar: '🧑‍💻',            // 이모지
    role: 'Backend',           // 역할
    color: '#4facfe'           // 색상
  }
];
```

### 2단계: 프로젝트 정보 등록

`PROJECTS` 배열에 추가:

```javascript
const PROJECTS = [
  // ... 기존 프로젝트들
  {
    id: 'my-new-project',                      // 프로젝트 ID
    name: 'MyNewProject',                      // 프로젝트명
    emoji: '🚀',                               // 아이콘
    description: '새로운 프로젝트 설명',          // 설명
    url: 'http://203.245.30.6:3004',           // URL
    port: 3004,                                // 포트
    status: 'development',                     // 상태
    category: 'backend',                       // 카테고리
    tags: ['Node.js', 'Express', 'MongoDB'],   // 기술 스택
    developer: 'team-c',                       // 개발자 ID
    version: '0.1.0',                          // 초기 버전
    deployedAt: '2025-10-17',                  // 배포일
    repository: 'https://github.com/...',      // 저장소 (선택)
    docs: 'https://docs.example.com'           // 문서 (선택)
  }
];
```

### 3단계: 릴리즈 노트 작성

`RELEASE_NOTES` 배열에 추가:

```javascript
const RELEASE_NOTES = [
  // ... 기존 릴리즈 노트들
  {
    id: 2,                                     // 다음 ID 번호
    projectId: 'my-new-project',               // 프로젝트 ID
    version: '0.1.0',                          // 버전
    date: '2025-10-17',                        // 날짜
    type: 'minor',                             // 타입
    developer: 'team-c',                       // 담당자
    title: 'MyNewProject 초기 개발 버전',         // 제목
    changes: [
      { type: 'feature', description: 'API 엔드포인트 구현' },
      { type: 'tech', description: 'MongoDB 연동' }
    ]
  }
];
```

### 4단계: nginx 설정

`/home/deploy/nginx/conf.d/port-based.conf`에 서버 블록 추가:

```nginx
# My New Project - Port 3004
server {
    listen 3004;
    server_name _;

    # Korean IP Whitelist
    include /etc/nginx/conf.d/korean-ips.conf;

    location / {
        limit_req zone=api burst=20 nodelay;

        proxy_pass http://172.20.0.14:8080;  # 컨테이너 IP:포트
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### 5단계: docker-compose.yml 설정

서비스 추가:

```yaml
services:
  my-new-project:
    build:
      context: ./projects/my-new-project
      dockerfile: Dockerfile.prod
    container_name: my-new-project
    restart: unless-stopped
    networks:
      app-network:
        ipv4_address: 172.20.0.14
    environment:
      - NODE_ENV=production
      - PORT=8080
```

### 6단계: 배포

```bash
# 대시보드 재빌드
cd /home/deploy
docker compose build dashboard
docker compose up -d dashboard

# nginx 재시작
docker compose restart nginx

# 새 프로젝트 배포
docker compose up -d my-new-project
```

## 🔄 버전 업데이트 가이드

프로젝트를 업데이트할 때:

### 1. PROJECTS 배열에서 version 업데이트
```javascript
{
  id: 'lotto-master',
  // ...
  version: '1.1.0',  // 1.0.0 → 1.1.0
}
```

### 2. RELEASE_NOTES에 새 항목 추가
```javascript
{
  id: 3,                           // 새 ID
  projectId: 'lotto-master',
  version: '1.1.0',               // 새 버전
  date: '2025-10-17',             // 오늘 날짜
  type: 'minor',                  // major/minor/patch
  developer: 'team-a',
  title: '검색 기능 추가',
  changes: [
    { type: 'feature', description: '당첨 번호 검색 기능' },
    { type: 'fix', description: '통계 계산 버그 수정' }
  ]
}
```

### 3. 대시보드 재배포
```bash
docker compose build dashboard
docker compose up -d dashboard
```

## 🎨 UI/UX 커스터마이징

### 색상 테마 변경

`server.js`의 CSS 변수 수정:

```css
:root {
  --primary: #667eea;           /* 주 색상 */
  --primary-dark: #5568d3;      /* 어두운 주 색상 */
  --sidebar-bg: #1e293b;        /* 사이드바 배경 */
  --sidebar-hover: #334155;     /* 사이드바 호버 */
}
```

### 사이드바 너비 변경

```css
.sidebar {
  width: 280px;  /* 원하는 너비로 변경 */
}

.main-content {
  margin-left: 280px;  /* 사이드바 너비와 동일하게 */
}
```

## 🔍 검색 기능

검색은 다음 필드에서 작동합니다:
- 프로젝트명 (`name`)
- 프로젝트 설명 (`description`)
- 기술 스택 태그 (`tags`)

검색어는 대소문자 구분 없이 부분 일치로 작동합니다.

## 📊 통계 및 모니터링

대시보드는 다음 통계를 자동으로 계산합니다:
- 전체 프로젝트 수
- 상태별 프로젝트 수 (운영중/개발중)
- 카테고리별 분포
- 개발자별 프로젝트 수
- 전체 릴리즈 수

## 🐳 Docker 구성

### Dockerfile
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --only=production
COPY server.js ./
COPY public/ ./public/
RUN addgroup -g 1001 -S nodejs && adduser -S nodejs -u 1001
RUN chown -R nodejs:nodejs /app
USER nodejs
EXPOSE 3000
CMD ["node", "server.js"]
```

### docker-compose.yml
```yaml
dashboard:
  build:
    context: ./projects/dashboard
    dockerfile: Dockerfile
  container_name: dashboard
  restart: unless-stopped
  networks:
    app-network:
      ipv4_address: 172.20.0.10
  environment:
    - NODE_ENV=production
    - PORT=3000
```

## 🔒 보안

- **IP 화이트리스트**: 한국 IP만 접속 가능 (nginx 설정)
- **Rate Limiting**: API 요청 제한
- **Docker 네트워크**: 내부 네트워크로 격리
- **Non-root 사용자**: nodejs 계정으로 실행

## 📚 기술 스택

- **Backend**: Node.js + Express.js
- **Frontend**: Vanilla JavaScript (템플릿 리터럴)
- **Containerization**: Docker
- **Reverse Proxy**: Nginx
- **Styling**: CSS3 (Grid, Flexbox, Custom Properties)

## 🛠️ 유지보수

### 로그 확인
```bash
docker compose logs dashboard
docker compose logs --tail=50 dashboard
```

### 재시작
```bash
docker compose restart dashboard
```

### 전체 재배포
```bash
docker compose down dashboard
docker compose up -d dashboard
```

## 📞 문제 해결

### 대시보드가 표시되지 않음
1. 컨테이너 상태 확인: `docker compose ps`
2. 로그 확인: `docker compose logs dashboard`
3. nginx 설정 확인: `docker compose logs nginx`

### 프로젝트가 목록에 없음
1. `PROJECTS` 배열에 제대로 추가되었는지 확인
2. 대시보드 재빌드 및 재시작
3. 브라우저 캐시 삭제

### API가 동작하지 않음
1. API 엔드포인트 확인: `curl http://localhost/api/projects`
2. nginx 프록시 설정 확인
3. 컨테이너 네트워크 확인

## 📄 라이센스

Internal Use Only

## 👥 기여자

- Team A - LottoMaster 개발
- Team B - 대시보드 v2.0 개발

---

**마지막 업데이트**: 2025-10-16
**버전**: 2.0.0
**문의**: 시스템 관리자
