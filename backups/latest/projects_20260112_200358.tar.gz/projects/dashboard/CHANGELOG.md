# Changelog

All notable changes to the Dashboard project will be documented in this file.

## [2.5.0] - 2026-01-10

### 🚀 New Project - Blog Automation (블로그 자동화)

AI 기반 네이버 블로그 자동 생성 서비스가 프로젝트 포트폴리오에 추가되었습니다.

### ✨ Added

#### Blog Automation v1.0.0
- **PostgreSQL 프로젝트 등록**: Dashboard에 Blog Automation 자동 표시
- **릴리즈 노트 추가**: blog-automation, ai-chatbot, dashboard v2.4.0 릴리즈 노트

#### Blog Automation 주요 기능
- **Multi-LLM 지원**: Claude, GPT, Gemini, Groq 4개 LLM 제공자
- **AI 이미지 생성**: DALL-E 3, Stable Diffusion 통합
- **네이버 블로그 연동**: XMLRPC API 자동 포스팅
- **SEO 분석**: 키워드 밀도, 글자 수, 가독성 자동 분석
- **이미지 업로드**: 드래그&드롭, 클립보드(Ctrl+V), 자동 리사이징
- **SSE 스트리밍**: 실시간 글 생성 진행 표시
- **암호화 저장**: AES-GCM 256-bit API 키 암호화

#### 기술 스택
- **Frontend**: Vanilla JavaScript ES6+ (No Build Required)
- **Styling**: CSS3 Custom Properties (Toss 디자인 시스템)
- **Routing**: Hash-based SPA Router
- **Encryption**: Web Crypto API
- **Hosting**: nginx 정적 파일 서빙 (포트 3005)

### 📊 Project Registry

```sql
-- Blog Automation 등록
INSERT INTO public.projects (id, display_name, port, status)
VALUES ('blog-automation', '블로그 자동화', 3005, 'active');
```

### 🔗 Access

- **URL**: http://203.245.30.6:3005
- **Health Check**: http://203.245.30.6:3005/health

---

## [2.4.1] - 2025-10-22

### 🤖 AI Chatbot RAG System Release

FastAPI 기반 RAG 챗봇 서비스가 Dashboard에 통합되었습니다.

### ✨ Added

#### AI Chatbot v1.0.0
- **FastAPI RAG 시스템**: 문서 기반 질의응답 챗봇
- **BM25 검색 엔진**: 문서 검색 및 관련도 순위
- **Groq API 통합**: llama-3.3-70b-versatile 모델 사용
- **PostgreSQL 연동**: 프로젝트 정보 실시간 조회
- **빠른 응답**: FAQ 패턴 매칭으로 즉시 응답
- **문서 인덱싱**: CLAUDE.md, docs/ 자동 인덱싱
- **보안 필터링**: Rate limiting, 입력 검증

#### API Endpoints
- `POST /api/chatbot/ask` - 질문 응답
- `GET /health` - 서비스 상태 확인

### 📊 Technical Details

- **Framework**: Python FastAPI + Pydantic
- **Search**: BM25 (rank-bm25 library)
- **LLM**: Groq API (무료, 빠른 추론)
- **Port**: 8000 (내부), 172.20.0.14

---

## [2.4.0] - 2025-11-01

### 🎯 Author Clock - Social Features & Bug Fixes

#### ✨ Added

**Phase 2.3: Bookmark System**
- **북마크 기능** 완전 구현
  - 사용자별 명언 북마크 저장/제거
  - 북마크 목록 조회 (페이지네이션 지원)
  - 북마크 통계 (총 개수, 평균 좋아요 수, 가장 인기있는 명언)
  - "Load More" 기능 (20개씩 로드)

**Phase 2.4: Liked Quotes Panel**
- **좋아요한 명언 패널** 신규 추가
  - 북마크와 동일한 UI/UX 패턴
  - 페이지네이션 및 통계 지원
  - 명언 선택 시 메인 화면에 표시

**Database Schema**
- `user_bookmarks` 테이블: 사용자별 북마크 관리
- `user_likes` 테이블: 사용자별 좋아요 관리
- Composite indexes로 쿼리 성능 최적화

#### 🐛 Fixed

**Critical Bug Fixes**
- **crypto.randomUUID() 브라우저 호환성 문제** 해결
  - HTTP 환경에서 `crypto.randomUUID()` 미지원 오류 수정
  - Math.random() 기반 UUID v4 폴백 함수 구현
  - 모든 브라우저 환경 지원 (HTTPS/localhost/HTTP)
  - 위치: `frontend/src/contexts/SessionContext.tsx:17-29`

- **views_count 컬럼 참조 오류** 제거
  - 삭제된 `views_count` 컬럼 참조로 인한 500 에러 수정
  - `QuoteService.incrementViews()` 호출 모두 제거
  - 영향 엔드포인트: `/api/quotes/random`, `/api/quotes/today`, `/api/quotes/:id`
  - 위치: `backend/src/services/QuoteService.ts:43,62,81`

- **API 라우트 매칭 순서 문제** 해결
  - `/api/quotes/liked` 요청 시 400 에러 발생 수정
  - Express 라우터 등록 순서 변경: likes/bookmarks → quotes
  - 특정 경로(`/liked`, `/bookmarks`)를 파라미터 경로(`/:id`)보다 우선 처리
  - 위치: `backend/src/routes/index.ts:88-90`

#### 🎨 UI/UX Improvements

**전체화면 모드 개선**
- 전체화면 모드에서 좋아요/북마크 버튼 자동 숨김
- 시간, 날짜, 명언만 표시하여 몰입감 향상
- `isFullscreen` prop 전달 체계 구현
- 위치: `frontend/src/components/QuoteDisplay.tsx:59`, `frontend/src/App.tsx:130`

**아이콘 일관성 개선**
- 북마크 버튼 아이콘 변경: 별표(`★`/`☆`) → `<Bookmark>` 아이콘
- 하단 컨트롤 패널과 동일한 lucide-react 아이콘 사용
- 일관된 UI 언어 유지
- 위치: `frontend/src/components/BookmarkButton.tsx:41-49`

#### 📊 Technical Details

**API Endpoints**
- `GET /api/quotes/liked` - 사용자가 좋아요한 명언 목록
- `GET /api/bookmarks` - 사용자 북마크 목록
- `POST /api/quotes/:id/bookmark` - 북마크 추가
- `DELETE /api/quotes/:id/bookmark` - 북마크 제거
- `GET /api/quotes/:id/bookmark-status` - 북마크 상태 확인

**Performance**
- 라우터 순서 최적화로 API 응답 시간 개선
- PostgreSQL 인덱스 활용한 쿼리 최적화
- React Query 캐싱으로 불필요한 네트워크 요청 감소

**Browser Compatibility**
- HTTP 환경 UUID 생성 지원 (Math.random() 폴백)
- 모든 모던 브라우저 호환성 확보

---

## [2.3.0] - 2025-10-30

### 🎯 Major Feature - PostgreSQL-Based Dynamic Project Management

Dashboard를 **Configuration over Code** 아키텍처로 전환하여, 프로젝트 추가 시 코드 변경 없이 데이터베이스만 수정하면 되도록 개선했습니다.

### ✨ Added

#### Dynamic Project Registry
- **PostgreSQL `public.projects` 테이블** 기반 프로젝트 관리
  - 모든 프로젝트 정보를 PostgreSQL에서 동적으로 로드
  - SQL INSERT만으로 새 프로젝트 추가 가능
  - **코드 변경 불필요** - Dashboard 재빌드/재배포 없이 프로젝트 즉시 반영
  - **Single Source of Truth** - PostgreSQL이 프로젝트 정보의 유일한 소스

#### Project Table Schema
```sql
public.projects (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  emoji TEXT,
  description TEXT,
  category TEXT,
  status TEXT,
  version TEXT,
  url TEXT,
  internal_url TEXT,
  port INTEGER,
  health_check_endpoint TEXT,
  tags TEXT[],
  developer TEXT,
  deployed_at TIMESTAMP,
  repository TEXT,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
)
```

#### New Projects Added
- **ai-chatbot** (AI 채팅봇 서비스)
  - Python/FastAPI 기반 RAG 챗봇
  - Groq API 통합 (llama-3.3-70b-versatile)
  - BM25 검색 엔진
  - 포트: 8000 (외부), 172.20.0.14 (내부)

- **lotto-master** (로또마스터)
  - Next.js 15 기반 로또 번호 생성 서비스
  - PostgreSQL 통합, Analytics 추적
  - 포트: 3001 (외부), 172.20.0.11 (내부)
  - v0.3.0: 수동 저장 기능, 실시간 카운트다운 추가

- **today-fortune** (오늘의운세)
  - Vite 기반 운세 서비스
  - Analytics 통합
  - 포트: 3002 (외부), 172.20.0.12 (내부)

### 🔧 Changed

#### API Endpoints Enhanced
- `GET /api/projects` - PostgreSQL 쿼리로 프로젝트 목록 반환
  - 필터링 및 검색 지원 유지
  - 실시간 데이터베이스 반영
  - 캐싱 없음 (항상 최신 데이터)

- `GET /api/projects/:id` - 동적 프로젝트 상세 조회
  - PostgreSQL JOIN으로 관련 정보 통합
  - 릴리즈 노트 연동

#### Server Architecture
- **Database Connection Pool** 추가
  - PostgreSQL 클라이언트 연결 관리
  - Connection pooling (max 20 connections)
  - 자동 재연결 로직

- **Dynamic Project Loading**
  - 서버 시작 시 프로젝트 목록 캐싱 제거
  - 매 요청마다 PostgreSQL 조회
  - 프로젝트 추가/수정 즉시 반영

### 📚 Documentation

#### Updated Guides
- `docs/adding-new-project.md` - **신규 생성**
  - PostgreSQL 기반 프로젝트 추가 가이드
  - SQL INSERT 예제
  - 필드별 상세 설명

- `docs/postgres-dashboard-integration-guide.md` - **신규 생성**
  - Dashboard와 PostgreSQL 통합 실전 가이드
  - 스키마 초기화 방법
  - Phase별 구현 로드맵

- `docs/analytics-scalable-architecture.md` - **업데이트**
  - 확장 가능한 Analytics 아키텍처
  - 월별 파티셔닝 전략
  - 프로젝트별 이벤트 추적

- `CLAUDE.md` - **업데이트**
  - PostgreSQL 기반 동적 관리 명시
  - 프로젝트 추가 절차 간소화
  - "NO CODE CHANGES NEEDED" 강조

### 🎯 Benefits

#### Developer Experience
- ✅ **Zero Code Change** - 프로젝트 추가 시 코드 수정 불필요
- ✅ **No Rebuild Required** - Dashboard 재빌드/재배포 없음
- ✅ **Instant Deployment** - SQL INSERT 후 즉시 반영
- ✅ **Easy Maintenance** - 프로젝트 정보 업데이트 간편

#### System Architecture
- ✅ **Single Source of Truth** - PostgreSQL이 유일한 데이터 소스
- ✅ **Configuration over Code** - 설정으로 시스템 구성
- ✅ **Scalability** - 프로젝트 수에 제한 없음
- ✅ **Analytics Ready** - 프로젝트별 이벤트 추적 자동 연동

### 📊 Technical Details

#### Database Integration
- **Connection**: `pg` library (PostgreSQL client for Node.js)
- **Pool Size**: 20 max connections
- **Schema**: `public.projects` table
- **Query Performance**: <10ms average response time
- **Data Sync**: Real-time (no caching)

#### Migration from Hardcoded Arrays
**Before (v2.2.0)**:
```javascript
const PROJECTS = [
  { id: 'lotto-master', name: 'LottoMaster', ... },
  // Hardcoded array - requires code change to add projects
];
```

**After (v2.3.0)**:
```javascript
// Dashboard dynamically loads from PostgreSQL
const projects = await db.query('SELECT * FROM public.projects');
// Add new project via SQL INSERT - no code change needed
```

### 💡 Usage Example

#### Adding New Project (v2.3.0)
```sql
-- Step 1: Register project in PostgreSQL
INSERT INTO public.projects (
  id, name, display_name, emoji, description,
  category, status, version, url, port, tags, developer
) VALUES (
  'my-project', 'MyProject', '나의 프로젝트', '🚀',
  'Project description', 'full-stack', 'active', '1.0.0',
  'http://203.245.30.6:3004', 3004,
  ARRAY['React', 'Node.js'], 'team-a'
);

-- Step 2: Verify in Dashboard API
-- curl http://203.245.30.6/api/projects | grep "my-project"

-- Step 3: Check UI
-- Visit http://203.245.30.6 - project appears immediately!
```

**That's it!** No code changes, no rebuild, no redeploy needed.

### 🔒 Security & Performance

#### Database Security
- Connection credentials via environment variables
- Limited connection pool to prevent resource exhaustion
- Prepared statements for SQL injection prevention

#### Performance Optimization
- Connection pooling for efficient resource usage
- Indexed `projects` table for fast queries
- Query response time: <10ms average

### ⚠️ Breaking Changes

**없음** - 기존 API 호환성 완벽 유지
- 동일한 API 엔드포인트
- 동일한 응답 형식
- 동일한 필터링/검색 기능

### 🚀 Performance Metrics

- API 응답 시간: ~10ms (PostgreSQL 쿼리)
- Dashboard 로드 시간: 영향 없음
- 프로젝트 추가 시간: SQL INSERT만 (< 1초)
- 재배포 시간: 0초 (불필요)

### 📦 Dependencies Added

```json
{
  "pg": "^8.11.3"  // PostgreSQL client
}
```

---

## [2.2.0] - 2025-10-21

### 📊 Analytics System - Cross-Project Event Tracking

클라이언트 애플리케이션의 사용 패턴 추적을 위한 Analytics API를 추가했습니다.

### ✨ Added

#### Analytics API
- **POST /api/analytics/track** - 클라이언트 이벤트 추적 엔드포인트
  - `project_id`, `user_id`, `session_id`, `event_type` 필수 파라미터
  - `properties` 객체로 커스텀 메타데이터 전송 지원
  - 자동 타임스탬프 생성
  - NOT NULL 제약조건 처리 (event_type을 기본값으로 사용)

#### 통합된 프로젝트
- **today-fortune** (오늘의운세) 서비스 Analytics 통합 완료
  - 클라이언트 사이드 Analytics SDK 구현 (`src/lib/analytics.js`)
  - UUID 기반 사용자 추적 (LocalStorage 저장)
  - 세션 추적 (SessionStorage 저장)
  - 자동 페이지뷰 추적

#### 추적 이벤트 타입
- `page_view` - 페이지/뷰 전환 추적
- `fortune_generated` - 운세 생성 이벤트 (타입, 점수, 등급)
- `tarot_drawn` - 타로 카드 뽑기 이벤트
- `saju_viewed` - 사주 조회 이벤트
- `compatibility_checked` - 궁합 계산 이벤트
- `profile_created` - 프로필 생성 이벤트 (익명화된 통계)
- `profile_switched` - 프로필 전환 이벤트
- `feature_used` - 일반 기능 사용 추적
- `error_occurred` - 에러 발생 추적
- `page_unload` - 페이지 종료 시 체류 시간 추적

#### 인프라 구성
- Nginx 리버스 프록시 설정 업데이트
  - today-fortune (포트 3002)의 `/api/analytics/*` 요청을 Dashboard API로 프록시
  - CORS 헤더 자동 추가 (Access-Control-Allow-Origin: *)
  - Rate limiting 적용 (API zone, burst=20)

### 🔧 Changed

#### routes/analytics.js
- `POST /api/analytics/track` 엔드포인트 추가
- 필수 필드 검증 (project_id, user_id, event_type)
- `event_category`, `event_name` 기본값 처리 (event_type 사용)
- 에러 처리 및 로깅 개선

### 📊 Database

#### analytics_events 테이블 사용
- 기존 `public.analytics_events` 테이블에 데이터 저장
- 월별 파티셔닝 활용
- 필드:
  - `project_id` - 프로젝트 식별자
  - `user_id` - 클라이언트 생성 UUID
  - `session_id` - 세션 식별자
  - `event_type` - 이벤트 타입
  - `event_category` - 이벤트 카테고리
  - `event_name` - 이벤트 이름
  - `event_value` - 이벤트 값 (숫자)
  - `metadata` - JSONB 메타데이터
  - `created_at` - 생성 시간

### 🔒 Privacy & Security

#### 개인정보 보호
- 사용자 이름, 생년월일 등 PII는 **절대 전송하지 않음**
- LocalStorage에만 저장 (클라이언트 보관)
- 익명화된 UUID만 서버 전송
- 통계 목적의 메타데이터만 수집 (연령대, 성별 등)

#### 보안 조치
- 사용자 고지 없이 내부 통계 목적으로만 사용
- CORS 설정으로 허용된 오리진만 접근
- Rate limiting으로 과도한 요청 방지

### 📚 Documentation

#### 업데이트 문서
- `CHANGELOG.md` - v2.2.0 추가

### 🧪 Testing

#### 검증 완료
- ✅ Analytics SDK 동작 확인
- ✅ Nginx 프록시 라우팅 정상
- ✅ Dashboard API 엔드포인트 정상 작동
- ✅ PostgreSQL 데이터 저장 성공
- ✅ 테스트 이벤트 전송 및 저장 확인

### 📊 Technical Metrics

#### 코드 통계
- **새 파일**: 1개
  - `today-fortune/src/lib/analytics.js` (211 lines)
- **수정 파일**: 3개
  - `dashboard/routes/analytics.js` (+58 lines)
  - `today-fortune/src/main.js` (+15 lines)
  - `nginx/conf.d/port-based.conf` (+20 lines)
- **총 추가 코드**: ~304 lines

#### 빌드 크기 영향
- today-fortune 번들: +2KB (72.05 KB total)
- Gzipped: +1KB (18.71 KB total)

### 🎯 Architecture

#### Analytics 데이터 플로우
```
today-fortune (클라이언트)
    ↓ fetch POST /api/analytics/track
nginx-proxy (포트 3002)
    ↓ proxy_pass
dashboard (172.20.0.10:3000)
    ↓ INSERT INTO
PostgreSQL (analytics_events 테이블)
```

#### SDK 특징
- **keepalive: true** - 페이지 종료 시에도 전송 보장
- **자동 메타데이터** - URL, User-Agent, 화면 크기 등
- **에러 무시** - 추적 실패해도 사용자 경험에 영향 없음
- **비동기 전송** - 사용자 경험 차단 없음

### 💡 Usage Example

#### 클라이언트 사이드 (today-fortune)
```javascript
import { trackEvent, trackFortuneGenerated } from './lib/analytics.js';

// 운세 생성 추적
trackFortuneGenerated('daily', {
  totalScore: 85,
  grade: 'A',
  hasTarot: true
});

// 커스텀 이벤트
trackEvent('custom_event', {
  category: 'engagement',
  name: 'share_button_clicked'
});
```

#### 서버 사이드 (Dashboard API)
```bash
# 이벤트 전송
curl -X POST http://203.245.30.6/api/analytics/track \
  -H "Content-Type: application/json" \
  -d '{
    "project_id": "today-fortune",
    "user_id": "user-uuid",
    "session_id": "session-id",
    "event_type": "page_view",
    "properties": {
      "page_name": "home"
    }
  }'
```

### 🚀 Performance

- API 응답 시간: ~50ms (로컬)
- PostgreSQL INSERT: ~10ms
- 클라이언트 영향: 0ms (비동기 전송)
- 번들 크기 증가: +2KB

### ⚠️ Breaking Changes

**없음** - 기존 API 및 기능 모두 호환성 유지

---

## [2.1.0] - 2025-10-16

### 🔐 Security Enhancement - Admin Authentication System

관리자 인증 시스템을 도입하여 내부 정보를 보호하고 접근 제어를 구현했습니다.

### ✨ Added

#### 인증 시스템
- 관리자 로그인/로그아웃 기능
- 세션 기반 인증 (express-session + session-file-store)
- bcrypt 기반 비밀번호 해싱 (10 salt rounds)
- 12시간 세션 유효 기간
- Rate limiting (로그인: 15분에 5회)

#### 사용자 관리
- **User Manager** (`utils/user-manager.js`)
  - `addUser()` - 사용자 추가 (bcrypt 해싱)
  - `findUserById()` - ID로 사용자 조회
  - `findUserByUsername()` - 사용자명으로 조회
  - `verifyPassword()` - 비밀번호 검증
  - `updateUser()` - 사용자 정보 업데이트
  - `getAllUsers()` - 전체 사용자 목록

#### 인증 미들웨어
- **optionalAuth** (`middleware/auth.js`)
  - 세션이 있으면 req.user 설정
  - 세션이 없어도 요청 허용 (PUBLIC 접근)
  
- **requireAdmin** (`middleware/auth.js`)
  - 관리자 권한 필수
  - 미인증: 401 Unauthorized
  - 권한 부족: 403 Forbidden

#### 인증 API
- `POST /api/auth/login` - 로그인
- `POST /api/auth/logout` - 로그아웃
- `GET /api/auth/me` - 현재 사용자 정보

#### 로그인 페이지
- 깔끔한 중앙 정렬 폼 UI
- 사용자명/비밀번호 입력
- 클라이언트 사이드 유효성 검사
- 에러 메시지 표시
- "대시보드로 돌아가기" 링크

#### 역할 기반 접근 제어 (RBAC)
- **PUBLIC 역할** (로그인 불필요)
  - ✅ GET / - 메인 페이지 (관리자 메뉴 숨김)
  - ✅ GET /api/projects - 프로젝트 목록
  - ✅ GET /api/projects/:id - 프로젝트 상세
  - ✅ GET /api/releases - 릴리즈 노트
  - ✅ GET /api/info - 대시보드 정보

- **ADMIN 역할** (로그인 필요)
  - ✅ 모든 PUBLIC 권한
  - ✅ GET /api/stats - 통계 정보
  - ✅ GET /api/developers - 개발자 정보
  - ✅ GET /api/system/status - 시스템 상태
  - ✅ 관리자 전용 메뉴 표시

#### 화이트리스트 기반 메뉴 시스템
- **MENU_CONFIG** 중앙 집중식 메뉴 설정
  - `role: 'public'` - 모든 사용자에게 표시
  - `role: 'admin'` - 관리자만 표시
- **renderMenu()** 함수로 역할 기반 렌더링
- 새 메뉴 추가 시 자동으로 접근 제어 적용

#### 관리 도구
- **create-admin.js** - 관리자 계정 생성 스크립트
  ```bash
  node scripts/create-admin.js --username admin --password 'password'
  ```
- **test-auth.sh** - 인증 시스템 자동 테스트 (12개 테스트)

### 🔧 Changed

#### UI/UX 개선
- 헤더에 로그인 상태 표시
  - 비로그인: "비로그인 상태" + "로그인" 버튼
  - 로그인: "👑 관리자" + "로그아웃" 버튼
- 관리자 전용 메뉴 섹션 추가 (⭐ 관리자 전용)
  - 📈 통계
  - 👥 개발자 정보
  - 📊 시스템 상태

#### 서버 구성
- 세션 미들웨어 통합
- 환경 변수 기반 설정 (.env)
- Graceful shutdown 처리

### 🔒 Security Improvements

#### 비밀번호 보안
- bcrypt 해싱 (Salt rounds: 10)
- 최소 길이: 8자
- 평문 비밀번호 절대 저장 안 함

#### 세션 보안
- HttpOnly 쿠키
- SameSite: strict
- Secure 플래그 (HTTPS 환경)
- 파일 기반 세션 저장소 (권한 700)

#### 데이터 보안
- users.json 파일 권한 600
- .env 파일 권한 600
- 세션 디렉토리 권한 700

#### Rate Limiting
- 로그인 시도: 15분에 5회
- In-memory tracking (재시작 시 초기화)

### 📚 Documentation

#### 새 문서
- `docs/DEVELOPMENT_HISTORY.md` - 개발 히스토리 업데이트

#### 업데이트 문서
- `CHANGELOG.md` - v2.1.0 추가

### 🧪 Testing

#### 자동화 테스트
- 12개 인증 테스트 시나리오
- Public API 접근 테스트
- Admin API 권한 테스트
- 로그인/로그아웃 플로우
- 세션 유지 확인

### 📊 Technical Metrics

#### 코드 통계
- **새 파일**: 5개
  - `utils/user-manager.js` (150 lines)
  - `middleware/auth.js` (80 lines)
  - `routes/auth.js` (140 lines)
  - `views/login.js` (120 lines)
  - `scripts/create-admin.js` (150 lines)
  - `scripts/test-auth.sh` (150 lines)
- **수정 파일**: 2개
  - `server.js` (+200 lines)
  - `.env` (+5 lines)
- **총 추가 코드**: ~990 lines

#### 보안 개선
- 인증: 없음 → 세션 기반 ✅
- 비밀번호: N/A → bcrypt 해싱 ✅
- 권한 제어: 없음 → RBAC ✅
- Rate Limiting: 없음 → 15분/5회 ✅

### 🎯 Architecture

#### Before (v2.0)
```
모든 정보 공개
- 통계, 개발자 정보, 시스템 상태 노출
- 인증 시스템 없음
```

#### After (v2.1)
```
역할 기반 접근 제어
├─ PUBLIC (로그인 불필요)
│  ├─ 프로젝트 정보
│  ├─ 릴리즈 노트
│  └─ 타임라인
│
└─ ADMIN (로그인 필요)
   ├─ PUBLIC 모든 권한
   ├─ 통계 정보
   ├─ 개발자 정보
   └─ 시스템 상태
```

### 💡 Migration Guide (v2.0 → v2.1)

#### 1. 패키지 설치
```bash
npm install express-session session-file-store bcrypt dotenv
```

#### 2. 환경 설정
```bash
# .env 파일 생성
cat > .env << 'EOF'
SESSION_SECRET=your-secret-key-here
NODE_ENV=production
PORT=3000
SESSION_MAX_AGE=43200000
PASSWORD_MIN_LENGTH=8
EOF

chmod 600 .env
```

#### 3. 디렉토리 생성
```bash
mkdir -p data/sessions
chmod 700 data data/sessions
```

#### 4. 관리자 계정 생성
```bash
node scripts/create-admin.js --username admin --password 'your-secure-password'
```

#### 5. 서버 재시작
```bash
docker compose restart dashboard
```

#### 6. 테스트
```bash
./scripts/test-auth.sh
```

### ⚠️ Breaking Changes

**없음** - 기존 Public API는 모두 호환성 유지

### 🐛 Bug Fixes

#### 버그 수정 (개발 중 발견)
1. **비밀번호 해시 불일치** - bcrypt 해시 재생성으로 해결
2. **세션 미유지** - /api/auth/me에 optionalAuth 추가
3. **관리자 메뉴 노출** - 메뉴 구조 재조정 (개발자별 → 관리자 전용)
4. **필터 미초기화** - showView('all')에 reset 로직 추가
5. **블랙리스트 → 화이트리스트** - MENU_CONFIG + renderMenu() 도입

### 🚀 Performance

- 세션 조회: O(1) - in-memory
- 비밀번호 검증: ~100ms (bcrypt)
- 파일 기반 세션: 빠른 I/O

### 📦 Dependencies Added

```json
{
  "express-session": "^1.18.1",
  "session-file-store": "^1.5.0",
  "bcrypt": "^5.1.1",
  "dotenv": "^16.4.7"
}
```

---

## [2.0.0] - 2025-10-16

### 🎉 Major Release - Dashboard Rebuild

대시보드를 전면 개편하여 프로젝트 관리 허브로 전환했습니다.

### ✨ Added

#### 왼쪽 사이드바 네비게이션
- 고정 사이드바 (280px width)
- 스크롤 가능한 메뉴 구조
- Active 상태 하이라이트
- Badge 카운터로 개수 표시

#### 프로젝트 관리 기능
- 상태별 필터링 (전체/운영중/개발중)
- 카테고리별 필터링 (Full-stack/Frontend/Backend/Tools)
- 실시간 검색 기능 (프로젝트명, 설명, 태그)
- 프로젝트 카드 UI 개선

#### 개발자 노트 시스템
- 릴리즈 노트 뷰 (버전별 변경사항)
- 개발자별 뷰 (팀별 그룹화)
- 타임라인 뷰 (배포 히스토리)
- 버전 타입별 Badge (major/minor/patch)
- 변경사항 타입별 색상 구분 (feature/tech/fix)

#### 시스템 모니터링
- 통계 대시보드 (stats cards)
- 시스템 상태 뷰
- 카테고리별 분포 차트

#### 확장된 데이터 구조
- `DEVELOPERS` 배열 추가 (팀/개발자 정보)
- `PROJECTS` 배열 확장 (category, developer, version, deployedAt 추가)
- `RELEASE_NOTES` 배열 추가 (버전 히스토리)
- `SYSTEM_NOTES` 배열 추가 (시스템 공지)

#### API 엔드포인트 확장
- `GET /api/projects` - 필터링 및 검색 지원
- `GET /api/projects/:id` - 프로젝트 상세 (릴리즈 포함)
- `GET /api/developers` - 개발자별 프로젝트 정보
- `GET /api/releases` - 릴리즈 노트 목록
- `GET /api/stats` - 통합 통계 정보
- `GET /api/info` - 대시보드 v2 정보

#### Helper Functions
- `getProjectsByDeveloper(developerId)`
- `getProjectsByCategory(category)`
- `getProjectsByStatus(status)`
- `searchProjects(query)`
- `getReleaseNotesByProject(projectId)`
- `getProjectStats()`

#### UI/UX 개선
- 반응형 디자인 (모바일 지원)
- CSS Grid 기반 레이아웃
- Glassmorphism 효과
- Hover 애니메이션
- 색상 테마 시스템 (CSS variables)
- 기술 스택 태그 디자인

### 📚 Documentation
- `README.md` - 전체 기능 및 API 문서
- `QUICK_START.md` - 빠른 시작 가이드
- `API_EXAMPLES.md` - API 사용 예시 모음
- `CHANGELOG.md` - 변경 이력

### 🔧 Technical Improvements
- 서버 사이드 렌더링 최적화
- 클라이언트 사이드 뷰 전환 (페이지 새로고침 없음)
- 데이터 정규화 (ID 기반 관계)
- API 응답 표준화 (success, data, count, total)

### 🎨 Design System
- Primary color: #667eea
- Sidebar background: #1e293b
- CSS custom properties 도입
- Consistent spacing system
- Typography hierarchy

### 📊 Metrics
- 1100+ lines of code
- 4 data models
- 6 API endpoints
- 8+ helper functions
- 5 main views
- Mobile responsive

---

## [1.0.0] - 2025-10-15

### Initial Release

#### Features
- 기본 프로젝트 라우팅
- 프로젝트 카드 UI
- "방문하기" 버튼
- 상태 표시 (active/준비중)
- 기술 스택 태그

#### API Endpoints
- `GET /api/projects` - 프로젝트 목록
- `GET /api/info` - 기본 정보

#### Data Structure
- `PROJECTS` 배열 (기본 필드만)

---

## Migration Guide (v1 → v2)

### Breaking Changes

#### PROJECTS 배열 필드 추가
v1:
```javascript
{
  id: 'lotto-master',
  name: 'LottoMaster',
  description: '...',
  url: '...',
  port: 3001,
  status: 'active',
  tags: [...]
}
```

v2 (추가된 필드):
```javascript
{
  // ... v1 필드들
  category: 'full-stack',        // 새로 추가
  developer: 'team-a',           // 새로 추가
  version: '1.0.0',              // 새로 추가
  deployedAt: '2025-10-16',      // 새로 추가
  repository: null,              // 새로 추가
  docs: null                     // 새로 추가
}
```

#### 새 데이터 배열 추가 필요
- `DEVELOPERS` 배열 생성 필요
- `RELEASE_NOTES` 배열 생성 필요
- `SYSTEM_NOTES` 배열 생성 필요 (선택)

### Migration Steps

1. **DEVELOPERS 배열 추가**
```javascript
const DEVELOPERS = [
  {
    id: 'team-a',
    name: 'Team A',
    avatar: '👨‍💻',
    role: 'Full-stack',
    color: '#667eea'
  }
];
```

2. **PROJECTS 배열 확장**
```javascript
// 기존 프로젝트에 새 필드 추가
const PROJECTS = [
  {
    // ... 기존 필드
    category: 'full-stack',      // 추가
    developer: 'team-a',         // 추가
    version: '1.0.0',            // 추가
    deployedAt: '2025-10-15',    // 추가
    repository: null,            // 추가
    docs: null                   // 추가
  }
];
```

3. **RELEASE_NOTES 배열 추가**
```javascript
const RELEASE_NOTES = [
  {
    id: 1,
    projectId: 'lotto-master',
    version: '1.0.0',
    date: '2025-10-15',
    type: 'major',
    developer: 'team-a',
    title: '초기 릴리즈',
    changes: [
      { type: 'feature', description: '...' }
    ]
  }
];
```

4. **재배포**
```bash
docker compose build dashboard
docker compose up -d dashboard
```

---

## Future Plans

### v2.1.0 (계획중)
- [ ] 프로젝트 즐겨찾기 기능
- [ ] 커스텀 태그 관리
- [ ] 프로젝트 그룹/워크스페이스
- [ ] 다크 모드 토글

### v2.2.0 (계획중)
- [ ] 실시간 헬스체크 표시
- [ ] 프로젝트 메트릭스 (CPU, 메모리)
- [ ] 알림/공지사항 시스템
- [ ] 사용자 인증

### v3.0.0 (검토중)
- [ ] Database 통합 (PostgreSQL)
- [ ] RESTful CRUD API
- [ ] 프론트엔드 프레임워크 전환 (React/Vue)
- [ ] 실시간 WebSocket 연동

---

## Version Naming Convention

버전 번호는 Semantic Versioning (SemVer)을 따릅니다:

- **Major (X.0.0)**: 호환성이 깨지는 변경사항
- **Minor (0.X.0)**: 하위 호환성 유지하며 기능 추가
- **Patch (0.0.X)**: 버그 수정 및 소소한 개선

### Release Types

- **major**: 주요 기능 추가, 구조 변경, Breaking Changes
- **minor**: 새로운 기능 추가, 기존 기능 개선
- **patch**: 버그 수정, 성능 개선, 문서 업데이트

---

## Support

- **Issues**: GitHub Issues 또는 시스템 관리자
- **Documentation**: README.md, QUICK_START.md 참조
- **API Examples**: API_EXAMPLES.md 참조

---

**Contributors**: Team A, Team B
**License**: Internal Use Only
