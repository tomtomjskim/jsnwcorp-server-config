/**
 * Analytics Modal - Project Detail Modal Management
 * Handles project detail modal display, data loading, and visualizations
 */

// Global state
let currentProjectId = null;
let currentProjectUrl = '';
let refreshInterval = null;

/**
 * Show project detail modal
 * @param {string} projectId - Project ID
 * @param {string} projectUrl - Project URL
 */
async function showProjectDetail(projectId, projectUrl) {
    currentProjectId = projectId;
    currentProjectUrl = projectUrl;

    const modal = document.getElementById('project-detail-modal');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';

    // Set visit button onclick
    const visitBtn = document.getElementById('visit-project-btn');
    visitBtn.onclick = () => window.open(projectUrl, '_blank');

    // Load initial data
    await loadProjectData();

    // Start auto-refresh (every 30 seconds)
    startAutoRefresh();
}

/**
 * Close project detail modal
 */
function closeProjectDetailModal() {
    const modal = document.getElementById('project-detail-modal');
    modal.style.display = 'none';
    document.body.style.overflow = '';

    // Stop auto-refresh
    stopAutoRefresh();

    currentProjectId = null;
    currentProjectUrl = '';
}

/**
 * Load project data from API
 */
async function loadProjectData() {
    if (!currentProjectId) return;

    try {
        const response = await fetch(`/api/analytics/projects/${currentProjectId}`);
        const result = await response.json();

        if (result.success) {
            const { project, daily_stats, recent_events } = result.data;

            // Update modal header
            document.getElementById('modal-project-emoji').textContent = project.emoji || '📦';
            document.getElementById('modal-project-name').textContent = project.display_name || project.name;
            document.getElementById('modal-project-description').textContent = project.description || '';

            // Calculate totals from daily_stats
            const totalUsers = daily_stats.reduce((sum, day) => sum + (parseInt(day.unique_users) || 0), 0);
            const totalPageviews = daily_stats.reduce((sum, day) => sum + (parseInt(day.page_views) || 0), 0);
            const totalEvents = daily_stats.reduce((sum, day) => sum + (parseInt(day.total_events) || 0), 0);
            const latestDay = daily_stats[0] || {};

            // Update summary cards
            document.getElementById('modal-total-users').textContent = totalUsers.toLocaleString();
            document.getElementById('modal-total-pageviews').textContent = totalPageviews.toLocaleString();
            document.getElementById('modal-total-events').textContent = totalEvents.toLocaleString();
            document.getElementById('modal-daily-active').textContent = (latestDay.unique_users || 0).toLocaleString();

            // Update last refresh time
            updateRefreshTime();

            // Render visualizations
            renderDailyStatsChart(daily_stats);
            renderEventTypeDistribution(daily_stats);
            renderRecentEvents(recent_events);
        }
    } catch (error) {
        console.error('Failed to load project details:', error);
        // Don't close modal on refresh errors, just log
        if (!document.getElementById('project-detail-modal').style.display) {
            alert('프로젝트 상세 정보를 불러오는데 실패했습니다.');
            closeProjectDetailModal();
        }
    }
}

/**
 * Update last refresh timestamp
 */
function updateRefreshTime() {
    const refreshTimeEl = document.getElementById('last-refresh-time');
    if (refreshTimeEl) {
        const now = new Date();
        refreshTimeEl.textContent = now.toLocaleTimeString('ko-KR', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }
}

/**
 * Start auto-refresh
 */
function startAutoRefresh() {
    // Clear existing interval
    stopAutoRefresh();

    // Refresh every 30 seconds
    refreshInterval = setInterval(() => {
        loadProjectData();
    }, 30000);
}

/**
 * Stop auto-refresh
 */
function stopAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
}

/**
 * Render daily stats chart (7-day trend)
 * @param {Array} dailyStats - Array of daily stats
 */
function renderDailyStatsChart(dailyStats) {
    const canvas = document.getElementById('daily-stats-chart');
    const ctx = canvas.getContext('2d');

    if (!dailyStats || dailyStats.length === 0) {
        canvas.parentElement.innerHTML = '<p style="text-align: center; color: #999; padding: 20px;">데이터가 없습니다.</p>';
        return;
    }

    // Reverse to show chronological order (oldest to newest)
    const data = [...dailyStats].reverse();

    // Canvas setup
    const width = canvas.width = canvas.parentElement.offsetWidth;
    const height = canvas.height = 250;
    const padding = { top: 20, right: 20, bottom: 50, left: 60 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Find max values
    const maxEvents = Math.max(...data.map(d => parseInt(d.total_events) || 0), 1);
    const maxUsers = Math.max(...data.map(d => parseInt(d.unique_users) || 0), 1);

    // Draw grid lines
    ctx.strokeStyle = '#f0f0f0';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
        const y = padding.top + (chartHeight / 5) * i;
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(padding.left + chartWidth, y);
        ctx.stroke();
    }

    // Draw axes
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(padding.left, padding.top);
    ctx.lineTo(padding.left, padding.top + chartHeight);
    ctx.lineTo(padding.left + chartWidth, padding.top + chartHeight);
    ctx.stroke();

    // Plot data
    const pointSpacing = chartWidth / (data.length - 1 || 1);

    // Events line (purple)
    ctx.strokeStyle = '#667eea';
    ctx.lineWidth = 3;
    ctx.beginPath();
    data.forEach((day, i) => {
        const x = padding.left + (i * pointSpacing);
        const events = parseInt(day.total_events) || 0;
        const y = padding.top + chartHeight - (events / maxEvents * chartHeight);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // Events points
    ctx.fillStyle = '#667eea';
    data.forEach((day, i) => {
        const x = padding.left + (i * pointSpacing);
        const events = parseInt(day.total_events) || 0;
        const y = padding.top + chartHeight - (events / maxEvents * chartHeight);
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fill();
    });

    // Users line (orange)
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    data.forEach((day, i) => {
        const x = padding.left + (i * pointSpacing);
        const users = parseInt(day.unique_users) || 0;
        const y = padding.top + chartHeight - (users / maxUsers * chartHeight);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.setLineDash([]);

    // Users points
    ctx.fillStyle = '#f59e0b';
    data.forEach((day, i) => {
        const x = padding.left + (i * pointSpacing);
        const users = parseInt(day.unique_users) || 0;
        const y = padding.top + chartHeight - (users / maxUsers * chartHeight);
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, Math.PI * 2);
        ctx.fill();
    });

    // X-axis labels (dates)
    ctx.fillStyle = '#666';
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'center';
    data.forEach((day, i) => {
        const x = padding.left + (i * pointSpacing);
        const date = new Date(day.stat_date);
        const label = `${date.getMonth() + 1}/${date.getDate()}`;
        ctx.fillText(label, x, padding.top + chartHeight + 20);
    });

    // Y-axis labels
    ctx.textAlign = 'right';
    for (let i = 0; i <= 5; i++) {
        const y = padding.top + (chartHeight / 5) * i;
        const value = Math.round(maxEvents * (1 - i / 5));
        ctx.fillText(value, padding.left - 10, y + 4);
    }

    // Legend
    ctx.textAlign = 'left';
    ctx.fillStyle = '#667eea';
    ctx.fillRect(padding.left, height - 30, 15, 3);
    ctx.fillStyle = '#333';
    ctx.font = '12px sans-serif';
    ctx.fillText('이벤트', padding.left + 20, height - 25);

    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(padding.left + 80, height - 30, 15, 3);
    ctx.fillStyle = '#333';
    ctx.fillText('사용자', padding.left + 100, height - 25);
}

/**
 * Render event type distribution chart
 * @param {Array} dailyStats - Array of daily stats
 */
function renderEventTypeDistribution(dailyStats) {
    const canvas = document.getElementById('event-distribution-chart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    if (!dailyStats || dailyStats.length === 0) {
        canvas.parentElement.innerHTML = '<p style="text-align: center; color: #999; padding: 20px;">데이터가 없습니다.</p>';
        return;
    }

    // Aggregate event types from all days
    const eventTypes = {};
    dailyStats.forEach(day => {
        if (day.event_breakdown) {
            Object.entries(day.event_breakdown).forEach(([type, count]) => {
                eventTypes[type] = (eventTypes[type] || 0) + parseInt(count);
            });
        }
    });

    const entries = Object.entries(eventTypes).sort((a, b) => b[1] - a[1]);

    if (entries.length === 0) {
        canvas.parentElement.innerHTML = '<p style="text-align: center; color: #999; padding: 20px;">이벤트 데이터가 없습니다.</p>';
        return;
    }

    // Canvas setup
    const width = canvas.width = canvas.parentElement.offsetWidth;
    const height = canvas.height = 200;
    const padding = { top: 20, right: 20, bottom: 30, left: 120 };
    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Calculate max value
    const maxCount = Math.max(...entries.map(e => e[1]), 1);

    // Colors for bars
    const colors = ['#667eea', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#ec4899'];

    // Draw horizontal bars
    const barHeight = chartHeight / entries.length;
    const barPadding = barHeight * 0.2;

    entries.forEach(([type, count], i) => {
        const barWidth = (count / maxCount) * chartWidth;
        const y = padding.top + (i * barHeight);

        // Draw bar
        ctx.fillStyle = colors[i % colors.length];
        ctx.fillRect(padding.left, y + barPadding / 2, barWidth, barHeight - barPadding);

        // Draw label
        ctx.fillStyle = '#333';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(type, padding.left - 10, y + barHeight / 2 + 4);

        // Draw count
        ctx.textAlign = 'left';
        ctx.fillText(count.toLocaleString(), padding.left + barWidth + 5, y + barHeight / 2 + 4);
    });
}

/**
 * Render recent events list
 * @param {Array} events - Array of recent events
 */
function renderRecentEvents(events) {
    const container = document.getElementById('recent-events-list');

    if (!events || events.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #999; padding: 20px;">최근 이벤트가 없습니다.</p>';
        return;
    }

    container.innerHTML = events.map(event => {
        const eventTime = new Date(event.created_at);
        const timeStr = eventTime.toLocaleString('ko-KR', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });

        return `
            <div class="event-item">
                <div class="event-info">
                    <div class="event-type">${event.event_type || '-'}</div>
                    <div class="event-name">${event.event_name || event.event_category || '-'}</div>
                </div>
                <div class="event-time">${timeStr}</div>
            </div>
        `;
    }).join('');
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Close modal on ESC key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && currentProjectId) {
            closeProjectDetailModal();
        }
    });

    // Close modal on overlay click
    document.addEventListener('click', (e) => {
        if (e.target.id === 'project-detail-modal') {
            closeProjectDetailModal();
        }
    });

    // Manual refresh button
    const refreshBtn = document.getElementById('modal-refresh-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => {
            loadProjectData();
        });
    }
});

// Export functions for global scope
window.showProjectDetail = showProjectDetail;
window.closeProjectDetailModal = closeProjectDetailModal;
