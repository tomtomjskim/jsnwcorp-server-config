/**
 * Login Page HTML
 */

module.exports = `
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>관리자 로그인 - Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #667eea;
            --primary-dark: #5568d3;
            --danger: #f44336;
            --bg-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg-gradient);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 50px 40px;
            width: 100%;
            max-width: 400px;
            animation: slideUp 0.5s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .login-icon {
            font-size: 4em;
            margin-bottom: 10px;
        }

        .login-title {
            font-size: 1.8em;
            color: #333;
            margin-bottom: 8px;
        }

        .login-subtitle {
            color: #999;
            font-size: 0.95em;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
            font-size: 0.95em;
        }

        .form-input {
            width: 100%;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1em;
            transition: all 0.3s;
            outline: none;
        }

        .form-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-input.error {
            border-color: var(--danger);
        }

        .error-message {
            color: var(--danger);
            font-size: 0.85em;
            margin-top: 8px;
            display: none;
        }

        .error-message.show {
            display: block;
        }

        .submit-btn {
            width: 100%;
            padding: 15px;
            background: var(--bg-gradient);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
        }

        .submit-btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .submit-btn:active:not(:disabled) {
            transform: translateY(0);
        }

        .submit-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .loading {
            display: inline-block;
            width: 14px;
            height: 14px;
            border: 2px solid white;
            border-top: 2px solid transparent;
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
            margin-right: 8px;
            vertical-align: middle;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .back-link {
            text-align: center;
            margin-top: 25px;
        }

        .back-link a {
            color: var(--primary);
            text-decoration: none;
            font-size: 0.95em;
            transition: opacity 0.2s;
        }

        .back-link a:hover {
            opacity: 0.8;
            text-decoration: underline;
        }

        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: none;
        }

        .alert.show {
            display: block;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-danger {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ef9a9a;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="login-icon">🔐</div>
            <h1 class="login-title">관리자 로그인</h1>
            <p class="login-subtitle">Dashboard 관리자 전용</p>
        </div>

        <div id="alert" class="alert alert-danger"></div>

        <form id="loginForm">
            <div class="form-group">
                <label class="form-label" for="username">사용자명</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    class="form-input"
                    placeholder="사용자명을 입력하세요"
                    required
                    autocomplete="username"
                    autofocus
                >
                <div id="usernameError" class="error-message"></div>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">비밀번호</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    class="form-input"
                    placeholder="비밀번호를 입력하세요"
                    required
                    autocomplete="current-password"
                >
                <div id="passwordError" class="error-message"></div>
            </div>

            <button type="submit" id="submitBtn" class="submit-btn">
                로그인
            </button>
        </form>

        <div class="back-link">
            <a href="/">← 대시보드로 돌아가기</a>
        </div>
    </div>

    <script>
        const form = document.getElementById('loginForm');
        const submitBtn = document.getElementById('submitBtn');
        const alert = document.getElementById('alert');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');

        // Clear errors on input
        [usernameInput, passwordInput].forEach(input => {
            input.addEventListener('input', () => {
                input.classList.remove('error');
                hideAlert();
            });
        });

        function showAlert(message) {
            alert.textContent = message;
            alert.classList.add('show');
        }

        function hideAlert() {
            alert.classList.remove('show');
        }

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            hideAlert();

            const username = usernameInput.value.trim();
            const password = passwordInput.value;

            // Validation
            if (!username) {
                usernameInput.classList.add('error');
                showAlert('사용자명을 입력해주세요.');
                usernameInput.focus();
                return;
            }

            if (!password) {
                passwordInput.classList.add('error');
                showAlert('비밀번호를 입력해주세요.');
                passwordInput.focus();
                return;
            }

            // Disable form
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="loading"></span> 로그인 중...';

            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ username, password })
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    // Login successful
                    submitBtn.innerHTML = '✓ 로그인 성공!';
                    setTimeout(() => {
                        window.location.href = '/';
                    }, 500);
                } else {
                    // Login failed
                    throw new Error(data.message || '로그인에 실패했습니다.');
                }
            } catch (error) {
                console.error('Login error:', error);
                showAlert(error.message || '로그인 중 오류가 발생했습니다.');

                // Reset button
                submitBtn.disabled = false;
                submitBtn.innerHTML = '로그인';

                // Focus on username
                usernameInput.focus();
                usernameInput.select();
            }
        });

        // Enter key handling
        passwordInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                form.dispatchEvent(new Event('submit'));
            }
        });
    </script>
</body>
</html>
`;
