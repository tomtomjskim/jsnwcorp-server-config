#!/usr/bin/env node

/**
 * 프로젝트 헬스체크 스크립트
 * - 모든 프로젝트의 health_check_endpoint로 HTTP 요청 전송
 * - 응답 시간과 상태를 DB에 기록
 * - 5분마다 cron으로 실행
 */

const { Pool } = require('pg');
const http = require('http');
const https = require('https');

// PostgreSQL 연결 설정
const pool = new Pool({
  host: process.env.POSTGRES_HOST || 'postgres',
  port: process.env.POSTGRES_PORT || 5432,
  database: process.env.POSTGRES_DB || 'maindb',
  user: process.env.POSTGRES_USER || 'appuser',
  password: process.env.POSTGRES_PASSWORD || 'apppassword',
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

/**
 * HTTP/HTTPS 요청을 보내고 응답 시간과 상태 코드 반환
 */
async function checkEndpoint(url, timeout = 10000) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    const urlObj = new URL(url);
    const protocol = urlObj.protocol === 'https:' ? https : http;

    const req = protocol.get(url, { timeout }, (res) => {
      const responseTime = Date.now() - startTime;
      const statusCode = res.statusCode;

      // 응답 본문 소비 (메모리 누수 방지)
      res.resume();

      resolve({
        success: statusCode >= 200 && statusCode < 400,
        statusCode,
        responseTime,
        error: null
      });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({
        success: false,
        statusCode: null,
        responseTime: timeout,
        error: 'Request timeout'
      });
    });

    req.on('error', (err) => {
      const responseTime = Date.now() - startTime;
      resolve({
        success: false,
        statusCode: null,
        responseTime,
        error: err.message
      });
    });
  });
}

/**
 * 프로젝트 헬스 상태 결정
 */
function determineHealthStatus(checkResult, responseTime) {
  if (!checkResult.success) {
    return 'unhealthy';
  }

  if (responseTime > 5000) {
    return 'degraded';
  }

  return 'healthy';
}

/**
 * 모든 프로젝트의 헬스 체크 수행
 */
async function performHealthChecks() {
  const client = await pool.connect();

  try {
    console.log(`[${new Date().toISOString()}] Starting health checks...`);

    // 활성 상태인 프로젝트만 체크
    const result = await client.query(`
      SELECT id, name, display_name, internal_url, health_check_endpoint
      FROM public.projects
      WHERE status = 'active'
    `);

    const projects = result.rows;
    console.log(`Found ${projects.length} active projects to check`);

    for (const project of projects) {
      const healthEndpoint = project.health_check_endpoint || '/';
      const baseUrl = project.internal_url;

      if (!baseUrl) {
        console.warn(`⚠️  ${project.display_name}: No internal_url configured, skipping`);
        continue;
      }

      const checkUrl = `${baseUrl}${healthEndpoint}`;
      console.log(`Checking ${project.display_name} (${project.id}): ${checkUrl}`);

      const checkResult = await checkEndpoint(checkUrl);
      const healthStatus = determineHealthStatus(checkResult, checkResult.responseTime);

      // DB 업데이트
      await client.query(`
        UPDATE public.projects
        SET
          health_status = $1,
          last_health_check = NOW(),
          avg_response_time_ms = $2
        WHERE id = $3
      `, [healthStatus, checkResult.responseTime, project.id]);

      const statusIcon = healthStatus === 'healthy' ? '🟢' : healthStatus === 'degraded' ? '🟡' : '🔴';
      console.log(
        `${statusIcon} ${project.display_name}: ${healthStatus} ` +
        `(${checkResult.responseTime}ms, status: ${checkResult.statusCode || 'N/A'})`
      );

      if (checkResult.error) {
        console.error(`   Error: ${checkResult.error}`);
      }
    }

    console.log(`[${new Date().toISOString()}] Health checks completed\n`);
  } catch (error) {
    console.error('❌ Error during health checks:', error);
  } finally {
    client.release();
  }
}

/**
 * 메인 실행
 */
async function main() {
  try {
    await performHealthChecks();
    await pool.end();
    process.exit(0);
  } catch (error) {
    console.error('Fatal error:', error);
    await pool.end();
    process.exit(1);
  }
}

// 스크립트가 직접 실행될 때만 main 호출
if (require.main === module) {
  main();
}

module.exports = { performHealthChecks, checkEndpoint };
