// ============================================================================
// Analytics API Routes for Dashboard
// ============================================================================
// Purpose: Serve aggregated analytics data from PostgreSQL to Dashboard UI
// Endpoints:
//   GET /api/analytics/summary - All projects summary
//   GET /api/analytics/projects - List all projects
//   GET /api/analytics/projects/:projectId - Project details with stats
//   GET /api/analytics/events/recent - Recent analytics events
// ============================================================================

const express = require('express');
const router = express.Router();
const db = require('../lib/db');

// ============================================================================
// GET /api/analytics/summary
// Returns: Overall system statistics across all projects
// ============================================================================
router.get('/summary', async (req, res) => {
  try {
    const result = await db.query(`
      SELECT
        COUNT(DISTINCT id) as total_projects,
        COUNT(DISTINCT id) FILTER (WHERE status = 'active') as active_projects,
        COALESCE(SUM(total_users), 0) as total_users,
        COALESCE(SUM(daily_active_users), 0) as daily_active_users,
        COALESCE(SUM(total_requests), 0) as total_requests,
        COALESCE(AVG(avg_response_time_ms), 0)::numeric(10,2) as avg_response_time_ms,
        COUNT(*) FILTER (WHERE health_status = 'healthy') as healthy_count,
        COUNT(*) FILTER (WHERE health_status = 'unhealthy') as unhealthy_count
      FROM public.projects
    `);

    const summary = result.rows[0];

    // Get recent events count (last 24 hours)
    const eventsResult = await db.query(`
      SELECT
        COUNT(*) as events_24h,
        COUNT(DISTINCT project_id) as active_projects_24h
      FROM public.analytics_events
      WHERE created_at > NOW() - INTERVAL '24 hours'
    `);

    res.json({
      success: true,
      data: {
        ...summary,
        events_last_24h: parseInt(eventsResult.rows[0].events_24h || 0),
        active_projects_24h: parseInt(eventsResult.rows[0].active_projects_24h || 0),
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('[Analytics API] Error in /summary:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch analytics summary',
      message: error.message,
    });
  }
});

// ============================================================================
// GET /api/analytics/projects
// Returns: List of all projects with aggregated analytics from analytics_events
// ============================================================================
router.get('/projects', async (req, res) => {
  try {
    const result = await db.query(`
      SELECT
        p.id,
        p.name,
        p.display_name,
        p.emoji,
        p.description,
        p.category,
        p.status,
        p.version,
        p.url,
        p.internal_url,
        p.port,
        p.health_status,
        p.last_health_check,
        p.created_at,
        p.updated_at,
        -- Aggregate stats from analytics_events (all time)
        COALESCE(COUNT(DISTINCT CASE WHEN ae.user_id IS NOT NULL THEN ae.user_id END), 0)::int as total_users,
        COALESCE(COUNT(*) FILTER (WHERE ae.event_type = 'pageview'), 0)::int as total_page_views,
        COALESCE(COUNT(*), 0)::int as total_events,
        -- Daily active users (last 24 hours)
        COALESCE(COUNT(DISTINCT CASE
          WHEN ae.user_id IS NOT NULL AND ae.created_at > NOW() - INTERVAL '24 hours'
          THEN ae.user_id
        END), 0)::int as daily_active_users,
        -- Total requests/events (as proxy for total_requests)
        COALESCE(COUNT(*) FILTER (WHERE ae.created_at > NOW() - INTERVAL '24 hours'), 0)::int as requests_24h,
        -- Average response time (if available in metadata)
        COALESCE(AVG((ae.metadata->>'response_time')::numeric) FILTER (WHERE ae.metadata->>'response_time' IS NOT NULL), 0)::numeric(10,2) as avg_response_time_ms
      FROM public.projects p
      LEFT JOIN public.analytics_events ae ON ae.project_id = p.id
      GROUP BY p.id, p.name, p.display_name, p.emoji, p.description, p.category,
               p.status, p.version, p.url, p.internal_url, p.port, p.health_status,
               p.last_health_check, p.created_at, p.updated_at
      ORDER BY
        CASE p.status
          WHEN 'active' THEN 1
          WHEN 'development' THEN 2
          WHEN 'maintenance' THEN 3
          ELSE 4
        END,
        p.display_name ASC
    `);

    res.json({
      success: true,
      data: result.rows,
      count: result.rowCount,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('[Analytics API] Error in /projects:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch projects',
      message: error.message,
    });
  }
});

// ============================================================================
// GET /api/analytics/projects/:projectId
// Returns: Detailed project information with analytics stats
// ============================================================================
router.get('/projects/:projectId', async (req, res) => {
  const { projectId } = req.params;

  try {
    // Get project info
    const projectResult = await db.query(
      'SELECT * FROM public.projects WHERE id = $1',
      [projectId]
    );

    if (projectResult.rowCount === 0) {
      return res.status(404).json({
        success: false,
        error: 'Project not found',
      });
    }

    const project = projectResult.rows[0];

    // Get daily stats for last 7 days
    const dailyStatsResult = await db.query(`
      SELECT
        date as stat_date,
        total_events,
        unique_visitors as unique_users,
        total_page_views as page_views,
        avg_response_time_ms
      FROM analytics.daily_stats
      WHERE project_id = $1
        AND date >= CURRENT_DATE - INTERVAL '7 days'
      ORDER BY date DESC
    `, [projectId]);

    // Get recent events (last 50)
    const recentEventsResult = await db.query(`
      SELECT
        event_type,
        event_category,
        event_name,
        event_value,
        session_id,
        user_id,
        created_at
      FROM public.analytics_events
      WHERE project_id = $1
      ORDER BY created_at DESC
      LIMIT 50
    `, [projectId]);

    res.json({
      success: true,
      data: {
        project,
        daily_stats: dailyStatsResult.rows,
        recent_events: recentEventsResult.rows,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error(`[Analytics API] Error in /projects/${projectId}:`, error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch project details',
      message: error.message,
    });
  }
});

// ============================================================================
// GET /api/analytics/events/recent
// Returns: Recent analytics events across all projects
// Query params: limit (default: 100), projectId (optional filter)
// ============================================================================
router.get('/events/recent', async (req, res) => {
  const limit = parseInt(req.query.limit || '100');
  const projectId = req.query.projectId;

  try {
    let query = `
      SELECT
        ae.project_id,
        p.display_name as project_name,
        ae.event_type,
        ae.event_category,
        ae.event_name,
        ae.event_value,
        ae.session_id,
        ae.user_id,
        ae.created_at
      FROM public.analytics_events ae
      LEFT JOIN public.projects p ON ae.project_id = p.id
    `;

    const params = [];

    if (projectId) {
      query += ' WHERE ae.project_id = $1';
      params.push(projectId);
    }

    query += ` ORDER BY ae.created_at DESC LIMIT ${limit}`;

    const result = await db.query(query, params);

    res.json({
      success: true,
      data: result.rows,
      count: result.rowCount,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('[Analytics API] Error in /events/recent:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch recent events',
      message: error.message,
    });
  }
});

// ============================================================================
// POST /api/analytics/track
// Purpose: Track analytics events from client-side applications
// Body: { project_id, user_id, session_id, event_type, properties }
// ============================================================================
router.post('/track', async (req, res) => {
  try {
    const {
      project_id,
      user_id,
      session_id,
      event_type,
      properties = {}
    } = req.body;

    // Validation
    if (!project_id || !user_id || !event_type) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: project_id, user_id, event_type'
      });
    }

    // Insert event into analytics_events table
    await db.query(`
      INSERT INTO public.analytics_events (
        project_id,
        user_id,
        session_id,
        event_type,
        event_category,
        event_name,
        event_value,
        metadata,
        created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW())
    `, [
      project_id,
      user_id,
      session_id || null,
      event_type,
      properties.category || event_type, // Use event_type as category if not provided
      properties.name || event_type, // Use event_type as name if not provided
      properties.value || null,
      JSON.stringify(properties)
    ]);

    res.json({
      success: true,
      message: 'Event tracked successfully',
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('[Analytics API] Error in POST /track:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to track event',
      message: error.message
    });
  }
});

// ============================================================================
// GET /api/analytics/health
// Returns: Database connection health status
// ============================================================================
router.get('/health', async (req, res) => {
  try {
    const isConnected = await db.testConnection();

    res.json({
      success: true,
      database: isConnected ? 'connected' : 'disconnected',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Health check failed',
      message: error.message,
    });
  }
});

module.exports = router;
