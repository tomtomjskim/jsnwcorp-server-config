const express = require('express');
const router = express.Router();
const db = require('../lib/db');

router.get('/status', async (req, res) => {
  try {
    const statusResult = await db.query(`
      SELECT service_name, status, reason, memory_percent, memory_usage_mb, total_memory_mb, last_check
      FROM public.ai_service_status
      WHERE service_name = 'ai-chatbot'
      ORDER BY last_check DESC
      LIMIT 1
    `);

    let healthCheck = { healthy: false };
    try {
      const chatbotUrl = process.env.CHATBOT_URL || 'http://172.20.0.14:8000';
      const response = await fetch(`${chatbotUrl}/health`, { timeout: 3000 });
      if (response.ok) healthCheck = await response.json();
    } catch (err) {}

    const dbStatus = statusResult.rows[0] || { status: 'unknown', reason: 'No status' };
    const actualStatus = healthCheck.healthy ? 'active' : dbStatus.status;

    res.json({
      success: true,
      data: {
        status: actualStatus,
        reason: dbStatus.reason,
        memoryPercent: dbStatus.memory_percent,
        lastCheck: dbStatus.last_check,
        health: healthCheck
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
