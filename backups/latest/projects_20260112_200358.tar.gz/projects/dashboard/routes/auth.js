/**
 * Authentication Routes
 * 로그인/로그아웃 관련 API 라우트
 */

const express = require('express');
const router = express.Router();
const userManager = require('../utils/user-manager');
const { optionalAuth, checkAuth } = require('../middleware/auth');

// Rate limiting용 메모리 저장소
const loginAttempts = new Map();

/**
 * Rate Limiting: 로그인 시도 제한
 * 15분당 5회
 */
function checkLoginRateLimit(username) {
  const now = Date.now();
  const windowMs = 15 * 60 * 1000; // 15분
  const maxAttempts = 5;

  if (!loginAttempts.has(username)) {
    loginAttempts.set(username, []);
  }

  const attempts = loginAttempts.get(username);

  // 15분 이전 시도는 제거
  const recentAttempts = attempts.filter(time => now - time < windowMs);
  loginAttempts.set(username, recentAttempts);

  if (recentAttempts.length >= maxAttempts) {
    const oldestAttempt = Math.min(...recentAttempts);
    const waitTime = Math.ceil((windowMs - (now - oldestAttempt)) / 1000 / 60);
    return {
      allowed: false,
      waitTime: waitTime
    };
  }

  return { allowed: true };
}

/**
 * 로그인 시도 기록
 */
function recordLoginAttempt(username) {
  if (!loginAttempts.has(username)) {
    loginAttempts.set(username, []);
  }
  loginAttempts.get(username).push(Date.now());
}

/**
 * POST /api/auth/login
 * 로그인 요청
 */
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    // 입력 검증
    if (!username || !password) {
      return res.status(400).json({
        success: false,
        error: 'Missing credentials',
        message: 'Username and password are required'
      });
    }

    // Rate limiting 체크
    const rateLimit = checkLoginRateLimit(username);
    if (!rateLimit.allowed) {
      return res.status(429).json({
        success: false,
        error: 'Too many attempts',
        message: `Too many login attempts. Please try again in ${rateLimit.waitTime} minutes.`
      });
    }

    // 비밀번호 검증
    const result = await userManager.verifyPassword(username, password);

    if (!result.success) {
      // 실패한 시도 기록
      recordLoginAttempt(username);

      return res.status(401).json({
        success: false,
        error: 'Invalid credentials',
        message: 'Invalid username or password'
      });
    }

    // 로그인 성공 - 세션 생성
    req.session.userId = result.user.id;
    req.session.username = result.user.username;
    req.session.role = result.user.role;

    // 세션 저장 보장
    req.session.save((err) => {
      if (err) {
        console.error('Session save error:', err);
        return res.status(500).json({
          success: false,
          error: 'Session error',
          message: 'Failed to create session'
        });
      }

      // 성공 응답
      res.json({
        success: true,
        message: 'Login successful',
        user: {
          id: result.user.id,
          username: result.user.username,
          role: result.user.role
        }
      });
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error',
      message: 'An error occurred during login'
    });
  }
});

/**
 * POST /api/auth/logout
 * 로그아웃 요청
 */
router.post('/logout', (req, res) => {
  try {
    if (req.session) {
      req.session.destroy((err) => {
        if (err) {
          console.error('Session destroy error:', err);
          return res.status(500).json({
            success: false,
            error: 'Logout error',
            message: 'Failed to logout'
          });
        }

        res.clearCookie('connect.sid');
        res.json({
          success: true,
          message: 'Logout successful'
        });
      });
    } else {
      res.json({
        success: true,
        message: 'Already logged out'
      });
    }
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      error: 'Server error',
      message: 'An error occurred during logout'
    });
  }
});

/**
 * GET /api/auth/me
 * 현재 로그인 상태 확인
 */
router.get('/me', optionalAuth, checkAuth);

module.exports = router;
