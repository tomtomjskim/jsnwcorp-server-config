#!/usr/bin/env node

/**
 * Create Admin User Script
 * 관리자 계정 생성 스크립트
 *
 * Usage:
 *   node scripts/create-admin.js
 *   node scripts/create-admin.js --username admin --password mypassword
 */

const readline = require('readline');
const userManager = require('../utils/user-manager');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

/**
 * 사용자 입력 받기
 */
function question(query) {
  return new Promise(resolve => rl.question(query, resolve));
}

/**
 * 비밀번호 입력 (숨김 처리)
 */
function questionSecret(query) {
  return new Promise((resolve) => {
    const stdin = process.stdin;
    const stdout = process.stdout;

    stdout.write(query);
    stdin.resume();
    stdin.setRawMode(true);
    stdin.setEncoding('utf8');

    let password = '';

    const onData = (char) => {
      char = char.toString();

      switch (char) {
        case '\n':
        case '\r':
        case '\u0004': // Ctrl+D
          stdin.setRawMode(false);
          stdin.pause();
          stdin.removeListener('data', onData);
          stdout.write('\n');
          resolve(password);
          break;

        case '\u0003': // Ctrl+C
          process.exit();
          break;

        case '\u007F': // Backspace
        case '\b':
          if (password.length > 0) {
            password = password.slice(0, -1);
            stdout.write('\b \b');
          }
          break;

        default:
          password += char;
          stdout.write('*');
          break;
      }
    };

    stdin.on('data', onData);
  });
}

/**
 * 명령줄 인자 파싱
 */
function parseArgs() {
  const args = process.argv.slice(2);
  const parsed = {};

  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].substring(2);
      const value = args[i + 1];
      if (value && !value.startsWith('--')) {
        parsed[key] = value;
        i++;
      }
    }
  }

  return parsed;
}

/**
 * 비밀번호 유효성 검증
 */
function validatePassword(password) {
  const minLength = parseInt(process.env.PASSWORD_MIN_LENGTH) || 8;

  if (password.length < minLength) {
    return { valid: false, message: `Password must be at least ${minLength} characters` };
  }

  return { valid: true };
}

/**
 * 사용자명 유효성 검증
 */
function validateUsername(username) {
  if (!username || username.length < 3) {
    return { valid: false, message: 'Username must be at least 3 characters' };
  }

  if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
    return { valid: false, message: 'Username can only contain letters, numbers, underscore, and hyphen' };
  }

  return { valid: true };
}

/**
 * 관리자 계정 생성
 */
async function createAdmin() {
  try {
    console.log('=== Dashboard Admin User Creation ===\n');

    // .env 파일 로드
    require('dotenv').config();

    const args = parseArgs();
    let username, password;

    // 명령줄 인자가 있으면 사용
    if (args.username && args.password) {
      username = args.username;
      password = args.password;
      console.log(`Using provided credentials for user: ${username}\n`);
    } else {
      // 대화형 입력
      username = await question('Enter admin username (default: admin): ');
      username = username.trim() || 'admin';

      password = await questionSecret('Enter admin password: ');

      if (!password) {
        console.error('Error: Password cannot be empty');
        rl.close();
        process.exit(1);
      }

      const confirmPassword = await questionSecret('Confirm password: ');

      if (password !== confirmPassword) {
        console.error('Error: Passwords do not match');
        rl.close();
        process.exit(1);
      }
    }

    // 검증
    const usernameValidation = validateUsername(username);
    if (!usernameValidation.valid) {
      console.error(`Error: ${usernameValidation.message}`);
      rl.close();
      process.exit(1);
    }

    const passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
      console.error(`Error: ${passwordValidation.message}`);
      rl.close();
      process.exit(1);
    }

    // 기존 사용자 확인
    const existingUser = userManager.findUserByUsername(username);
    if (existingUser) {
      const overwrite = await question(`\nUser "${username}" already exists. Overwrite? (yes/no): `);
      if (overwrite.toLowerCase() !== 'yes' && overwrite.toLowerCase() !== 'y') {
        console.log('Operation cancelled.');
        rl.close();
        process.exit(0);
      }

      // 기존 사용자 삭제
      userManager.deleteUser(existingUser.id);
    }

    // 사용자 추가
    console.log('\nCreating admin user...');

    const newUser = await userManager.addUser({
      id: `admin-${Date.now()}`,
      username: username,
      password: password,
      role: 'admin',
      active: true
    });

    console.log('\n✅ Admin user created successfully!');
    console.log('\nUser Details:');
    console.log(`  ID: ${newUser.id}`);
    console.log(`  Username: ${newUser.username}`);
    console.log(`  Role: ${newUser.role}`);
    console.log(`  Active: ${newUser.active}`);
    console.log(`  Created: ${newUser.createdAt}`);

    console.log('\n🔐 Please save your credentials securely.');
    console.log('You can now login at: http://localhost:3000/login');

    rl.close();
  } catch (error) {
    console.error('\n❌ Error creating admin user:', error.message);
    rl.close();
    process.exit(1);
  }
}

// 스크립트 실행
createAdmin();
