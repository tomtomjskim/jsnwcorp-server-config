#!/bin/bash

# Test Authentication Script
# Dashboard v2.1.0 보안 테스트

set -e

BASE_URL="http://localhost:3000"
COOKIES_FILE="/tmp/dashboard-cookies.txt"
TEST_USERNAME="jsnetwork"
TEST_PASSWORD="jsnetwork1!1!"

echo "========================================="
echo "Dashboard v2.1.0 Authentication Test"
echo "========================================="
echo ""

# Clean up old cookies
rm -f $COOKIES_FILE

# Test 1: Public API (No auth required)
echo "[Test 1] Public API - GET /api/projects"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $BASE_URL/api/projects)
if [ "$RESPONSE" = "200" ]; then
    echo "✅ PASS: Public API accessible without authentication"
else
    echo "❌ FAIL: Expected 200, got $RESPONSE"
    exit 1
fi
echo ""

# Test 2: Public API - GET /api/releases
echo "[Test 2] Public API - GET /api/releases"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $BASE_URL/api/releases)
if [ "$RESPONSE" = "200" ]; then
    echo "✅ PASS: Releases API accessible without authentication"
else
    echo "❌ FAIL: Expected 200, got $RESPONSE"
    exit 1
fi
echo ""

# Test 3: Admin API (Unauthorized)
echo "[Test 3] Admin API - GET /api/stats (Unauthorized)"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $BASE_URL/api/stats)
if [ "$RESPONSE" = "401" ]; then
    echo "✅ PASS: Admin API requires authentication"
else
    echo "❌ FAIL: Expected 401, got $RESPONSE"
    exit 1
fi
echo ""

# Test 4: Admin API - GET /api/developers (Unauthorized)
echo "[Test 4] Admin API - GET /api/developers (Unauthorized)"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $BASE_URL/api/developers)
if [ "$RESPONSE" = "401" ]; then
    echo "✅ PASS: Developers API requires authentication"
else
    echo "❌ FAIL: Expected 401, got $RESPONSE"
    exit 1
fi
echo ""

# Test 5: Login with wrong credentials
echo "[Test 5] Login - Wrong credentials"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
  $BASE_URL/api/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"admin\",\"password\":\"wrongpassword\"}")
if [ "$RESPONSE" = "401" ]; then
    echo "✅ PASS: Login rejected with wrong credentials"
else
    echo "❌ FAIL: Expected 401, got $RESPONSE"
    exit 1
fi
echo ""

# Test 6: Login with correct credentials
echo "[Test 6] Login - Correct credentials"
RESPONSE=$(curl -s -X POST \
  $BASE_URL/api/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"$TEST_USERNAME\",\"password\":\"$TEST_PASSWORD\"}" \
  -c $COOKIES_FILE)

if echo "$RESPONSE" | grep -q '"success":true'; then
    echo "✅ PASS: Login successful"
else
    echo "❌ FAIL: Login failed"
    echo "Response: $RESPONSE"
    exit 1
fi
echo ""

# Test 7: Check auth status
echo "[Test 7] GET /api/auth/me (Authenticated)"
RESPONSE=$(curl -s $BASE_URL/api/auth/me -b $COOKIES_FILE)
if echo "$RESPONSE" | grep -q '"authenticated":true'; then
    echo "✅ PASS: Auth status confirmed"
else
    echo "❌ FAIL: Not authenticated"
    echo "Response: $RESPONSE"
    exit 1
fi
echo ""

# Test 8: Admin API with authentication
echo "[Test 8] Admin API - GET /api/stats (Authenticated)"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $BASE_URL/api/stats -b $COOKIES_FILE)
if [ "$RESPONSE" = "200" ]; then
    echo "✅ PASS: Admin API accessible with authentication"
else
    echo "❌ FAIL: Expected 200, got $RESPONSE"
    exit 1
fi
echo ""

# Test 9: Admin API - GET /api/developers (Authenticated)
echo "[Test 9] Admin API - GET /api/developers (Authenticated)"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $BASE_URL/api/developers -b $COOKIES_FILE)
if [ "$RESPONSE" = "200" ]; then
    echo "✅ PASS: Developers API accessible with authentication"
else
    echo "❌ FAIL: Expected 200, got $RESPONSE"
    exit 1
fi
echo ""

# Test 10: Admin API - GET /api/system/status (Authenticated)
echo "[Test 10] Admin API - GET /api/system/status (Authenticated)"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $BASE_URL/api/system/status -b $COOKIES_FILE)
if [ "$RESPONSE" = "200" ]; then
    echo "✅ PASS: System status API accessible with authentication"
else
    echo "❌ FAIL: Expected 200, got $RESPONSE"
    exit 1
fi
echo ""

# Test 11: Logout
echo "[Test 11] POST /api/auth/logout"
RESPONSE=$(curl -s -X POST $BASE_URL/api/auth/logout \
  -H "Content-Type: application/json" \
  -b $COOKIES_FILE)

if echo "$RESPONSE" | grep -q '"success":true'; then
    echo "✅ PASS: Logout successful"
else
    echo "❌ FAIL: Logout failed"
    echo "Response: $RESPONSE"
    exit 1
fi
echo ""

# Test 12: Verify logout (admin API should now fail)
echo "[Test 12] Admin API after logout (should fail)"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $BASE_URL/api/stats -b $COOKIES_FILE)
if [ "$RESPONSE" = "401" ]; then
    echo "✅ PASS: Admin API blocked after logout"
else
    echo "❌ FAIL: Expected 401, got $RESPONSE"
    exit 1
fi
echo ""

# Clean up
rm -f $COOKIES_FILE

echo "========================================="
echo "All tests passed! ✅"
echo "========================================="
