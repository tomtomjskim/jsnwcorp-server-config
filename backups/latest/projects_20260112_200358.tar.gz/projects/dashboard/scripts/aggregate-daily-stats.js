#!/usr/bin/env node

const db = require('../lib/db');

const args = process.argv.slice(2);
let targetDates = [];

if (args.length === 0) {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  targetDates.push(yesterday.toISOString().split('T')[0]);
} else if (args[0] === '--last-7-days') {
  for (let i = 1; i <= 7; i++) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    targetDates.push(date.toISOString().split('T')[0]);
  }
} else if (args[0] === '--all') {
  targetDates = null;
} else {
  targetDates.push(args[0]);
}

async function aggregateDailyStats(date) {
  console.log(`[${date}] Aggregating...`);

  try {
    const projectsResult = await db.query('SELECT id FROM public.projects');
    const projects = projectsResult.rows;

    for (const project of projects) {
      const projectId = project.id;

      const statsResult = await db.query(`
        SELECT
          COUNT(DISTINCT user_id) FILTER (WHERE user_id IS NOT NULL) as unique_visitors,
          COUNT(*) FILTER (WHERE event_type IN ('pageview', 'page_view')) as total_page_views,
          COUNT(*) as total_events,
          COUNT(*) FILTER (WHERE event_type = 'error_occurred') as error_count,
          AVG((metadata->>'response_time')::numeric) FILTER (
            WHERE metadata->>'response_time' IS NOT NULL
          ) as avg_response_time_ms
        FROM public.analytics_events
        WHERE project_id = $1 AND DATE(created_at) = $2
      `, [projectId, date]);

      if (!statsResult.rows[0] || statsResult.rows[0].total_events === '0') {
        console.log(`  [${projectId}] No events`);
        continue;
      }

      const stats = statsResult.rows[0];

      const breakdownResult = await db.query(`
        SELECT jsonb_object_agg(event_type, event_count) as event_breakdown
        FROM (
          SELECT event_type, COUNT(*) as event_count
          FROM public.analytics_events
          WHERE project_id = $1 AND DATE(created_at) = $2 AND event_type IS NOT NULL
          GROUP BY event_type
        ) sub
      `, [projectId, date]);

      const newUsersResult = await db.query(`
        SELECT COUNT(DISTINCT user_id) as new_users
        FROM public.analytics_events
        WHERE project_id = $1 AND DATE(created_at) = $2 AND user_id IS NOT NULL
          AND NOT EXISTS (
            SELECT 1 FROM public.analytics_events e2
            WHERE e2.project_id = $1 AND e2.user_id = analytics_events.user_id
              AND DATE(e2.created_at) < $2
          )
      `, [projectId, date]);

      const returningUsersResult = await db.query(`
        SELECT COUNT(DISTINCT user_id) as returning_users
        FROM public.analytics_events
        WHERE project_id = $1 AND DATE(created_at) = $2 AND user_id IS NOT NULL
          AND EXISTS (
            SELECT 1 FROM public.analytics_events e2
            WHERE e2.project_id = $1 AND e2.user_id = analytics_events.user_id
              AND DATE(e2.created_at) < $2
          )
      `, [projectId, date]);

      const uniqueVisitors = parseInt(stats.unique_visitors) || 0;
      const totalPageViews = parseInt(stats.total_page_views) || 0;
      const totalEvents = parseInt(stats.total_events) || 0;
      const errorCount = parseInt(stats.error_count) || 0;
      const newUsers = parseInt(newUsersResult.rows[0]?.new_users) || 0;
      const returningUsers = parseInt(returningUsersResult.rows[0]?.returning_users) || 0;
      const avgResponseTime = stats.avg_response_time_ms ? parseFloat(stats.avg_response_time_ms).toFixed(2) : null;
      const errorRate = totalEvents > 0 ? ((errorCount / totalEvents) * 100).toFixed(2) : 0;
      const eventBreakdown = breakdownResult.rows[0]?.event_breakdown || {};

      await db.query(`
        INSERT INTO analytics.daily_stats (
          project_id, date, unique_visitors, total_page_views, new_users, returning_users,
          total_events, event_breakdown, avg_response_time_ms, error_count, error_rate,
          total_api_calls, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW())
        ON CONFLICT (project_id, date)
        DO UPDATE SET
          unique_visitors = EXCLUDED.unique_visitors,
          total_page_views = EXCLUDED.total_page_views,
          new_users = EXCLUDED.new_users,
          returning_users = EXCLUDED.returning_users,
          total_events = EXCLUDED.total_events,
          event_breakdown = EXCLUDED.event_breakdown,
          avg_response_time_ms = EXCLUDED.avg_response_time_ms,
          error_count = EXCLUDED.error_count,
          error_rate = EXCLUDED.error_rate,
          updated_at = NOW()
      `, [
        projectId, date, uniqueVisitors, totalPageViews, newUsers, returningUsers,
        totalEvents, eventBreakdown, avgResponseTime, errorCount, errorRate, 0
      ]);

      console.log(`  ✓ [${projectId}] ${totalEvents} events, ${uniqueVisitors} visitors`);
    }

    console.log(`[${date}] Completed`);
  } catch (error) {
    console.error(`[${date}] Failed:`, error.message);
    throw error;
  }
}

async function main() {
  console.log('Daily Stats Aggregator');

  try {
    const testResult = await db.testConnection();
    if (!testResult) throw new Error('DB connection failed');

    if (targetDates === null) {
      const datesResult = await db.query(`
        SELECT DISTINCT DATE(created_at) as date
        FROM public.analytics_events
        ORDER BY date DESC
      `);
      targetDates = datesResult.rows.map(row => row.date.toISOString().split('T')[0]);
    }

    for (const date of targetDates) {
      await aggregateDailyStats(date);
    }

    console.log('✓ All completed');
    process.exit(0);
  } catch (error) {
    console.error('✗ Failed:', error.message);
    process.exit(1);
  }
}

process.on('unhandledRejection', (error) => {
  console.error('Unhandled rejection:', error);
  process.exit(1);
});

main();
