/**
 * User Manager
 * 사용자 계정 관리 유틸리티
 */

const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');

const USERS_FILE = path.join(__dirname, '../data/users.json');
const SALT_ROUNDS = 10;

/**
 * 사용자 데이터 로드
 */
function loadUsers() {
  try {
    if (!fs.existsSync(USERS_FILE)) {
      return [];
    }
    const data = fs.readFileSync(USERS_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error loading users:', error);
    return [];
  }
}

/**
 * 사용자 데이터 저장
 */
function saveUsers(users) {
  try {
    const dir = path.dirname(USERS_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    }
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), { mode: 0o600 });
    return true;
  } catch (error) {
    console.error('Error saving users:', error);
    return false;
  }
}

/**
 * ID로 사용자 찾기
 */
function findUserById(userId) {
  const users = loadUsers();
  return users.find(u => u.id === userId);
}

/**
 * 사용자명으로 사용자 찾기
 */
function findUserByUsername(username) {
  const users = loadUsers();
  return users.find(u => u.username === username);
}

/**
 * 사용자 추가
 */
async function addUser(userData) {
  try {
    const users = loadUsers();

    // 중복 체크
    if (users.some(u => u.username === userData.username)) {
      throw new Error('Username already exists');
    }
    if (users.some(u => u.id === userData.id)) {
      throw new Error('User ID already exists');
    }

    // 비밀번호 해싱
    const passwordHash = await bcrypt.hash(userData.password, SALT_ROUNDS);

    const newUser = {
      id: userData.id,
      username: userData.username,
      passwordHash: passwordHash,
      role: userData.role || 'admin',
      active: userData.active !== undefined ? userData.active : true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    users.push(newUser);

    if (saveUsers(users)) {
      // 비밀번호 제거하고 반환
      const { passwordHash, ...userWithoutPassword } = newUser;
      return userWithoutPassword;
    } else {
      throw new Error('Failed to save user');
    }
  } catch (error) {
    throw error;
  }
}

/**
 * 사용자 업데이트
 */
async function updateUser(userId, updates) {
  try {
    const users = loadUsers();
    const userIndex = users.findIndex(u => u.id === userId);

    if (userIndex === -1) {
      throw new Error('User not found');
    }

    const user = users[userIndex];

    // 비밀번호 변경
    if (updates.password) {
      updates.passwordHash = await bcrypt.hash(updates.password, SALT_ROUNDS);
      delete updates.password;
    }

    // 사용자명 중복 체크
    if (updates.username && updates.username !== user.username) {
      if (users.some(u => u.username === updates.username)) {
        throw new Error('Username already exists');
      }
    }

    // 업데이트
    users[userIndex] = {
      ...user,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    if (saveUsers(users)) {
      const { passwordHash, ...userWithoutPassword } = users[userIndex];
      return userWithoutPassword;
    } else {
      throw new Error('Failed to update user');
    }
  } catch (error) {
    throw error;
  }
}

/**
 * 사용자 삭제
 */
function deleteUser(userId) {
  try {
    const users = loadUsers();
    const filteredUsers = users.filter(u => u.id !== userId);

    if (filteredUsers.length === users.length) {
      throw new Error('User not found');
    }

    return saveUsers(filteredUsers);
  } catch (error) {
    throw error;
  }
}

/**
 * 비밀번호 검증
 */
async function verifyPassword(username, password) {
  try {
    const user = findUserByUsername(username);

    if (!user) {
      return { success: false, message: 'User not found' };
    }

    if (!user.active) {
      return { success: false, message: 'User is inactive' };
    }

    const isValid = await bcrypt.compare(password, user.passwordHash);

    if (isValid) {
      const { passwordHash, ...userWithoutPassword } = user;
      return { success: true, user: userWithoutPassword };
    } else {
      return { success: false, message: 'Invalid password' };
    }
  } catch (error) {
    console.error('Error verifying password:', error);
    return { success: false, message: 'Verification error' };
  }
}

/**
 * 모든 사용자 목록 (비밀번호 제외)
 */
function getAllUsers() {
  const users = loadUsers();
  return users.map(({ passwordHash, ...user }) => user);
}

module.exports = {
  loadUsers,
  saveUsers,
  findUserById,
  findUserByUsername,
  addUser,
  updateUser,
  deleteUser,
  verifyPassword,
  getAllUsers
};
