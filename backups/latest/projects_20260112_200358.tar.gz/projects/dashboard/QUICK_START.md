# Dashboard v2.0 - 빠른 시작 가이드

## 🚀 5분 안에 시작하기

### 1. 대시보드 접속
브라우저에서 http://203.245.30.6:80 열기

### 2. 주요 기능 둘러보기

#### 프로젝트 찾기
- **검색창 사용**: 사이드바 상단 검색창에 키워드 입력
  - 예: "lotto", "Next.js", "데이터"

#### 프로젝트 필터링
- **운영중 프로젝트만**: 사이드바 → 프로젝트 → 운영중
- **Full-stack 프로젝트**: 사이드바 → 카테고리 → Full-stack
- **특정 팀 프로젝트**: 사이드바 → 개발자 노트 → 개발자별

#### 릴리즈 히스토리 확인
- 사이드바 → 개발자 노트 → 릴리즈 노트
- 모든 프로젝트의 버전 업데이트 히스토리 확인

#### 배포 타임라인
- 사이드바 → 개발자 노트 → 타임라인
- 시간순으로 정렬된 배포 히스토리

## ⚡ 자주 사용하는 작업

### 새 프로젝트 추가 (3단계)

**1단계**: `server.js`에서 PROJECTS 배열에 추가
```javascript
{
  id: 'my-project',
  name: 'MyProject',
  emoji: '🚀',
  description: '프로젝트 설명',
  url: 'http://203.245.30.6:3005',
  port: 3005,
  status: 'development',
  category: 'backend',
  tags: ['Node.js', 'Express'],
  developer: 'team-a',
  version: '0.1.0',
  deployedAt: '2025-10-17',
  repository: null,
  docs: null
}
```

**2단계**: 대시보드 재배포
```bash
cd /home/deploy
docker compose build dashboard
docker compose up -d dashboard
```

**3단계**: 브라우저에서 확인 (Ctrl+F5로 새로고침)

### 버전 업데이트 (2단계)

**1단계**: RELEASE_NOTES에 추가
```javascript
{
  id: 5,  // 다음 번호
  projectId: 'lotto-master',
  version: '1.1.0',
  date: '2025-10-17',
  type: 'minor',
  developer: 'team-a',
  title: '새 기능 추가',
  changes: [
    { type: 'feature', description: '검색 기능' }
  ]
}
```

**2단계**: 재배포
```bash
docker compose build dashboard && docker compose up -d dashboard
```

## 📊 API 빠른 참조

### 모든 프로젝트
```bash
curl http://203.245.30.6/api/projects
```

### 운영중인 프로젝트만
```bash
curl http://203.245.30.6/api/projects?status=active
```

### 특정 프로젝트 상세
```bash
curl http://203.245.30.6/api/projects/lotto-master
```

### 통계 조회
```bash
curl http://203.245.30.6/api/stats
```

### 개발자 목록
```bash
curl http://203.245.30.6/api/developers
```

### 릴리즈 노트
```bash
curl http://203.245.30.6/api/releases
```

## 🎯 사용 시나리오

### 시나리오 1: 팀원에게 프로젝트 공유
1. 대시보드에서 프로젝트 찾기
2. 프로젝트 카드의 "방문하기" 버튼 URL 복사
3. 팀원에게 공유

### 시나리오 2: 프로젝트 현황 파악
1. 대시보드 메인 화면에서 통계 카드 확인
2. "시스템" → "시스템 상태"에서 전체 현황 확인
3. 카테고리별로 필터링하여 세부 현황 파악

### 시나리오 3: 릴리즈 히스토리 추적
1. "개발자 노트" → "릴리즈 노트"
2. 특정 프로젝트의 버전 업데이트 확인
3. 변경사항 상세 내용 확인

### 시나리오 4: 새 프로젝트 배포
1. docker-compose.yml에 서비스 추가
2. nginx 설정에 포트 추가
3. server.js에 프로젝트 정보 등록
4. 대시보드 재배포
5. 브라우저에서 확인

## 🔧 문제 해결

### 프로젝트가 보이지 않아요
- 브라우저 새로고침 (Ctrl+F5)
- PROJECTS 배열 확인
- 대시보드 재배포 확인

### "방문하기" 버튼이 작동하지 않아요
- nginx 설정 확인
- 프로젝트 컨테이너 상태 확인: `docker compose ps`
- 프로젝트 로그 확인: `docker compose logs [service-name]`

### 검색이 작동하지 않아요
- JavaScript 콘솔 에러 확인 (F12)
- 브라우저 캐시 삭제
- 페이지 새로고침

## 💡 팁과 트릭

### 빠른 검색 단축키
- 검색창에 포커스하려면 페이지 로딩 후 Tab 키
- 검색어 지우기: 검색창의 X 버튼 또는 Ctrl+A → Delete

### 여러 조건으로 필터링
1. API를 사용하면 여러 조건 동시 적용 가능
```bash
curl "http://203.245.30.6/api/projects?status=active&category=full-stack"
```

### 프로젝트 정보 자동 완성
- 기존 프로젝트를 복사해서 수정하면 빠름
- 필수 필드: id, name, url, port, status, category, developer

### 배치 업데이트
여러 프로젝트를 한 번에 추가/수정한 후:
```bash
# 한 번만 재배포
docker compose build dashboard && docker compose up -d dashboard
```

## 📱 모바일 접속

대시보드는 반응형으로 제작되어 모바일에서도 사용 가능합니다:
- 사이드바가 자동으로 축소됨
- 프로젝트 카드가 세로로 정렬됨
- 터치 인터페이스 지원

## 🔐 보안 참고사항

- 한국 IP에서만 접속 가능
- 내부 네트워크 전용
- 외부 공개 금지

## 📈 다음 단계

자세한 내용은 다음 문서를 참조하세요:
- **README.md**: 전체 기능 및 API 문서
- **API_EXAMPLES.md**: API 사용 예시 모음
- **DEVELOPER_GUIDE.md**: 개발자 가이드

## ❓ 자주 묻는 질문

**Q: 프로젝트 순서를 변경할 수 있나요?**
A: PROJECTS 배열의 순서를 변경하면 됩니다.

**Q: 프로젝트를 삭제하려면?**
A: PROJECTS 배열에서 해당 항목을 제거하고 재배포하세요.

**Q: 여러 팀이 같은 프로젝트를 관리하면?**
A: developer 필드는 하나만 지정 가능합니다. 메인 담당자를 지정하세요.

**Q: 릴리즈 노트를 수정하려면?**
A: RELEASE_NOTES 배열에서 해당 항목을 수정하고 재배포하세요.

**Q: API 응답 형식을 변경할 수 있나요?**
A: server.js의 API 라우트 핸들러를 수정하세요.

---

**도움이 필요하세요?** README.md의 "문제 해결" 섹션을 참조하거나 시스템 관리자에게 문의하세요.
