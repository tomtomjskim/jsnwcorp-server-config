# Dashboard 보안 강화 구현 실행 계획

## 📋 프로젝트 개요

### 목표
관리자 로그인 시스템 구현으로 내부 정보(통계, 개발자 정보, 시스템 상태) 보호

### 범위
- **Phase 1**: 기본 인증 시스템 (관리자 로그인)
- **기간**: 2주 (10 영업일)
- **예상 공수**: 13.5시간 (실개발 시간)
- **버전**: v2.1.0

### 성공 기준
1. ✅ 일반 사용자는 로그인 없이 프로젝트 정보 조회 가능
2. ✅ 관리자는 로그인 후 통계/시스템 정보 조회 가능
3. ✅ 비밀번호 안전하게 저장 (bcrypt)
4. ✅ 세션 12시간 유지
5. ✅ 관리자 전용 UI 조건부 표시

---

## 📅 일정 계획

### Week 1: 기반 구축 (Day 1-5)

#### Day 1 (월요일) - 환경 설정 및 데이터 모델
**작업 시간**: 2시간
**담당**: Backend Developer

**Task 1.1: 환경 설정** (30분)
```bash
# 작업 내용
- npm 패키지 설치 (express-session, bcrypt, dotenv)
- .env 파일 생성 및 보안 설정
- 데이터 디렉토리 생성 (data/sessions)
- 권한 설정 (chmod 700)

# 완료 조건
□ package.json에 의존성 추가 확인
□ .env 파일 생성 및 SESSION_SECRET 설정
□ data/sessions 디렉토리 생성
□ .gitignore 업데이트
```

**Task 1.2: 데이터 모델 구현** (1시간)
```bash
# 작업 내용
- utils/user-manager.js 작성
- scripts/create-admin.js 작성
- 관리자 계정 생성

# 완료 조건
□ user-manager.js 함수 구현 (loadUsers, saveUsers 등)
□ create-admin.js 스크립트 작성
□ 관리자 계정 생성 및 data/users.json 확인
□ 비밀번호 bcrypt 해싱 확인
```

**검증**:
```bash
# 패키지 확인
npm list express-session bcrypt dotenv

# 사용자 파일 확인
cat data/users.json

# 비밀번호 해시 확인
node -e "console.log(require('./data/users.json').users[0].passwordHash.length > 50)"
```

---

#### Day 2 (화요일) - 인증 미들웨어
**작업 시간**: 1.5시간
**담당**: Backend Developer

**Task 2: 인증 미들웨어 구현**
```bash
# 작업 내용
- middleware/auth.js 작성
- optionalAuth 미들웨어 (로그인 여부 확인)
- requireAdmin 미들웨어 (관리자 필수)

# 완료 조건
□ optionalAuth 함수 작성
□ requireAdmin 함수 작성
□ 에러 처리 로직 구현
□ 문법 체크 통과 (node -c middleware/auth.js)
```

**코드 구현**:
```javascript
// middleware/auth.js 핵심 로직
function optionalAuth(req, res, next) {
  if (req.session?.userId) {
    const user = findUserById(req.session.userId);
    if (user?.active && user.role === 'admin') {
      req.user = { id: user.id, username: user.username, role: 'admin' };
    }
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session?.userId) {
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ success: false, error: 'Admin login required' });
    }
    return res.redirect('/login');
  }

  const user = findUserById(req.session.userId);
  if (!user?.active || user.role !== 'admin') {
    return res.status(403).json({ success: false, error: 'Admin privileges required' });
  }

  req.user = user;
  next();
}
```

**검증**:
```bash
# 모듈 로드 테스트
node -e "const auth = require('./middleware/auth'); console.log(Object.keys(auth));"
# 예상 출력: [ 'optionalAuth', 'requireAdmin' ]
```

---

#### Day 3 (수요일) - 로그인 API
**작업 시간**: 2시간
**담당**: Backend Developer

**Task 3: 로그인/로그아웃 API 구현**
```bash
# 작업 내용
- routes/auth.js 작성
- POST /api/login (로그인)
- POST /api/logout (로그아웃)
- GET /api/me (현재 사용자)
- server.js에 세션 미들웨어 및 라우트 통합

# 완료 조건
□ /api/login 엔드포인트 구현
□ /api/logout 엔드포인트 구현
□ /api/me 엔드포인트 구현
□ 세션 설정 (express-session) 적용
□ bcrypt 비밀번호 검증 로직
```

**API 스펙**:
```javascript
// POST /api/login
Request:  { "username": "admin", "password": "password" }
Response: { "success": true, "data": { "userId": "...", "role": "admin" } }

// POST /api/logout
Response: { "success": true, "message": "Logged out" }

// GET /api/me
Response: { "success": true, "data": { "userId": "...", "username": "admin", "role": "admin" } }
```

**검증**:
```bash
# 로그인 테스트
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"YourPassword"}' \
  -c cookies.txt -v

# 현재 사용자 확인
curl http://localhost:3000/api/me -b cookies.txt

# 로그아웃
curl -X POST http://localhost:3000/api/logout -b cookies.txt
```

---

#### Day 4-5 (목-금요일) - 로그인 페이지 UI
**작업 시간**: 2시간
**담당**: Frontend Developer (또는 Backend + 간단한 UI)

**Task 4: 로그인 페이지 구현**
```bash
# 작업 내용
- 로그인 페이지 HTML/CSS 작성
- JavaScript 폼 핸들링
- 에러 메시지 표시
- GET /login 라우트 추가

# 완료 조건
□ 로그인 폼 UI 완성
□ 로그인 버튼 클릭 시 /api/login 호출
□ 성공 시 메인 페이지로 리다이렉트
□ 실패 시 에러 메시지 표시
□ "대시보드로 돌아가기" 링크
```

**UI 요구사항**:
- 심플한 중앙 정렬 폼
- 사용자명, 비밀번호 입력
- 로그인 버튼
- 에러 메시지 영역
- 반응형 디자인 (모바일 대응)

**검증**:
```bash
# 브라우저에서 테스트
1. http://localhost:3000/login 접속
2. 잘못된 비밀번호로 로그인 시도 → 에러 메시지 확인
3. 올바른 비밀번호로 로그인 → 메인 페이지 이동 확인
4. 관리자 표시 확인 (헤더에 "관리자" 표시)
```

---

### Week 2: API 보호 및 UI 통합 (Day 6-10)

#### Day 6 (월요일) - API 권한 적용
**작업 시간**: 1시간
**담당**: Backend Developer

**Task 5: 기존 API에 권한 적용**
```bash
# 작업 내용
- Public API 확인 (인증 불필요)
- Admin API에 requireAdmin 적용
- 메인 페이지에 optionalAuth 적용

# 완료 조건
□ GET /api/projects - 인증 불필요 (공개)
□ GET /api/projects/:id - 인증 불필요 (공개)
□ GET /api/releases - 인증 불필요 (공개)
□ GET /api/stats - requireAdmin 적용
□ GET /api/developers - requireAdmin 적용
□ GET /api/system/status - requireAdmin 적용
□ GET / - optionalAuth 적용 (isAdmin 전달)
```

**코드 변경**:
```javascript
// server.js
const { optionalAuth, requireAdmin } = require('./middleware/auth');

// Public API (변경 없음)
app.get('/api/projects', (req, res) => { /* ... */ });
app.get('/api/releases', (req, res) => { /* ... */ });

// Admin API (requireAdmin 추가)
app.get('/api/stats', requireAdmin, (req, res) => { /* ... */ });
app.get('/api/developers', requireAdmin, (req, res) => { /* ... */ });
app.get('/api/system/status', requireAdmin, (req, res) => {
  res.json({
    success: true,
    data: {
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      version: '2.1.0'
    }
  });
});

// Main page (optionalAuth)
app.get('/', optionalAuth, (req, res) => {
  const isAdmin = req.user?.role === 'admin';
  res.send(renderDashboard(isAdmin));
});
```

**검증**:
```bash
# Public API (인증 없이 접근)
curl http://localhost:3000/api/projects
# 예상: 200 OK

# Admin API (미인증)
curl http://localhost:3000/api/stats
# 예상: 401 Unauthorized

# Admin API (인증됨)
curl http://localhost:3000/api/stats -b cookies.txt
# 예상: 200 OK + 통계 데이터
```

---

#### Day 7-8 (화-수요일) - UI 조건부 표시
**작업 시간**: 2시간
**담당**: Frontend Developer

**Task 6: UI 역할별 표시 구현**
```bash
# 작업 내용
- 헤더에 로그인/로그아웃 버튼
- 사이드바에 관리자 전용 섹션 (조건부)
- 관리자 뷰 (통계, 개발자, 시스템) 구현
- JavaScript 로그아웃 함수

# 완료 조건
□ 헤더: 미로그인 시 "🔐 관리자" 링크
□ 헤더: 로그인 시 "👑 관리자 | 로그아웃" 버튼
□ 사이드바: 관리자 전용 섹션 (isAdmin일 때만)
□ 관리자 뷰: 통계 페이지
□ 관리자 뷰: 개발자 정보 페이지
□ 관리자 뷰: 시스템 상태 페이지
□ 로그아웃 시 페이지 새로고침
```

**UI 구조**:
```html
<!-- 헤더 (조건부) -->
<nav class="navbar">
  <div class="nav-left">
    <h1>🚀 Dashboard</h1>
  </div>
  <div class="nav-right">
    <!-- 미로그인 -->
    <a href="/login" class="admin-login-link">🔐 관리자</a>

    <!-- 로그인 시 -->
    <div class="user-menu">
      <span class="admin-badge">👑 관리자</span>
      <button onclick="logout()">로그아웃</button>
    </div>
  </div>
</nav>

<!-- 사이드바: 관리자 전용 섹션 (조건부) -->
<div class="menu-section admin-section" style="display: ${isAdmin ? 'block' : 'none'}">
  <div class="menu-title">⭐ 관리자 전용</div>
  <div class="menu-item" onclick="showAdminView('stats')">
    <span class="menu-icon">📊</span>
    <span>통계</span>
  </div>
  <div class="menu-item" onclick="showAdminView('developers')">
    <span class="menu-icon">👥</span>
    <span>개발자 정보</span>
  </div>
  <div class="menu-item" onclick="showAdminView('system')">
    <span class="menu-icon">⚙️</span>
    <span>시스템 상태</span>
  </div>
</div>
```

**JavaScript 함수**:
```javascript
async function showAdminView(view) {
  if (!window.IS_ADMIN) {
    alert('관리자만 접근 가능합니다.');
    return;
  }

  let data;
  switch(view) {
    case 'stats':
      data = await fetch('/api/stats').then(r => r.json());
      renderStatsView(data.data);
      break;
    case 'developers':
      data = await fetch('/api/developers').then(r => r.json());
      renderDevelopersView(data.data);
      break;
    case 'system':
      data = await fetch('/api/system/status').then(r => r.json());
      renderSystemView(data.data);
      break;
  }
}

async function logout() {
  await fetch('/api/logout', { method: 'POST' });
  window.location.reload();
}
```

**검증**:
```bash
# 브라우저에서 테스트
1. 비로그인 상태로 http://localhost:3000 접속
   → "🔐 관리자" 링크 확인
   → 사이드바에 관리자 섹션 없음 확인

2. 로그인 후
   → "👑 관리자 | 로그아웃" 확인
   → 사이드바에 "⭐ 관리자 전용" 섹션 확인

3. 통계 클릭 → 통계 데이터 표시 확인
4. 개발자 정보 클릭 → 개발자 정보 표시 확인
5. 시스템 상태 클릭 → 시스템 정보 표시 확인
6. 로그아웃 → 페이지 새로고침 및 관리자 섹션 숨김 확인
```

---

#### Day 9 (목요일) - 테스트 및 검증
**작업 시간**: 1.5시간
**담당**: QA + Backend Developer

**Task 7: 통합 테스트**
```bash
# 테스트 시나리오

# 7.1 Public API 테스트
□ 프로젝트 목록 조회 (미인증) → 200 OK
□ 프로젝트 상세 조회 (미인증) → 200 OK
□ 릴리즈 노트 조회 (미인증) → 200 OK
□ 프로젝트 검색 (미인증) → 200 OK

# 7.2 Admin API 테스트 (미인증)
□ 통계 조회 (미인증) → 401 Unauthorized
□ 개발자 정보 (미인증) → 401 Unauthorized
□ 시스템 상태 (미인증) → 401 Unauthorized

# 7.3 로그인 테스트
□ 잘못된 사용자명 → 401 Invalid credentials
□ 잘못된 비밀번호 → 401 Invalid credentials
□ 올바른 로그인 → 200 OK + 세션 생성
□ 로그인 Rate limiting → 15분 5회 제한

# 7.4 Admin API 테스트 (인증됨)
□ 통계 조회 (인증) → 200 OK + 통계 데이터
□ 개발자 정보 (인증) → 200 OK + 개발자 데이터
□ 시스템 상태 (인증) → 200 OK + 시스템 정보

# 7.5 세션 테스트
□ 세션 12시간 유지 확인
□ 로그아웃 후 세션 무효화 확인
□ 유효하지 않은 세션 ID → 401

# 7.6 UI 테스트
□ 비로그인: 관리자 섹션 숨김
□ 로그인: 관리자 섹션 표시
□ 관리자 뷰 데이터 로딩
□ 로그아웃 버튼 동작
```

**자동화 테스트 스크립트**:
```bash
#!/bin/bash
# test-auth.sh

echo "=== Public API Tests ==="
curl -s http://localhost:3000/api/projects | grep -q "success" && echo "✅ Projects API" || echo "❌ Projects API"

echo ""
echo "=== Admin API Tests (Unauthorized) ==="
curl -s http://localhost:3000/api/stats | grep -q "401" && echo "✅ Stats blocked" || echo "❌ Stats not blocked"

echo ""
echo "=== Login Test ==="
curl -s -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"YourPassword"}' \
  -c cookies.txt | grep -q "success" && echo "✅ Login success" || echo "❌ Login failed"

echo ""
echo "=== Admin API Tests (Authorized) ==="
curl -s http://localhost:3000/api/stats -b cookies.txt | grep -q "success" && echo "✅ Stats accessible" || echo "❌ Stats not accessible"

echo ""
echo "=== Logout Test ==="
curl -s -X POST http://localhost:3000/api/logout -b cookies.txt | grep -q "success" && echo "✅ Logout success" || echo "❌ Logout failed"

rm -f cookies.txt
```

**실행**:
```bash
chmod +x test-auth.sh
./test-auth.sh
```

---

#### Day 10 (금요일) - 문서화 및 배포
**작업 시간**: 2시간
**담당**: Tech Lead + DevOps

**Task 8: 문서 업데이트** (1시간)
```bash
# 작업 내용
- README.md 업데이트 (인증 시스템 섹션)
- API_EXAMPLES.md 업데이트 (로그인 예시)
- CHANGELOG.md 업데이트 (v2.1.0)

# 완료 조건
□ README.md에 "인증 시스템" 섹션 추가
□ API_EXAMPLES.md에 로그인 예시 추가
□ CHANGELOG.md에 v2.1.0 변경사항 추가
```

**Task 9: 배포** (1시간)
```bash
# 배포 절차

# 9.1 백업
cp -r /home/deploy/projects/dashboard /home/deploy/backup/dashboard-v2.0-$(date +%Y%m%d)

# 9.2 환경 변수 설정
echo "SESSION_SECRET=$(openssl rand -base64 32)" >> /home/deploy/projects/dashboard/.env
chmod 600 /home/deploy/projects/dashboard/.env

# 9.3 관리자 계정 생성
cd /home/deploy/projects/dashboard
node scripts/create-admin.js "SecurePassword123!"
# 비밀번호를 안전한 곳에 기록

# 9.4 빌드
cd /home/deploy
docker compose build dashboard

# 9.5 배포
docker compose up -d dashboard

# 9.6 로그 확인
docker compose logs -f dashboard

# 9.7 헬스 체크
curl http://localhost:80/
curl http://localhost:80/api/projects

# 완료 조건
□ 백업 완료
□ 환경 변수 설정
□ 관리자 계정 생성
□ 컨테이너 빌드 성공
□ 서비스 정상 시작
□ 헬스 체크 통과
```

**배포 후 검증**:
```bash
# 1. 대시보드 접속
curl http://203.245.30.6:80/

# 2. Public API 테스트
curl http://203.245.30.6/api/projects

# 3. 로그인 테스트
curl -X POST http://203.245.30.6/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"SecurePassword123!"}' \
  -c cookies.txt

# 4. Admin API 테스트
curl http://203.245.30.6/api/stats -b cookies.txt

# 5. 브라우저 테스트
# http://203.245.30.6:80/ 접속
# 로그인 테스트
# 관리자 기능 확인
```

---

## 📊 진행 상황 추적

### 진행률 체크리스트

```
Week 1: 기반 구축
├─ [진행전] Day 1: 환경 설정 및 데이터 모델 (2h)
│  ├─ [진행전] Task 1.1: 환경 설정 (30분)
│  └─ [진행전] Task 1.2: 데이터 모델 (1시간)
├─ [진행전] Day 2: 인증 미들웨어 (1.5h)
│  └─ [진행전] Task 2: 미들웨어 구현
├─ [진행전] Day 3: 로그인 API (2h)
│  └─ [진행전] Task 3: API 구현
└─ [진행전] Day 4-5: 로그인 페이지 UI (2h)
   └─ [진행전] Task 4: UI 구현

Week 2: API 보호 및 UI 통합
├─ [진행전] Day 6: API 권한 적용 (1h)
│  └─ [진행전] Task 5: 권한 적용
├─ [진행전] Day 7-8: UI 조건부 표시 (2h)
│  └─ [진행전] Task 6: UI 통합
├─ [진행전] Day 9: 테스트 (1.5h)
│  └─ [진행전] Task 7: 통합 테스트
└─ [진행전] Day 10: 문서화 및 배포 (2h)
   ├─ [진행전] Task 8: 문서 업데이트
   └─ [진행전] Task 9: 배포

총 예상 시간: 13.5시간
```

### Daily Standup Template

```markdown
## Day X Standup

**어제 완료**:
- [ ] Task 항목

**오늘 계획**:
- [ ] Task 항목

**이슈/블로커**:
- 없음 / 또는 이슈 기술

**도움 필요**:
- 없음 / 또는 도움 요청
```

---

## 🎯 역할 및 책임

### Backend Developer
- Day 1-3: 환경 설정, 데이터 모델, 미들웨어, API
- Day 6: API 권한 적용
- Day 9: 테스트 지원
- **총 공수**: 8시간

### Frontend Developer
- Day 4-5: 로그인 페이지
- Day 7-8: UI 조건부 표시
- **총 공수**: 4시간

### QA
- Day 9: 통합 테스트
- **총 공수**: 1.5시간

### Tech Lead / DevOps
- Day 10: 문서화 및 배포
- 전체 리뷰 및 승인
- **총 공수**: 2시간

---

## 📋 체크리스트

### 구현 완료 조건

#### 기능
- [ ] 관리자 로그인/로그아웃 기능
- [ ] Public API 인증 불필요
- [ ] Admin API 인증 필요
- [ ] 관리자 전용 UI (조건부 표시)
- [ ] 세션 12시간 유지
- [ ] 비밀번호 bcrypt 해싱

#### 보안
- [ ] SESSION_SECRET 안전하게 관리 (.env)
- [ ] httpOnly 쿠키 사용
- [ ] sameSite 'strict' 설정
- [ ] 로그인 Rate limiting (15분 5회)
- [ ] 에러 메시지에서 정보 누출 방지

#### 테스트
- [ ] Public API 접근 테스트 통과
- [ ] Admin API 미인증 차단 테스트 통과
- [ ] 로그인/로그아웃 테스트 통과
- [ ] Admin API 인증 접근 테스트 통과
- [ ] UI 조건부 표시 테스트 통과
- [ ] 세션 만료 테스트 통과

#### 문서
- [ ] README.md 업데이트
- [ ] API_EXAMPLES.md 업데이트
- [ ] CHANGELOG.md 업데이트
- [ ] 관리자 비밀번호 안전하게 기록

#### 배포
- [ ] 백업 완료
- [ ] 환경 변수 설정
- [ ] 관리자 계정 생성
- [ ] 빌드 성공
- [ ] 서비스 정상 시작
- [ ] 헬스 체크 통과

---

## 🚨 리스크 및 대응

### 리스크 1: npm 패키지 설치 실패
**확률**: 낮음
**영향도**: 높음
**대응**:
- package-lock.json 백업
- npm cache clean
- Node.js 버전 확인 (18+)

### 리스크 2: 세션 저장소 권한 문제
**확률**: 중간
**영향도**: 높음
**대응**:
- 디렉토리 권한 확인 (chmod 700)
- Docker 컨테이너 사용자 확인
- Volume 마운트 확인

### 리스크 3: 관리자 비밀번호 분실
**확률**: 낮음
**영향도**: 중간
**대응**:
- 비밀번호를 안전한 곳에 기록
- create-admin.js 스크립트로 재생성 가능
- 백업에서 복구 가능

### 리스크 4: 기존 기능 영향
**확률**: 낮음
**영향도**: 높음
**대응**:
- 배포 전 백업 필수
- Public API 인증 제거 확인
- 점진적 배포 (테스트 환경 → 운영)

### 리스크 5: 테스트 시간 부족
**확률**: 중간
**영향도**: 중간
**대응**:
- 자동화 테스트 스크립트 사용
- 핵심 시나리오 우선 테스트
- 필요 시 Day 10을 테스트에 할애

---

## 📞 커뮤니케이션 계획

### Daily Standup
- **시간**: 매일 오전 10시
- **소요**: 15분
- **참석**: 전체 팀
- **내용**: 진행 상황, 이슈, 계획

### 주간 리뷰
- **Week 1 종료 (Day 5)**: 기반 구축 리뷰
- **Week 2 종료 (Day 10)**: 최종 배포 및 회고

### 이슈 보고
- **즉시**: 블로커 발생 시
- **일일**: Standup에서 공유
- **주간**: 리뷰 미팅에서 정리

---

## 🎉 완료 기준

### Phase 1 완료 선언 조건
1. ✅ 모든 테스트 통과
2. ✅ 운영 환경 배포 완료
3. ✅ 문서 업데이트 완료
4. ✅ 팀 리뷰 승인
5. ✅ 관리자 비밀번호 안전하게 관리

### 성공 지표
- **기능 완성도**: 100% (모든 Task 완료)
- **테스트 통과율**: 100%
- **버그**: 0건 (Critical/High)
- **문서화**: 100% (README, API_EXAMPLES, CHANGELOG)
- **배포 성공**: ✅ 롤백 없음

---

## 📚 참고 문서

1. **SECURITY_REDESIGN.md** - 상세 설계 및 코드 예시
2. **SECURITY_FINAL.md** - 빠른 참조 및 FAQ
3. **README.md** - 프로젝트 전체 문서
4. **API_EXAMPLES.md** - API 사용 예시

---

## 🔄 다음 단계 (Phase 2)

Phase 1 완료 후:
1. 1주일 안정화 기간
2. 사용자 피드백 수집
3. Phase 2 (API 키) 계획 수립
4. Phase 2 개발 시작 (예상 1-2주)

---

**문서 버전**: 1.0
**작성일**: 2025-10-16
**승인**: 대기중
**상태**: 📋 실행 계획 작성 완료
