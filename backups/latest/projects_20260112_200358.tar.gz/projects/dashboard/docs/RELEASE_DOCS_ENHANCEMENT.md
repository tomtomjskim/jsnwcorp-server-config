# 프로젝트별 릴리즈 문서 참조 기능 개선

## 📋 현재 상태

### 기존 구조
```javascript
const RELEASE_NOTES = [
  {
    id: 1,
    projectId: 'lotto-master',
    version: '1.0.0',
    date: '2025-10-16',
    type: 'major',
    developer: 'team-a',
    title: 'LottoMaster 초기 릴리즈',
    changes: [
      { type: 'feature', description: '3가지 알고리즘 기반 번호 생성' }
    ]
  }
];
```

### 문제점
- ❌ 릴리즈 문서가 dashboard의 `server.js`에 하드코딩됨
- ❌ 각 프로젝트의 실제 CHANGELOG나 릴리즈 문서와 분리됨
- ❌ 프로젝트별로 자체 릴리즈 문서가 있어도 참조 불가
- ❌ 릴리즈 정보 업데이트 시 dashboard를 수정해야 함

---

## 🎯 개선 방안

### 방안 1: 프로젝트별 릴리즈 문서 참조 (권장)

각 프로젝트가 자신의 릴리즈 정보를 API로 제공하고, Dashboard가 이를 수집하는 방식

#### 아키텍처
```
┌─────────────────┐
│   Dashboard     │
│                 │
│  GET /releases  │
└────────┬────────┘
         │
         ├─ fetch → http://lotto-master:3000/api/release-info
         ├─ fetch → http://project2:3000/api/release-info
         └─ fetch → http://project3:3000/api/release-info
                           │
                           ▼
                    각 프로젝트의 릴리즈 정보
```

#### 구현 상세

**1단계: 각 프로젝트에 릴리즈 정보 API 추가**

각 프로젝트 (예: LottoMaster)에 릴리즈 정보를 제공하는 엔드포인트 추가:

```javascript
// lotto-master/server.js 또는 별도 API 파일

const RELEASE_INFO = {
  projectId: 'lotto-master',
  projectName: 'LottoMaster',
  currentVersion: '1.0.0',
  releases: [
    {
      version: '1.0.0',
      date: '2025-10-16',
      type: 'major',
      title: 'LottoMaster 초기 릴리즈',
      changes: [
        { type: 'feature', description: '3가지 알고리즘 기반 번호 생성 (랜덤, 빈도, 패턴)' },
        { type: 'feature', description: '당첨 이력 조회 기능' },
        { type: 'feature', description: '번호별 출현 빈도 통계' },
        { type: 'tech', description: 'Next.js 15 + TypeScript 기반 구축' },
        { type: 'tech', description: 'Docker 멀티스테이지 빌드 최적화' }
      ],
      // 외부 문서 링크 (선택)
      changelogUrl: '/CHANGELOG.md',
      releaseNotesUrl: 'https://github.com/user/lotto-master/releases/tag/v1.0.0'
    }
  ]
};

// API 엔드포인트
app.get('/api/release-info', (req, res) => {
  res.json({
    success: true,
    data: RELEASE_INFO
  });
});
```

**2단계: Dashboard에서 프로젝트별 릴리즈 정보 수집**

```javascript
// dashboard/server.js

// 프로젝트 설정에 릴리즈 API URL 추가
const PROJECTS = [
  {
    id: 'lotto-master',
    name: 'LottoMaster',
    url: 'http://203.245.30.6:3001',
    port: 3001,
    // 내부 컨테이너 URL (Docker 네트워크)
    internalUrl: 'http://172.20.0.11:3000',
    releaseApiUrl: 'http://172.20.0.11:3000/api/release-info',  // 추가
    hasReleaseApi: true,  // 릴리즈 API 지원 여부
    // ... 기타 필드
  }
];

// 릴리즈 정보 수집 함수
async function fetchProjectReleases(project) {
  if (!project.hasReleaseApi || !project.releaseApiUrl) {
    return null;
  }

  try {
    const response = await fetch(project.releaseApiUrl, {
      timeout: 3000  // 3초 타임아웃
    });

    if (!response.ok) {
      console.warn(`Failed to fetch releases for ${project.id}: ${response.status}`);
      return null;
    }

    const data = await response.json();
    return data.success ? data.data : null;

  } catch (error) {
    console.error(`Error fetching releases for ${project.id}:`, error.message);
    return null;
  }
}

// 모든 프로젝트의 릴리즈 정보 수집
async function aggregateReleases() {
  const releasePromises = PROJECTS
    .filter(p => p.hasReleaseApi)
    .map(p => fetchProjectReleases(p));

  const results = await Promise.allSettled(releasePromises);

  const aggregated = [];
  results.forEach((result, index) => {
    if (result.status === 'fulfilled' && result.value) {
      const project = PROJECTS.filter(p => p.hasReleaseApi)[index];
      const releaseInfo = result.value;

      // 릴리즈 정보에 프로젝트 메타데이터 추가
      releaseInfo.releases.forEach(release => {
        aggregated.push({
          id: `${releaseInfo.projectId}-${release.version}`,
          projectId: releaseInfo.projectId,
          projectName: releaseInfo.projectName,
          projectUrl: project.url,
          ...release
        });
      });
    }
  });

  // 날짜순 정렬
  return aggregated.sort((a, b) => new Date(b.date) - new Date(a.date));
}

// API 엔드포인트
app.get('/api/releases', async (req, res) => {
  try {
    // 캐시 확인 (5분)
    if (releasesCache && Date.now() - releasesCache.timestamp < 5 * 60 * 1000) {
      return res.json({
        success: true,
        data: releasesCache.data,
        cached: true
      });
    }

    // 릴리즈 정보 수집
    const releases = await aggregateReleases();

    // 캐시 업데이트
    releasesCache = {
      data: releases,
      timestamp: Date.now()
    };

    res.json({
      success: true,
      data: releases,
      count: releases.length
    });

  } catch (error) {
    console.error('Error aggregating releases:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch release information'
    });
  }
});
```

**3단계: CHANGELOG.md 파일 자동 파싱 (선택)**

프로젝트에 CHANGELOG.md 파일이 있는 경우 자동으로 파싱:

```javascript
// lotto-master/utils/changelog-parser.js

const fs = require('fs');
const path = require('path');

/**
 * CHANGELOG.md 파일을 파싱하여 릴리즈 정보로 변환
 */
function parseChangelog(changelogPath) {
  try {
    const content = fs.readFileSync(changelogPath, 'utf8');
    const releases = [];

    // ## [1.0.0] - 2025-10-16 형식 파싱
    const versionRegex = /##\s+\[(\d+\.\d+\.\d+)\]\s+-\s+(\d{4}-\d{2}-\d{2})/g;
    const sections = content.split(versionRegex).slice(1);

    for (let i = 0; i < sections.length; i += 3) {
      const version = sections[i];
      const date = sections[i + 1];
      const body = sections[i + 2];

      const release = {
        version,
        date,
        type: determineReleaseType(version),
        title: extractTitle(body),
        changes: extractChanges(body)
      };

      releases.push(release);
    }

    return releases;

  } catch (error) {
    console.error('Error parsing CHANGELOG:', error);
    return [];
  }
}

function determineReleaseType(version) {
  const [major, minor, patch] = version.split('.').map(Number);
  if (patch > 0) return 'patch';
  if (minor > 0) return 'minor';
  return 'major';
}

function extractTitle(body) {
  // 첫 번째 섹션 또는 첫 번째 줄을 제목으로
  const lines = body.trim().split('\n');
  return lines[0]?.replace(/^#+\s*/, '') || '';
}

function extractChanges(body) {
  const changes = [];
  const lines = body.split('\n');

  let currentType = 'feature';
  for (const line of lines) {
    // ### Added, ### Fixed 등의 섹션 감지
    if (line.startsWith('### Added')) currentType = 'feature';
    else if (line.startsWith('### Fixed')) currentType = 'fix';
    else if (line.startsWith('### Changed')) currentType = 'tech';

    // - 항목 파싱
    if (line.startsWith('- ')) {
      changes.push({
        type: currentType,
        description: line.substring(2).trim()
      });
    }
  }

  return changes;
}

module.exports = { parseChangelog };
```

**사용 예시**:
```javascript
// lotto-master/server.js

const { parseChangelog } = require('./utils/changelog-parser');

const releases = parseChangelog(path.join(__dirname, 'CHANGELOG.md'));

app.get('/api/release-info', (req, res) => {
  res.json({
    success: true,
    data: {
      projectId: 'lotto-master',
      projectName: 'LottoMaster',
      currentVersion: '1.0.0',
      releases: releases.length > 0 ? releases : FALLBACK_RELEASES
    }
  });
});
```

---

### 방안 2: 중앙집중식 릴리즈 관리 (간단)

Dashboard가 각 프로젝트의 CHANGELOG 파일을 직접 읽는 방식

#### 구현

```javascript
// dashboard/server.js

const PROJECTS = [
  {
    id: 'lotto-master',
    name: 'LottoMaster',
    changelogPath: '../lotto-master/CHANGELOG.md',  // 상대 경로
    hasChangelog: true
  }
];

function loadProjectChangelog(project) {
  if (!project.hasChangelog || !project.changelogPath) {
    return [];
  }

  try {
    const fullPath = path.join(__dirname, project.changelogPath);
    if (!fs.existsSync(fullPath)) {
      console.warn(`Changelog not found for ${project.id}: ${fullPath}`);
      return [];
    }

    return parseChangelog(fullPath);
  } catch (error) {
    console.error(`Error loading changelog for ${project.id}:`, error);
    return [];
  }
}

app.get('/api/releases', (req, res) => {
  const allReleases = [];

  PROJECTS.forEach(project => {
    const releases = loadProjectChangelog(project);
    releases.forEach(release => {
      allReleases.push({
        id: `${project.id}-${release.version}`,
        projectId: project.id,
        projectName: project.name,
        projectUrl: project.url,
        ...release
      });
    });
  });

  // 날짜순 정렬
  allReleases.sort((a, b) => new Date(b.date) - new Date(a.date));

  res.json({
    success: true,
    data: allReleases,
    count: allReleases.length
  });
});
```

**장점**:
- 구현이 간단함
- API 호출 불필요

**단점**:
- 파일 시스템 접근 필요
- Docker 컨테이너 간 파일 공유 필요 (Volume)
- 실시간 업데이트 어려움

---

### 방안 3: 하이브리드 방식 (최적)

각 프로젝트의 릴리즈 API를 우선 사용하고, 없으면 로컬 CHANGELOG 파일을 사용

```javascript
async function fetchReleases(project) {
  // 1순위: 프로젝트 릴리즈 API
  if (project.hasReleaseApi) {
    const releases = await fetchProjectReleases(project);
    if (releases) return releases;
  }

  // 2순위: 로컬 CHANGELOG 파일
  if (project.hasChangelog) {
    return loadProjectChangelog(project);
  }

  // 3순위: Dashboard에 하드코딩된 정보
  return FALLBACK_RELEASES.filter(r => r.projectId === project.id);
}
```

---

## 📊 UI 개선

### 릴리즈 노트 뷰에 추가 기능

```javascript
// 릴리즈 카드에 외부 링크 추가
function renderReleaseCard(release) {
  return `
<div class="release-card">
  <div class="release-header">
    <h3>${release.projectName} v${release.version}</h3>
    <span class="badge badge-${release.type}">${release.type}</span>
  </div>

  <div class="release-meta">
    <span class="date">${release.date}</span>
    ${release.developer ? `<span class="developer">by ${release.developer}</span>` : ''}
  </div>

  <div class="release-title">${release.title}</div>

  <div class="release-changes">
    ${release.changes.map(change => `
      <div class="change change-${change.type}">
        <span class="change-icon">${getChangeIcon(change.type)}</span>
        <span class="change-text">${change.description}</span>
      </div>
    `).join('')}
  </div>

  <!-- 외부 링크 (있는 경우) -->
  ${release.changelogUrl || release.releaseNotesUrl ? `
  <div class="release-links">
    ${release.changelogUrl ? `
      <a href="${release.projectUrl}${release.changelogUrl}" target="_blank" class="release-link">
        📄 Changelog
      </a>
    ` : ''}
    ${release.releaseNotesUrl ? `
      <a href="${release.releaseNotesUrl}" target="_blank" class="release-link">
        📝 Release Notes
      </a>
    ` : ''}
  </div>
  ` : ''}
</div>
  `;
}
```

---

## 🔧 구현 단계

### Phase 1: 기본 구현
1. LottoMaster에 `/api/release-info` 엔드포인트 추가
2. Dashboard에서 릴리즈 정보 fetch 및 aggregate
3. 캐싱 구현 (5분)

### Phase 2: CHANGELOG 파싱
1. `changelog-parser.js` 유틸리티 작성
2. CHANGELOG.md 형식 표준화
3. 자동 파싱 및 릴리즈 정보 생성

### Phase 3: UI 개선
1. 릴리즈 카드에 외부 링크 추가
2. 프로젝트별 릴리즈 필터링
3. 검색 기능 (버전, 변경사항)

---

## 📝 CHANGELOG.md 표준 형식

각 프로젝트의 CHANGELOG.md는 다음 형식을 따름:

```markdown
# Changelog

All notable changes to this project will be documented in this file.

## [1.1.0] - 2025-10-20

### Added
- 검색 기능 추가
- 사용자 프로필 페이지

### Changed
- UI 개선
- 성능 최적화

### Fixed
- 로그인 버그 수정

## [1.0.0] - 2025-10-16

### Added
- 초기 릴리즈
- 기본 기능 구현
```

---

## 🎯 권장 사항

### 단기 (즉시 적용 가능)
1. **방안 1 (프로젝트별 API)** 구현
2. LottoMaster에 `/api/release-info` 추가
3. Dashboard에서 fetch 및 표시

### 중기 (1-2주)
1. CHANGELOG.md 파싱 기능 추가
2. 다른 프로젝트들도 릴리즈 API 추가
3. UI 개선 (외부 링크 등)

### 장기 (1개월+)
1. 릴리즈 자동화 (GitHub Actions)
2. 버전 비교 기능
3. 릴리즈 알림 (Slack, Email)

---

## ✅ 체크리스트

### LottoMaster (각 프로젝트)
- [ ] `/api/release-info` 엔드포인트 추가
- [ ] CHANGELOG.md 작성 (표준 형식)
- [ ] 릴리즈 정보 업데이트

### Dashboard
- [ ] 릴리즈 fetch 함수 구현
- [ ] 캐싱 로직 추가
- [ ] UI 개선 (외부 링크)
- [ ] 에러 처리 (API 실패 시)

---

**작성일**: 2025-10-16
**버전**: 1.0
**상태**: 제안서
