# Dashboard 보안 강화 최종 설계 (공개 서비스)

## 🎯 핵심 개념

### 서비스 특성
- **공개 대시보드**: 누구나 프로젝트 정보 조회 가능
- **관리자 로그인**: 내부 정보(통계, 시스템 상태)만 로그인 필요
- **심플한 구조**: 2가지 역할만 (PUBLIC, ADMIN)

---

## 👥 역할 및 권한

| 기능 | PUBLIC | ADMIN |
|------|--------|-------|
| 프로젝트 목록 조회 | ✅ | ✅ |
| 프로젝트 상세 정보 | ✅ | ✅ |
| 프로젝트 검색 | ✅ | ✅ |
| 카테고리 필터링 | ✅ | ✅ |
| 릴리즈 노트 조회 | ✅ | ✅ |
| 타임라인 조회 | ✅ | ✅ |
| 프로젝트 방문 | ✅ | ✅ |
| **통계 조회** | ❌ | ✅ |
| **개발자 정보** | ❌ | ✅ |
| **시스템 상태** | ❌ | ✅ |

---

## 🔌 API 엔드포인트

### Public API (인증 불필요)

```javascript
// 모두 인증 없이 접근 가능
GET  /                      → 메인 페이지
GET  /api/projects          → 프로젝트 목록
GET  /api/projects/:id      → 프로젝트 상세
GET  /api/releases          → 릴리즈 노트
GET  /api/info              → 대시보드 정보
```

### Admin API (관리자 전용)

```javascript
// 로그인 필요
GET  /login                 → 로그인 페이지 (public)
POST /api/login             → 로그인 처리 (public)
POST /api/logout            → 로그아웃
GET  /api/me                → 현재 사용자 정보
GET  /api/stats             → 통계 정보 ⭐
GET  /api/developers        → 개발자 정보 ⭐
GET  /api/system/status     → 시스템 상태 ⭐
```

---

## 🌐 UI 구조

### 일반 사용자 (PUBLIC)

```
┌────────────────────────────────────────┐
│  🚀 Dashboard          🔐 관리자        │ ← 헤더
├────────────────────────────────────────┤
│ [사이드바]       [프로젝트 카드]         │
│                                        │
│ 📦 프로젝트        🎰 LottoMaster       │
│  └ 전체 (1)       데이터 기반 로또      │
│  └ 운영중 (1)     [방문하기]           │
│                                        │
│ 📁 카테고리                             │
│  └ Full-stack                          │
│  └ Frontend                            │
│                                        │
│ 📝 릴리즈 노트                          │
│  └ 전체 릴리즈                          │
│  └ 타임라인                             │
│                                        │
└────────────────────────────────────────┘
```

### 관리자 로그인 후

```
┌────────────────────────────────────────┐
│  🚀 Dashboard   👑 관리자 │ 로그아웃    │ ← 헤더
├────────────────────────────────────────┤
│ [사이드바]       [프로젝트 카드]         │
│                                        │
│ 📦 프로젝트        🎰 LottoMaster       │
│  └ 전체 (1)       데이터 기반 로또      │
│  └ 운영중 (1)     [방문하기]           │
│                                        │
│ 📁 카테고리                             │
│  └ Full-stack                          │
│  └ Frontend                            │
│                                        │
│ 📝 릴리즈 노트                          │
│  └ 전체 릴리즈                          │
│  └ 타임라인                             │
│                                        │
│ ⭐ 관리자 전용  ← 새로 나타남!           │
│  └ 📊 통계                              │
│  └ 👥 개발자 정보                        │
│  └ ⚙️ 시스템 상태                        │
│                                        │
└────────────────────────────────────────┘
```

---

## 💻 핵심 코드

### 미들웨어

```javascript
// middleware/auth.js

const { findUserById } = require('../utils/user-manager');

/**
 * 선택적 인증 (로그인 여부 확인, 강제 안 함)
 */
function optionalAuth(req, res, next) {
  if (req.session?.userId) {
    const user = findUserById(req.session.userId);
    if (user?.active && user.role === 'admin') {
      req.user = { id: user.id, username: user.username, role: 'admin' };
    }
  }
  next();
}

/**
 * 관리자 필수 인증
 */
function requireAdmin(req, res, next) {
  if (!req.session?.userId) {
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({
        success: false,
        error: 'Admin login required'
      });
    }
    return res.redirect('/login');
  }

  const user = findUserById(req.session.userId);
  if (!user?.active || user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      error: 'Admin privileges required'
    });
  }

  req.user = { id: user.id, username: user.username, role: 'admin' };
  next();
}

module.exports = { optionalAuth, requireAdmin };
```

### 라우트 적용

```javascript
// server.js

const { optionalAuth, requireAdmin } = require('./middleware/auth');

// ===== PUBLIC API (인증 불필요) =====
app.get('/', optionalAuth, (req, res) => {
  const isAdmin = req.user?.role === 'admin';
  res.send(renderDashboard(isAdmin));
});

app.get('/api/projects', (req, res) => {
  const projects = getProjects(req.query);
  res.json({ success: true, data: projects });
});

app.get('/api/releases', (req, res) => {
  const releases = getReleases(req.query);
  res.json({ success: true, data: releases });
});

// ===== ADMIN API (관리자 전용) =====
app.get('/api/stats', requireAdmin, (req, res) => {
  const stats = getStats();
  res.json({ success: true, data: stats });
});

app.get('/api/developers', requireAdmin, (req, res) => {
  const devs = getDevelopers();
  res.json({ success: true, data: devs });
});

app.get('/api/system/status', requireAdmin, (req, res) => {
  const status = getSystemStatus();
  res.json({ success: true, data: status });
});
```

---

## 🚀 구현 단계 (총 13.5시간)

### Quick Start
```bash
# 1. 패키지 설치
cd /home/deploy/projects/dashboard
npm install express-session session-file-store bcrypt dotenv

# 2. 환경 변수
cat > .env << 'EOF'
SESSION_SECRET=$(openssl rand -base64 32)
NODE_ENV=production
PORT=3000
SESSION_MAX_AGE=43200000
EOF

# 3. 데이터 디렉토리
mkdir -p data/sessions
chmod 700 data

# 4. 관리자 계정
node scripts/create-admin.js "SecurePassword123!"

# 5. 재배포
cd /home/deploy
docker compose build dashboard
docker compose up -d dashboard
```

### 상세 태스크

| # | Task | 시간 | 설명 |
|---|------|------|------|
| 1 | 환경 설정 | 30분 | npm 패키지, .env, 디렉토리 |
| 2 | 데이터 모델 | 1시간 | user-manager.js, admin 생성 |
| 3 | 인증 미들웨어 | 1.5시간 | optionalAuth, requireAdmin |
| 4 | 로그인 API | 2시간 | POST /api/login, /logout, /me |
| 5 | 로그인 페이지 | 2시간 | 관리자 로그인 UI |
| 6 | API 권한 적용 | 1시간 | Public vs Admin 분리 |
| 7 | UI 조건부 표시 | 2시간 | 관리자 섹션 토글 |
| 8 | 테스트 | 1.5시간 | Public/Admin API 검증 |
| 9 | 문서 업데이트 | 1시간 | README 등 |
| 10 | 배포 | 1시간 | 빌드 및 배포 |

**총: 13.5시간 (기존 16.5시간 대비 3시간 단축)**

---

## 🧪 테스트 시나리오

### Public API (누구나)
```bash
# 프로젝트 목록
curl http://203.245.30.6/api/projects

# 프로젝트 상세
curl http://203.245.30.6/api/projects/lotto-master

# 릴리즈 노트
curl http://203.245.30.6/api/releases

# 모두 200 OK 반환
```

### Admin API (미로그인 시 401)
```bash
# 통계 (401 예상)
curl http://203.245.30.6/api/stats

# 개발자 정보 (401 예상)
curl http://203.245.30.6/api/developers

# 시스템 상태 (401 예상)
curl http://203.245.30.6/api/system/status
```

### Admin API (로그인 후 200)
```bash
# 로그인
curl -X POST http://203.245.30.6/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"password"}' \
  -c cookies.txt

# 통계 (200 OK)
curl http://203.245.30.6/api/stats -b cookies.txt

# 개발자 정보 (200 OK)
curl http://203.245.30.6/api/developers -b cookies.txt

# 시스템 상태 (200 OK)
curl http://203.245.30.6/api/system/status -b cookies.txt
```

---

## ✅ 체크리스트

### 기능
- [ ] Public API 인증 제거
- [ ] Admin API 인증 적용
- [ ] optionalAuth 구현
- [ ] requireAdmin 구현
- [ ] 관리자 로그인 페이지
- [ ] 관리자 전용 섹션 (조건부)
- [ ] 로그아웃 기능

### 보안
- [ ] 비밀번호 bcrypt 해싱
- [ ] 세션 Secret (.env)
- [ ] httpOnly 쿠키
- [ ] sameSite strict
- [ ] 로그인 Rate limiting

### UI
- [ ] 일반 사용자: 모든 프로젝트 볼 수 있음
- [ ] 일반 사용자: 릴리즈 노트 볼 수 있음
- [ ] 헤더 우측: 관리자 로그인 링크
- [ ] 로그인 시: 관리자 전용 섹션 표시
- [ ] 로그아웃 시: 일반 뷰로 전환

### 테스트
- [ ] Public API 접근 테스트
- [ ] Admin API 미인증 차단 테스트
- [ ] 관리자 로그인 테스트
- [ ] Admin API 인증 접근 테스트
- [ ] UI 조건부 표시 테스트

---

## 📊 기존 설계 vs 재설계

| 항목 | 기존 (잘못됨) | 재설계 (올바름) |
|------|-------------|---------------|
| **역할 수** | 3개 (PUBLIC, VIEWER, ADMIN) | 2개 (PUBLIC, ADMIN) |
| **프로젝트 API** | 로그인 필요 (VIEWER+) | 인증 불필요 ✅ |
| **릴리즈 API** | 로그인 필요 (VIEWER+) | 인증 불필요 ✅ |
| **통계 API** | 관리자만 | 관리자만 |
| **개발 시간** | 16.5시간 | 13.5시간 (-18%) |
| **복잡도** | 높음 | 낮음 |
| **사용자 계정** | VIEWER 계정 필요 | 불필요 ✅ |

---

## ❓ FAQ

**Q: 일반 사용자도 프로젝트를 볼 수 있나요?**
A: ✅ 네! 로그인 없이 모든 프로젝트와 릴리즈 노트를 볼 수 있습니다.

**Q: 관리자 로그인은 어떻게 하나요?**
A: 헤더 우측 상단의 "🔐 관리자" 링크를 클릭하면 로그인 페이지로 이동합니다.

**Q: 일반 사용자 계정을 만들어야 하나요?**
A: ❌ 아니요. 관리자 계정만 있으면 됩니다.

**Q: 통계는 누가 볼 수 있나요?**
A: 관리자만 볼 수 있습니다. 로그인 후 사이드바에 "⭐ 관리자 전용" 섹션이 나타납니다.

**Q: 프로젝트 정보는 비공개로 할 수 있나요?**
A: 아니요. 현재 설계는 모든 프로젝트 정보를 공개합니다. 비공개가 필요하면 프로젝트별 공개 여부 플래그를 추가해야 합니다.

**Q: API 키는 언제 추가되나요?**
A: Phase 2 (v2.2.0)에서 외부 시스템 통합을 위한 API 키 시스템이 추가됩니다.

**Q: HTTPS는 필수인가요?**
A: 내부 네트워크는 HTTP 가능하지만, 외부 공개 시 HTTPS 필수입니다.

---

## 🎯 다음 단계

### 즉시 시작 가능
```bash
# 문서 확인
cat /home/deploy/projects/dashboard/docs/SECURITY_REDESIGN.md

# Task 1 시작
cd /home/deploy/projects/dashboard
npm install express-session session-file-store bcrypt dotenv
```

### Phase 1 완료 후
1. 배포 및 테스트
2. 사용자 피드백 수집
3. Phase 2 (API 키) 계획
4. Phase 2 개발 시작

---

## 📚 관련 문서

1. **SECURITY_REDESIGN.md** (16KB) - 상세 설계 및 모든 태스크
2. **SECURITY_FINAL.md** (이 문서) - 빠른 참조 및 요약
3. ~~SECURITY_IMPROVEMENT_PLAN.md~~ (구 버전, 무시)
4. ~~SECURITY_QUICK_REFERENCE.md~~ (구 버전, 무시)

---

**문서 버전**: 3.0 (최종)
**작성일**: 2025-10-16
**상태**: ✅ 재설계 완료
**담당**: DevOps Team
