# Phase 1 구현 태스크 상세

## 📋 전체 개요

**목표**: 기본 인증 시스템 구현 (로그인/로그아웃, 역할 기반 접근 제어)
**예상 기간**: 2-3주
**난이도**: 중간

---

## Task 1: 환경 설정 및 의존성 설치

### 목표
프로젝트에 인증 시스템 구현에 필요한 패키지 설치 및 환경 구성

### 예상 시간
30분

### 사전 요구사항
- Node.js 18+ 설치
- npm 사용 가능
- 프로젝트 디렉토리 접근 권한

### 작업 단계

#### 1.1 패키지 설치
```bash
cd /home/deploy/projects/dashboard

# 필수 패키지 설치
npm install express-session session-file-store bcrypt dotenv

# 타입 정의 (선택사항, TypeScript 사용 시)
npm install --save-dev @types/express-session @types/bcrypt
```

**설치되는 패키지**:
- `express-session`: 세션 관리
- `session-file-store`: 파일 기반 세션 저장소
- `bcrypt`: 비밀번호 해싱
- `dotenv`: 환경 변수 관리

#### 1.2 환경 변수 파일 생성
```bash
# .env 파일 생성
cat > .env << 'EOF'
# 세션 시크릿 (운영 환경에서는 반드시 변경!)
SESSION_SECRET=change-this-to-random-secret-key

# 환경
NODE_ENV=production

# 포트
PORT=3000

# 세션 설정
SESSION_MAX_AGE=43200000
# 12 hours in milliseconds

# 비밀번호 최소 길이
PASSWORD_MIN_LENGTH=8
EOF

# 보안을 위해 권한 제한
chmod 600 .env
```

#### 1.3 데이터 디렉토리 생성
```bash
# 사용자 데이터 저장 디렉토리
mkdir -p data/sessions

# 보안을 위해 권한 제한
chmod 700 data
chmod 700 data/sessions

# .gitignore에 추가 (git 사용 시)
cat >> .gitignore << 'EOF'
# 인증 관련
.env
data/users.json
data/sessions/*
!data/sessions/.gitkeep
EOF

touch data/sessions/.gitkeep
```

### 완료 조건
- [x] npm 패키지 설치 완료
- [x] .env 파일 생성 및 권한 설정
- [x] data 디렉토리 생성 및 권한 설정
- [x] package.json에 의존성 추가 확인

### 검증 방법
```bash
# 패키지 설치 확인
npm list express-session session-file-store bcrypt dotenv

# 디렉토리 확인
ls -la data/

# .env 파일 확인
ls -la .env
```

### 예상 결과
```
node_modules/
├── express-session/
├── session-file-store/
├── bcrypt/
└── dotenv/

data/
└── sessions/

.env (600 permissions)
```

---

## Task 2: 데이터 모델 및 초기 사용자 생성

### 목표
사용자 데이터 구조 정의 및 초기 관리자 계정 생성

### 예상 시간
1시간

### 작업 단계

#### 2.1 사용자 관리 유틸리티 작성
```bash
# utils 디렉토리 생성
mkdir -p utils

# utils/user-manager.js 생성
cat > utils/user-manager.js << 'EOF'
const fs = require('fs');
const path = require('path');

const USERS_FILE = path.join(__dirname, '../data/users.json');

/**
 * 사용자 파일 초기화
 */
function initUsersFile() {
  if (!fs.existsSync(USERS_FILE)) {
    fs.writeFileSync(USERS_FILE, JSON.stringify({ users: [] }, null, 2));
  }
}

/**
 * 모든 사용자 로드
 */
function loadUsers() {
  initUsersFile();
  const data = fs.readFileSync(USERS_FILE, 'utf8');
  return JSON.parse(data).users;
}

/**
 * 사용자 저장
 */
function saveUsers(users) {
  fs.writeFileSync(
    USERS_FILE,
    JSON.stringify({ users }, null, 2),
    'utf8'
  );
}

/**
 * ID로 사용자 찾기
 */
function findUserById(userId) {
  const users = loadUsers();
  return users.find(u => u.id === userId);
}

/**
 * 사용자명으로 사용자 찾기
 */
function findUserByUsername(username) {
  const users = loadUsers();
  return users.find(u => u.username === username);
}

/**
 * 새 사용자 추가
 */
function addUser(user) {
  const users = loadUsers();

  // 중복 체크
  if (users.some(u => u.username === user.username)) {
    throw new Error('Username already exists');
  }
  if (users.some(u => u.id === user.id)) {
    throw new Error('User ID already exists');
  }

  users.push(user);
  saveUsers(users);
  return user;
}

/**
 * 사용자 업데이트
 */
function updateUser(userId, updates) {
  const users = loadUsers();
  const index = users.findIndex(u => u.id === userId);

  if (index === -1) {
    throw new Error('User not found');
  }

  users[index] = { ...users[index], ...updates };
  saveUsers(users);
  return users[index];
}

/**
 * 마지막 로그인 시간 업데이트
 */
function updateUserLogin(userId) {
  return updateUser(userId, {
    lastLogin: new Date().toISOString()
  });
}

/**
 * 사용자 삭제
 */
function deleteUser(userId) {
  const users = loadUsers();
  const filtered = users.filter(u => u.id !== userId);

  if (filtered.length === users.length) {
    throw new Error('User not found');
  }

  saveUsers(filtered);
  return true;
}

module.exports = {
  initUsersFile,
  loadUsers,
  saveUsers,
  findUserById,
  findUserByUsername,
  addUser,
  updateUser,
  updateUserLogin,
  deleteUser
};
EOF
```

#### 2.2 관리자 생성 스크립트 작성
```bash
# scripts 디렉토리 생성
mkdir -p scripts

# scripts/create-admin.js 생성
cat > scripts/create-admin.js << 'EOF'
#!/usr/bin/env node

const bcrypt = require('bcrypt');
const { addUser, findUserByUsername } = require('../utils/user-manager');

const SALT_ROUNDS = 10;

async function createAdmin() {
  // 명령행 인자에서 비밀번호 가져오기
  const password = process.argv[2];

  if (!password) {
    console.error('Usage: node scripts/create-admin.js <password>');
    console.error('Example: node scripts/create-admin.js MySecurePassword123');
    process.exit(1);
  }

  // 비밀번호 강도 체크
  if (password.length < 8) {
    console.error('Error: Password must be at least 8 characters long');
    process.exit(1);
  }

  try {
    // 기존 admin 계정 체크
    const existing = findUserByUsername('admin');
    if (existing) {
      console.error('Error: Admin user already exists');
      console.error('Please delete or rename the existing admin user first');
      process.exit(1);
    }

    // 비밀번호 해싱
    console.log('Hashing password...');
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    // 관리자 사용자 생성
    const admin = {
      id: 'admin-001',
      username: 'admin',
      passwordHash,
      role: 'admin',
      email: 'admin@localhost',
      createdAt: new Date().toISOString().split('T')[0],
      lastLogin: null,
      active: true
    };

    addUser(admin);

    console.log('\n✅ Admin user created successfully!');
    console.log('\nLogin credentials:');
    console.log('  Username: admin');
    console.log('  Password: ' + password);
    console.log('\n⚠️  Please save these credentials securely!');
    console.log('⚠️  Change the password after first login!\n');

  } catch (error) {
    console.error('\n❌ Error creating admin user:');
    console.error(error.message);
    process.exit(1);
  }
}

createAdmin();
EOF

chmod +x scripts/create-admin.js
```

#### 2.3 관리자 계정 생성
```bash
# 관리자 계정 생성 (비밀번호는 안전한 것으로 변경)
node scripts/create-admin.js "YourSecurePassword123!"

# 생성 확인
cat data/users.json
```

### 완료 조건
- [x] user-manager.js 작성 완료
- [x] create-admin.js 스크립트 작성 완료
- [x] 관리자 계정 생성 완료
- [x] data/users.json 파일 생성 확인

### 검증 방법
```bash
# 사용자 파일 확인
cat data/users.json

# 올바른 형식인지 확인
node -e "console.log(JSON.parse(require('fs').readFileSync('./data/users.json')))"
```

### 예상 결과
```json
{
  "users": [
    {
      "id": "admin-001",
      "username": "admin",
      "passwordHash": "$2b$10$...",
      "role": "admin",
      "email": "admin@localhost",
      "createdAt": "2025-10-16",
      "lastLogin": null,
      "active": true
    }
  ]
}
```

---

## Task 3: 인증 미들웨어 구현

### 목표
Express 미들웨어를 작성하여 인증 및 권한 검증 구현

### 예상 시간
2시간

### 작업 단계

#### 3.1 인증 미들웨어 파일 생성
```bash
mkdir -p middleware

cat > middleware/auth.js << 'EOF'
const { findUserById } = require('../utils/user-manager');

/**
 * 인증 필수 미들웨어
 * 로그인하지 않은 사용자는 로그인 페이지로 리다이렉트
 */
function requireAuth(req, res, next) {
  // 세션에 userId가 없으면 미인증
  if (!req.session || !req.session.userId) {
    // API 요청인 경우 JSON 응답
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required'
      });
    }

    // 웹 페이지 요청인 경우 로그인 페이지로
    return res.redirect('/login?redirect=' + encodeURIComponent(req.originalUrl));
  }

  // 사용자 정보 로드
  try {
    const user = findUserById(req.session.userId);

    // 사용자가 없거나 비활성화된 경우
    if (!user || !user.active) {
      req.session.destroy();

      if (req.path.startsWith('/api/')) {
        return res.status(401).json({
          success: false,
          error: 'Invalid session'
        });
      }

      return res.redirect('/login');
    }

    // req 객체에 사용자 정보 추가
    req.user = {
      id: user.id,
      username: user.username,
      role: user.role,
      email: user.email
    };

    next();

  } catch (error) {
    console.error('Auth middleware error:', error);

    if (req.path.startsWith('/api/')) {
      return res.status(500).json({
        success: false,
        error: 'Authentication error'
      });
    }

    res.redirect('/login');
  }
}

/**
 * 역할 확인 미들웨어
 * 특정 역할을 가진 사용자만 접근 허용
 *
 * @param {...string} allowedRoles - 허용할 역할 목록
 * @returns {Function} Express 미들웨어
 */
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    // 인증되지 않은 경우
    if (!req.user) {
      if (req.path.startsWith('/api/')) {
        return res.status(401).json({
          success: false,
          error: 'Authentication required'
        });
      }
      return res.redirect('/login');
    }

    // 역할 확인
    if (!allowedRoles.includes(req.user.role)) {
      if (req.path.startsWith('/api/')) {
        return res.status(403).json({
          success: false,
          error: 'Insufficient permissions',
          required: allowedRoles,
          current: req.user.role
        });
      }

      // 웹 페이지 요청인 경우 403 페이지
      return res.status(403).send(`
        <h1>접근 거부</h1>
        <p>이 페이지에 접근할 권한이 없습니다.</p>
        <p>필요한 권한: ${allowedRoles.join(', ')}</p>
        <p>현재 권한: ${req.user.role}</p>
        <a href="/">홈으로 돌아가기</a>
      `);
    }

    next();
  };
}

/**
 * 선택적 인증 미들웨어
 * 로그인한 경우 사용자 정보를 추가하지만, 로그인하지 않아도 계속 진행
 */
function optionalAuth(req, res, next) {
  if (req.session && req.session.userId) {
    try {
      const user = findUserById(req.session.userId);

      if (user && user.active) {
        req.user = {
          id: user.id,
          username: user.username,
          role: user.role,
          email: user.email
        };
      }
    } catch (error) {
      console.error('Optional auth error:', error);
    }
  }

  next();
}

module.exports = {
  requireAuth,
  requireRole,
  optionalAuth
};
EOF
```

### 완료 조건
- [x] requireAuth 미들웨어 작성
- [x] requireRole 미들웨어 작성
- [x] optionalAuth 미들웨어 작성
- [x] 에러 처리 구현

### 검증 방법
```bash
# 문법 체크
node -c middleware/auth.js

# 모듈 로드 테스트
node -e "const auth = require('./middleware/auth'); console.log(Object.keys(auth));"
```

### 예상 결과
```
[ 'requireAuth', 'requireRole', 'optionalAuth' ]
```

---

## Task 4: 로그인/로그아웃 API 구현

### 목표
인증 관련 API 엔드포인트 구현

### 예상 시간
2시간

### 작업 단계

#### 4.1 인증 라우트 파일 생성
```bash
mkdir -p routes

cat > routes/auth.js << 'EOF'
const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const {
  findUserByUsername,
  updateUserLogin
} = require('../utils/user-manager');
const { requireAuth } = require('../middleware/auth');

/**
 * POST /api/login
 * 로그인
 */
router.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  // 입력 검증
  if (!username || !password) {
    return res.status(400).json({
      success: false,
      error: 'Username and password are required'
    });
  }

  try {
    // 사용자 조회
    const user = findUserByUsername(username);

    if (!user) {
      // 보안: 사용자 없음과 비밀번호 불일치를 구분하지 않음
      return res.status(401).json({
        success: false,
        error: 'Invalid username or password'
      });
    }

    // 비활성화된 계정
    if (!user.active) {
      return res.status(401).json({
        success: false,
        error: 'Account is disabled'
      });
    }

    // 비밀번호 검증
    const valid = await bcrypt.compare(password, user.passwordHash);

    if (!valid) {
      return res.status(401).json({
        success: false,
        error: 'Invalid username or password'
      });
    }

    // 세션 생성
    req.session.userId = user.id;
    req.session.role = user.role;

    // 마지막 로그인 시간 업데이트
    updateUserLogin(user.id);

    // 성공 응답
    res.json({
      success: true,
      data: {
        userId: user.id,
        username: user.username,
        role: user.role,
        email: user.email
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      error: 'Login failed'
    });
  }
});

/**
 * POST /api/logout
 * 로그아웃
 */
router.post('/api/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Logout error:', err);
      return res.status(500).json({
        success: false,
        error: 'Logout failed'
      });
    }

    res.json({
      success: true,
      message: 'Logged out successfully'
    });
  });
});

/**
 * GET /api/me
 * 현재 사용자 정보
 */
router.get('/api/me', requireAuth, (req, res) => {
  res.json({
    success: true,
    data: req.user
  });
});

module.exports = router;
EOF
```

#### 4.2 server.js에 통합
```bash
# server.js 수정 (기존 파일 백업)
cp server.js server.js.backup

# server.js에 다음 내용 추가
cat >> server.js << 'EOF'

// ===== 인증 시스템 통합 =====
require('dotenv').config();
const session = require('express-session');
const FileStore = require('session-file-store')(session);
const authRoutes = require('./routes/auth');

// 세션 미들웨어 설정
app.use(session({
  store: new FileStore({
    path: './data/sessions',
    ttl: parseInt(process.env.SESSION_MAX_AGE || '43200'), // seconds
    retries: 0
  }),
  secret: process.env.SESSION_SECRET || 'change-this-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production' && process.env.HTTPS === 'true',
    httpOnly: true,
    maxAge: parseInt(process.env.SESSION_MAX_AGE || '43200000'), // milliseconds
    sameSite: 'strict'
  },
  name: 'dashboard.sid' // 기본 'connect.sid' 대신 커스텀 이름
}));

// 인증 라우트 등록
app.use(authRoutes);

console.log('Authentication system initialized');
EOF
```

### 완료 조건
- [x] POST /api/login 구현
- [x] POST /api/logout 구현
- [x] GET /api/me 구현
- [x] server.js에 세션 미들웨어 추가
- [x] server.js에 인증 라우트 등록

### 검증 방법
```bash
# 서버 재시작
npm start &

# 로그인 테스트
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"YourPassword"}' \
  -c cookies.txt \
  -v

# 현재 사용자 정보
curl http://localhost:3000/api/me \
  -b cookies.txt

# 로그아웃
curl -X POST http://localhost:3000/api/logout \
  -b cookies.txt
```

---

## Task 5-10 요약

나머지 태스크는 SECURITY_IMPROVEMENT_PLAN.md에 상세히 기술되어 있습니다.

### Task 5: 로그인 페이지 UI (2시간)
- 로그인 폼 HTML/CSS
- JavaScript 폼 핸들링
- 에러 메시지 표시

### Task 6: 기존 API에 권한 적용 (2시간)
- Public 엔드포인트 확인
- Viewer 엔드포인트에 requireAuth
- Admin 엔드포인트에 requireRole

### Task 7: UI 역할별 표시 수정 (3시간)
- 헤더에 사용자 정보
- 로그아웃 버튼
- 역할별 사이드바 필터링

### Task 8: 테스트 및 검증 (2시간)
- 로그인/로그아웃 테스트
- 권한 체크 테스트
- UI 역할별 표시 테스트

### Task 9: 문서 업데이트 (1시간)
- README.md
- API_EXAMPLES.md
- CHANGELOG.md
- SECURITY.md

### Task 10: 배포 및 마이그레이션 (1시간)
- 백업
- 환경 변수 설정
- 관리자 계정 생성
- 빌드 및 배포

---

## 📊 진행 상황 트래킹

### 체크리스트
```
Phase 1: 기본 인증 시스템
├─ [시작 전] Task 1: 환경 설정 및 의존성 (30분)
├─ [시작 전] Task 2: 데이터 모델 및 초기 사용자 (1시간)
├─ [시작 전] Task 3: 인증 미들웨어 (2시간)
├─ [시작 전] Task 4: 로그인/로그아웃 API (2시간)
├─ [시작 전] Task 5: 로그인 페이지 UI (2시간)
├─ [시작 전] Task 6: 기존 API 권한 적용 (2시간)
├─ [시작 전] Task 7: UI 역할별 표시 (3시간)
├─ [시작 전] Task 8: 테스트 및 검증 (2시간)
├─ [시작 전] Task 9: 문서 업데이트 (1시간)
└─ [시작 전] Task 10: 배포 및 마이그레이션 (1시간)

총 예상 시간: 16.5시간 (약 2-3주)
```

### 상태 코드
- `[시작 전]`: 작업 시작 안 함
- `[진행중]`: 작업 진행 중
- `[검토중]`: 작업 완료, 리뷰 대기
- `[완료]`: 작업 완료 및 검증됨
- `[보류]`: 일시적으로 보류됨
- `[취소]`: 작업 취소됨

---

**작성일**: 2025-10-16
**버전**: 1.0
**담당**: Backend Team
