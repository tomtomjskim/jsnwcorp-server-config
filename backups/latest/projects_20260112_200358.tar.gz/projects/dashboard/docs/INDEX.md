# Dashboard v2.0 - 문서 인덱스

## 📚 전체 문서 목록

### 🚀 시작하기
1. **[QUICK_START.md](../QUICK_START.md)** - 5분 안에 시작하기
   - 빠른 설치 및 설정
   - 자주 사용하는 작업
   - 실전 예제

2. **[README.md](../README.md)** - 전체 가이드
   - 프로젝트 개요
   - 전체 기능 설명
   - 데이터 구조 상세
   - API 레퍼런스

### 💻 개발자 가이드
3. **[API_EXAMPLES.md](../API_EXAMPLES.md)** - API 사용 예시
   - cURL 예제
   - JavaScript/TypeScript 예제
   - Python 예제
   - Shell 스크립트 예제
   - 실전 통합 예제

4. **[CHANGELOG.md](../CHANGELOG.md)** - 변경 이력
   - 버전별 변경사항
   - 마이그레이션 가이드
   - 향후 계획

## 📖 문서별 주요 내용

### QUICK_START.md
**대상**: 처음 사용하는 사용자, 빠르게 시작하고 싶은 사람

**포함 내용**:
- ✅ 5분 안에 시작하기
- ✅ 주요 기능 둘러보기
- ✅ 자주 사용하는 작업 (새 프로젝트 추가, 버전 업데이트)
- ✅ API 빠른 참조
- ✅ 사용 시나리오
- ✅ 문제 해결
- ✅ FAQ

**이런 경우에 읽으세요**:
- 대시보드를 처음 사용할 때
- 빠르게 기능을 파악하고 싶을 때
- 특정 작업을 바로 하고 싶을 때

### README.md
**대상**: 모든 사용자, 개발자

**포함 내용**:
- ✅ 프로젝트 전체 개요
- ✅ 주요 기능 상세 설명
- ✅ 데이터 구조 완벽 가이드 (DEVELOPERS, PROJECTS, RELEASE_NOTES, SYSTEM_NOTES)
- ✅ API 엔드포인트 레퍼런스
- ✅ 새 프로젝트 추가 가이드 (6단계)
- ✅ 버전 업데이트 가이드
- ✅ UI/UX 커스터마이징
- ✅ Docker 구성
- ✅ 보안 및 유지보수

**이런 경우에 읽으세요**:
- 대시보드의 모든 기능을 알고 싶을 때
- 데이터 구조를 이해하고 싶을 때
- 프로젝트를 추가하거나 수정할 때
- API 스펙을 확인할 때

### API_EXAMPLES.md
**대상**: API를 사용하는 개발자

**포함 내용**:
- ✅ 모든 API 엔드포인트 예시
- ✅ cURL 명령어
- ✅ JavaScript/TypeScript 코드
- ✅ Python 코드
- ✅ Shell 스크립트
- ✅ 실전 통합 예제 (대시보드 위젯, Slack 봇)
- ✅ 에러 처리
- ✅ 성능 최적화

**이런 경우에 읽으세요**:
- API를 코드에서 사용하고 싶을 때
- 다른 시스템과 통합하고 싶을 때
- 실제 코드 예제가 필요할 때
- 에러 처리 방법을 알고 싶을 때

### CHANGELOG.md
**대상**: 관리자, 기여자

**포함 내용**:
- ✅ 버전별 변경사항
- ✅ v2.0.0 주요 기능
- ✅ v1.0.0 → v2.0.0 마이그레이션 가이드
- ✅ Breaking Changes
- ✅ 향후 계획 (v2.1, v2.2, v3.0)
- ✅ 버전 명명 규칙

**이런 경우에 읽으세요**:
- 업데이트 내역을 확인하고 싶을 때
- 이전 버전에서 마이그레이션할 때
- 향후 로드맵을 확인하고 싶을 때

## 🎯 시나리오별 가이드

### 처음 사용하는 경우
1. **QUICK_START.md** 읽기
2. 대시보드 접속해서 둘러보기
3. 필요시 **README.md** 참조

### 새 프로젝트를 추가하는 경우
1. **README.md** → "새 프로젝트 추가 가이드" 섹션
2. **QUICK_START.md** → "새 프로젝트 추가 (3단계)" 섹션
3. 데이터 구조는 **README.md** → "데이터 구조" 섹션

### API를 사용하는 경우
1. **API_EXAMPLES.md** → 언어별 예제 찾기
2. **README.md** → "API 엔드포인트" 섹션 (스펙 확인)
3. 필요시 **API_EXAMPLES.md** → "에러 처리" 섹션

### 버전을 업데이트하는 경우
1. **README.md** → "버전 업데이트 가이드"
2. **QUICK_START.md** → "버전 업데이트 (2단계)"
3. **CHANGELOG.md** → 변경 이력 확인

### 이전 버전에서 마이그레이션하는 경우
1. **CHANGELOG.md** → "Migration Guide (v1 → v2)"
2. **README.md** → 새 데이터 구조 확인
3. 변경사항 적용 후 재배포

### 문제가 발생한 경우
1. **QUICK_START.md** → "문제 해결" 섹션
2. **README.md** → "문제 해결" 섹션
3. **QUICK_START.md** → "FAQ" 섹션
4. 해결 안 되면 시스템 관리자 문의

## 📂 파일 구조

```
/home/deploy/projects/dashboard/
├── README.md              # 📘 전체 가이드 (메인 문서)
├── QUICK_START.md         # 🚀 빠른 시작 가이드
├── API_EXAMPLES.md        # 💻 API 사용 예시
├── CHANGELOG.md           # 📝 변경 이력
├── docs/
│   └── INDEX.md          # 📚 이 문서 (문서 인덱스)
├── server.js             # 🖥️ 서버 코드
├── package.json          # 📦 의존성
└── Dockerfile            # 🐳 Docker 설정
```

## 🔍 키워드 검색

### 프로젝트 관련
- **새 프로젝트 추가**: README.md, QUICK_START.md
- **프로젝트 검색**: README.md (검색 기능), QUICK_START.md
- **프로젝트 필터링**: README.md, API_EXAMPLES.md
- **프로젝트 수정**: README.md
- **프로젝트 삭제**: QUICK_START.md (FAQ)

### 개발자 관련
- **개발자 추가**: README.md (새 프로젝트 추가 가이드)
- **팀 관리**: README.md (DEVELOPERS 배열)
- **개발자별 프로젝트**: API_EXAMPLES.md

### 릴리즈 관련
- **릴리즈 노트 작성**: README.md (버전 업데이트 가이드)
- **버전 업데이트**: README.md, QUICK_START.md
- **릴리즈 히스토리**: README.md, API_EXAMPLES.md

### API 관련
- **API 사용법**: API_EXAMPLES.md
- **API 레퍼런스**: README.md (API 엔드포인트)
- **JavaScript 예제**: API_EXAMPLES.md
- **Python 예제**: API_EXAMPLES.md
- **에러 처리**: API_EXAMPLES.md

### 기술 관련
- **데이터 구조**: README.md (데이터 구조)
- **Docker 설정**: README.md (Docker 구성)
- **nginx 설정**: README.md (새 프로젝트 추가 가이드)
- **보안**: README.md (보안)

### 문제 해결
- **트러블슈팅**: QUICK_START.md (문제 해결), README.md (문제 해결)
- **FAQ**: QUICK_START.md (FAQ)
- **로그 확인**: README.md (유지보수)

## 📊 문서 통계

- **총 문서 수**: 5개 (인덱스 포함)
- **총 라인 수**: 2000+ 라인
- **코드 예제**: 50+ 개
- **API 엔드포인트**: 6개
- **데이터 모델**: 4개

## 🤝 기여 가이드

문서를 개선하고 싶으신가요?

1. 오타나 오류 발견: 즉시 수정
2. 새 예제 추가: API_EXAMPLES.md에 추가
3. 새 기능 추가: README.md와 CHANGELOG.md 업데이트
4. FAQ 추가: QUICK_START.md에 추가

## 📞 문의

- **기술 지원**: 시스템 관리자
- **문서 관련**: 개발팀
- **기능 제안**: GitHub Issues 또는 개발팀

## 🔗 관련 링크

- **대시보드**: http://203.245.30.6:80
- **API Base**: http://203.245.30.6/api
- **Docker Compose**: /home/deploy/docker-compose.yml
- **nginx 설정**: /home/deploy/nginx/conf.d/port-based.conf

---

**마지막 업데이트**: 2025-10-16
**버전**: 2.0.0
**유지보수**: Team B
