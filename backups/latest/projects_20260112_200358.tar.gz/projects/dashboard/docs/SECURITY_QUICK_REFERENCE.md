# 보안 강화 빠른 참조

## 🎯 핵심 요약

### 현재 문제점
1. ❌ API 인증 없음 → 누구나 접근 가능
2. ❌ 관리자/일반 사용자 구분 없음
3. ❌ 통계/시스템 정보가 모두에게 노출

### 해결 방안
1. ✅ 로그인 시스템 구현
2. ✅ 역할 기반 접근 제어 (admin/viewer/public)
3. ✅ 관리자 전용 메뉴 분리

---

## 📅 구현 일정

| Phase | 내용 | 기간 | 상태 |
|-------|------|------|------|
| **Phase 1** | 기본 인증 시스템 | 2-3주 | 📝 계획 |
| **Phase 2** | API 키 시스템 | 1-2주 | ⏰ 대기 |
| **Phase 3** | 고급 보안 (JWT, OAuth2) | TBD | ⏰ 대기 |

---

## 🔐 Phase 1: 기본 인증 (v2.1.0)

### 주요 기능
```
✅ 로그인/로그아웃
✅ 세션 기반 인증 (12시간)
✅ 비밀번호 해싱 (bcrypt)
✅ 역할: admin, viewer, public
✅ API 엔드포인트 권한 설정
✅ 관리자 전용 UI (통계, 시스템 상태)
```

### 역할별 권한

#### PUBLIC (비로그인)
```
허용:
- 로그인 페이지만

차단:
- 모든 API
- 모든 프로젝트 정보
```

#### VIEWER (일반 사용자)
```
허용:
- 프로젝트 조회
- 릴리즈 노트 조회
- 프로젝트 방문

차단:
- 통계 API
- 개발자 정보 API
- 시스템 상태 API
```

#### ADMIN (관리자)
```
허용:
- 모든 기능
- 통계 조회
- 개발자 정보
- 시스템 상태
- 사용자 관리

차단:
- 없음 (전체 권한)
```

### 구현 태스크 (총 16.5시간)

```
[30분] Task 1: 환경 설정
[1시간] Task 2: 데이터 모델
[2시간] Task 3: 인증 미들웨어
[2시간] Task 4: 로그인/로그아웃 API
[2시간] Task 5: 로그인 페이지 UI
[2시간] Task 6: 기존 API 권한 적용
[3시간] Task 7: UI 역할별 표시
[2시간] Task 8: 테스트 및 검증
[1시간] Task 9: 문서 업데이트
[1시간] Task 10: 배포
```

### 빠른 시작

#### 1. 패키지 설치
```bash
cd /home/deploy/projects/dashboard
npm install express-session session-file-store bcrypt dotenv
```

#### 2. 환경 변수 설정
```bash
cat > .env << 'EOF'
SESSION_SECRET=your-random-secret-key-here
NODE_ENV=production
PORT=3000
SESSION_MAX_AGE=43200000
EOF
```

#### 3. 관리자 계정 생성
```bash
mkdir -p data/sessions
node scripts/create-admin.js "SecurePassword123!"
```

#### 4. 서버 재시작
```bash
cd /home/deploy
docker compose build dashboard
docker compose up -d dashboard
```

#### 5. 로그인 테스트
```
http://203.245.30.6:80/login
Username: admin
Password: SecurePassword123!
```

---

## 🔑 Phase 2: API 키 시스템 (v2.2.0)

### 주요 기능
```
✅ API 키 발급/관리
✅ API 키 기반 인증
✅ API 키별 Rate limiting
✅ 사용량 추적
```

### API 키 사용 예시

#### 발급 (관리자만)
```bash
curl -X POST http://203.245.30.6/api/keys \
  -H "Cookie: dashboard.sid=xxx" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Slack Bot",
    "permissions": ["projects:read", "stats:read"],
    "rateLimit": 100
  }'
```

#### 사용
```bash
curl http://203.245.30.6/api/projects \
  -H "Authorization: Bearer dk_live_xxxxxxxxx"
```

### 구현 예상 기간
- **설계**: 1일
- **구현**: 3-4일
- **테스트**: 1일
- **총**: 약 1-2주

---

## 📊 API 엔드포인트 권한

| 엔드포인트 | Public | Viewer | Admin | API Key |
|-----------|--------|--------|-------|---------|
| GET / | ✅ | ✅ | ✅ | ❌ |
| GET /login | ✅ | - | - | ❌ |
| POST /api/login | ✅ | ✅ | ✅ | ❌ |
| POST /api/logout | ❌ | ✅ | ✅ | ❌ |
| GET /api/projects | ❌ | ✅ | ✅ | ✅ |
| GET /api/projects/:id | ❌ | ✅ | ✅ | ✅ |
| GET /api/releases | ❌ | ✅ | ✅ | ✅ |
| GET /api/stats | ❌ | ❌ | ✅ | ✅* |
| GET /api/developers | ❌ | ❌ | ✅ | ❌ |
| GET /api/system/status | ❌ | ❌ | ✅ | ❌ |

*권한이 있는 API 키만

---

## 🛡️ 보안 체크리스트

### Phase 1 완료 시
- [ ] 비밀번호 bcrypt로 해싱
- [ ] 세션 Secret 안전하게 저장 (.env)
- [ ] httpOnly 쿠키 사용
- [ ] sameSite 'strict' 설정
- [ ] 로그인 Rate limiting (15분 5회)
- [ ] 세션 타임아웃 (12시간)
- [ ] 에러 메시지에서 정보 누출 방지
- [ ] HTTPS 사용 (운영 환경)

### Phase 2 완료 시
- [ ] API 키 안전하게 저장
- [ ] API 키별 Rate limiting
- [ ] API 키 만료 기능
- [ ] 사용량 로깅
- [ ] 의심스러운 활동 감지

---

## 🧪 테스트 시나리오

### 로그인 테스트
```bash
# 1. 성공 케이스
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"correct"}' \
  -c cookies.txt

# 2. 실패 케이스 (잘못된 비밀번호)
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"wrong"}'

# 3. 실패 케이스 (없는 사용자)
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"nouser","password":"any"}'
```

### 권한 테스트
```bash
# 1. 인증된 요청 (성공)
curl http://localhost:3000/api/projects \
  -b cookies.txt

# 2. 미인증 요청 (401)
curl http://localhost:3000/api/projects

# 3. 관리자 전용 (admin만 200)
curl http://localhost:3000/api/stats \
  -b cookies.txt

# 4. 일반 사용자 (viewer는 403)
curl http://localhost:3000/api/stats \
  -b viewer_cookies.txt
```

---

## 📚 관련 문서

### 상세 문서
- **설계**: `SECURITY_IMPROVEMENT_PLAN.md` (30KB)
- **구현**: `TASKS_PHASE1.md` (15KB)
- **이 문서**: `SECURITY_QUICK_REFERENCE.md` (빠른 참조)

### 읽는 순서
1. 이 문서 (빠른 이해)
2. SECURITY_IMPROVEMENT_PLAN.md (전체 설계)
3. TASKS_PHASE1.md (구현 상세)

---

## ❓ FAQ

**Q: 기존 사용자는 어떻게 되나요?**
A: 처음에는 관리자가 수동으로 계정 생성. Phase 2+에서 UI 추가 예정.

**Q: 비밀번호 찾기는?**
A: Phase 1에서는 관리자가 수동으로 재설정. 자동화는 나중에.

**Q: HTTPS 필수인가요?**
A: 내부 네트워크는 HTTP 가능하나, 운영 환경에서는 HTTPS 강력 권장.

**Q: 데이터베이스는 언제?**
A: Phase 3 (v3.0.0)에서 PostgreSQL 도입. 지금은 파일 기반으로 충분.

**Q: API 키 없이 외부 통합?**
A: Phase 1에서는 불가. Phase 2에서 API 키 도입 후 가능.

**Q: 기존 기능에 영향은?**
A: 로그인만 추가되고, 기존 기능은 모두 유지됨.

**Q: 얼마나 걸리나요?**
A: 풀타임 1명 기준 2-3주. 파트타임이면 4-6주.

**Q: 백업은?**
A: 배포 전 항상 백업. 롤백 가능.

---

## 🚀 시작하기

### 지금 바로 시작
```bash
# 1. 문서 확인
cat /home/deploy/projects/dashboard/docs/SECURITY_IMPROVEMENT_PLAN.md

# 2. 태스크 확인
cat /home/deploy/projects/dashboard/docs/TASKS_PHASE1.md

# 3. Task 1 시작
cd /home/deploy/projects/dashboard
npm install express-session session-file-store bcrypt dotenv
```

### 다음 단계
1. Task 1-2 완료 (데이터 모델)
2. Task 3-4 완료 (API 구현)
3. Task 5-7 완료 (UI 구현)
4. Task 8-10 완료 (테스트, 배포)

---

**문서 버전**: 1.0
**작성일**: 2025-10-16
**담당**: DevOps Team
**상태**: 계획 단계
