# Dashboard v2.0 보안 강화 계획

## 📋 현재 보안 상태 분석

### ✅ 현재 적용된 보안
1. **nginx IP 화이트리스트**: 한국 IP만 접속 가능
2. **Docker 내부 네트워크**: 172.20.0.0/16 격리
3. **Rate Limiting**: API 요청 제한
4. **Non-root 사용자**: nodejs 계정으로 실행

### ❌ 보안 취약점

#### 1. API 인증 부재
- **문제**: 모든 API 엔드포인트가 인증 없이 노출
- **위험도**: 🔴 높음
- **영향**:
  - 누구나 프로젝트 정보 조회 가능
  - 통계 데이터 무단 수집 가능
  - 릴리즈 노트 등 내부 정보 노출

#### 2. 관리자 기능 미구분
- **문제**: 일반 사용자와 관리자 구분 없음
- **위험도**: 🟡 중간
- **영향**:
  - 시스템 통계가 모두에게 노출
  - 개발자 정보가 모두에게 노출
  - 릴리즈 노트 상세 정보 노출

#### 3. CORS 미설정
- **문제**: Cross-Origin 요청 제한 없음
- **위험도**: 🟡 중간
- **영향**: 외부 도메인에서 API 호출 가능

#### 4. API 키 관리 시스템 부재
- **문제**: 외부 시스템 연동 시 인증 방법 없음
- **위험도**: 🟠 중간-높음
- **영향**: 안전한 API 통합 불가능

## 🎯 보안 강화 목표

### Phase 1: 기본 인증 시스템 (v2.1.0)
1. 관리자 로그인 기능
2. 세션 기반 인증
3. 역할 기반 접근 제어 (RBAC)
4. API 엔드포인트별 권한 설정

### Phase 2: API 키 시스템 (v2.2.0)
1. API 키 발급/관리 기능
2. API 키 기반 인증
3. Rate limiting per API key
4. API 사용량 추적

### Phase 3: 고급 보안 (v3.0.0)
1. JWT 토큰 인증
2. OAuth2 통합
3. 2FA (Two-Factor Authentication)
4. 감사 로그 (Audit Log)

## 🔐 Phase 1: 기본 인증 시스템 설계

### 1. 인증 아키텍처

```
┌─────────────────────────────────────────────────────────┐
│                    사용자 요청                            │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              Express 미들웨어 체인                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │ 1. Session Check (express-session)              │   │
│  └──────────────────┬──────────────────────────────┘   │
│                     │                                   │
│  ┌──────────────────▼──────────────────────────────┐   │
│  │ 2. Authentication Middleware                    │   │
│  │    - 로그인 상태 확인                              │   │
│  │    - 세션 유효성 검증                              │   │
│  └──────────────────┬──────────────────────────────┘   │
│                     │                                   │
│  ┌──────────────────▼──────────────────────────────┐   │
│  │ 3. Authorization Middleware                     │   │
│  │    - 역할 확인 (admin/viewer/api_user)           │   │
│  │    - 권한 검증                                     │   │
│  └──────────────────┬──────────────────────────────┘   │
└─────────────────────┼───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│                  라우트 핸들러                             │
│  - Public Routes (인증 불필요)                            │
│  - Viewer Routes (로그인만 필요)                          │
│  - Admin Routes (관리자 권한 필요)                        │
└─────────────────────────────────────────────────────────┘
```

### 2. 사용자 역할 정의

#### 역할 종류
```javascript
const ROLES = {
  PUBLIC: 'public',      // 비로그인 사용자
  VIEWER: 'viewer',      // 일반 사용자 (읽기 전용)
  ADMIN: 'admin',        // 관리자 (모든 권한)
  API_USER: 'api_user'   // API 키 사용자 (제한된 API 접근)
};
```

#### 역할별 권한

| 역할 | 접근 가능 기능 | 제한 |
|------|--------------|------|
| **PUBLIC** | - 로그인 페이지<br>- 공개 프로젝트 카드 (제한적) | - API 접근 불가<br>- 통계 불가<br>- 개발자 정보 불가 |
| **VIEWER** | - 모든 프로젝트 조회<br>- 프로젝트 방문<br>- 릴리즈 노트 조회 | - 통계 불가<br>- 개발자 정보 불가<br>- 시스템 상태 불가 |
| **ADMIN** | - 모든 기능<br>- 통계 조회<br>- 개발자 정보<br>- 시스템 상태<br>- 사용자 관리 | 제한 없음 |
| **API_USER** | - API 엔드포인트<br>- Rate limit 내 요청 | - UI 접근 불가 |

### 3. 데이터베이스 스키마 (간소화)

#### 파일 기반 (초기 버전 - v2.1.0)

```javascript
// data/users.json
const USERS = [
  {
    id: 'admin-001',
    username: 'admin',
    passwordHash: '$2b$10$...', // bcrypt hash
    role: 'admin',
    email: 'admin@example.com',
    createdAt: '2025-10-16',
    lastLogin: '2025-10-16T10:30:00Z',
    active: true
  },
  {
    id: 'viewer-001',
    username: 'developer1',
    passwordHash: '$2b$10$...',
    role: 'viewer',
    email: 'dev1@example.com',
    createdAt: '2025-10-16',
    lastLogin: null,
    active: true
  }
];

// data/sessions.json (메모리 or Redis 권장)
const SESSIONS = {
  'session-id-xxx': {
    userId: 'admin-001',
    role: 'admin',
    createdAt: '2025-10-16T10:00:00Z',
    expiresAt: '2025-10-16T22:00:00Z'
  }
};

// data/api_keys.json (Phase 2)
const API_KEYS = [
  {
    id: 'key-001',
    key: 'dk_live_xxxxxxxxxxxxxxxxx',
    name: 'Slack Bot Integration',
    userId: 'admin-001',
    role: 'api_user',
    permissions: ['projects:read', 'stats:read'],
    rateLimit: 100, // requests per hour
    createdAt: '2025-10-16',
    lastUsed: '2025-10-16T10:30:00Z',
    active: true
  }
];
```

### 4. API 엔드포인트 권한 설정

```javascript
// 엔드포인트별 필요 권한
const ENDPOINT_PERMISSIONS = {
  // Public (인증 불필요)
  'GET /': ['public'],
  'GET /login': ['public'],
  'POST /api/login': ['public'],
  'POST /api/logout': ['viewer', 'admin'],

  // Viewer (로그인 필요)
  'GET /api/projects': ['viewer', 'admin', 'api_user'],
  'GET /api/projects/:id': ['viewer', 'admin', 'api_user'],
  'GET /api/releases': ['viewer', 'admin'],

  // Admin only
  'GET /api/stats': ['admin'],
  'GET /api/developers': ['admin'],
  'GET /api/system/status': ['admin'],
  'GET /api/users': ['admin'],
  'POST /api/users': ['admin'],
  'PUT /api/users/:id': ['admin'],
  'DELETE /api/users/:id': ['admin'],

  // API Key Management (Admin only - Phase 2)
  'GET /api/keys': ['admin'],
  'POST /api/keys': ['admin'],
  'DELETE /api/keys/:id': ['admin']
};
```

### 5. UI 변경사항

#### 로그인 페이지
```
┌─────────────────────────────────────┐
│          🚀 Dashboard               │
│                                     │
│  ┌───────────────────────────────┐ │
│  │  Username                     │ │
│  │  ┌─────────────────────────┐ │ │
│  │  │ admin                   │ │ │
│  │  └─────────────────────────┘ │ │
│  │                               │ │
│  │  Password                     │ │
│  │  ┌─────────────────────────┐ │ │
│  │  │ ••••••••                │ │ │
│  │  └─────────────────────────┘ │ │
│  │                               │ │
│  │  ┌─────────────────────────┐ │ │
│  │  │      로그인              │ │ │
│  │  └─────────────────────────┘ │ │
│  └───────────────────────────────┘ │
└─────────────────────────────────────┘
```

#### 헤더 변경 (로그인 상태)
```
┌─────────────────────────────────────────────────┐
│  🚀 Dashboard              admin ▼ │  로그아웃  │
│                              └─────────────┐   │
│                              관리자         │   │
│                              프로필         │   │
│                              API 키 관리    │   │
│                              (Admin only)   │   │
└─────────────────────────────────────────────────┘
```

#### 사이드바 메뉴 (역할별)

**PUBLIC (비로그인)**:
- 로그인 필요 메시지 표시
- 제한적인 프로젝트 미리보기만

**VIEWER**:
```
📦 프로젝트
  ├─ 전체 프로젝트
  ├─ 운영중
  └─ 개발중

📁 카테고리
  ├─ Full-stack
  ├─ Frontend
  ├─ Backend
  └─ Tools

📝 개발자 노트
  ├─ 릴리즈 노트
  └─ 타임라인

❌ 통계 (숨김)
❌ 시스템 상태 (숨김)
```

**ADMIN**:
```
📦 프로젝트
  └─ ... (전체)

📁 카테고리
  └─ ... (전체)

📝 개발자 노트
  ├─ 릴리즈 노트
  ├─ 개발자별
  └─ 타임라인

📊 관리자 영역 ⭐
  ├─ 통계
  ├─ 개발자 정보
  ├─ 시스템 상태
  ├─ 사용자 관리
  └─ API 키 관리 (Phase 2)
```

### 6. 보안 설정

#### 세션 설정
```javascript
const session = require('express-session');
const FileStore = require('session-file-store')(session);

app.use(session({
  store: new FileStore({
    path: './data/sessions',
    ttl: 43200, // 12 hours
    retries: 0
  }),
  secret: process.env.SESSION_SECRET || 'change-this-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // HTTPS에서는 true
    httpOnly: true,
    maxAge: 12 * 60 * 60 * 1000, // 12 hours
    sameSite: 'strict'
  }
}));
```

#### 비밀번호 보안
```javascript
const bcrypt = require('bcrypt');
const SALT_ROUNDS = 10;

// 비밀번호 해싱
async function hashPassword(password) {
  return await bcrypt.hash(password, SALT_ROUNDS);
}

// 비밀번호 검증
async function verifyPassword(password, hash) {
  return await bcrypt.compare(password, hash);
}
```

#### Rate Limiting (강화)
```javascript
const rateLimit = require('express-rate-limit');

// 로그인 엔드포인트
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15분
  max: 5, // 5번 시도
  message: '너무 많은 로그인 시도. 15분 후 다시 시도하세요.'
});

// API 엔드포인트 (인증된 사용자)
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  keyGenerator: (req) => req.session?.userId || req.ip
});

// API 키 사용자 (Phase 2)
const apiKeyLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1시간
  max: (req) => req.apiKey?.rateLimit || 100,
  keyGenerator: (req) => req.apiKey?.id || req.ip
});
```

## 📝 Phase 1 구현 태스크

### Task 1: 환경 설정 및 의존성
**예상 시간**: 30분

```bash
# 1.1 패키지 설치
npm install express-session session-file-store bcrypt

# 1.2 환경 변수 설정
cat > .env << EOF
SESSION_SECRET=your-super-secret-key-change-this
NODE_ENV=production
PORT=3000
EOF

# 1.3 데이터 디렉토리 생성
mkdir -p data/sessions
chmod 700 data/sessions
```

**완료 조건**:
- [x] 필요한 npm 패키지 설치
- [x] .env 파일 생성 및 설정
- [x] 데이터 디렉토리 생성

---

### Task 2: 데이터 모델 및 초기 사용자 생성
**예상 시간**: 1시간

```javascript
// 2.1 data/users.json 생성
{
  "users": [
    {
      "id": "admin-001",
      "username": "admin",
      "passwordHash": "$2b$10$...", // 'admin123' hashed
      "role": "admin",
      "email": "admin@localhost",
      "createdAt": "2025-10-16",
      "lastLogin": null,
      "active": true
    }
  ]
}

// 2.2 초기 비밀번호 해싱 스크립트
// scripts/create-admin.js
const bcrypt = require('bcrypt');
const fs = require('fs');

async function createAdmin() {
  const password = process.argv[2] || 'admin123';
  const hash = await bcrypt.hash(password, 10);

  const user = {
    id: 'admin-001',
    username: 'admin',
    passwordHash: hash,
    role: 'admin',
    email: 'admin@localhost',
    createdAt: new Date().toISOString().split('T')[0],
    lastLogin: null,
    active: true
  };

  fs.writeFileSync('./data/users.json',
    JSON.stringify({ users: [user] }, null, 2));

  console.log('Admin user created:');
  console.log('Username: admin');
  console.log('Password:', password);
}

createAdmin();
```

**실행**:
```bash
node scripts/create-admin.js "your-secure-password"
```

**완료 조건**:
- [x] users.json 파일 생성
- [x] 관리자 계정 생성
- [x] 비밀번호 안전하게 보관

---

### Task 3: 인증 미들웨어 구현
**예상 시간**: 2시간

```javascript
// 3.1 middleware/auth.js
const fs = require('fs');
const path = require('path');

// 사용자 데이터 로드
function loadUsers() {
  const usersPath = path.join(__dirname, '../data/users.json');
  const data = fs.readFileSync(usersPath, 'utf8');
  return JSON.parse(data).users;
}

// 인증 체크 미들웨어
function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) {
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required'
      });
    }
    return res.redirect('/login');
  }

  // 사용자 정보를 req에 추가
  const users = loadUsers();
  const user = users.find(u => u.id === req.session.userId);

  if (!user || !user.active) {
    req.session.destroy();
    return res.status(401).json({
      success: false,
      error: 'Invalid session'
    });
  }

  req.user = user;
  next();
}

// 역할 체크 미들웨어
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required'
      });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions'
      });
    }

    next();
  };
}

module.exports = {
  requireAuth,
  requireRole
};
```

**완료 조건**:
- [x] requireAuth 미들웨어 작성
- [x] requireRole 미들웨어 작성
- [x] 세션 검증 로직 구현

---

### Task 4: 로그인/로그아웃 API 구현
**예상 시간**: 2시간

```javascript
// 4.1 routes/auth.js
const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const { loadUsers, updateUserLogin } = require('../utils/user-manager');

// 로그인
router.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({
      success: false,
      error: 'Username and password required'
    });
  }

  const users = loadUsers();
  const user = users.find(u => u.username === username);

  if (!user || !user.active) {
    return res.status(401).json({
      success: false,
      error: 'Invalid credentials'
    });
  }

  const valid = await bcrypt.compare(password, user.passwordHash);

  if (!valid) {
    return res.status(401).json({
      success: false,
      error: 'Invalid credentials'
    });
  }

  // 세션 생성
  req.session.userId = user.id;
  req.session.role = user.role;

  // 마지막 로그인 시간 업데이트
  updateUserLogin(user.id);

  res.json({
    success: true,
    data: {
      userId: user.id,
      username: user.username,
      role: user.role
    }
  });
});

// 로그아웃
router.post('/api/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({
        success: false,
        error: 'Logout failed'
      });
    }

    res.json({
      success: true,
      message: 'Logged out successfully'
    });
  });
});

// 현재 사용자 정보
router.get('/api/me', requireAuth, (req, res) => {
  res.json({
    success: true,
    data: {
      userId: req.user.id,
      username: req.user.username,
      role: req.user.role,
      email: req.user.email
    }
  });
});

module.exports = router;
```

**완료 조건**:
- [x] POST /api/login 구현
- [x] POST /api/logout 구현
- [x] GET /api/me 구현
- [x] 세션 생성/파괴 확인

---

### Task 5: 로그인 페이지 UI 구현
**예상 시간**: 2시간

```javascript
// 5.1 views/login.html (템플릿 리터럴)
function renderLoginPage() {
  return `
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>로그인 - Dashboard</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .login-container {
      background: white;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
      width: 100%;
      max-width: 400px;
    }

    .login-header {
      text-align: center;
      margin-bottom: 30px;
    }

    .login-header h1 {
      font-size: 28px;
      color: #333;
      margin-bottom: 8px;
    }

    .login-header p {
      color: #666;
      font-size: 14px;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      margin-bottom: 8px;
      color: #333;
      font-weight: 500;
    }

    .form-group input {
      width: 100%;
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 14px;
      transition: border-color 0.3s;
    }

    .form-group input:focus {
      outline: none;
      border-color: #667eea;
    }

    .login-button {
      width: 100%;
      padding: 12px;
      background: #667eea;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s;
    }

    .login-button:hover {
      background: #5568d3;
    }

    .login-button:disabled {
      background: #ccc;
      cursor: not-allowed;
    }

    .error-message {
      background: #fee;
      color: #c33;
      padding: 12px;
      border-radius: 6px;
      margin-bottom: 20px;
      display: none;
    }

    .error-message.show {
      display: block;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <div class="login-header">
      <h1>🚀 Dashboard</h1>
      <p>관리자 로그인</p>
    </div>

    <div class="error-message" id="errorMessage"></div>

    <form id="loginForm">
      <div class="form-group">
        <label for="username">사용자명</label>
        <input type="text" id="username" name="username"
               placeholder="admin" required autofocus>
      </div>

      <div class="form-group">
        <label for="password">비밀번호</label>
        <input type="password" id="password" name="password"
               placeholder="••••••••" required>
      </div>

      <button type="submit" class="login-button" id="loginButton">
        로그인
      </button>
    </form>
  </div>

  <script>
    const form = document.getElementById('loginForm');
    const errorMsg = document.getElementById('errorMessage');
    const loginBtn = document.getElementById('loginButton');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;

      loginBtn.disabled = true;
      loginBtn.textContent = '로그인 중...';
      errorMsg.classList.remove('show');

      try {
        const response = await fetch('/api/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (data.success) {
          window.location.href = '/';
        } else {
          errorMsg.textContent = data.error || '로그인 실패';
          errorMsg.classList.add('show');
        }
      } catch (error) {
        errorMsg.textContent = '서버 오류가 발생했습니다.';
        errorMsg.classList.add('show');
      } finally {
        loginBtn.disabled = false;
        loginBtn.textContent = '로그인';
      }
    });
  </script>
</body>
</html>
  `;
}

// GET /login
app.get('/login', (req, res) => {
  if (req.session && req.session.userId) {
    return res.redirect('/');
  }
  res.send(renderLoginPage());
});
```

**완료 조건**:
- [x] 로그인 페이지 HTML/CSS 작성
- [x] 로그인 폼 JavaScript 작성
- [x] 에러 메시지 표시 구현

---

### Task 6: 기존 API에 권한 적용
**예상 시간**: 2시간

```javascript
// 6.1 server.js 수정

const { requireAuth, requireRole } = require('./middleware/auth');

// Public endpoints (인증 불필요)
app.get('/', (req, res) => {
  // 비로그인 시 제한된 정보만 표시
  const isAuthenticated = req.session && req.session.userId;
  const userRole = req.session?.role || 'public';
  res.send(renderDashboard(isAuthenticated, userRole));
});

app.get('/login', ...); // 이미 구현

// Viewer endpoints (로그인 필요)
app.get('/api/projects', requireAuth, (req, res) => {
  // 기존 코드
});

app.get('/api/projects/:id', requireAuth, (req, res) => {
  // 기존 코드
});

app.get('/api/releases', requireAuth, (req, res) => {
  // 기존 코드
});

// Admin only endpoints
app.get('/api/stats', requireAuth, requireRole('admin'), (req, res) => {
  // 기존 코드
});

app.get('/api/developers', requireAuth, requireRole('admin'), (req, res) => {
  // 기존 코드
});

app.get('/api/system/status', requireAuth, requireRole('admin'), (req, res) => {
  // 새로 구현
  res.json({
    success: true,
    data: {
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      version: '2.1.0'
    }
  });
});
```

**완료 조건**:
- [x] Public 엔드포인트 확인
- [x] Viewer 엔드포인트에 requireAuth 적용
- [x] Admin 엔드포인트에 requireRole 적용

---

### Task 7: UI 역할별 표시 수정
**예상 시간**: 3시간

```javascript
// 7.1 renderDashboard() 수정

function renderDashboard(isAuthenticated, userRole) {
  const isAdmin = userRole === 'admin';
  const isViewer = userRole === 'viewer' || isAdmin;

  return `
<!DOCTYPE html>
<html lang="ko">
<head>
  <!-- ... 기존 head ... -->
  <script>
    // 클라이언트에서 사용할 전역 변수
    window.USER_ROLE = '${userRole}';
    window.IS_AUTHENTICATED = ${isAuthenticated};
  </script>
</head>
<body>
  <!-- 헤더에 사용자 정보 추가 -->
  <nav class="navbar">
    <div class="nav-left">
      <h1>🚀 Dashboard</h1>
    </div>
    <div class="nav-right">
      ${isAuthenticated ? `
        <div class="user-menu">
          <span class="username">${userRole === 'admin' ? '관리자' : '사용자'}</span>
          <button onclick="logout()">로그아웃</button>
        </div>
      ` : `
        <a href="/login" class="login-link">로그인</a>
      `}
    </div>
  </nav>

  <!-- 사이드바 메뉴 (역할별 필터링) -->
  <aside class="sidebar">
    <!-- ... 기존 메뉴 ... -->

    <!-- 관리자 전용 메뉴 -->
    ${isAdmin ? `
    <div class="menu-section admin-section">
      <div class="menu-title">⭐ 관리자 영역</div>
      <div class="menu-item" onclick="showView('stats')">
        <span class="menu-icon">📊</span>
        <span>통계</span>
      </div>
      <div class="menu-item" onclick="showView('developers')">
        <span class="menu-icon">👥</span>
        <span>개발자 정보</span>
      </div>
      <div class="menu-item" onclick="showView('system')">
        <span class="menu-icon">⚙️</span>
        <span>시스템 상태</span>
      </div>
    </div>
    ` : ''}
  </aside>

  <script>
    // 로그아웃 함수
    async function logout() {
      const res = await fetch('/api/logout', { method: 'POST' });
      if (res.ok) {
        window.location.href = '/login';
      }
    }

    // API 호출 시 인증 확인
    async function fetchAPI(url, options = {}) {
      const res = await fetch(url, options);

      if (res.status === 401) {
        window.location.href = '/login';
        return null;
      }

      if (res.status === 403) {
        alert('접근 권한이 없습니다.');
        return null;
      }

      return res.json();
    }
  </script>
</body>
</html>
  `;
}
```

**완료 조건**:
- [x] 헤더에 사용자 정보 표시
- [x] 로그아웃 버튼 구현
- [x] 역할별 사이드바 메뉴 필터링
- [x] 관리자 전용 섹션 추가

---

### Task 8: 테스트 및 검증
**예상 시간**: 2시간

```bash
# 8.1 로그인 테스트
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}' \
  -c cookies.txt

# 8.2 인증된 API 요청
curl http://localhost:3000/api/projects \
  -b cookies.txt

# 8.3 관리자 전용 API
curl http://localhost:3000/api/stats \
  -b cookies.txt

# 8.4 미인증 요청 (401 예상)
curl http://localhost:3000/api/stats

# 8.5 로그아웃
curl -X POST http://localhost:3000/api/logout \
  -b cookies.txt
```

**테스트 체크리스트**:
- [ ] 로그인 성공 테스트
- [ ] 잘못된 비밀번호로 로그인 실패 테스트
- [ ] 인증된 사용자 API 접근 테스트
- [ ] 미인증 사용자 API 차단 테스트
- [ ] 관리자 전용 API 접근 테스트
- [ ] 일반 사용자의 관리자 API 차단 테스트
- [ ] 로그아웃 후 세션 무효화 테스트
- [ ] UI에서 역할별 메뉴 표시 테스트

---

### Task 9: 문서 업데이트
**예상 시간**: 1시간

업데이트할 문서:
- README.md: 인증 시스템 섹션 추가
- API_EXAMPLES.md: 인증 헤더 예시 추가
- CHANGELOG.md: v2.1.0 변경사항 추가
- 새 문서: SECURITY.md (보안 가이드)

---

### Task 10: 배포 및 마이그레이션
**예상 시간**: 1시간

```bash
# 10.1 백업
cp -r /home/deploy/projects/dashboard /home/deploy/backup/dashboard-v2.0

# 10.2 환경 변수 설정
echo "SESSION_SECRET=$(openssl rand -base64 32)" >> /home/deploy/projects/dashboard/.env

# 10.3 관리자 계정 생성
cd /home/deploy/projects/dashboard
node scripts/create-admin.js "secure-password-here"

# 10.4 빌드 및 재배포
cd /home/deploy
docker compose build dashboard
docker compose up -d dashboard

# 10.5 로그 확인
docker compose logs -f dashboard
```

**완료 조건**:
- [x] 기존 데이터 백업
- [x] 환경 변수 설정
- [x] 관리자 계정 생성
- [x] 서비스 재시작
- [x] 로그인 테스트

---

## 📊 Phase 1 완료 체크리스트

### 기능 체크리스트
- [ ] 로그인/로그아웃 기능
- [ ] 세션 기반 인증
- [ ] 역할 기반 접근 제어 (Public/Viewer/Admin)
- [ ] API 엔드포인트 권한 설정
- [ ] 로그인 페이지 UI
- [ ] 역할별 사이드바 메뉴 필터링
- [ ] 관리자 전용 섹션 (통계, 개발자 정보, 시스템 상태)
- [ ] 비밀번호 해싱 (bcrypt)
- [ ] Rate limiting (로그인)
- [ ] 세션 보안 설정

### 보안 체크리스트
- [ ] 비밀번호 안전하게 저장 (bcrypt)
- [ ] 세션 Secret 안전하게 관리
- [ ] httpOnly 쿠키 사용
- [ ] sameSite 'strict' 설정
- [ ] Rate limiting 적용
- [ ] 에러 메시지에서 정보 누출 방지
- [ ] 세션 타임아웃 설정 (12시간)

### 테스트 체크리스트
- [ ] 로그인 성공/실패 테스트
- [ ] 인증 미들웨어 테스트
- [ ] 권한 미들웨어 테스트
- [ ] API 접근 제어 테스트
- [ ] UI 역할별 표시 테스트
- [ ] 세션 만료 테스트
- [ ] 로그아웃 테스트

### 문서 체크리스트
- [ ] README.md 업데이트
- [ ] API_EXAMPLES.md 업데이트
- [ ] CHANGELOG.md 업데이트
- [ ] SECURITY.md 생성
- [ ] 사용자 가이드 작성

---

## 🔮 Phase 2: API 키 시스템 (간략)

Phase 2는 Phase 1 완료 후 진행하며, 다음 기능을 포함합니다:

### 주요 기능
1. **API 키 발급/관리**
   - 관리자가 API 키 생성
   - API 키별 권한 설정
   - API 키별 Rate limit 설정

2. **API 키 인증**
   - Authorization: Bearer <api-key> 헤더
   - API 키 유효성 검증
   - 사용량 추적

3. **관리 UI**
   - API 키 목록
   - API 키 생성 폼
   - 사용량 통계
   - API 키 비활성화/삭제

### 예상 개발 기간
- 설계: 1일
- 구현: 3-4일
- 테스트: 1일
- 문서화: 1일
- **총: 6-7일**

---

## 📅 타임라인

### Phase 1 (v2.1.0)
- **기간**: 2-3주
- **목표일**: 2025-11-06

| 주차 | 작업 내용 |
|------|----------|
| Week 1 | Task 1-3 (환경설정, 데이터모델, 미들웨어) |
| Week 2 | Task 4-7 (API, UI 구현) |
| Week 3 | Task 8-10 (테스트, 문서, 배포) |

### Phase 2 (v2.2.0)
- **기간**: 1-2주
- **목표일**: 2025-11-20

### Phase 3 (v3.0.0)
- **기간**: TBD
- **검토 필요**: Phase 2 완료 후

---

## 💰 예상 리소스

### 개발 인력
- Backend 개발자: 1명
- Frontend 개발자: 0.5명 (UI 작업)
- QA: 0.5명 (테스트)

### 인프라
- 추가 패키지: ~5MB (bcrypt, express-session)
- 세션 저장소: 파일 기반 (Phase 1), Redis 고려 (Phase 2+)
- 메모리: +50MB (예상)

---

## 🎯 성공 기준

### Phase 1
1. ✅ 관리자만 통계/시스템 정보 접근 가능
2. ✅ 일반 사용자는 프로젝트 정보만 조회 가능
3. ✅ 비로그인 사용자는 로그인 페이지로 리다이렉트
4. ✅ 비밀번호 안전하게 저장 (bcrypt)
5. ✅ 세션 12시간 유지
6. ✅ 로그인 시도 제한 (15분에 5번)

### 측정 지표
- 무단 API 접근 시도: 0건
- 로그인 성공률: >95%
- 세션 만료로 인한 로그아웃: <5% (12시간 내)
- 평균 로그인 시간: <2초

---

## ❓ FAQ

### Q1: 기존 사용자들은 어떻게 하나요?
A: Phase 1에서는 관리자가 수동으로 계정을 생성합니다. Phase 2에서 사용자 관리 UI를 추가할 예정입니다.

### Q2: 비밀번호 재설정은?
A: Phase 1에서는 관리자가 수동으로 변경합니다. Phase 2+에서 자동화를 고려합니다.

### Q3: HTTPS는?
A: nginx에서 SSL 설정 필요 (별도 작업). 현재는 내부 네트워크만 사용하므로 HTTP도 가능하나, 운영 환경에서는 HTTPS 필수입니다.

### Q4: 데이터베이스는 언제 도입하나요?
A: Phase 3 (v3.0.0)에서 PostgreSQL 도입 예정. Phase 1-2는 파일 기반으로 충분합니다.

### Q5: API 키 없이 외부 통합은?
A: Phase 1에서는 불가능합니다. Phase 2에서 API 키 시스템 도입 후 가능합니다.

---

**작성일**: 2025-10-16
**버전**: 1.0
**작성자**: DevOps Team
