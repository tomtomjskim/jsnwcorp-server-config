# Dashboard 보안 강화 재설계 (공개 서비스 방식)

## 📋 서비스 특성 재정의

### 기본 개념
- **공개 서비스**: 대시보드는 누구나 접근 가능한 공개 서비스
- **프로젝트 정보 공개**: 모든 사용자가 프로젝트 목록, 설명, 링크 확인 가능
- **관리자 전용 영역**: 통계, 개발자 정보, 시스템 상태 등 내부 정보만 관리자 로그인 필요

### 잘못된 기존 설계
❌ Viewer 역할 불필요 (로그인 없이도 볼 수 있어야 함)
❌ 프로젝트 정보에 인증 필요 (공개되어야 함)
❌ 과도한 접근 제어 (오픈 서비스 특성 무시)

---

## 🎯 올바른 접근 제어 재설계

### 역할 정의 (2가지만)

```javascript
const ROLES = {
  PUBLIC: 'public',      // 일반 사용자 (비로그인, 기본)
  ADMIN: 'admin'         // 관리자 (로그인 필요)
};
```

### 역할별 권한

| 역할 | 프로젝트 | 릴리즈 노트 | 통계 | 개발자 정보 | 시스템 상태 |
|------|---------|----------|------|-----------|----------|
| **PUBLIC** | ✅ | ✅ | ❌ | ❌ | ❌ |
| **ADMIN** | ✅ | ✅ | ✅ | ✅ | ✅ |

**PUBLIC (일반 사용자)**:
- ✅ 프로젝트 목록 조회
- ✅ 프로젝트 상세 정보
- ✅ 프로젝트 방문 (링크 클릭)
- ✅ 프로젝트 검색
- ✅ 카테고리별 필터링
- ✅ 릴리즈 노트 조회 (공개 정보)
- ✅ 타임라인 조회
- ❌ 통계 정보 (내부)
- ❌ 개발자 정보 (내부)
- ❌ 시스템 상태 (내부)

**ADMIN (관리자)**:
- ✅ PUBLIC의 모든 권한
- ✅ 통계 조회
- ✅ 개발자 정보 조회
- ✅ 시스템 상태 조회
- ✅ 사용자 관리 (나중에)
- ✅ API 키 관리 (Phase 2)

---

## 🌐 UI/UX 재설계

### 메인 페이지 (PUBLIC)

```
┌─────────────────────────────────────────────────────┐
│  🚀 Dashboard                        🔐 관리자 로그인 │
├─────────────────────────────────────────────────────┤
│                                                     │
│  [사이드바]              [프로젝트 카드 영역]          │
│                                                     │
│  📦 프로젝트              ┌──────────────┐          │
│    └─ 전체 (1)           │ 🎰 Lotto     │          │
│    └─ 운영중 (1)         │  데이터 기반  │          │
│    └─ 개발중 (0)         │  로또 번호    │          │
│                         │  [방문하기]   │          │
│  📁 카테고리             └──────────────┘          │
│    └─ Full-stack (1)                              │
│    └─ Frontend (0)                                │
│    └─ Backend (0)                                 │
│                                                     │
│  📝 릴리즈 노트                                      │
│    └─ 전체 릴리즈                                    │
│    └─ 타임라인                                       │
│                                                     │
└─────────────────────────────────────────────────────┘
```

### 관리자 로그인 후

```
┌─────────────────────────────────────────────────────┐
│  🚀 Dashboard              관리자 ▼ │  로그아웃       │
├─────────────────────────────────────────────────────┤
│                                                     │
│  [사이드바]              [프로젝트 카드 영역]          │
│                                                     │
│  📦 프로젝트                                          │
│    └─ 전체 (1)                                       │
│    └─ 운영중 (1)                                     │
│    └─ 개발중 (0)                                     │
│                                                     │
│  📁 카테고리                                          │
│    └─ Full-stack (1)                               │
│    └─ Frontend (0)                                 │
│    └─ Backend (0)                                  │
│                                                     │
│  📝 릴리즈 노트                                       │
│    └─ 전체 릴리즈                                     │
│    └─ 타임라인                                        │
│                                                     │
│  ⭐ 관리자 전용 (새로 나타남)                          │
│    └─ 📊 통계                                        │
│    └─ 👥 개발자 정보                                  │
│    └─ ⚙️ 시스템 상태                                 │
│                                                     │
└─────────────────────────────────────────────────────┘
```

**핵심 변경사항**:
- PUBLIC 사용자도 프로젝트, 릴리즈 노트 모두 볼 수 있음
- 관리자 로그인 시 "⭐ 관리자 전용" 섹션만 추가로 나타남
- 로그인 버튼은 헤더 우측 상단에 작게 위치

---

## 🔌 API 엔드포인트 권한 재설계

### Public API (인증 불필요)

| 엔드포인트 | 메서드 | 설명 | 인증 | 역할 |
|----------|--------|------|------|------|
| `/` | GET | 메인 페이지 | ❌ | PUBLIC |
| `/api/projects` | GET | 프로젝트 목록 | ❌ | PUBLIC |
| `/api/projects/:id` | GET | 프로젝트 상세 | ❌ | PUBLIC |
| `/api/releases` | GET | 릴리즈 노트 | ❌ | PUBLIC |
| `/api/info` | GET | 대시보드 기본 정보 | ❌ | PUBLIC |

### Admin Only API (인증 필수)

| 엔드포인트 | 메서드 | 설명 | 인증 | 역할 |
|----------|--------|------|------|------|
| `/login` | GET | 로그인 페이지 | ❌ | PUBLIC |
| `/api/login` | POST | 로그인 처리 | ❌ | PUBLIC |
| `/api/logout` | POST | 로그아웃 | ✅ | ADMIN |
| `/api/me` | GET | 현재 사용자 정보 | ✅ | ADMIN |
| `/api/stats` | GET | 통계 정보 | ✅ | ADMIN |
| `/api/developers` | GET | 개발자 정보 | ✅ | ADMIN |
| `/api/system/status` | GET | 시스템 상태 | ✅ | ADMIN |
| `/api/users` | GET | 사용자 목록 | ✅ | ADMIN |
| `/api/users` | POST | 사용자 생성 | ✅ | ADMIN |

### 코드 예시

```javascript
const { requireAuth, requireRole } = require('./middleware/auth');
const { optionalAuth } = require('./middleware/auth');

// ===== PUBLIC API (인증 불필요) =====

// 메인 페이지 (로그인 여부에 따라 UI 다르게 표시)
app.get('/', optionalAuth, (req, res) => {
  const isAdmin = req.user && req.user.role === 'admin';
  res.send(renderDashboard(isAdmin));
});

// 프로젝트 API (모두 공개)
app.get('/api/projects', (req, res) => {
  // 필터링, 검색 지원
  const { status, category, search } = req.query;
  let projects = filterProjects(status, category, search);
  res.json({ success: true, data: projects });
});

app.get('/api/projects/:id', (req, res) => {
  const project = getProjectById(req.params.id);
  const releases = getReleaseNotesByProject(req.params.id);
  res.json({
    success: true,
    data: { project, releases }
  });
});

// 릴리즈 노트 (모두 공개)
app.get('/api/releases', (req, res) => {
  const releases = getReleaseNotes(req.query);
  res.json({ success: true, data: releases });
});

// ===== ADMIN API (인증 필수) =====

// 통계 (관리자만)
app.get('/api/stats', requireAuth, requireRole('admin'), (req, res) => {
  const stats = getProjectStats();
  res.json({ success: true, data: stats });
});

// 개발자 정보 (관리자만)
app.get('/api/developers', requireAuth, requireRole('admin'), (req, res) => {
  const developers = getDevelopersWithProjects();
  res.json({ success: true, data: developers });
});

// 시스템 상태 (관리자만)
app.get('/api/system/status', requireAuth, requireRole('admin'), (req, res) => {
  const status = getSystemStatus();
  res.json({ success: true, data: status });
});
```

---

## 📊 데이터 공개 범위 재정의

### 공개 정보 (PUBLIC)

**PROJECTS 배열** - 공개 필드:
```javascript
{
  id: 'lotto-master',
  name: 'LottoMaster',
  emoji: '🎰',
  description: '데이터 기반 로또 번호 추천 서비스',
  url: 'http://203.245.30.6:3001',
  port: 3001,              // 필요시 숨길 수 있음
  status: 'active',
  category: 'full-stack',
  tags: ['Next.js', 'TypeScript', 'Tailwind CSS'],
  version: '1.0.0',
  deployedAt: '2025-10-16',
  repository: null,        // 공개 저장소면 표시
  docs: null              // 공개 문서면 표시
}
```

**RELEASE_NOTES 배열** - 공개 필드:
```javascript
{
  id: 1,
  projectId: 'lotto-master',
  version: '1.0.0',
  date: '2025-10-16',
  type: 'major',
  title: 'LottoMaster 초기 릴리즈',
  changes: [
    {
      type: 'feature',
      description: '3가지 알고리즘 기반 번호 생성'
    }
  ]
  // developer 정보는 포함하지 않음 (내부 정보)
}
```

### 비공개 정보 (ADMIN)

**통계 정보**:
```javascript
{
  total: 1,
  active: 1,
  development: 0,
  byCategory: { ... },
  developers: 2,           // 개발자 수
  releases: 1
}
```

**개발자 정보**:
```javascript
{
  id: 'team-a',
  name: 'Team A',
  avatar: '👨‍💻',
  role: 'Full-stack',
  projects: [...],
  projectCount: 1
}
```

**시스템 상태**:
```javascript
{
  uptime: 12345,
  memory: { ... },
  containers: { ... },
  version: '2.1.0'
}
```

---

## 🔐 Phase 1 재설계 구현 태스크

### Task 1: 환경 설정 및 의존성 (30분)
**변경 없음** - 기존 계획 그대로

```bash
npm install express-session session-file-store bcrypt dotenv
```

---

### Task 2: 데이터 모델 (1시간)
**변경 없음** - 관리자 계정만 생성

```bash
# 관리자만 생성 (일반 사용자 계정 불필요)
node scripts/create-admin.js "SecurePassword123!"
```

---

### Task 3: 인증 미들웨어 (1.5시간)
**변경**: requireRole에서 viewer 제거, optionalAuth 추가

```javascript
// middleware/auth.js

/**
 * 선택적 인증 미들웨어
 * 로그인 시 사용자 정보 추가하지만, 미로그인도 허용
 */
function optionalAuth(req, res, next) {
  if (req.session && req.session.userId) {
    try {
      const user = findUserById(req.session.userId);
      if (user && user.active && user.role === 'admin') {
        req.user = {
          id: user.id,
          username: user.username,
          role: user.role
        };
      }
    } catch (error) {
      console.error('Optional auth error:', error);
    }
  }
  next();
}

/**
 * 관리자 전용 미들웨어
 * requireAuth + requireRole('admin')을 합친 것
 */
function requireAdmin(req, res, next) {
  if (!req.session || !req.session.userId) {
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({
        success: false,
        error: 'Admin authentication required'
      });
    }
    return res.redirect('/login');
  }

  const user = findUserById(req.session.userId);

  if (!user || !user.active || user.role !== 'admin') {
    if (req.path.startsWith('/api/')) {
      return res.status(403).json({
        success: false,
        error: 'Admin privileges required'
      });
    }
    return res.status(403).send(`
      <h1>접근 거부</h1>
      <p>관리자만 접근 가능합니다.</p>
      <a href="/">홈으로 돌아가기</a>
    `);
  }

  req.user = {
    id: user.id,
    username: user.username,
    role: user.role
  };

  next();
}

module.exports = {
  optionalAuth,
  requireAdmin
};
```

---

### Task 4: 로그인/로그아웃 API (2시간)
**변경 없음** - 관리자 로그인만 처리

---

### Task 5: 로그인 페이지 UI (2시간)
**변경**: 심플하게 변경 (일반 사용자용 아님)

```javascript
function renderLoginPage() {
  return `
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>관리자 로그인 - Dashboard</title>
  <style>
    /* 기존 스타일 */
  </style>
</head>
<body>
  <div class="login-container">
    <div class="login-header">
      <h1>🔐 관리자 로그인</h1>
      <p>Dashboard 관리 시스템</p>
    </div>

    <div class="error-message" id="errorMessage"></div>

    <form id="loginForm">
      <div class="form-group">
        <label for="username">사용자명</label>
        <input type="text" id="username" name="username"
               placeholder="admin" required autofocus>
      </div>

      <div class="form-group">
        <label for="password">비밀번호</label>
        <input type="password" id="password" name="password"
               placeholder="••••••••" required>
      </div>

      <button type="submit" class="login-button">로그인</button>

      <div style="text-align: center; margin-top: 20px;">
        <a href="/" style="color: #667eea; text-decoration: none;">
          ← 대시보드로 돌아가기
        </a>
      </div>
    </form>
  </div>

  <script>
    /* 기존 로그인 스크립트 */
  </script>
</body>
</html>
  `;
}
```

---

### Task 6: API 권한 적용 (1시간)
**대폭 간소화**: Public API는 인증 불필요, Admin API만 보호

```javascript
const { optionalAuth, requireAdmin } = require('./middleware/auth');

// ===== PUBLIC API (인증 불필요) =====

app.get('/', optionalAuth, (req, res) => {
  const isAdmin = req.user && req.user.role === 'admin';
  res.send(renderDashboard(isAdmin));
});

app.get('/api/projects', (req, res) => {
  // 인증 불필요 - 모두 공개
});

app.get('/api/projects/:id', (req, res) => {
  // 인증 불필요 - 모두 공개
});

app.get('/api/releases', (req, res) => {
  // 인증 불필요 - 모두 공개
});

// ===== ADMIN API (관리자만) =====

app.get('/api/stats', requireAdmin, (req, res) => {
  // 관리자 전용
});

app.get('/api/developers', requireAdmin, (req, res) => {
  // 관리자 전용
});

app.get('/api/system/status', requireAdmin, (req, res) => {
  // 관리자 전용
});
```

---

### Task 7: UI 역할별 표시 (2시간)
**변경**: 헤더와 사이드바만 조건부 표시

```javascript
function renderDashboard(isAdmin = false) {
  return `
<!DOCTYPE html>
<html lang="ko">
<head>
  <!-- ... -->
  <script>
    window.IS_ADMIN = ${isAdmin};
  </script>
</head>
<body>
  <!-- 헤더 -->
  <nav class="navbar">
    <div class="nav-left">
      <h1>🚀 Dashboard</h1>
    </div>
    <div class="nav-right">
      ${isAdmin ? `
        <div class="user-menu">
          <span class="admin-badge">👑 관리자</span>
          <button onclick="logout()" class="logout-btn">로그아웃</button>
        </div>
      ` : `
        <a href="/login" class="admin-login-link">🔐 관리자</a>
      `}
    </div>
  </nav>

  <!-- 사이드바 -->
  <aside class="sidebar">
    <div class="search-box">
      <input type="text" placeholder="🔍 프로젝트 검색...">
    </div>

    <!-- 공개 메뉴 (모두 볼 수 있음) -->
    <nav class="sidebar-menu">
      <div class="menu-section">
        <div class="menu-title">📦 프로젝트</div>
        <div class="menu-item active" onclick="showView('all')">
          <span>전체 프로젝트</span>
          <span class="badge">${stats.total}</span>
        </div>
        <div class="menu-item" onclick="showView('active')">
          <span>운영중</span>
          <span class="badge">${stats.active}</span>
        </div>
        <div class="menu-item" onclick="showView('development')">
          <span>개발중</span>
          <span class="badge">${stats.development}</span>
        </div>
      </div>

      <div class="menu-section">
        <div class="menu-title">📁 카테고리</div>
        <div class="menu-item" onclick="filterCategory('full-stack')">
          <span>Full-stack</span>
        </div>
        <div class="menu-item" onclick="filterCategory('frontend')">
          <span>Frontend</span>
        </div>
        <div class="menu-item" onclick="filterCategory('backend')">
          <span>Backend</span>
        </div>
        <div class="menu-item" onclick="filterCategory('tools')">
          <span>Tools</span>
        </div>
      </div>

      <div class="menu-section">
        <div class="menu-title">📝 릴리즈 노트</div>
        <div class="menu-item" onclick="showView('releases')">
          <span>전체 릴리즈</span>
        </div>
        <div class="menu-item" onclick="showView('timeline')">
          <span>타임라인</span>
        </div>
      </div>

      <!-- 관리자 전용 메뉴 (조건부 표시) -->
      ${isAdmin ? `
      <div class="menu-section admin-section">
        <div class="menu-title">⭐ 관리자 전용</div>
        <div class="menu-item" onclick="showAdminView('stats')">
          <span class="menu-icon">📊</span>
          <span>통계</span>
        </div>
        <div class="menu-item" onclick="showAdminView('developers')">
          <span class="menu-icon">👥</span>
          <span>개발자 정보</span>
        </div>
        <div class="menu-item" onclick="showAdminView('system')">
          <span class="menu-icon">⚙️</span>
          <span>시스템 상태</span>
        </div>
      </div>
      ` : ''}
    </nav>
  </aside>

  <!-- 메인 콘텐츠 -->
  <main class="main-content">
    <!-- 프로젝트 카드 등 -->
  </main>

  <script>
    // 관리자 뷰 표시 (API 호출)
    async function showAdminView(view) {
      if (!window.IS_ADMIN) {
        alert('관리자만 접근 가능합니다.');
        return;
      }

      let data;
      switch(view) {
        case 'stats':
          data = await fetch('/api/stats').then(r => r.json());
          renderStatsView(data.data);
          break;
        case 'developers':
          data = await fetch('/api/developers').then(r => r.json());
          renderDevelopersView(data.data);
          break;
        case 'system':
          data = await fetch('/api/system/status').then(r => r.json());
          renderSystemView(data.data);
          break;
      }
    }

    // 로그아웃
    async function logout() {
      await fetch('/api/logout', { method: 'POST' });
      window.location.reload();
    }
  </script>
</body>
</html>
  `;
}
```

---

### Task 8: 테스트 및 검증 (1.5시간)
**간소화**: Public API 테스트 추가, Viewer 테스트 제거

```bash
# Public API 테스트 (인증 불필요)
curl http://localhost:3000/api/projects
curl http://localhost:3000/api/releases

# Admin API 테스트 (미인증 - 401 예상)
curl http://localhost:3000/api/stats

# 관리자 로그인
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"password"}' \
  -c cookies.txt

# Admin API 테스트 (인증됨 - 200 예상)
curl http://localhost:3000/api/stats -b cookies.txt
curl http://localhost:3000/api/developers -b cookies.txt
curl http://localhost:3000/api/system/status -b cookies.txt
```

---

### Task 9: 문서 업데이트 (1시간)
**변경 없음**

---

### Task 10: 배포 (1시간)
**변경 없음**

---

## 📊 재설계 완료 체크리스트

### 기능 체크리스트
- [ ] Public API 인증 제거 (프로젝트, 릴리즈)
- [ ] Admin API 인증 적용 (통계, 개발자, 시스템)
- [ ] optionalAuth 미들웨어 구현
- [ ] requireAdmin 미들웨어 구현
- [ ] 헤더에 간단한 관리자 로그인 링크
- [ ] 사이드바에 관리자 전용 섹션 (조건부)
- [ ] 관리자 로그인 페이지
- [ ] 관리자 로그아웃 기능

### UI 체크리스트
- [ ] 일반 사용자도 모든 프로젝트 볼 수 있음
- [ ] 일반 사용자도 릴리즈 노트 볼 수 있음
- [ ] 관리자 로그인 링크 (헤더 우측)
- [ ] 관리자 전용 섹션은 로그인 시에만 표시
- [ ] 로그아웃 시 새로고침하여 일반 뷰로 전환

### 보안 체크리스트
- [ ] Public API는 인증 불필요
- [ ] Admin API는 반드시 인증 필요
- [ ] 비밀번호 bcrypt 해싱
- [ ] 세션 보안 설정
- [ ] Rate limiting (로그인)

---

## 🎯 핵심 변경 사항 요약

### Before (잘못된 설계)
```
❌ PUBLIC: 아무것도 못 봄
❌ VIEWER: 프로젝트만 봄 (로그인 필요)
✅ ADMIN: 모든 것 봄
```

### After (올바른 설계)
```
✅ PUBLIC: 프로젝트, 릴리즈 모두 봄 (로그인 불필요)
✅ ADMIN: PUBLIC + 통계, 개발자 정보, 시스템 상태
```

### 코드 변경 요약
```diff
- 3개 역할 (PUBLIC, VIEWER, ADMIN)
+ 2개 역할 (PUBLIC, ADMIN)

- requireAuth, requireRole 미들웨어
+ optionalAuth, requireAdmin 미들웨어

- 프로젝트 API에 requireAuth
+ 프로젝트 API 인증 불필요

- Viewer 계정 생성 필요
+ 관리자 계정만 생성

- 복잡한 역할 체크
+ 간단한 isAdmin 체크
```

---

## 📅 재설계 타임라인

| Task | 변경 전 | 변경 후 | 절감 |
|------|--------|--------|------|
| Task 1 | 30분 | 30분 | - |
| Task 2 | 1시간 | 1시간 | - |
| Task 3 | 2시간 | 1.5시간 | -30분 |
| Task 4 | 2시간 | 2시간 | - |
| Task 5 | 2시간 | 2시간 | - |
| Task 6 | 2시간 | 1시간 | -1시간 |
| Task 7 | 3시간 | 2시간 | -1시간 |
| Task 8 | 2시간 | 1.5시간 | -30분 |
| Task 9 | 1시간 | 1시간 | - |
| Task 10 | 1시간 | 1시간 | - |
| **총합** | **16.5시간** | **13.5시간** | **-3시간** |

**재설계로 3시간 절감! (약 18% 감소)**

---

**문서 버전**: 2.0 (재설계)
**작성일**: 2025-10-16
**상태**: 재설계 완료
**담당**: DevOps Team
