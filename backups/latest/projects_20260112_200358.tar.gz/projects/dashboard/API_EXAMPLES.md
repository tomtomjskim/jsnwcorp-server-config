# Dashboard v2.0 - API 사용 예시

## 📋 목차
- [기본 사용법](#기본-사용법)
- [프로젝트 API](#프로젝트-api)
- [개발자 API](#개발자-api)
- [릴리즈 API](#릴리즈-api)
- [통계 API](#통계-api)
- [고급 사용법](#고급-사용법)
- [에러 처리](#에러-처리)

## 기본 사용법

### Base URL
```
http://203.245.30.6
```

### 응답 형식
모든 API는 JSON 형식으로 응답합니다:

```json
{
  "success": true,
  "data": { ... },
  "count": 1,
  "total": 10
}
```

## 프로젝트 API

### GET /api/projects

모든 프로젝트 또는 필터링된 프로젝트 목록을 가져옵니다.

#### 예시 1: 모든 프로젝트 조회

**요청**:
```bash
curl http://203.245.30.6/api/projects
```

**응답**:
```json
{
  "success": true,
  "data": [
    {
      "id": "lotto-master",
      "name": "LottoMaster",
      "emoji": "🎰",
      "description": "데이터 기반 로또 번호 추천 서비스",
      "url": "http://203.245.30.6:3001",
      "port": 3001,
      "status": "active",
      "category": "full-stack",
      "tags": ["Next.js", "TypeScript", "Tailwind CSS"],
      "developer": "team-a",
      "version": "1.0.0",
      "deployedAt": "2025-10-16",
      "repository": null,
      "docs": null
    }
  ],
  "count": 1,
  "total": 1
}
```

#### 예시 2: 운영중인 프로젝트만 조회

**요청**:
```bash
curl "http://203.245.30.6/api/projects?status=active"
```

**응답**:
```json
{
  "success": true,
  "data": [
    {
      "id": "lotto-master",
      "status": "active",
      ...
    }
  ],
  "count": 1,
  "total": 1
}
```

#### 예시 3: Full-stack 프로젝트만 조회

**요청**:
```bash
curl "http://203.245.30.6/api/projects?category=full-stack"
```

#### 예시 4: Team A의 프로젝트 조회

**요청**:
```bash
curl "http://203.245.30.6/api/projects?developer=team-a"
```

#### 예시 5: 프로젝트 검색

**요청**:
```bash
# Next.js를 사용하는 프로젝트 검색
curl "http://203.245.30.6/api/projects?search=next.js"

# "로또"가 포함된 프로젝트 검색
curl "http://203.245.30.6/api/projects?search=로또"

# "데이터"가 포함된 프로젝트 검색
curl "http://203.245.30.6/api/projects?search=데이터"
```

#### 예시 6: 여러 필터 조합

**요청**:
```bash
# 운영중인 Full-stack 프로젝트
curl "http://203.245.30.6/api/projects?status=active&category=full-stack"

# Team A의 개발중인 프로젝트
curl "http://203.245.30.6/api/projects?status=development&developer=team-a"

# TypeScript를 사용하는 운영중인 프로젝트
curl "http://203.245.30.6/api/projects?status=active&search=typescript"
```

### GET /api/projects/:id

특정 프로젝트의 상세 정보를 가져옵니다 (릴리즈 노트 포함).

#### 예시 1: LottoMaster 상세 정보

**요청**:
```bash
curl http://203.245.30.6/api/projects/lotto-master
```

**응답**:
```json
{
  "success": true,
  "data": {
    "project": {
      "id": "lotto-master",
      "name": "LottoMaster",
      "emoji": "🎰",
      "description": "데이터 기반 로또 번호 추천 서비스",
      "url": "http://203.245.30.6:3001",
      "port": 3001,
      "status": "active",
      "category": "full-stack",
      "tags": ["Next.js", "TypeScript", "Tailwind CSS"],
      "developer": "team-a",
      "version": "1.0.0",
      "deployedAt": "2025-10-16",
      "repository": null,
      "docs": null
    },
    "releases": [
      {
        "id": 1,
        "projectId": "lotto-master",
        "version": "1.0.0",
        "date": "2025-10-16",
        "type": "major",
        "developer": "team-a",
        "title": "LottoMaster 초기 릴리즈",
        "changes": [
          {
            "type": "feature",
            "description": "3가지 알고리즘 기반 번호 생성 (랜덤, 빈도, 패턴)"
          },
          {
            "type": "feature",
            "description": "당첨 이력 조회 기능"
          },
          {
            "type": "tech",
            "description": "Next.js 15 + TypeScript 기반 구축"
          }
        ]
      }
    ]
  }
}
```

#### 예시 2: 존재하지 않는 프로젝트

**요청**:
```bash
curl http://203.245.30.6/api/projects/non-existent
```

**응답**:
```json
{
  "success": false,
  "error": "Project not found"
}
```

## 개발자 API

### GET /api/developers

모든 개발자와 담당 프로젝트 목록을 가져옵니다.

#### 예시 1: 개발자 목록 조회

**요청**:
```bash
curl http://203.245.30.6/api/developers
```

**응답**:
```json
{
  "success": true,
  "data": [
    {
      "id": "team-a",
      "name": "Team A",
      "avatar": "👨‍💻",
      "role": "Full-stack",
      "color": "#667eea",
      "projects": [
        {
          "id": "lotto-master",
          "name": "LottoMaster",
          ...
        }
      ],
      "projectCount": 1
    },
    {
      "id": "team-b",
      "name": "Team B",
      "avatar": "👩‍💻",
      "role": "Frontend",
      "color": "#f093fb",
      "projects": [],
      "projectCount": 0
    }
  ],
  "count": 2
}
```

## 릴리즈 API

### GET /api/releases

릴리즈 노트 목록을 가져옵니다.

#### 예시 1: 모든 릴리즈 조회

**요청**:
```bash
curl http://203.245.30.6/api/releases
```

**응답**:
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "projectId": "lotto-master",
      "version": "1.0.0",
      "date": "2025-10-16",
      "type": "major",
      "developer": "team-a",
      "title": "LottoMaster 초기 릴리즈",
      "changes": [
        {
          "type": "feature",
          "description": "3가지 알고리즘 기반 번호 생성 (랜덤, 빈도, 패턴)"
        },
        {
          "type": "feature",
          "description": "당첨 이력 조회 기능"
        },
        {
          "type": "feature",
          "description": "번호별 출현 빈도 통계"
        },
        {
          "type": "tech",
          "description": "Next.js 15 + TypeScript 기반 구축"
        },
        {
          "type": "tech",
          "description": "Docker 멀티스테이지 빌드 최적화"
        }
      ]
    }
  ],
  "count": 1
}
```

#### 예시 2: 특정 프로젝트의 릴리즈만 조회

**요청**:
```bash
curl "http://203.245.30.6/api/releases?projectId=lotto-master"
```

#### 예시 3: Major 릴리즈만 조회

**요청**:
```bash
curl "http://203.245.30.6/api/releases?type=major"
```

#### 예시 4: Minor 릴리즈만 조회

**요청**:
```bash
curl "http://203.245.30.6/api/releases?type=minor"
```

#### 예시 5: 특정 프로젝트의 Major 릴리즈

**요청**:
```bash
curl "http://203.245.30.6/api/releases?projectId=lotto-master&type=major"
```

## 통계 API

### GET /api/stats

전체 통계 정보를 가져옵니다.

#### 예시 1: 통계 조회

**요청**:
```bash
curl http://203.245.30.6/api/stats
```

**응답**:
```json
{
  "success": true,
  "data": {
    "total": 1,
    "active": 1,
    "development": 0,
    "byCategory": {
      "full-stack": 1,
      "frontend": 0,
      "backend": 0,
      "tools": 0
    },
    "developers": 2,
    "releases": 1,
    "categories": [
      "full-stack",
      "frontend",
      "backend",
      "tools"
    ]
  }
}
```

**필드 설명**:
- `total`: 전체 프로젝트 수
- `active`: 운영중인 프로젝트 수
- `development`: 개발중인 프로젝트 수
- `byCategory`: 카테고리별 프로젝트 수
- `developers`: 등록된 개발자/팀 수
- `releases`: 전체 릴리즈 수
- `categories`: 사용 가능한 카테고리 목록

### GET /api/info

대시보드 정보를 가져옵니다.

#### 예시 1: 대시보드 정보

**요청**:
```bash
curl http://203.245.30.6/api/info
```

**응답**:
```json
{
  "success": true,
  "data": {
    "name": "Project Dashboard",
    "version": "2.0.0",
    "description": "Multi-project management dashboard with sidebar navigation and developer notes",
    "environment": "production",
    "stats": {
      "total": 1,
      "active": 1,
      "development": 0
    }
  }
}
```

## 고급 사용법

### JavaScript/TypeScript에서 사용

#### 예시 1: Fetch API 사용

```javascript
// 모든 프로젝트 가져오기
async function getProjects() {
  const response = await fetch('http://203.245.30.6/api/projects');
  const data = await response.json();

  if (data.success) {
    console.log('프로젝트 목록:', data.data);
    console.log('총 개수:', data.count);
  }
}

// 운영중인 프로젝트만 가져오기
async function getActiveProjects() {
  const response = await fetch('http://203.245.30.6/api/projects?status=active');
  const data = await response.json();
  return data.data;
}

// 특정 프로젝트 상세 정보
async function getProjectDetails(projectId) {
  const response = await fetch(`http://203.245.30.6/api/projects/${projectId}`);
  const data = await response.json();

  if (data.success) {
    console.log('프로젝트:', data.data.project);
    console.log('릴리즈 노트:', data.data.releases);
  }
}
```

#### 예시 2: Axios 사용

```javascript
import axios from 'axios';

const API_BASE = 'http://203.245.30.6/api';

// 프로젝트 검색
async function searchProjects(query) {
  try {
    const response = await axios.get(`${API_BASE}/projects`, {
      params: { search: query }
    });
    return response.data.data;
  } catch (error) {
    console.error('검색 실패:', error);
    return [];
  }
}

// 개발자별 프로젝트
async function getProjectsByDeveloper(developerId) {
  const response = await axios.get(`${API_BASE}/projects`, {
    params: { developer: developerId }
  });
  return response.data.data;
}

// 통계 조회
async function getStats() {
  const response = await axios.get(`${API_BASE}/stats`);
  return response.data.data;
}
```

### Python에서 사용

#### 예시 1: requests 라이브러리

```python
import requests

API_BASE = 'http://203.245.30.6/api'

# 모든 프로젝트
def get_projects():
    response = requests.get(f'{API_BASE}/projects')
    data = response.json()
    if data['success']:
        return data['data']
    return []

# 필터링된 프로젝트
def get_projects_by_status(status):
    response = requests.get(f'{API_BASE}/projects', params={'status': status})
    return response.json()['data']

# 프로젝트 검색
def search_projects(query):
    response = requests.get(f'{API_BASE}/projects', params={'search': query})
    return response.json()['data']

# 통계
def get_stats():
    response = requests.get(f'{API_BASE}/stats')
    return response.json()['data']

# 사용 예시
if __name__ == '__main__':
    # 모든 프로젝트 출력
    projects = get_projects()
    for project in projects:
        print(f"{project['name']} - {project['status']}")

    # 통계 출력
    stats = get_stats()
    print(f"Total projects: {stats['total']}")
    print(f"Active: {stats['active']}")
```

### Shell 스크립트에서 사용

#### 예시 1: 프로젝트 목록 가져오기

```bash
#!/bin/bash

# 모든 프로젝트의 이름과 URL 출력
curl -s http://203.245.30.6/api/projects | \
  python3 -c "import sys, json; data = json.load(sys.stdin); \
  [print(f\"{p['name']}: {p['url']}\") for p in data['data']]"
```

#### 예시 2: 운영중인 프로젝트 수 확인

```bash
#!/bin/bash

ACTIVE_COUNT=$(curl -s "http://203.245.30.6/api/projects?status=active" | \
  python3 -c "import sys, json; print(json.load(sys.stdin)['count'])")

echo "운영중인 프로젝트: $ACTIVE_COUNT개"
```

#### 예시 3: 프로젝트 상태 모니터링

```bash
#!/bin/bash

# 모든 프로젝트의 URL 확인
curl -s http://203.245.30.6/api/projects | \
  python3 -c "
import sys, json, requests

data = json.load(sys.stdin)
for project in data['data']:
    try:
        response = requests.get(project['url'], timeout=5)
        status = '✅' if response.status_code == 200 else '❌'
    except:
        status = '❌'
    print(f\"{status} {project['name']}: {project['url']}\")
"
```

## 에러 처리

### 일반적인 에러 응답

#### 404 Not Found
```json
{
  "success": false,
  "error": "Project not found"
}
```

#### 400 Bad Request
```json
{
  "success": false,
  "error": "Invalid parameter"
}
```

### JavaScript 에러 처리 예시

```javascript
async function getProjectSafely(projectId) {
  try {
    const response = await fetch(`http://203.245.30.6/api/projects/${projectId}`);
    const data = await response.json();

    if (!data.success) {
      console.error('에러:', data.error);
      return null;
    }

    return data.data;
  } catch (error) {
    console.error('네트워크 에러:', error);
    return null;
  }
}
```

### Python 에러 처리 예시

```python
import requests

def get_project_safely(project_id):
    try:
        response = requests.get(
            f'http://203.245.30.6/api/projects/{project_id}',
            timeout=10
        )
        response.raise_for_status()
        data = response.json()

        if not data['success']:
            print(f"에러: {data['error']}")
            return None

        return data['data']
    except requests.exceptions.RequestException as e:
        print(f"요청 실패: {e}")
        return None
```

## 성능 최적화

### 캐싱 활용

```javascript
// 간단한 메모리 캐시
const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5분

async function getCachedProjects() {
  const now = Date.now();
  const cached = cache.get('projects');

  if (cached && (now - cached.timestamp < CACHE_TTL)) {
    return cached.data;
  }

  const response = await fetch('http://203.245.30.6/api/projects');
  const data = await response.json();

  cache.set('projects', {
    data: data.data,
    timestamp: now
  });

  return data.data;
}
```

### 병렬 요청

```javascript
// 여러 API를 동시에 호출
async function getAllData() {
  const [projects, developers, stats] = await Promise.all([
    fetch('http://203.245.30.6/api/projects').then(r => r.json()),
    fetch('http://203.245.30.6/api/developers').then(r => r.json()),
    fetch('http://203.245.30.6/api/stats').then(r => r.json())
  ]);

  return {
    projects: projects.data,
    developers: developers.data,
    stats: stats.data
  };
}
```

## 실전 사용 예시

### 대시보드 위젯 만들기

```html
<!DOCTYPE html>
<html>
<head>
  <title>프로젝트 현황</title>
  <style>
    .widget { padding: 20px; max-width: 400px; }
    .stat { margin: 10px 0; }
    .project { border: 1px solid #ddd; padding: 10px; margin: 10px 0; }
  </style>
</head>
<body>
  <div class="widget">
    <h2>프로젝트 현황</h2>
    <div id="stats"></div>
    <div id="projects"></div>
  </div>

  <script>
    async function loadDashboard() {
      // 통계 로드
      const statsRes = await fetch('http://203.245.30.6/api/stats');
      const stats = await statsRes.json();

      document.getElementById('stats').innerHTML = `
        <div class="stat">전체: ${stats.data.total}개</div>
        <div class="stat">운영중: ${stats.data.active}개</div>
        <div class="stat">개발중: ${stats.data.development}개</div>
      `;

      // 프로젝트 로드
      const projectsRes = await fetch('http://203.245.30.6/api/projects');
      const projects = await projectsRes.json();

      const projectsHTML = projects.data.map(p => `
        <div class="project">
          <h3>${p.emoji} ${p.name}</h3>
          <p>${p.description}</p>
          <a href="${p.url}" target="_blank">방문하기</a>
        </div>
      `).join('');

      document.getElementById('projects').innerHTML = projectsHTML;
    }

    loadDashboard();
  </script>
</body>
</html>
```

### Slack 봇 통합

```python
import requests
from slack_sdk import WebClient

slack_client = WebClient(token="YOUR_SLACK_TOKEN")

def post_project_status():
    # 통계 가져오기
    stats_res = requests.get('http://203.245.30.6/api/stats')
    stats = stats_res.json()['data']

    # 프로젝트 가져오기
    projects_res = requests.get('http://203.245.30.6/api/projects?status=active')
    projects = projects_res.json()['data']

    # Slack 메시지 작성
    message = f"""
📊 *프로젝트 현황*
• 전체: {stats['total']}개
• 운영중: {stats['active']}개
• 개발중: {stats['development']}개

🚀 *운영중인 프로젝트*
"""

    for project in projects:
        message += f"\n• {project['emoji']} {project['name']}: {project['url']}"

    # Slack에 전송
    slack_client.chat_postMessage(
        channel="#dev-status",
        text=message
    )

# 매일 아침 9시에 실행 (cron 등으로 스케줄링)
if __name__ == '__main__':
    post_project_status()
```

---

**더 많은 예시가 필요하신가요?** README.md의 전체 문서를 참조하세요.
