/**
 * Authentication Middleware
 * 인증 및 권한 검증 미들웨어
 */

const userManager = require('../utils/user-manager');

/**
 * optionalAuth: 세션이 있으면 사용자 정보를 req.user에 설정
 * 세션이 없어도 요청은 계속 진행 (Public 접근 허용)
 */
function optionalAuth(req, res, next) {
  try {
    // 세션에 userId가 있는지 확인
    if (req.session && req.session.userId) {
      const user = userManager.findUserById(req.session.userId);

      // 사용자가 존재하고 활성화되어 있으며 admin 권한이 있는 경우
      if (user && user.active && user.role === 'admin') {
        req.user = {
          id: user.id,
          username: user.username,
          role: user.role
        };
      } else {
        // 유효하지 않은 세션이면 제거
        req.session.destroy();
      }
    }

    next();
  } catch (error) {
    console.error('optionalAuth error:', error);
    next();
  }
}

/**
 * requireAdmin: 관리자 권한 필수
 * 인증되지 않은 경우 401, 권한이 없는 경우 403 반환
 */
function requireAdmin(req, res, next) {
  try {
    // 세션이 없는 경우
    if (!req.session || !req.session.userId) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required',
        message: 'Please login to access this resource'
      });
    }

    // 사용자 확인
    const user = userManager.findUserById(req.session.userId);

    if (!user) {
      // 사용자가 없으면 세션 제거
      req.session.destroy();
      return res.status(401).json({
        success: false,
        error: 'Invalid session',
        message: 'User not found'
      });
    }

    // 비활성화된 사용자
    if (!user.active) {
      req.session.destroy();
      return res.status(403).json({
        success: false,
        error: 'Account inactive',
        message: 'Your account has been deactivated'
      });
    }

    // 관리자 권한 확인
    if (user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions',
        message: 'Admin access required'
      });
    }

    // req.user 설정
    req.user = {
      id: user.id,
      username: user.username,
      role: user.role
    };

    next();
  } catch (error) {
    console.error('requireAdmin error:', error);
    return res.status(500).json({
      success: false,
      error: 'Authentication error',
      message: 'An error occurred during authentication'
    });
  }
}

/**
 * checkAuth: 현재 인증 상태 확인 (API용)
 */
function checkAuth(req, res) {
  if (req.user) {
    return res.json({
      success: true,
      authenticated: true,
      user: {
        id: req.user.id,
        username: req.user.username,
        role: req.user.role
      }
    });
  } else {
    return res.json({
      success: true,
      authenticated: false,
      user: null
    });
  }
}

module.exports = {
  optionalAuth,
  requireAdmin,
  checkAuth
};
