import { Sun, Moon, Maximize, Minimize, RefreshCw, Settings, Bookmark, Heart } from 'lucide-react';

interface ControlPanelProps {
  theme: 'light' | 'dark';
  isFullscreen: boolean;
  onThemeToggle: () => void;
  onFullscreenToggle: () => void;
  onRefresh: () => void;
  onSettingsClick: () => void;
  onBookmarkClick: () => void;
  onLikedClick: () => void;
  isRefreshing?: boolean;
  isVisible?: boolean;
}

export function ControlPanel({
  theme,
  isFullscreen,
  onThemeToggle,
  onFullscreenToggle,
  onRefresh,
  onSettingsClick,
  onBookmarkClick,
  onLikedClick,
  isRefreshing = false,
  isVisible = true,
}: ControlPanelProps) {
  return (
    <div
      className={`fixed bottom-8 left-1/2 -translate-x-1/2 bg-white dark:bg-gray-800 rounded-full shadow-lg px-6 py-3 flex items-center gap-4 border border-gray-200 dark:border-gray-700 transition-all duration-500 ease-in-out ${
        isVisible ? 'translate-y-0 opacity-100' : 'translate-y-24 opacity-0 pointer-events-none'
      }`}
    >
      {/* Settings Button */}
      <button
        onClick={onSettingsClick}
        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title="설정"
        aria-label="설정"
      >
        <Settings size={20} />
      </button>

      {/* Bookmark Button */}
      <button
        onClick={onBookmarkClick}
        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title="내 북마크"
        aria-label="내 북마크"
      >
        <Bookmark size={20} className="text-yellow-400" />
      </button>

      {/* Liked Quotes Button */}
      <button
        onClick={onLikedClick}
        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title="좋아요한 명언"
        aria-label="좋아요한 명언"
      >
        <Heart size={20} className="text-red-500" fill="currentColor" />
      </button>

      {/* Refresh Button */}
      <button
        onClick={onRefresh}
        disabled={isRefreshing}
        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
        title="다음 명언"
        aria-label="다음 명언"
      >
        <RefreshCw
          size={20}
          className={isRefreshing ? 'animate-spin' : ''}
        />
      </button>

      {/* Theme Toggle */}
      <button
        onClick={onThemeToggle}
        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title={theme === 'light' ? '다크 모드' : '라이트 모드'}
        aria-label="테마 전환"
      >
        {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
      </button>

      {/* Fullscreen Toggle */}
      <button
        onClick={onFullscreenToggle}
        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
        title={isFullscreen ? '전체화면 해제' : '전체화면'}
        aria-label="전체화면 전환"
      >
        {isFullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
      </button>
    </div>
  );
}
