"""
Security module for AI chatbot
Implements input validation, output sanitization, and rate limiting
"""

import re
import time
from typing import Dict, List
from cachetools import TTLCache

# Blocked patterns for security
BLOCKED_PATTERNS = [
    r'password',
    r'secret',
    r'token',
    r'api[_\-]?key',
    r'credential',
    r'private[_\-]?key',
    r'\.env',
    r'pg_password',
    r'redis_password',
    r'database.*password',
]

# Rate limiting: 10 requests per minute per IP
RATE_LIMIT = 10
RATE_WINDOW = 60  # seconds

# In-memory rate limit storage (TTL cache)
rate_limit_cache: Dict[str, List[float]] = TTLCache(maxsize=1000, ttl=RATE_WINDOW)


def is_safe_query(question: str) -> bool:
    """
    Check if the question contains any blocked patterns

    Args:
        question: User's question

    Returns:
        True if safe, False if contains blocked patterns
    """
    question_lower = question.lower()

    for pattern in BLOCKED_PATTERNS:
        if re.search(pattern, question_lower):
            return False

    return True


def sanitize_response(response: str) -> str:
    """
    Remove sensitive information from AI response

    Args:
        response: AI generated response

    Returns:
        Sanitized response
    """
    # Mask password patterns
    response = re.sub(
        r'password[\s:=]+\S+',
        'password: ****',
        response,
        flags=re.IGNORECASE
    )

    # Mask API key patterns
    response = re.sub(
        r'(api[_\-]?key)[\s:=]+\S+',
        r'\1: ****',
        response,
        flags=re.IGNORECASE
    )

    # Mask secret patterns
    response = re.sub(
        r'(secret)[\s:=]+\S+',
        r'\1: ****',
        response,
        flags=re.IGNORECASE
    )

    return response


def check_rate_limit(user_ip: str) -> bool:
    """
    Check if user has exceeded rate limit

    Args:
        user_ip: User's IP address

    Returns:
        True if allowed, False if rate limit exceeded
    """
    now = time.time()

    if user_ip not in rate_limit_cache:
        rate_limit_cache[user_ip] = []

    # Filter out old requests
    rate_limit_cache[user_ip] = [
        req_time for req_time in rate_limit_cache[user_ip]
        if now - req_time < RATE_WINDOW
    ]

    # Check limit
    if len(rate_limit_cache[user_ip]) >= RATE_LIMIT:
        return False

    # Add current request
    rate_limit_cache[user_ip].append(now)
    return True


def validate_question_length(question: str, max_length: int = 500) -> bool:
    """
    Validate question length

    Args:
        question: User's question
        max_length: Maximum allowed length

    Returns:
        True if valid, False if too long
    """
    return len(question.strip()) <= max_length


def get_blocked_reason(question: str) -> str:
    """
    Get reason why question was blocked

    Args:
        question: User's question

    Returns:
        Reason string
    """
    question_lower = question.lower()

    for pattern in BLOCKED_PATTERNS:
        if re.search(pattern, question_lower):
            return f"질문에 보안상 허용되지 않는 패턴이 포함되어 있습니다."

    return "알 수 없는 이유로 차단되었습니다."
