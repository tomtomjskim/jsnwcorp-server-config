"""
Quick Response System - Rule-based instant answers
Provides fast responses (<100ms) for common questions
"""

import re
from typing import Optional, Dict, Any
from db_search import get_db


# 규칙 기반 응답 패턴
QUICK_PATTERNS = {
    # 인사
    r"^(안녕|hi|hello|하이|ㅎㅇ|hey)$": {
        "answer": "안녕하세요! 프로젝트 정보에 대해 무엇이든 물어보세요. 😊\n\n예시 질문:\n• 현재 운영 중인 프로젝트는?\n• LottoMaster 정보 알려줘\n• 헬스 체크 상태는?",
        "type": "static"
    },

    # 감사
    r"(고마워|감사|thank)": {
        "answer": "도움이 되어 기쁩니다! 더 궁금한 점이 있으면 언제든 물어보세요.",
        "type": "static"
    },

    # 프로젝트 목록
    r"(프로젝트|서비스).{0,10}(목록|뭐|있|어떤|몇|개|알려)": {
        "type": "db_template",
        "query_func": "get_all_active_projects",
        "template": "현재 **{count}개** 프로젝트가 운영 중입니다:\n\n{project_list}\n\n자세한 정보가 필요하시면 프로젝트 이름을 말씀해주세요!"
    },

    # 헬스 체크 상태
    r"(헬스|health|상태|정상|작동|running)": {
        "type": "db_template",
        "query_func": "get_health_summary",
        "template": "{status_message}\n\n상세 상태:\n{details}"
    },

    # 특정 프로젝트 정보
    r"(lotto|로또|LottoMaster).{0,30}(정보|뭐|어떤|알려|설명|소개)": {
        "type": "db_template",
        "query_func": "get_project_detail",
        "project_id": "lotto-master",
        "template": "**{display_name}**\n\n{description}\n\n📊 **상태**: {status}\n💻 **기술 스택**: {tech_stack}\n👨‍💻 **개발자**: {developer}\n🔗 **URL**: {url}\n💚 **헬스**: {health_status}"
    },

    r"(운세|fortune|오늘의 운세).{0,30}(정보|뭐|어떤|알려|설명|소개)": {
        "type": "db_template",
        "query_func": "get_project_detail",
        "project_id": "today-fortune",
        "template": "**{display_name}**\n\n{description}\n\n📊 **상태**: {status}\n💻 **기술 스택**: {tech_stack}\n👨‍💻 **개발자**: {developer}\n🔗 **URL**: {url}\n💚 **헬스**: {health_status}"
    },

    r"(dashboard|대시보드).{0,30}(정보|뭐|어떤|알려|설명|소개)": {
        "type": "db_template",
        "query_func": "get_project_detail",
        "project_id": "dashboard",
        "template": "**{display_name}**\n\n{description}\n\n📊 **상태**: {status}\n💻 **기술 스택**: {tech_stack}\n👨‍💻 **개발자**: {developer}\n🔗 **URL**: {url}\n💚 **헬스**: {health_status}"
    },

    r"(ai|챗봇|chatbot).{0,30}(정보|뭐|어떤|알려|설명|소개)": {
        "type": "db_template",
        "query_func": "get_project_detail",
        "project_id": "ai-chatbot",
        "template": "**{display_name}**\n\n{description}\n\n📊 **상태**: {status}\n💻 **기술 스택**: {tech_stack}\n👨‍💻 **개발자**: {developer}\n🔗 **URL**: {url}\n💚 **헬스**: {health_status}"
    },

    # 배포 정책 질문
    r"(배포|deploy).{0,30}(정책|policy|방법|절차|프로세스|승인)": {
        "answer": "**배포 정책**\n\n✅ **승인 필요**: 모든 배포는 사용자 명시적 승인 필요\n🔄 **빌드와 배포 분리**: 빌드만 하거나 배포만 가능\n⏰ **리소스 제약**: 1GB RAM 환경으로 빌드 시간 고려\n🔙 **롤백 가능**: 이전 이미지로 즉시 롤백 가능\n\n자세한 내용은 deployment-policy.md 문서를 참조하세요.",
        "type": "static"
    },

    # 도움말
    r"(도움|help|사용법|how)": {
        "answer": "무엇을 도와드릴까요? 다음과 같은 질문이 가능합니다:\n\n📋 **프로젝트 정보**\n• 현재 운영 중인 프로젝트는?\n• LottoMaster 정보 알려줘\n• 오늘의 운세 기술 스택은?\n\n💚 **시스템 상태**\n• 헬스 체크 상태는?\n• 서비스 정상 작동 중?\n\n📚 **기술 문서**\n• Analytics 시스템은 어떻게 작동하나요?\n• 배포 프로세스 알려줘",
        "type": "static"
    },

    # 기술 스택 질문
    r"(기술|tech|스택|stack).{0,30}(뭐|무엇|what|사용|쓰)": {
        "type": "db_template",
        "query_func": "get_all_tech_stacks",
        "template": "현재 사용 중인 주요 기술 스택:\n\n{tech_stacks}\n\n특정 프로젝트의 기술 스택이 궁금하시면 프로젝트 이름을 말씀해주세요!"
    },

    # 프로젝트 수 관련
    r"(몇|얼마나|how many).{0,20}(프로젝트|서비스|project)": {
        "type": "db_template",
        "query_func": "get_project_count",
        "template": "현재 총 **{total_count}개**의 프로젝트가 있으며, 그 중 **{active_count}개**가 활성 상태입니다."
    },

    # URL/접속 관련
    r"(주소|url|링크|접속|사이트).{0,30}(뭐|어디|what|where)": {
        "type": "db_template",
        "query_func": "get_all_urls",
        "template": "프로젝트 접속 주소:\n\n{url_list}\n\n직접 접속하시려면 위 URL을 사용하세요!"
    },

    # 개발자/팀 정보
    r"(개발자|developer|팀|team|누가|who).{0,30}(만들|개발|작업)": {
        "type": "db_template",
        "query_func": "get_developers",
        "template": "프로젝트 개발 팀 정보:\n\n{developer_info}"
    },

    # 최신 프로젝트
    r"(최신|최근|new|recent|latest).{0,20}(프로젝트|서비스)": {
        "answer": "최근 배포된 프로젝트:\n\n• **AI 챗봇** (2025-10-22): 하이브리드 RAG 시스템으로 업그레이드\n• **오늘의 운세** (2025-10-20): 사주팔자 기반 운세 서비스\n• **LottoMaster** (2025-10-15): AI 기반 로또 번호 생성기\n\n모든 프로젝트는 정상 운영 중입니다!",
        "type": "static"
    },
}


class QuickResponseSystem:
    """
    Quick response system for instant answers
    """

    def __init__(self):
        self.db = get_db()

    def match(self, question: str) -> Optional[Dict[str, Any]]:
        """
        Try to match question with quick response patterns

        Args:
            question: User's question

        Returns:
            Response dict or None if no match
        """
        question_clean = question.strip()

        for pattern, response_config in QUICK_PATTERNS.items():
            match = re.search(pattern, question_clean, re.IGNORECASE)
            if match:
                if response_config["type"] == "static":
                    return {
                        "success": True,
                        "answer": response_config["answer"],
                        "source": "quick_response",
                        "pattern": pattern,
                        "generation_time_ms": 0
                    }

                elif response_config["type"] == "db_template":
                    # Execute database query and fill template
                    data = self._execute_query(
                        response_config["query_func"],
                        response_config.get("project_id")
                    )

                    if data:
                        answer = response_config["template"].format(**data)
                        return {
                            "success": True,
                            "answer": answer,
                            "source": "db_template",
                            "pattern": pattern,
                            "generation_time_ms": 0
                        }

        return None

    def _execute_query(self, query_func: str, project_id: Optional[str] = None) -> Optional[Dict]:
        """
        Execute database query function

        Args:
            query_func: Name of query function
            project_id: Optional project ID

        Returns:
            Query result dict or None
        """
        try:
            if query_func == "get_all_active_projects":
                projects = self.db.get_project_info()
                if projects:
                    project_list = "\n".join([
                        f"• **{p.get('display_name')}** ({p.get('id')}): {p.get('description', 'N/A')[:80]}..."
                        for p in projects
                    ])
                    return {
                        "count": len(projects),
                        "project_list": project_list
                    }

            elif query_func == "get_health_summary":
                summary = self.db.get_analytics_summary()
                projects = self.db.get_project_info()

                healthy_count = sum(1 for p in projects if p.get('health_status') == 'healthy')
                total_count = len(projects)

                if healthy_count == total_count:
                    status_message = f"✅ 모든 서비스가 정상 작동 중입니다! ({healthy_count}/{total_count})"
                else:
                    status_message = f"⚠️ 일부 서비스에 문제가 있습니다. ({healthy_count}/{total_count} 정상)"

                details = "\n".join([
                    f"• {p.get('display_name')}: {'✅ ' if p.get('health_status') == 'healthy' else '⚠️ '}{p.get('health_status', 'unknown')}"
                    for p in projects
                ])

                return {
                    "status_message": status_message,
                    "details": details,
                    "healthy_count": healthy_count,
                    "total_count": total_count
                }

            elif query_func == "get_project_detail":
                if not project_id:
                    return None

                projects = self.db.get_project_info(project_id)
                if projects:
                    p = projects[0]
                    tech_stack = ", ".join(p.get('tags', [])) if p.get('tags') else "N/A"

                    return {
                        "display_name": p.get('display_name', 'N/A'),
                        "description": p.get('description', 'N/A'),
                        "status": p.get('status', 'N/A'),
                        "tech_stack": tech_stack,
                        "developer": p.get('developer', 'N/A'),
                        "url": p.get('url', 'N/A'),
                        "health_status": p.get('health_status', 'unknown')
                    }

            elif query_func == "get_all_tech_stacks":
                projects = self.db.get_project_info()
                if projects:
                    tech_list = []
                    for p in projects:
                        tags = p.get('tags', [])
                        if tags:
                            tech_list.append(f"• **{p.get('display_name')}**: {', '.join(tags)}")

                    return {
                        "tech_stacks": "\n".join(tech_list) if tech_list else "기술 스택 정보 없음"
                    }

            elif query_func == "get_project_count":
                projects = self.db.get_project_info()
                if projects:
                    total = len(projects)
                    active = sum(1 for p in projects if p.get('status') == 'active')

                    return {
                        "total_count": total,
                        "active_count": active
                    }

            elif query_func == "get_all_urls":
                projects = self.db.get_project_info()
                if projects:
                    url_list = []
                    for p in projects:
                        url = p.get('url', 'N/A')
                        name = p.get('display_name', 'N/A')
                        url_list.append(f"• **{name}**: {url}")

                    return {
                        "url_list": "\n".join(url_list)
                    }

            elif query_func == "get_developers":
                projects = self.db.get_project_info()
                if projects:
                    dev_dict = {}
                    for p in projects:
                        dev = p.get('developer', 'N/A')
                        name = p.get('display_name', 'N/A')
                        if dev not in dev_dict:
                            dev_dict[dev] = []
                        dev_dict[dev].append(name)

                    dev_info = []
                    for dev, proj_list in dev_dict.items():
                        dev_info.append(f"• **{dev}**: {', '.join(proj_list)}")

                    return {
                        "developer_info": "\n".join(dev_info)
                    }

        except Exception as e:
            print(f"Query execution error: {e}")
            return None

        return None


# Singleton instance
_quick_response_instance: Optional[QuickResponseSystem] = None


def get_quick_response() -> QuickResponseSystem:
    """
    Get or create QuickResponseSystem singleton

    Returns:
        QuickResponseSystem instance
    """
    global _quick_response_instance
    if _quick_response_instance is None:
        _quick_response_instance = QuickResponseSystem()
    return _quick_response_instance
