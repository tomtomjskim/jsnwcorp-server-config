"""
FastAPI chatbot server with RAG system
Provides /api/chatbot/ask endpoint for Dashboard integration
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional
import time

from rag_system import get_rag
from security import is_safe_query, check_rate_limit, validate_question_length, get_blocked_reason
from document_indexer import get_indexer
from db_search import get_db

# FastAPI app
app = FastAPI(
    title="AI Chatbot Service",
    description="Document-based RAG chatbot for project information",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request/Response models
class ChatRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=500, description="User's question")
    session_id: Optional[str] = Field(None, description="Optional session ID for tracking")


class ChatResponse(BaseModel):
    success: bool
    answer: str
    has_context: bool
    model: Optional[str] = None
    generation_time_ms: Optional[int] = None
    error: Optional[str] = None


class HealthResponse(BaseModel):
    status: str
    ollama_connected: bool
    documents_indexed: int
    database_connected: bool


# Startup event
@app.on_event("startup")
async def startup_event():
    """Initialize services on startup"""
    print("=" * 50)
    print("AI Chatbot Service Starting...")
    print("=" * 50)

    # Initialize document indexer
    indexer = get_indexer()
    print(f"✓ Documents indexed: {indexer.get_document_count()}")
    print(f"✓ Files: {', '.join(indexer.get_file_list()[:5])}")

    # Initialize database connection
    db = get_db()
    projects = db.get_project_info()
    print(f"✓ Database connected: {len(projects)} active projects")

    # Initialize RAG system
    rag = get_rag()
    ollama_healthy = await rag.health_check()
    print(f"✓ Ollama service: {'Connected' if ollama_healthy else 'Not connected (will retry)'}")

    print("=" * 50)
    print("AI Chatbot Service Ready!")
    print("=" * 50)


# API Routes
@app.get("/health", response_model=HealthResponse)
async def health_check():
    """
    Health check endpoint
    """
    rag = get_rag()
    indexer = get_indexer()
    db = get_db()

    ollama_healthy = await rag.health_check()

    # Check database
    db_healthy = False
    try:
        projects = db.get_project_info()
        db_healthy = isinstance(projects, list)
    except:
        pass

    return HealthResponse(
        status="healthy" if (ollama_healthy and db_healthy) else "degraded",
        ollama_connected=ollama_healthy,
        documents_indexed=indexer.get_document_count(),
        database_connected=db_healthy
    )


@app.post("/api/chatbot/ask", response_model=ChatResponse)
async def ask_question(request: ChatRequest, req: Request):
    """
    Ask a question to the chatbot

    Args:
        request: ChatRequest with question
        req: FastAPI Request object for IP tracking

    Returns:
        ChatResponse with answer
    """
    start_time = time.time()

    # Get client IP
    client_ip = req.client.host if req.client else "unknown"

    # Security checks
    # 1. Rate limiting
    if not check_rate_limit(client_ip):
        raise HTTPException(
            status_code=429,
            detail="요청 횟수 제한 초과 (분당 10회)"
        )

    # 2. Question length validation
    if not validate_question_length(request.question):
        raise HTTPException(
            status_code=400,
            detail="질문이 너무 깁니다 (최대 500자)"
        )

    # 3. Security pattern check
    if not is_safe_query(request.question):
        raise HTTPException(
            status_code=400,
            detail=get_blocked_reason(request.question)
        )

    # Process question with RAG
    rag = get_rag()

    try:
        result = await rag.ask(request.question, timeout=120)

        # Add processing time
        processing_time = int((time.time() - start_time) * 1000)

        return ChatResponse(
            success=result["success"],
            answer=result["answer"],
            has_context=result.get("has_context", False),
            model=result.get("model"),
            generation_time_ms=result.get("generation_time_ms", processing_time),
            error=result.get("error")
        )

    except Exception as e:
        print(f"Error processing question: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )


@app.get("/api/chatbot/stats")
async def get_stats():
    """
    Get chatbot statistics

    Returns:
        Statistics about indexed documents and database
    """
    indexer = get_indexer()
    db = get_db()

    return {
        "documents": {
            "total_sections": indexer.get_document_count(),
            "files": indexer.get_file_list()
        },
        "projects": db.get_analytics_summary()
    }


@app.get("/api/chatbot/quick-questions")
async def get_quick_questions():
    """
    Get suggested quick questions

    Returns:
        List of quick question suggestions
    """
    return {
        "questions": [
            {"id": "projects", "text": "현재 운영 중인 프로젝트는?", "emoji": "📊"},
            {"id": "lotto-info", "text": "LottoMaster 프로젝트 정보 알려줘", "emoji": "🎰"},
            {"id": "health", "text": "서비스 헬스 상태는?", "emoji": "💚"},
            {"id": "tech-stack", "text": "각 프로젝트의 기술 스택은?", "emoji": "🛠️"},
            {"id": "deployment", "text": "최근 배포 이력은?", "emoji": "🚀"},
        ]
    }


# Root endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "AI Chatbot API",
        "version": "1.0.0",
        "status": "running",
        "endpoints": {
            "health": "/health",
            "ask": "/api/chatbot/ask",
            "stats": "/api/chatbot/stats",
            "quick_questions": "/api/chatbot/quick-questions"
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )
