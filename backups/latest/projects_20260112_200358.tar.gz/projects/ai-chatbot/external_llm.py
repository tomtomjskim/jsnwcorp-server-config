"""
External LLM Integration - Groq API
Provides fast, high-quality AI responses using cloud APIs
"""

import os
import httpx
from typing import Dict, Any, Optional


# API Configuration
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"

# Model configuration
GROQ_MODEL = "llama-3.1-8b-instant"  # Fast, free
# Alternative: "llama-3.3-70b-versatile", "mixtral-8x7b-32768"

SYSTEM_PROMPT = """당신은 프로젝트 정보를 제공하는 AI 어시스턴트입니다.
제공된 컨텍스트를 활용하여 사용자의 질문에 정확하게 답변하세요.

답변 규칙:
1. 컨텍스트에 관련 정보가 있으면 반드시 활용하여 답변
2. 컨텍스트가 불완전하면 "제공된 정보에 따르면..."으로 시작
3. "문서에 해당 정보가 없습니다"는 컨텍스트가 정말 비어있거나 무관할 때만 사용
4. 비밀번호, API 키 등 보안 정보는 절대 제공 금지
5. 간결하고 명확하게 답변 (300자 이내)
6. 한국어로 답변, 마크다운 형식 사용 가능 (**, -, •)
7. 숫자나 목록은 정확하게 제공"""


class ExternalLLM:
    """
    External LLM (Groq API) integration
    """

    def __init__(self):
        self.api_key = GROQ_API_KEY
        self.api_url = GROQ_URL
        self.model = GROQ_MODEL
        self.enabled = bool(self.api_key)

    def is_enabled(self) -> bool:
        """
        Check if external LLM is enabled (API key exists)

        Returns:
            True if enabled, False otherwise
        """
        return self.enabled

    async def generate(
        self,
        question: str,
        context: str,
        timeout: int = 10
    ) -> Dict[str, Any]:
        """
        Generate answer using Groq API

        Args:
            question: User's question
            context: Retrieved context
            timeout: Request timeout in seconds

        Returns:
            Response dictionary
        """
        if not self.enabled:
            return {
                "success": False,
                "answer": "외부 AI API 키가 설정되지 않았습니다. 관리자에게 문의하세요.",
                "error": "GROQ_API_KEY not set",
                "source": "error"
            }

        try:
            # Prepare messages
            messages = [
                {
                    "role": "system",
                    "content": SYSTEM_PROMPT
                },
                {
                    "role": "user",
                    "content": f"""컨텍스트:
{context if context.strip() else "관련 정보가 없습니다."}

질문: {question}

답변:"""
                }
            ]

            # Call Groq API
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.post(
                    self.api_url,
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": self.model,
                        "messages": messages,
                        "temperature": 0.3,  # Low creativity (factual)
                        "max_tokens": 300,
                        "top_p": 0.9,
                    }
                )

                if response.status_code == 200:
                    result = response.json()
                    answer = result["choices"][0]["message"]["content"]
                    usage = result.get("usage", {})

                    return {
                        "success": True,
                        "answer": answer,
                        "source": "groq_api",
                        "model": self.model,
                        "generation_time_ms": result.get("usage", {}).get("total_time", 0),
                        "tokens_used": {
                            "prompt": usage.get("prompt_tokens", 0),
                            "completion": usage.get("completion_tokens", 0),
                            "total": usage.get("total_tokens", 0)
                        }
                    }
                else:
                    error_msg = response.text
                    print(f"Groq API error: {error_msg}")

                    return {
                        "success": False,
                        "answer": "외부 AI API 호출에 실패했습니다. 잠시 후 다시 시도해주세요.",
                        "error": f"Status {response.status_code}: {error_msg}",
                        "source": "groq_api_error"
                    }

        except httpx.TimeoutException:
            return {
                "success": False,
                "answer": "외부 AI API 요청 시간이 초과되었습니다.",
                "error": "Timeout",
                "source": "groq_api_timeout"
            }

        except Exception as e:
            print(f"External LLM error: {e}")
            return {
                "success": False,
                "answer": "외부 AI API 연결에 실패했습니다.",
                "error": str(e),
                "source": "groq_api_exception"
            }

    async def health_check(self) -> bool:
        """
        Check if Groq API is accessible

        Returns:
            True if healthy, False otherwise
        """
        if not self.enabled:
            return False

        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                # Simple test request
                response = await client.post(
                    self.api_url,
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": self.model,
                        "messages": [{"role": "user", "content": "test"}],
                        "max_tokens": 5
                    }
                )
                return response.status_code == 200

        except:
            return False


# Singleton instance
_external_llm_instance: Optional[ExternalLLM] = None


def get_external_llm() -> ExternalLLM:
    """
    Get or create ExternalLLM singleton

    Returns:
        ExternalLLM instance
    """
    global _external_llm_instance
    if _external_llm_instance is None:
        _external_llm_instance = ExternalLLM()
    return _external_llm_instance
