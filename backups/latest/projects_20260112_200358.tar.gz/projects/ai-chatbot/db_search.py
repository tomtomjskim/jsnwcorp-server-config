"""
PostgreSQL project information retrieval module
"""

import os
from typing import List, Dict, Optional
import psycopg2
from psycopg2.extras import RealDictCursor


class ProjectInfoRetriever:
    """
    Retrieves project information from PostgreSQL
    """

    def __init__(self):
        self.conn_params = {
            'host': os.getenv('POSTGRES_HOST', 'postgres'),
            'port': int(os.getenv('POSTGRES_PORT', '5432')),
            'database': os.getenv('POSTGRES_DB', 'maindb'),
            'user': os.getenv('POSTGRES_USER', 'appuser'),
            'password': os.getenv('POSTGRES_PASSWORD', ''),
        }
        self.conn: Optional[psycopg2.extensions.connection] = None
        self._connect()

    def _connect(self):
        """Establish database connection"""
        try:
            self.conn = psycopg2.connect(**self.conn_params)
            print("PostgreSQL connection established")
        except Exception as e:
            print(f"PostgreSQL connection error: {e}")
            self.conn = None

    def _ensure_connection(self):
        """Ensure connection is alive"""
        if self.conn is None or self.conn.closed:
            self._connect()

    def get_project_info(self, project_id: str = None) -> List[Dict]:
        """
        Get project information from database

        Args:
            project_id: Specific project ID, or None for all projects

        Returns:
            List of project dictionaries
        """
        self._ensure_connection()

        if self.conn is None:
            return []

        try:
            with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
                if project_id:
                    query = """
                        SELECT
                            id, name, display_name, emoji, description,
                            category, status, version, url, internal_url,
                            port, tags, developer, deployed_at,
                            health_status, avg_response_time_ms,
                            total_users, daily_active_users, total_requests
                        FROM public.projects
                        WHERE id = %s
                    """
                    cur.execute(query, (project_id,))
                else:
                    query = """
                        SELECT
                            id, display_name, emoji, description,
                            status, health_status, developer, tags
                        FROM public.projects
                        WHERE status = 'active'
                        ORDER BY display_name
                    """
                    cur.execute(query)

                results = cur.fetchall()
                return [dict(row) for row in results]

        except Exception as e:
            print(f"Database query error: {e}")
            return []

    def get_analytics_summary(self) -> Dict:
        """
        Get analytics summary

        Returns:
            Dictionary with summary statistics
        """
        self._ensure_connection()

        if self.conn is None:
            return {}

        try:
            with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
                query = """
                    SELECT
                        COUNT(DISTINCT id) as total_projects,
                        COUNT(DISTINCT id) FILTER (WHERE status = 'active') as active_projects,
                        COALESCE(SUM(total_users), 0) as total_users,
                        COALESCE(SUM(daily_active_users), 0) as dau,
                        COUNT(*) FILTER (WHERE health_status = 'healthy') as healthy_count,
                        COUNT(*) FILTER (WHERE health_status = 'unhealthy') as unhealthy_count
                    FROM public.projects
                """
                cur.execute(query)
                result = cur.fetchone()
                return dict(result) if result else {}

        except Exception as e:
            print(f"Analytics query error: {e}")
            return {}

    def search_projects_by_keyword(self, keyword: str) -> List[Dict]:
        """
        Search projects by keyword in name, description, or tags

        Args:
            keyword: Search keyword

        Returns:
            List of matching projects
        """
        self._ensure_connection()

        if self.conn is None:
            return []

        try:
            with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
                query = """
                    SELECT
                        id, display_name, description, category,
                        status, tags, developer
                    FROM public.projects
                    WHERE
                        LOWER(name) LIKE LOWER(%s) OR
                        LOWER(display_name) LIKE LOWER(%s) OR
                        LOWER(description) LIKE LOWER(%s) OR
                        EXISTS (
                            SELECT 1 FROM unnest(tags) AS tag
                            WHERE LOWER(tag) LIKE LOWER(%s)
                        )
                """
                search_pattern = f"%{keyword}%"
                cur.execute(query, (search_pattern, search_pattern, search_pattern, search_pattern))

                results = cur.fetchall()
                return [dict(row) for row in results]

        except Exception as e:
            print(f"Search query error: {e}")
            return []

    def close(self):
        """Close database connection"""
        if self.conn and not self.conn.closed:
            self.conn.close()
            print("PostgreSQL connection closed")


# Singleton instance
_db_instance: Optional[ProjectInfoRetriever] = None


def get_db() -> ProjectInfoRetriever:
    """
    Get or create database retriever singleton

    Returns:
        ProjectInfoRetriever instance
    """
    global _db_instance
    if _db_instance is None:
        _db_instance = ProjectInfoRetriever()
    return _db_instance
