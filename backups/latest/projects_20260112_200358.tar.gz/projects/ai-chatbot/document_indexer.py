"""
BM25-based document indexer for markdown files
Lightweight search without vector database
"""

import os
import re
from typing import List, Dict, Optional
import bm25s
import Stemmer
from functools import lru_cache


class DocumentIndexer:
    """
    Indexes and searches markdown documents using BM25 algorithm
    """

    def __init__(self, docs_path: str = "/app/docs"):
        self.docs_path = docs_path
        self.corpus: List[Dict] = []
        self.corpus_texts: List[str] = []
        self.retriever: Optional[bm25s.BM25] = None
        self.stemmer = Stemmer.Stemmer("english")

        # Initialize and index documents
        self._load_documents()
        self._create_index()

    def _load_documents(self):
        """Load all markdown documents from docs directory"""
        if not os.path.exists(self.docs_path):
            print(f"Warning: Docs path {self.docs_path} does not exist")
            return

        for filename in sorted(os.listdir(self.docs_path)):
            if filename.endswith('.md'):
                filepath = os.path.join(self.docs_path, filename)

                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()

                    # Split by headers
                    sections = self._split_by_headers(content, filename)
                    self.corpus.extend(sections)

                except Exception as e:
                    print(f"Error reading {filename}: {e}")

        print(f"Loaded {len(self.corpus)} document sections from {len(set(s['file'] for s in self.corpus))} files")

    def _split_by_headers(self, content: str, filename: str) -> List[Dict]:
        """
        Split markdown content by headers (##)

        Args:
            content: Markdown file content
            filename: Source filename

        Returns:
            List of section dictionaries
        """
        sections = []
        lines = content.split('\n')
        current_section = None

        for line in lines:
            # Match ## or ### headers
            if line.strip().startswith('##'):
                if current_section and current_section['content'].strip():
                    sections.append(current_section)

                # Extract title
                title = re.sub(r'^#+\s*', '', line).strip()
                # Remove emojis and special chars
                title_clean = re.sub(r'[^\w\s가-힣\-]', '', title)

                current_section = {
                    'file': filename,
                    'title': title,
                    'content': line + '\n',
                    'id': f"{filename}:{title_clean[:50]}"
                }
            elif current_section is not None:
                current_section['content'] += line + '\n'

        # Add last section
        if current_section and current_section['content'].strip():
            sections.append(current_section)

        # If no sections found, treat whole document as one section
        if not sections and content.strip():
            sections.append({
                'file': filename,
                'title': filename,
                'content': content,
                'id': filename
            })

        return sections

    def _create_index(self):
        """Create BM25 index from corpus"""
        if not self.corpus:
            print("Warning: No documents to index")
            return

        # Extract texts
        self.corpus_texts = [section['content'] for section in self.corpus]

        # Tokenize corpus
        corpus_tokens = bm25s.tokenize(
            self.corpus_texts,
            stemmer=self.stemmer,
            stopwords='english'
        )

        # Create BM25 index
        self.retriever = bm25s.BM25()
        self.retriever.index(corpus_tokens)

        print(f"BM25 index created with {len(self.corpus_texts)} documents")

    def search(self, query: str, top_k: int = 3, min_score: float = 0.0) -> List[Dict]:
        """
        Search documents using BM25

        Args:
            query: Search query
            top_k: Number of top results to return
            min_score: Minimum BM25 score threshold

        Returns:
            List of matching document sections with scores
        """
        if not self.retriever or not self.corpus:
            return []

        # Tokenize query
        query_tokens = bm25s.tokenize(
            query,
            stemmer=self.stemmer,
            stopwords='english'
        )

        # Retrieve top-k documents
        results_idx, scores = self.retriever.retrieve(
            query_tokens,
            k=top_k
        )

        # Build result list
        matches = []
        for idx, score in zip(results_idx[0], scores[0]):
            if score > min_score:
                section = self.corpus[idx].copy()
                section['score'] = float(score)
                # Truncate content for context window
                section['content'] = section['content'][:1000]
                matches.append(section)

        return matches

    @lru_cache(maxsize=100)
    def search_cached(self, query: str, top_k: int = 3) -> tuple:
        """
        Cached version of search for frequently asked questions
        Returns tuple for hashability
        """
        results = self.search(query, top_k)
        return tuple((r['file'], r['title'], r['content'], r['score']) for r in results)

    def get_document_count(self) -> int:
        """Get total number of indexed document sections"""
        return len(self.corpus)

    def get_file_list(self) -> List[str]:
        """Get list of all indexed filenames"""
        return sorted(set(section['file'] for section in self.corpus))


# Singleton instance
_indexer_instance: Optional[DocumentIndexer] = None


def get_indexer(docs_path: str = "/app/docs") -> DocumentIndexer:
    """
    Get or create document indexer singleton

    Args:
        docs_path: Path to documents directory

    Returns:
        DocumentIndexer instance
    """
    global _indexer_instance
    if _indexer_instance is None:
        _indexer_instance = DocumentIndexer(docs_path)
    return _indexer_instance
