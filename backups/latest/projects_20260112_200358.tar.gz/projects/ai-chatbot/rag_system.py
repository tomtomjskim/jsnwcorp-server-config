"""
Hybrid RAG (Retrieval-Augmented Generation) System
Combines rule-based responses, document search, and external AI
"""

import os
import time
from typing import Dict, Optional
from document_indexer import get_indexer
from db_search import get_db
from security import sanitize_response
from quick_responses import get_quick_response
from external_llm import get_external_llm


class RAGSystem:
    """
    Hybrid RAG system with 3-tier response strategy:
    1. Quick responses (rule-based, <100ms)
    2. Template responses (BM25 + templates, <500ms)
    3. External AI (Groq API, 1-3s)
    """

    def __init__(self, ollama_url: str = None):
        # Keep for backward compatibility, but won't be used
        self.ollama_url = ollama_url or os.getenv('OLLAMA_HOST', 'http://172.20.0.13:11434')
        self.model_name = "hybrid-system"  # Not used anymore

        # Initialize components
        self.indexer = get_indexer(os.getenv('DOCS_PATH', '/app/docs'))
        self.db = get_db()
        self.quick_response = get_quick_response()
        self.external_llm = get_external_llm()

        # Statistics
        self.stats = {
            "quick_responses": 0,
            "template_responses": 0,
            "external_api_calls": 0,
            "fallback_responses": 0
        }

    def _extract_project_keywords(self, question: str) -> list:
        """Extract potential project names from question"""
        question_lower = question.lower()
        projects = []

        project_map = {
            'lotto': 'lotto-master',
            'lottomaster': 'lotto-master',
            '로또': 'lotto-master',
            '운세': 'today-fortune',
            'fortune': 'today-fortune',
            'dashboard': 'dashboard',
            '대시보드': 'dashboard',
        }

        for keyword, project_id in project_map.items():
            if keyword in question_lower:
                projects.append(project_id)

        return list(set(projects))

    def _build_context(self, question: str) -> str:
        """Build context from documents and database"""
        context_parts = []

        # 1. Search documents with BM25
        doc_results = self.indexer.search(question, top_k=5, min_score=0.0)
        if doc_results:
            context_parts.append("## 관련 문서:")
            for result in doc_results:
                context_parts.append(f"\n[{result['file']} - {result['title']}]")
                context_parts.append(result['content'][:800])

        # 2. Search PostgreSQL for project info
        project_ids = self._extract_project_keywords(question)
        for project_id in project_ids:
            projects = self.db.get_project_info(project_id)
            if projects:
                context_parts.append(f"\n## {project_id} 프로젝트 정보:")
                for proj in projects:
                    context_parts.append(f"- 이름: {proj.get('display_name', 'N/A')}")
                    context_parts.append(f"- 설명: {proj.get('description', 'N/A')}")
                    context_parts.append(f"- 상태: {proj.get('status', 'N/A')}")
                    context_parts.append(f"- 카테고리: {proj.get('category', 'N/A')}")

                    tags = proj.get('tags')
                    if tags:
                        context_parts.append(f"- 기술 스택: {', '.join(tags)}")

                    context_parts.append(f"- 개발자: {proj.get('developer', 'N/A')}")

                    health = proj.get('health_status')
                    if health:
                        context_parts.append(f"- 헬스 상태: {health}")

        # 3. If asking about all projects
        if any(word in question for word in ['프로젝트', 'project', '운영', '서비스']):
            if not project_ids:
                summary = self.db.get_analytics_summary()
                if summary:
                    context_parts.append("\n## 전체 프로젝트 요약:")
                    context_parts.append(f"- 총 프로젝트: {summary.get('total_projects', 0)}개")
                    context_parts.append(f"- 활성 프로젝트: {summary.get('active_projects', 0)}개")
                    context_parts.append(f"- 정상 상태: {summary.get('healthy_count', 0)}개")

                all_projects = self.db.get_project_info()
                if all_projects:
                    context_parts.append("\n활성 프로젝트 목록:")
                    for proj in all_projects:
                        context_parts.append(
                            f"- {proj.get('display_name')} ({proj.get('id')}): {proj.get('description', '')[:100]}"
                        )

        return "\n".join(context_parts)

    async def ask(self, question: str, timeout: int = 30) -> Dict:
        """
        Ask a question using hybrid strategy

        Strategy:
        1. Try quick response (rule-based) - <100ms
        2. If no match, build context and try external AI - 1-3s
        3. If external AI fails, return context-based fallback

        Args:
            question: User's question
            timeout: Not used (kept for compatibility)

        Returns:
            Dictionary with answer and metadata
        """
        start_time = time.time()

        # Strategy 1: Quick Response (Rule-based)
        quick_result = self.quick_response.match(question)
        if quick_result:
            self.stats["quick_responses"] += 1
            quick_result["generation_time_ms"] = int((time.time() - start_time) * 1000)
            return quick_result

        # Build context for remaining strategies
        context = self._build_context(question)

        # Strategy 2: External AI (Groq)
        if self.external_llm.is_enabled():
            external_result = await self.external_llm.generate(question, context)

            if external_result["success"]:
                self.stats["external_api_calls"] += 1
                # Sanitize response
                external_result["answer"] = sanitize_response(external_result["answer"])
                external_result["has_context"] = bool(context.strip())
                external_result["generation_time_ms"] = int((time.time() - start_time) * 1000)
                return external_result

        # Strategy 3: Fallback (Context only)
        self.stats["fallback_responses"] += 1

        if context.strip():
            fallback_answer = f"관련 정보를 찾았습니다:\n\n{context[:500]}..."
        else:
            fallback_answer = "죄송합니다. 해당 질문에 대한 정보를 찾을 수 없습니다.\n\n다른 질문을 시도해보시거나, 프로젝트 관련 질문을 해주세요."

        return {
            "success": True,
            "answer": fallback_answer,
            "has_context": bool(context.strip()),
            "source": "fallback",
            "model": "context_only",
            "generation_time_ms": int((time.time() - start_time) * 1000),
        }

    async def health_check(self) -> bool:
        """
        Check if system is healthy

        Returns:
            True if at least one response method works
        """
        # Quick response always works (no external dependency)
        # Check if external LLM is available
        if self.external_llm.is_enabled():
            return await self.external_llm.health_check()

        # If external LLM not enabled, system still works with quick responses
        return True

    def get_stats(self) -> Dict:
        """
        Get system statistics

        Returns:
            Statistics dictionary
        """
        total = sum(self.stats.values())
        if total == 0:
            return self.stats

        return {
            **self.stats,
            "total_requests": total,
            "quick_response_rate": f"{self.stats['quick_responses'] / total * 100:.1f}%",
            "external_api_rate": f"{self.stats['external_api_calls'] / total * 100:.1f}%",
            "fallback_rate": f"{self.stats['fallback_responses'] / total * 100:.1f}%"
        }


# Singleton instance
_rag_instance: Optional[RAGSystem] = None


def get_rag() -> RAGSystem:
    """
    Get or create RAG system singleton

    Returns:
        RAGSystem instance
    """
    global _rag_instance
    if _rag_instance is None:
        _rag_instance = RAGSystem()
    return _rag_instance
